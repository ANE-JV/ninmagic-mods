"""Build an offline seed of public GitHub mod indexes, never mod payloads."""
from pathlib import Path
import argparse
import concurrent.futures
import hashlib
import json
import re
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
SOURCES = [
    ("ADEMOLA200/Switch-Emulator-Mod-Database", "develop", "ademola.json"),
    ("medinacristofer034-art/SwitchOptimizerMods", "main", "optimizer.json"),
    ("yuzu-mirror/yuzu-mod-archive", "main", "yuzu.json"),
    ("StevensND/switch-port-mods", "main", "stevens.json"),
    ("masagrator/NXGraphicsPatches", "master", "masagrator.json"),
    ("cucholix/NX-IPS-romfs-compilation", "main", "cucholix.json"),
    ("StevensND/ue4-emuswitch-60fps", "main", "ue4.json"),
    ("Kenji-NX/switch-pchtxt-mods", "main", "kenji.json"),
    ("theboy181/switch-ptchtxt-mods", "main", "theboy.json"),
    ("h2y/BOTW-Chinese-Linkle", "master", "linkle.json"),
]

def check(data):
    if len(data) > 8 * 1024 * 1024:
        raise ValueError("Index exceeds bound")
    tree = json.loads(data)
    if tree.get("truncated") is not False or not re.fullmatch(r"[a-f0-9]{40}", tree.get("sha", "")):
        raise ValueError("Incomplete or invalid GitHub tree")
    seen = set()
    for entry in tree["tree"]:
        path = entry["path"]
        if path.startswith("/") or "\\" in path or any(p in ("", ".", "..") for p in path.split("/")) or path in seen:
            raise ValueError("Unsafe or duplicate index path")
        seen.add(path)
        if entry["type"] == "blob" and (not re.fullmatch(r"[a-f0-9]{40}", entry["sha"]) or entry.get("size", -1) < 0):
            raise ValueError("Missing blob identity")
    return tree

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reuse-research", action="store_true")
    args = parser.parse_args()
    folder = ROOT / "dist/mods-seed/config/NinMagicMods"
    slot = folder / "mods-a"
    slot.mkdir(parents=True, exist_ok=True)
    def source(item):
        repo, branch, name = item
        url = f"https://api.github.com/repos/{repo}/git/trees/{branch}?recursive=1"
        research = ROOT / "dist/research" / (repo.replace("/", "-") + ".json")
        if args.reuse_research and research.is_file():
            data = research.read_bytes()
        else:
            request = urllib.request.Request(url, headers={"User-Agent": "NinMagic-Mods", "Accept": "application/vnd.github+json"})
            with urllib.request.urlopen(request, timeout=40) as response:
                data = response.read(8 * 1024 * 1024 + 1)
        tree = check(data)
        (slot / name).write_bytes(data)
        return {"repository": repo, "branch": branch, "file": name, "url": url,
                "tree_sha": tree["sha"], "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                "blobs": sum(e["type"] == "blob" for e in tree["tree"])}
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        reports = list(pool.map(source, SOURCES))
    stamp = str(int(time.time()))
    (slot / "complete.txt").write_text("NMMODS1\n" + stamp + "\n", encoding="ascii", newline="\n")
    (folder / "mods-active.txt").write_text("a\n", encoding="ascii", newline="\n")
    (folder / "mods-check.txt").write_text(stamp + "\n", encoding="ascii", newline="\n")
    report = {"indexes_only": True, "mod_payloads_included": False, "sources": reports, "checked_at": int(stamp)}
    (ROOT / "dist/mods-seed/verification.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"sources": len(reports), "index_bytes": sum(r["bytes"] for r in reports), "seed": str(folder)}))

if __name__ == "__main__":
    main()
