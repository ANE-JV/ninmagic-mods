#define _POSIX_C_SOURCE 200809L
#include "mod_queue.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <cstdlib>
#include <chrono>
namespace fs=std::filesystem;
using namespace nmm;
int checks=0;void need(bool b,const char*s){++checks;if(!b){std::cerr<<"FAIL "<<s<<"\n";std::exit(1);}}
Game game(){Game g;g.id=0x010015100B514000ULL;g.name="Super Mario Bros. Wonder";g.version="1.2.1";g.versionKnown=g.buildVerified=g.running=true;g.contentVersion=196608;g.fullBuildId="FF773E90972D544E"+std::string(48,'0');g.buildId=g.fullBuildId.substr(0,16);return g;}
ModEntry mod(const Game&g){ModEntry m;m.titleId=g.id;m.id="author/repo|game/fps.pchtxt";m.name="60 FPS";m.category="60 FPS";m.source=m.repository="author/repo";m.sourceUrl="https://github.com/author/repo";m.buildId=g.fullBuildId;m.version=g.version;m.compatible=true;m.format=ModFormat::Pchtxt;return m;}
void env(const std::string&s){
#ifdef _WIN32
_putenv_s("NMM_QUEUE_ROOT",s.c_str());
#else
setenv("NMM_QUEUE_ROOT",s.c_str(),1);
#endif
}
int main(){const auto parent=fs::temp_directory_path();const auto sandbox=parent/("nmm-queue-"+std::to_string(std::chrono::high_resolution_clock::now().time_since_epoch().count()));fs::create_directories(sandbox);env((sandbox/"config"/"NinMagicMods").generic_string());Game g=game();auto m=mod(g);std::string e;std::vector<std::string>ids;std::vector<ModEntry>out;
 need(saveModSelection(g,{m},e),"save exact running game");need(loadModSelection(g,ids,e)&&ids==std::vector<std::string>{m.id},"roundtrip ids only");
 need(saveModMenuCache(g,{m},e),"cache save");need(loadModMenuCache(g,out,e)&&out.size()==1&&out[0].compatible&&!out[0].selected&&out[0].files.empty(),"menu strips payload selection");
 auto bad=g;bad.fullBuildId[63]='1';need(!loadModSelection(bad,ids,e)&&ids.empty(),"stale full build blocked");bad=g;bad.buildId="0000000000000000";need(!saveModSelection(bad,{m},e),"short/full build mismatch blocked");bad=g;bad.version="1.2.2";need(!loadModSelection(bad,ids,e),"stale display version blocked");bad=g;++bad.contentVersion;need(!loadModSelection(bad,ids,e),"stale content version blocked");bad=g;bad.buildVerified=false;need(!loadModSelection(bad,ids,e),"unverified identity blocked");bad=g;bad.versionKnown=false;need(!saveModSelection(bad,{m},e),"unknown version cannot queue");bad=g;bad.id=0;need(!saveModSelection(bad,{m},e),"unknown title blocked");
 auto blocked=m;blocked.compatible=false;need(!saveModSelection(g,{blocked},e),"blocked entry rejected");blocked=m;++blocked.titleId;need(!saveModSelection(g,{blocked},e),"foreign title rejected");blocked=m;blocked.buildId[0]='1';need(!saveModSelection(g,{blocked},e),"entry build differs rejected");blocked=m;blocked.version="1.0.0";need(!saveModSelection(g,{blocked},e),"entry version differs rejected");need(!saveModSelection(g,{},e),"empty selection rejected");need(!saveModSelection(g,{m,m},e),"duplicate ids rejected");std::vector<ModEntry>many;for(int i=0;i<33;++i){auto v=m;v.id+=std::to_string(i);many.push_back(v);}need(!saveModSelection(g,many,e),"32 id limit");many.resize(32);need(saveModSelection(g,many,e)&&loadModSelection(g,ids,e)&&ids.size()==32,"32 unique allowed");
 auto rom=m;rom.format=ModFormat::Romfs;rom.buildId.clear();rom.consoleOnly=true;need(saveModSelection(g,{rom},e),"exact physical romfs metadata allowed");rom.consoleOnly=false;need(!saveModSelection(g,{rom},e),"emulator-only romfs rejected");
 auto informational=m;informational.compatible=false;informational.id="GameBanana|556710";informational.gbModId=556710;informational.gbGameId=18604;informational.author="diegoforfun";informational.modVersion="1.0";informational.reason="Versión de juego sin comprobar";need(saveModMenuCache(g,{informational},e)&&loadModMenuCache(g,out,e)&&!out[0].compatible&&out[0].gbModId==556710,"blocked GB remains blocked");
 const auto dir=sandbox/"config"/"NinMagicMods"/"overlay"/titleId(g.id);const auto path=dir/"selection.bin";{std::fstream f(path,std::ios::in|std::ios::out|std::ios::binary);f.seekp(9);f.put('x');}need(!loadModSelection(g,ids,e)&&ids.empty(),"modified digest rejected");need(clearModSelection(g,e),"clear corrupt exact regular queue");need(!loadModSelection(g,ids,e),"cleared queue missing");
 need(saveModSelection(g,{m},e),"resave");{std::ofstream f(dir/"selection.bin.previous");f<<"foreign preserved";}need(!saveModSelection(g,{m},e),"pending previous blocks overwrite");need(fs::file_size(dir/"selection.bin.previous")==17,"foreign previous preserved");fs::remove(dir/"selection.bin.previous");
 fs::remove(path);const auto foreign=sandbox/"untouched";{std::ofstream f(foreign);f<<"foreign";}std::error_code ec;fs::create_symlink(foreign,path,ec);if(!ec){need(!saveModSelection(g,{m},e),"queue symlink rejected");need(!clearModSelection(g,e),"queue symlink not removed");need(fs::file_size(foreign)==7,"symlink target untouched");fs::remove(path);}else std::cout<<"symlink fixture unavailable: "<<ec.message()<<"\n";
 many.assign(129,m);need(!saveModMenuCache(g,many,e),"128 menu limit");auto text=m;text.reason=std::string(2049,'x');need(!saveModMenuCache(g,{text},e),"bounded menu text");
 for(const auto&entry:fs::recursive_directory_iterator(sandbox)){const auto rel=entry.path().lexically_relative(sandbox).generic_string();need(rel=="untouched"||rel.rfind("config",0)==0,"writes confined private config");}
 const auto resolved=fs::weakly_canonical(sandbox);need(resolved.parent_path()==fs::weakly_canonical(parent)&&resolved.filename().string().rfind("nmm-queue-",0)==0,"cleanup sandbox resolved");fs::remove_all(resolved);std::cout<<checks<<" queue checks passed\n";return 0;}
