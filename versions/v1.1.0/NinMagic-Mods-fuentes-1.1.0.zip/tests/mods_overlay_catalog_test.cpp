#define NC_MODS_TEST
#include "../source/mods.cpp"
#include <chrono>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <new>
#include <sstream>
#include <stdexcept>
namespace {size_t liveBytes=0,peakBytes=0;struct alignas(std::max_align_t) Allocation {size_t size;};}
[[gnu::noinline]] void *operator new(size_t size){auto*p=static_cast<Allocation*>(std::malloc(sizeof(Allocation)+size));if(!p)throw std::bad_alloc();p->size=size;liveBytes+=size;peakBytes=std::max(peakBytes,liveBytes);return p+1;}
[[gnu::noinline]] void *operator new[](size_t size){return ::operator new(size);}
[[gnu::noinline]] void operator delete(void *p)noexcept{if(p){auto*h=static_cast<Allocation*>(p)-1;liveBytes-=h->size;std::free(h);}}
[[gnu::noinline]] void operator delete[](void *p)noexcept{::operator delete(p);}
[[gnu::noinline]] void operator delete(void *p,size_t)noexcept{::operator delete(p);}
[[gnu::noinline]] void operator delete[](void *p,size_t)noexcept{::operator delete(p);}
namespace nmm {unsigned overlayQueries=0;bool downloadModHttps(const std::string&,const std::string&,uint64_t maximum,std::string&error){++overlayQueries;if(maximum>3*1024*1024)throw std::runtime_error("tree bound");error="HTTPS offline fixture";return false;}}
namespace fs=std::filesystem;
namespace {unsigned checks=0;void check(bool ok,const char*line){++checks;if(!ok)throw std::runtime_error(line);}
#define CHECK(x) check((x),#x)
void put(const fs::path&p,const std::string&s){fs::create_directories(p.parent_path());std::ofstream f(p,std::ios::binary);f<<s;CHECK(bool(f));}
}
int main(int argc,char**argv){fs::path sandbox;try{
    CHECK(argc==2);sandbox=fs::temp_directory_path()/("nmm-overlay-catalog-test-"+std::to_string(getpid())+"-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));fs::create_directories(sandbox);fs::copy(fs::path(argv[1]),sandbox,fs::copy_options::recursive|fs::copy_options::overwrite_existing);setenv("NC_MODS_ROOT",sandbox.generic_string().c_str(),1);
    nmm::Game game;game.id=0x010093801237C000ULL;game.name="Metroid Dread";std::vector<nmm::ModEntry> entries;std::string error;const auto baseline=liveBytes;peakBytes=liveBytes;
    CHECK(nmm::loadOverlayMods(game,entries,error)&&entries.size()==25);const auto peak=peakBytes-baseline;CHECK(peak<12*1024*1024);for(const auto&e:entries)CHECK(!e.compatible&&!e.selected&&(e.titleId==game.id||!e.titleId));
    const auto original=entries.size();CHECK(nmm::loadOverlayMods(game,entries,error,true)&&entries.size()==original);CHECK(nmm::overlayQueries>=10);for(const auto&e:entries)CHECK(!e.compatible&&!e.selected&&(e.titleId==game.id||!e.titleId));
    game.id=0x010015100B514000ULL;game.name="Super Mario Bros. Wonder";CHECK(nmm::loadOverlayMods(game,entries,error));CHECK(!entries.empty()&&entries.size()<=128);for(const auto&e:entries)CHECK(!e.compatible&&!e.selected&&(e.titleId==game.id||!e.titleId));
    const auto catalogPeak=peakBytes-baseline;CHECK(catalogPeak<1024*1024);
    const auto badFile=sandbox/"bad.json";nmm::ModsCatalog parsed;
    const std::string valid="{\"sha\":\""+std::string(40,'a')+"\",\"truncated\":false,\"tree\":[{\"path\":\"Super Mario Bros. Wonder/010015100B514000/Test/1.2.1.pchtxt\",\"type\":\"blob\",\"sha\":\""+std::string(40,'b')+"\",\"size\":12}]}";
    put(badFile,valid);CHECK(nmm::filteredFile(badFile.generic_string(),game,"StevensND/switch-port-mods",parsed,error)&&parsed.entries.size()==1);
    for(auto bad:{valid+"garbage",valid.substr(0,valid.size()-1),std::string("{\"sha\":\"")+std::string(40,'a')+"\",\"truncated\":true,\"tree\":[]}",std::string("{\"sha\":\"")+std::string(40,'a')+"\",\"sha\":\""+std::string(40,'b')+"\",\"truncated\":false,\"tree\":[]}"}){put(badFile,bad);CHECK(!nmm::filteredFile(badFile.generic_string(),game,"StevensND/switch-port-mods",parsed,error));}
    auto bad=valid;bad.replace(bad.find("\"size\":12"),9,"\"size\":01");put(badFile,bad);CHECK(!nmm::filteredFile(badFile.generic_string(),game,"StevensND/switch-port-mods",parsed,error));
    bad=valid;bad.replace(bad.find("Super Mario Bros. Wonder/"),24,"../");put(badFile,bad);CHECK(!nmm::filteredFile(badFile.generic_string(),game,"StevensND/switch-port-mods",parsed,error));
    game.version="1.0.0";game.versionKnown=game.buildVerified=true;game.fullBuildId="112233445566778899AABBCCDDEEFF00"+std::string(32,'0');game.buildId=game.fullBuildId.substr(0,16);
    std::ostringstream patch;patch<<"@nsobid-"<<game.fullBuildId<<"\n# Demo [010015100B514000]\n@flag offset_shift 0x100\n@enabled\n";for(unsigned n=0;n<32;++n)patch<<std::hex<<std::setw(8)<<std::setfill('0')<<(0x1000+n*256)<<' '<<std::string(512,'0')<<'\n';patch<<"@stop\n";const auto bytes=patch.str();nmm::ModEntry candidate;candidate.titleId=game.id;candidate.path="Super Mario Bros. Wonder/[010015100B514000]/Test/1.0.0.pchtxt";candidate.repository="StevensND/switch-port-mods";candidate.branch="main";candidate.version="1.0.0";candidate.size=bytes.size();candidate.blobSha=nmm::gitBlobSha(bytes);candidate.format=nmm::ModFormat::Pchtxt;
    put(sandbox/"mod-files"/(candidate.blobSha+".bin"),bytes);nmm::ModPayload payload;const auto patchBaseline=liveBytes;peakBytes=liveBytes;CHECK(nmm::prepareMod(game,candidate,payload,error)&&payload.compatible);const auto patchPeak=peakBytes-patchBaseline;CHECK(patchPeak<1024*1024);CHECK(!payload.ips.empty()&&payload.ips.size()<20*1024);
    const auto absolute=fs::weakly_canonical(sandbox);CHECK(absolute.parent_path()==fs::weakly_canonical(fs::temp_directory_path())&&absolute.filename().string().rfind("nmm-overlay-catalog-test-",0)==0);fs::remove_all(absolute);
    std::cout<<"overlay catalog: "<<checks<<" source, identity and bound checks PASS; Dread peak="<<peak<<" bytes; all games peak="<<catalogPeak<<" bytes; 8KiB static patch peak="<<patchPeak<<" bytes\n";return 0;
}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<" sandbox "<<sandbox<<'\n';return 1;}}
