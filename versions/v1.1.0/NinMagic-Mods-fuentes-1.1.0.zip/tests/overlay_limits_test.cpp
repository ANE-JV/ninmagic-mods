#include "mods.hpp"
#include <iostream>
#include <cstdlib>
#include <cstdio>
using namespace nmm;int checks=0;void need(bool b,const char*s){++checks;if(!b){std::cerr<<"FAIL "<<s<<"\n";std::exit(1);}}
std::vector<uint8_t>rle(unsigned n){return {'P','A','T','C','H',0,1,0,0,0,uint8_t(n>>8),uint8_t(n),0x22,'E','O','F'};}
std::string pchtxt(const Game&g,unsigned count){std::string p="@nsobid-"+g.fullBuildId+"\n@enabled\n";for(unsigned at=0;at<count;){char address[16];snprintf(address,sizeof(address),"%08X ",0x100+at);p+=address;unsigned n=std::min(4096u,count-at);for(unsigned i=0;i<n;++i)p+="22";p+='\n';at+=n;}return p+"@stop\n";}
int main(){std::string e;need(validateModIps(rle(8192),e),"8KiB IPS expansion accepted");need(!validateModIps(rle(8193),e),"IPS RLE expansion above8KiB blocked");Game g;g.id=0x010015100B514000ULL;g.buildId="FF773E90972D544E";g.fullBuildId=g.buildId+std::string(48,'0');g.buildVerified=g.versionKnown=true;g.version="1.2.1";ModEntry m;m.titleId=g.id;m.buildId=g.fullBuildId;m.format=ModFormat::Pchtxt;ModPayload p;need(parseModPayload(g,m,pchtxt(g,8192),p,e),"8KiB PCHTXT accepted");need(!parseModPayload(g,m,pchtxt(g,8193),p,e),"PCHTXT expansion above8KiB blocked");m.format=ModFormat::Ips;auto large=rle(65535);need(!parseModPayload(g,m,std::string(large.begin(),large.end()),p,e),"tiny compressed IPS cannot inflate heap");std::cout<<checks<<" overlay static parser limit checks passed\n";}
