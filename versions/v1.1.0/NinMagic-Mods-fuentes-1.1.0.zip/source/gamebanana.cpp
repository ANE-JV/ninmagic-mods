#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "gamebanana.hpp"
#include "update_network.hpp"
#include <algorithm>
#include <array>
#include <cerrno>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <map>
#include <set>
#include <sys/stat.h>
#include <unistd.h>

namespace nmm {
namespace gb {
#ifdef NMM_OVERLAY
constexpr size_t MaxJson=128*1024,MaxNodes=3000;
#else
constexpr size_t MaxJson=512*1024,MaxNodes=12000;
#endif
constexpr size_t PerPage=15,MaxPages=6,MaxEntries=128;
struct Json {char kind=0;std::string text;std::map<std::string,Json> object;std::vector<Json> array;};
class Parser {
    const std::string &s;size_t p=0,nodes=0;
    void ws(){while(p<s.size()&&(s[p]==' '||s[p]=='\n'||s[p]=='\r'||s[p]=='\t'))++p;}
    bool chr(char c){ws();if(p==s.size()||s[p]!=c)return false;++p;return true;}
    bool code(uint32_t &v){v=0;for(unsigned i=0;i<4;++i){if(p==s.size())return false;unsigned char c=s[p++];if(!std::isxdigit(c))return false;v=(v<<4)|(c<='9'?c-'0':std::tolower(c)-'a'+10);}return true;}
    static void utf(std::string &v,uint32_t c){if(c<128)v+=char(c);else if(c<2048){v+=char(0xc0|(c>>6));v+=char(0x80|(c&63));}else if(c<65536){v+=char(0xe0|(c>>12));v+=char(0x80|((c>>6)&63));v+=char(0x80|(c&63));}else{v+=char(0xf0|(c>>18));v+=char(0x80|((c>>12)&63));v+=char(0x80|((c>>6)&63));v+=char(0x80|(c&63));}}
    bool string(std::string &v){v.clear();if(!chr('"'))return false;while(p<s.size()){unsigned char c=s[p++];if(c=='"')return true;if(c<32)return false;if(c!='\\')v+=char(c);else{if(p==s.size())return false;char e=s[p++];if(e=='"'||e=='/'||e=='\\')v+=e;else if(e=='b')v+='\b';else if(e=='f')v+='\f';else if(e=='n')v+='\n';else if(e=='r')v+='\r';else if(e=='t')v+='\t';else if(e=='u'){uint32_t a=0;if(!code(a))return false;if(a>=0xd800&&a<=0xdbff){if(s.compare(p,2,"\\u"))return false;p+=2;uint32_t b=0;if(!code(b)||b<0xdc00||b>0xdfff)return false;a=0x10000+((a-0xd800)<<10)+(b-0xdc00);}else if(a>=0xdc00&&a<=0xdfff)return false;utf(v,a);}else return false;}if(v.size()>32768)return false;}return false;}
    bool value(Json &v,unsigned depth){if(depth>24||++nodes>MaxNodes)return false;ws();if(p==s.size())return false;const char c=s[p];v.kind=c;if(c=='"')return string(v.text);
        if(c=='{'){++p;if(chr('}'))return true;do{std::string key;if(!string(key)||key.size()>256||!chr(':')||v.object.count(key))return false;Json item;if(!value(item,depth+1))return false;v.object.emplace(std::move(key),std::move(item));if(chr('}'))return true;}while(chr(','));return false;}
        if(c=='['){++p;if(chr(']'))return true;do{if(v.array.size()>=1024)return false;Json item;if(!value(item,depth+1))return false;v.array.push_back(std::move(item));if(chr(']'))return true;}while(chr(','));return false;}
        for(const char *literal:{"true","false","null"}){const size_t n=std::char_traits<char>::length(literal);if(s.compare(p,n,literal)==0){v.text=literal;p+=n;return true;}}
        v.kind='n';const size_t begin=p;if(s[p]=='-')++p;if(p==s.size()||s[p]<'0'||s[p]>'9')return false;if(s[p]=='0')++p;else while(p<s.size()&&s[p]>='0'&&s[p]<='9')++p;
        if(p<s.size()&&s[p]=='.'){++p;const auto start=p;while(p<s.size()&&s[p]>='0'&&s[p]<='9')++p;if(p==start)return false;}
        if(p<s.size()&&(s[p]=='e'||s[p]=='E')){++p;if(p<s.size()&&(s[p]=='+'||s[p]=='-'))++p;const auto start=p;while(p<s.size()&&s[p]>='0'&&s[p]<='9')++p;if(p==start)return false;}
        v.text=s.substr(begin,p-begin);return v.text.size()<=40;
    }
public:explicit Parser(const std::string &input):s(input){}bool parse(Json &v){if(s.empty()||s.size()>MaxJson||!value(v,0))return false;ws();return p==s.size()&&v.kind=='{';}
};
const Json &field(const Json &v,const char *key){static const Json none;auto i=v.object.find(key);return i==v.object.end()?none:i->second;}
std::string text(const Json &v,const char *key,size_t maximum=256){const auto &x=field(v,key);return x.kind=='"'&&x.text.size()<=maximum?x.text:std::string{};}
uint64_t number(const Json &v,const char *key){const auto &x=field(v,key);if(x.kind!='n'||x.text.empty()||x.text.size()>12||x.text.find_first_not_of("0123456789")!=std::string::npos)return 0;uint64_t n=0;for(char c:x.text)n=n*10+unsigned(c-'0');return n;}
bool yes(const Json &v,const char *key){return field(v,key).text=="true";}
std::string normalized(std::string s){const std::string suffix=" (Switch)";if(s.size()>suffix.size()&&s.compare(s.size()-suffix.size(),suffix.size(),suffix)==0)s.resize(s.size()-suffix.size());std::string out;for(unsigned char c:s){if(c>=128)out+=char(c);else if(std::isalnum(c))out+=char(std::tolower(c));}return out;}
struct Mapping {uint64_t title,id;const char *name;};
// Reviewed Switch-exclusive identities, not guessed from a similar title.
const Mapping Known[]={
 {0x010015100B514000ULL,18604,"Super Mario Bros. Wonder"},
 {0x010093801237C000ULL,14275,"Metroid Dread"},
 {0x0100F2C0115B6000ULL,7617,"The Legend of Zelda: Tears of the Kingdom"}
};
const Mapping *known(uint64_t title){for(const auto &v:Known)if(v.title==title)return &v;return nullptr;}
bool validGame(const Game &game,uint64_t id,const std::string &name){if(game.id<0x0100000000010000ULL||!id||id>999999999)return false;if(const auto *k=known(game.id))return k->id==id&&normalized(k->name)==normalized(name);const auto expected=normalized(game.name),actual=normalized(name);return !expected.empty()&&!actual.empty()&&name.size()>9&&name.compare(name.size()-9,9," (Switch)")==0&&actual==expected;}
std::string clean(const std::string &input,size_t maximum){std::string out;bool tag=false,space=false;for(unsigned char c:input){if(c=='<'){tag=true;space=true;continue;}if(c=='>'){tag=false;continue;}if(tag)continue;if(c<=32||c==127){space=true;continue;}if(space&&!out.empty())out+=' ';space=false;out+=char(c);if(out.size()>=maximum)break;}return out;}
std::string category(const Json &v){std::string s=normalized(text(field(v,"_aRootCategory"),"_sName")+" "+text(field(v,"_aSubCategory"),"_sName")+" "+text(v,"_sName"));if(s.find("character")!=s.npos||s.find("skin")!=s.npos||s.find("model")!=s.npos)return "Personajes";if(s.find("costume")!=s.npos||s.find("outfit")!=s.npos||s.find("cloth")!=s.npos)return "Ropa";if(s.find("fps")!=s.npos||s.find("framerate")!=s.npos)return "FPS";return "Gráficos";}
bool record(const Game &game,uint64_t gameId,uint64_t expected,const Json &v,ModEntry &out,std::string &error){
    const auto &remote=field(v,"_aGame");const auto id=expected?expected:number(v,"_idRow");const auto name=text(v,"_sName");
    const auto profile="https://gamebanana.com/mods/"+std::to_string(id);
    if(!id||id>999999999||(expected&&number(v,"_idRow")&&number(v,"_idRow")!=expected)||name.empty()||number(remote,"_idRow")!=gameId||!validGame(game,gameId,text(remote,"_sName"))||text(v,"_sProfileUrl")!=profile){error="GameBanana devolvió un mod de otro juego o una identidad sin verificar.";return false;}
    if(yes(v,"_bIsTrashed")||yes(v,"_bIsObsolete")){error="El autor ha retirado o marcado obsoleto este mod.";return false;}
    const auto model=text(v,"_sModelName");if(!model.empty()&&model!="Mod"){error="GameBanana devolvió un tipo de publicación distinto de Mod.";return false;}
    out={};out.titleId=game.id;out.gbGameId=gameId;out.gbModId=id;out.id="GameBanana|"+std::to_string(id);out.name=clean(name,192);out.source=out.repository="GameBanana";out.sourceUrl=profile;out.category=category(v);out.author=clean(text(field(v,"_aSubmitter"),"_sName"),128);out.modVersion=clean(text(v,"_sVersion",64),64);
    out.format=ModFormat::Unsupported;out.reason="Compatibilidad sin verificar: el autor no declara una versión del juego ni un Build ID comprobable. Instalación bloqueada.";
    out.detail="GameBanana · "+out.author+(out.modVersion.empty()?"":" · versión del mod "+out.modVersion)+". "+clean(text(v,"_sText",32768),900);
    const auto &files=field(v,"_aFiles");if(files.kind=='['){if(files.array.size()>32){error="La ficha supera el límite de archivos de GameBanana.";return false;}for(const auto &f:files.array){const auto fileId=number(f,"_idRow"),size=number(f,"_nFilesize");const auto filename=text(f,"_sFile");const auto url=text(f,"_sDownloadUrl",2048);if(!fileId||fileId>999999999||!size||size>512ULL*1024*1024||filename.empty()||filename.find_first_of("/\\")!=filename.npos||url!="https://gamebanana.com/dl/"+std::to_string(fileId))continue;out.fileName=filename;out.size=size;out.downloadUrl=url;out.format=ModFormat::Archive;break;}}
    if(!out.fileName.empty())out.detail+=" Archivo: "+out.fileName+" ("+std::to_string(out.size)+" bytes).";
    out.detail+=" La versión del mod no es la versión del juego. "+profile;return true;
}
bool parse(const std::string &data,Json &j,std::string &error){if(!Parser(data).parse(j)){error="Respuesta JSON de GameBanana inválida o demasiado grande.";return false;}return true;}
std::string root(){
#ifdef NM_GAMEBANANA_TEST
 const char *s=std::getenv("NM_GAMEBANANA_ROOT");return s?s:"gamebanana-test";
#else
 return "sdmc:/config/NinMagicMods/gamebanana";
#endif
}
bool directory(const std::string &path,bool make,std::string &error){struct stat st{};if(lstat(path.c_str(),&st)!=0){if(errno!=ENOENT||!make){error="No se puede leer la caché privada de GameBanana.";return false;}
#ifdef _WIN32
 if(mkdir(path.c_str())!=0){error="No se pudo crear la caché privada de GameBanana.";return false;}
#else
 if(mkdir(path.c_str(),0777)!=0){error="No se pudo crear la caché privada de GameBanana.";return false;}
#endif
 if(lstat(path.c_str(),&st)!=0)return false;}if(!S_ISDIR(st.st_mode)||S_ISLNK(st.st_mode)){error="La caché de GameBanana no es un directorio normal.";return false;}return true;}
bool regular(const std::string &p){struct stat st{};return lstat(p.c_str(),&st)==0&&S_ISREG(st.st_mode)&&!S_ISLNK(st.st_mode)&&st.st_size>0&&uint64_t(st.st_size)<=MaxJson;}
bool read(const std::string &p,std::string &out){if(!regular(p))return false;FILE*f=fopen(p.c_str(),"rb");if(!f)return false;out.clear();std::array<char,8192> b{};size_t n;bool ok=true;while((n=fread(b.data(),1,b.size(),f))){if(out.size()+n>MaxJson){ok=false;break;}out.append(b.data(),n);}if(ferror(f))ok=false;if(fclose(f)!=0)ok=false;return ok;}
bool cacheRoot(std::string &error){
#ifndef NM_GAMEBANANA_TEST
 for(const char *p:{"sdmc:/config","sdmc:/config/NinMagicMods"})if(!directory(p,true,error))return false;
#endif
 return directory(root(),true,error);
}
std::string encoded(const std::string &s){std::string out;const char*h="0123456789ABCDEF";for(unsigned char c:s){if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='-'||c=='_'||c=='.'||c=='~')out+=char(c);else{out+='%';out+=h[c>>4];out+=h[c&15];}}return out;}
bool fresh(const std::string &path){struct stat st{};const auto now=std::time(nullptr);return lstat(path.c_str(),&st)==0&&now>=st.st_mtime&&now-st.st_mtime<6*60*60;}
template<typename Validate>bool request(const std::string &url,const std::string &name,bool force,std::string &data,bool &cached,std::string &error,Validate valid){
    const auto target=root()+"/"+name,pending=target+".pending",previous=target+".previous";std::string saved,why;const bool have=read(target,saved)&&valid(saved,why);
    if(have&&!force&&fresh(target)){data=saved;cached=true;return true;}
    std::string received;bool downloaded=downloadGameBananaHttps(url,pending,MaxJson,why)&&read(pending,received)&&valid(received,why);
    if(downloaded){struct stat st{};bool prior=lstat(target.c_str(),&st)==0;
        if(prior&&!regular(target)){why="El archivo de caché no es regular.";downloaded=false;}
        if(downloaded&&lstat(previous.c_str(),&st)==0&&(!regular(previous)||unlink(previous.c_str())!=0)){why="No se pudo conservar la caché anterior.";downloaded=false;}
        if(downloaded&&prior&&rename(target.c_str(),previous.c_str())!=0){why="No se pudo conservar la caché anterior.";downloaded=false;}
        if(downloaded&&rename(pending.c_str(),target.c_str())!=0){if(prior)rename(previous.c_str(),target.c_str());why="No se pudo activar la caché de GameBanana.";downloaded=false;}
        if(downloaded){if(prior)unlink(previous.c_str());data=std::move(received);return true;}
    }
    if(regular(pending))unlink(pending.c_str());
    if(have){data=saved;cached=true;error="GameBanana no respondió; se conserva la copia guardada. "+why;return true;}
    error="No se pudo consultar GameBanana. "+why;return false;
}
bool identify(const Game &game,const std::string &data,uint64_t &id,std::string &error){Json j;if(!parse(data,j,error))return false;const auto &records=field(j,"_aRecords");if(records.kind!='['||records.array.size()>20){error="La búsqueda de juego de GameBanana no es válida.";return false;}std::set<uint64_t> ids;
    for(const auto &r:records.array){const auto n=number(r,"_idRow");if(validGame(game,n,text(r,"_sName"))&&text(r,"_sProfileUrl")=="https://gamebanana.com/games/"+std::to_string(n))ids.insert(n);}
    if(ids.size()!=1){error="GameBanana no confirma exactamente este juego para Switch; no se usarán coincidencias parecidas.";return false;}id=*ids.begin();return true;}
}
bool parseGameBananaMods(const Game &game,uint64_t id,const std::string &data,std::vector<ModEntry> &out,std::string &error){
    error.clear();gb::Json j;if(!gb::parse(data,j,error))return false;const auto &records=gb::field(j,"_aRecords"),&meta=gb::field(j,"_aMetadata");if(records.kind!='['||records.array.size()>gb::PerPage||meta.kind!='{'||gb::field(meta,"_nRecordCount").kind!='n'||gb::field(meta,"_nPerpage").kind!='n'||!gb::number(meta,"_nPerpage")||gb::number(meta,"_nPerpage")>gb::PerPage||gb::number(meta,"_nRecordCount")>100000000){error="La página de GameBanana supera los límites o no es un índice válido.";return false;}
    std::vector<ModEntry> result;std::set<uint64_t> ids;for(const auto &r:records.array){if(gb::yes(r,"_bIsTrashed")||gb::yes(r,"_bIsObsolete"))continue;ModEntry item;if(!gb::record(game,id,0,r,item,error)||!ids.insert(item.gbModId).second)return false;result.push_back(std::move(item));}out=std::move(result);return true;
}
bool parseGameBananaMod(const Game &game,uint64_t id,uint64_t mod,const std::string &data,ModEntry &out,std::string &error){error.clear();gb::Json j;return gb::parse(data,j,error)&&gb::record(game,id,mod,j,out,error);}
bool loadGameBananaMods(const Game &game,std::vector<ModEntry> &out,std::string &error,bool force){
    out.clear();error.clear();if(game.id<0x0100000000010000ULL||game.name.empty()||game.name.size()>256){error="El juego no tiene una identidad válida para consultar GameBanana.";return false;}if(!gb::cacheRoot(error))return false;
    const auto tid=titleId(game.id);uint64_t id=0;std::string data,why;bool cached=false;
    if(const auto*k=gb::known(game.id))id=k->id;
    else{if(!gb::request("https://gamebanana.com/apiv11/Util/Game/NameMatch?_sName="+gb::encoded(game.name),tid+"-game.json",force,data,cached,why,[&](const std::string&s,std::string&e){return gb::identify(game,s,id,e);})||!gb::identify(game,data,id,error)){if(error.empty())error=why;return false;}if(!why.empty())error=why;}
    // Include the independently identified character mod even beyond the page cap.
    if(game.id==0x010015100B514000ULL){ModEntry featured;why.clear();if(gb::request("https://gamebanana.com/apiv11/Mod/556710?_csvProperties=_sName,_sProfileUrl,_sVersion,_aGame,_aSubmitter,_aRootCategory,_aCategory,_aFiles,_sText,_bIsTrashed",tid+"-featured.json",force,data,cached,why,[&](const std::string&s,std::string&e){return parseGameBananaMod(game,id,556710,s,featured,e);})){const auto warning=why;if(parseGameBananaMod(game,id,556710,data,featured,why))out.push_back(std::move(featured));if(why.empty())why=warning;}if(!why.empty())error=why;}
    std::set<uint64_t> seen;for(const auto&e:out)seen.insert(e.gbModId);bool gotPage=false;
    for(size_t page=1;page<=gb::MaxPages;++page){std::vector<ModEntry> entries;why.clear();const auto url="https://gamebanana.com/apiv11/Mod/Index?_nPerpage=15&_nPage="+std::to_string(page)+"&_aFilters%5BGeneric_Game%5D="+std::to_string(id);
        if(!gb::request(url,tid+"-page"+std::to_string(page)+".json",force,data,cached,why,[&](const std::string&s,std::string&e){return parseGameBananaMods(game,id,s,entries,e);})){if(error.empty())error=why;break;}
        const auto warning=why;if(!parseGameBananaMods(game,id,data,entries,why)){error=why;break;}gotPage=true;if(!warning.empty())error=warning;for(auto&e:entries)if(seen.insert(e.gbModId).second&&out.size()<gb::MaxEntries)out.push_back(std::move(e));
        gb::Json j;std::string ignored;if(!gb::parse(data,j,ignored))break;const auto&meta=gb::field(j,"_aMetadata");if(gb::yes(meta,"_bIsComplete")||entries.size()<gb::PerPage||gb::number(meta,"_nRecordCount")<=page*gb::PerPage)break;
    }
    if(cached&&!out.empty())for(auto&e:out)e.detail+=" Metadatos guardados; actualizar vuelve a comprobar la fuente.";
    if(out.size()>=gb::MaxPages*gb::PerPage)for(auto&e:out)e.detail+=" Consulta acotada a 90 publicaciones por juego; la ficha enlaza la fuente completa.";
    if(!gotPage&&out.empty()){if(error.empty())error="GameBanana no devolvió un índice verificado; no significa que el juego carezca de mods.";return false;}return true;
}
}
