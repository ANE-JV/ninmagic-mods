#pragma once
#include "model.hpp"
namespace nmm {
bool platformInit(Environment&,std::string&error);
void platformExit();
bool scanGames(std::vector<Game>&,Environment&,std::string&error);
bool resolveBuild(Game&,Environment&,std::string&error);
// Read-only current-game identity for an overlay; never attaches to the cheat service.
// True means the real running program's full Build ID was verified. NS metadata is optional.
bool resolveRunningGame(Game&,Environment&,std::string&error);
// Must obtain a fresh effective content/version/build and prove the title is closed.
bool validateClosedGame(const Game&expected,std::string&error);
}
