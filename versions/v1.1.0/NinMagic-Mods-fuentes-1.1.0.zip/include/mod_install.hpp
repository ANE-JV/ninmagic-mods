#pragma once
#include "model.hpp"
namespace nmm {
bool inspectInstalledMods(const Game&,InstalledInfo&,std::string&error);
bool inspectPreparedMods(const Game&,const std::vector<ModPayload>&,InstalledInfo&,std::string&error);
Outcome installMods(const Game&,const std::vector<ModPayload>&,bool replaceExisting,const std::string&expectedFingerprint={});
Outcome removeMods(const Game&);
#ifdef NMM_MOD_INSTALL_TEST
void setModInstallFailureForTest(const std::string&);
#endif
}
