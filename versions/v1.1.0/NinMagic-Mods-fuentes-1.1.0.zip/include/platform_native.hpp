#pragma once
#include <array>
#include <cstdint>
#include <cstdio>
#include <string>
#ifndef NMM_PLATFORM_WRAPPER_TEST
#include <switch.h>
#endif

namespace nmm::platform_native {
// fsp-ldr's documented initialization protocol; a short-lived diagnostic session
// is kept separate from libnx's guarded global service and closed on every path.
// https://github.com/switchbrew/libnx/blob/master/nx/source/services/fsldr.c
enum class LoaderStage { Connect, Domain, CurrentProcess, Ready };
struct LoaderProbe { LoaderStage stage=LoaderStage::Connect; Result result=0; };
inline const char* stageName(LoaderStage stage) {
    switch(stage){case LoaderStage::Connect:return "SM/fsp-ldr";case LoaderStage::Domain:return "fsp-ldr/dominio";case LoaderStage::CurrentProcess:return "fsp-ldr/SetCurrentProcess";case LoaderStage::Ready:return "fsp-ldr/listo";}return "fsp-ldr";
}
inline LoaderProbe probeLoader() {
    Service service{};LoaderProbe probe;
    probe.result=smGetService(&service,"fsp-ldr");
    if(R_SUCCEEDED(probe.result)){probe.stage=LoaderStage::Domain;probe.result=serviceConvertToDomain(&service);}
    if(R_SUCCEEDED(probe.result)&&hosversionAtLeast(4,0,0)){
        probe.stage=LoaderStage::CurrentProcess;const u64 placeholder=0;
        probe.result=serviceDispatchIn(&service,2,placeholder,.in_send_pid=true);
    }
    if(R_SUCCEEDED(probe.result))probe.stage=LoaderStage::Ready;
    if(serviceIsActive(&service))serviceClose(&service);
    return probe;
}
// Only reads a fixed NSO header and closes the returned objects. No filesystem
// mounts, writes, commits, game-content changes, or memory access occur here.
inline Result readHeader(FsFileSystem& fs,std::array<uint8_t,0x60>& bytes,const char*& stage) {
    bytes.fill(0);FsFile file{};stage="abrir /main";
    Result result=fsFsOpenFile(&fs,"/main",FsOpenMode_Read,&file);
    if(R_SUCCEEDED(result)){
        u64 got=0;stage="leer cabecera NSO";
        result=fsFileRead(&file,0,bytes.data(),bytes.size(),FsReadOption_None,&got);
        fsFileClose(&file);
        if(R_SUCCEEDED(result)&&got!=bytes.size())result=MAKERESULT(Module_Libnx,LibnxError_IoError);
    }
    fsFsClose(&fs);return result;
}
inline Result readLoaderHeader(u64 id,NcmStorageId storage,const char* path,std::array<uint8_t,0x60>& bytes,const char*& stage) {
    FsCodeInfo info{};FsFileSystem fs{};stage="fsp-ldr/abrir contenido";
    const auto result=fsldrOpenCodeFileSystem(&info,id,storage,path,FsContentAttributes_None,&fs);
    if(R_FAILED(result))return result;
    return readHeader(fs,bytes,stage);
}
// FileSystemProxyType_Code=0 is documented by Atmosphere's own FS enum.
// Use only an exact Program NCA path resolved from the selected NCM key; a
// failure never authorizes reading an older CNMT or substituting base content.
// https://github.com/Atmosphere-NX/Atmosphere/blob/master/libraries/libstratosphere/include/stratosphere/fs/impl/fs_filesystem_proxy_type.hpp
inline Result readContentHeader(u64 id,const char* path,std::array<uint8_t,0x60>& bytes,const char*& stage) {
    FsFileSystem fs{};stage="fsp-srv/Code/NCM";
    const auto result=fsOpenFileSystemWithId(&fs,id,static_cast<FsFileSystemType>(0),path,FsContentAttributes_None);
    if(R_FAILED(result))return result;
    return readHeader(fs,bytes,stage);
}
inline std::string describe(const char* stage,Result result) {
    char value[16];std::snprintf(value,sizeof(value),"0x%08lX",static_cast<unsigned long>(result));return std::string(stage)+" "+value;
}
template<class ResolvePath>
bool readInstalledHeader(u64 applicationId,u64 metaId,NcmStorageId storage,bool loaderReady,bool legacy,const std::string& loaderDiagnostic,ResolvePath&& resolvePath,std::array<uint8_t,0x60>& bytes,std::string& error) {
    error.clear();bytes.fill(0);std::string path,pathError,loaderError;const char* stage="fsp-ldr";bool havePath=false,lookedUp=false;
    const auto getPath=[&](){if(!lookedUp){lookedUp=true;havePath=resolvePath(path,pathError);}return havePath;};
    if(legacy)getPath();
    if(loaderReady&&(!legacy||havePath)){
        const auto result=readLoaderHeader(applicationId,storage,path.c_str(),bytes,stage);
        if(R_SUCCEEDED(result))return true;
        loaderError=describe(stage,result);
    }else loaderError=loaderReady?pathError:loaderDiagnostic;
    // The resolver is bound by the caller to one effective NCM key. Even the
    // alternate-ID attempt reads that exact same path, never an older base.
    if(getPath()){
        auto result=readContentHeader(applicationId,path.c_str(),bytes,stage);
        if(R_FAILED(result)&&metaId!=applicationId)result=readContentHeader(metaId,path.c_str(),bytes,stage);
        if(R_SUCCEEDED(result))return true;
        pathError=describe(stage,result);
    }
    error="No se pudo comprobar el ejecutable actual. "+loaderError+"; "+pathError+". Instalación bloqueada.";return false;
}
}
