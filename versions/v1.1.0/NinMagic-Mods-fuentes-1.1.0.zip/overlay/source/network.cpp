#include "update_network.hpp"
#include "https_lite.hpp"
#include "controller.hpp"
#include <algorithm>
namespace nmm { namespace {
bool privatePath(const std::string&p){if(p.rfind("sdmc:/config/NinMagicMods/",0)!=0||p.find('\\')!=p.npos||p.find(':',5)!=p.npos)return false;size_t at=6;while(at<p.size()){auto n=p.find('/',at);auto part=p.substr(at,n==p.npos?n:n-at);if(part.empty()||part=="."||part=="..")return false;if(n==p.npos)break;at=n+1;}return true;}
bool run(const std::string&u,const std::string&p,uint64_t limit,std::string&e){if(!privatePath(p)||!limit||limit>3ULL*1024*1024){e="El overlay solo descarga metadatos o parches pequeños en su caché privada.";return false;}https_lite::Response response;return https_lite::download(u,p,response,e,false,limit,overlay::shouldCancel);}
}
bool downloadModHttps(const std::string&u,const std::string&p,uint64_t maximum,std::string&e){const bool tree=u.rfind("https://api.github.com/repos/",0)==0&&u.find("/git/trees/")!=u.npos;const bool raw=u.rfind("https://raw.githubusercontent.com/",0)==0;if(!tree&&!raw){e="Esta fuente no está autorizada para el catálogo del overlay.";return false;}const uint64_t cap=tree?3ULL*1024*1024:128ULL*1024;return run(u,p,std::min(maximum,cap),e);}
bool downloadGameBananaHttps(const std::string&u,const std::string&p,uint64_t maximum,std::string&e){if(u.rfind("https://gamebanana.com/apiv11/",0)!=0){e="GameBanana en el overlay solo consulta su API de metadatos.";return false;}return run(u,p,std::min<uint64_t>(maximum,2*1024*1024),e);}
void updateNetworkExit(){https_lite::shutdown();}
}
