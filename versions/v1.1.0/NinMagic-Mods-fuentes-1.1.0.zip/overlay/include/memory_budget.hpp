#pragma once
#include <cstdint>
namespace nmm::overlay {
// Keep a margin for UI/font growth, TLS IPC and allocator bookkeeping. An
// unknown loader heap never grants an unbounded network/JSON operation.
inline bool withinMemoryBudget(uint64_t total,uint64_t used,uint64_t required,uint64_t reserve=512*1024){return total&&used<=total&&required<=total-used&&reserve<=total-used-required;}
}
