#pragma once
#include "model.hpp"
namespace nmm::overlay {
struct Snapshot {Game game;std::vector<ModEntry>items;size_t highlighted=0,firstItem=0,totalItems=0,selectedCount=0;bool busy=false,searching=false,initialized=false,ready=false,lastSaveKnown=false,lastSaveOk=false;std::string status,error,lastSave;};
bool init(std::string&error);void shutdown();Snapshot snapshot();
bool refresh();bool search();bool move(int delta);bool toggle(size_t index);bool save();bool clear();void cancel();bool shouldCancel();
}
