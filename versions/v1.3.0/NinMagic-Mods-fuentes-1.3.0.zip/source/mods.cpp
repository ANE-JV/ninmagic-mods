#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "mods.hpp"
#include "update_network.hpp"
#include "mod_archive.hpp"
#include "gamebanana.hpp"
#include <algorithm>
#include <array>
#include <cerrno>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <fcntl.h>
#include <map>
#include <set>
#include <sys/stat.h>
#include <unistd.h>

namespace nmm {
namespace {
constexpr size_t MaxTree=8*1024*1024;
#ifdef NMM_OVERLAY
constexpr size_t MaxPayload=128*1024;
#else
constexpr size_t MaxPayload=32*1024*1024;
#endif
struct Repo {const char *name,*branch,*file;bool hardware;};
const Repo Repos[]={
 {"masagrator/NXGraphicsPatches","master","masagrator.json",true},
 {"cucholix/NX-IPS-romfs-compilation","main","cucholix.json",true},
 {"h2y/BOTW-Chinese-Linkle","master","linkle.json",true}
};
const Repo *repoFor(const std::string&name){for(const auto&r:Repos)if(name==r.name)return &r;return nullptr;}
std::string root() {
#ifdef NC_MODS_TEST
    const char *s=std::getenv("NC_MODS_ROOT");return s?s:"mods-test";
#else
    return "sdmc:/config/NinMagicMods";
#endif
}
std::string upper(std::string s){for(char &c:s)c=char(std::toupper(static_cast<unsigned char>(c)));return s;}
bool hex(const std::string &s,size_t count){return s.size()==count&&std::all_of(s.begin(),s.end(),[](unsigned char c){return std::isxdigit(c)!=0;});}
bool pathValid(const std::string &s) {
    if(s.empty()||s.size()>1024||s[0]=='/'||s.back()=='/'||s.find('\\')!=std::string::npos)return false;
    size_t start=0;
    for(unsigned char c:s)if(c<32||c==127)return false;
    while(start<s.size()){auto end=s.find('/',start);auto part=s.substr(start,end==std::string::npos?end:end-start);if(part.empty()||part=="."||part=="..")return false;if(end==std::string::npos)break;start=end+1;}
    return true;
}
struct Raw {std::string path,sha,type;uint64_t size=0;};
class TreeJson {
    const std::string &s;size_t p=0;
    void ws(){while(p<s.size()&&std::isspace(static_cast<unsigned char>(s[p])))++p;}
    bool character(char c){ws();if(p==s.size()||s[p]!=c)return false;++p;return true;}
    static void utf8(std::string &out,uint32_t cp){if(cp<128)out+=char(cp);else if(cp<2048){out+=char(0xc0|(cp>>6));out+=char(0x80|(cp&63));}else if(cp<65536){out+=char(0xe0|(cp>>12));out+=char(0x80|((cp>>6)&63));out+=char(0x80|(cp&63));}else{out+=char(0xf0|(cp>>18));out+=char(0x80|((cp>>12)&63));out+=char(0x80|((cp>>6)&63));out+=char(0x80|(cp&63));}}
    bool codepoint(uint32_t &value){value=0;for(unsigned n=0;n<4;++n){if(p==s.size()||!std::isxdigit(static_cast<unsigned char>(s[p])))return false;unsigned char c=s[p++];value=(value<<4)|(c<='9'?c-'0':std::tolower(c)-'a'+10);}return true;}
    bool string(std::string &out) {
        out.clear();if(!character('"'))return false;
        while(p<s.size()) {
            unsigned char c=s[p++];if(c=='"')return true;if(c<32)return false;
            if(c=='\\') {
                if(p==s.size())return false;
                char e=s[p++];
                if(e=='"'||e=='\\'||e=='/')out+=e;
                else if(e=='b')out+='\b';else if(e=='f')out+='\f';else if(e=='n')out+='\n';else if(e=='r')out+='\r';else if(e=='t')out+='\t';
                else if(e=='u'){uint32_t cp=0;if(!codepoint(cp))return false;if(cp>=0xd800&&cp<=0xdbff){if(p+2>s.size()||s.substr(p,2)!="\\u")return false;p+=2;uint32_t low=0;if(!codepoint(low)||low<0xdc00||low>0xdfff)return false;cp=0x10000+((cp-0xd800)<<10)+(low-0xdc00);}else if(cp>=0xdc00&&cp<=0xdfff)return false;utf8(out,cp);}else return false;
            }else out+=char(c);
            if(out.size()>8192)return false;
        }
        return false;
    }
    bool number(uint64_t &value){ws();size_t start=p;value=0;while(p<s.size()&&s[p]>='0'&&s[p]<='9'){unsigned n=s[p++]-'0';if(value>(UINT64_MAX-n)/10)return false;value=value*10+n;}return p>start;}
    bool literal(const char *value){ws();size_t n=std::char_traits<char>::length(value);if(s.compare(p,n,value))return false;p+=n;return true;}
    bool skip(unsigned depth=0) {
        if(depth>32)return false;
        ws();if(p==s.size())return false;
        if(s[p]=='"'){std::string ignored;return string(ignored);}
        if(s[p]=='{'){++p;ws();if(character('}'))return true;do{std::string key;if(!string(key)||!character(':')||!skip(depth+1))return false;if(character('}'))return true;}while(character(','));return false;}
        if(s[p]=='['){++p;ws();if(character(']'))return true;do{if(!skip(depth+1))return false;if(character(']'))return true;}while(character(','));return false;}
        if(s[p]=='t')return literal("true");
        if(s[p]=='f')return literal("false");
        if(s[p]=='n')return literal("null");
        uint64_t ignored=0;return number(ignored);
    }
    bool item(Raw &out) {
        if(!character('{'))return false;
        std::set<std::string> keys;
        if(character('}'))return false;
        do{std::string key;if(!string(key)||!keys.insert(key).second||!character(':'))return false;
            if(key=="path"){if(!string(out.path))return false;}else if(key=="sha"){if(!string(out.sha))return false;}else if(key=="type"){if(!string(out.type))return false;}else if(key=="size"){if(!number(out.size))return false;}else if(!skip())return false;
            if(character('}'))return pathValid(out.path)&&hex(out.sha,40)&&!out.type.empty()&&(out.type!="blob"||keys.count("size"));
        }while(character(','));return false;
    }
public:
    explicit TreeJson(const std::string &text):s(text){}
    bool parse(std::string &revision,std::vector<Raw> &items) {
        if(!character('{'))return false;
        bool tree=false,truncated=false,haveTruncated=false;std::set<std::string> keys;
        do{std::string key;if(!string(key)||!keys.insert(key).second||!character(':'))return false;
            if(key=="sha"){if(!string(revision))return false;}
            else if(key=="truncated"){haveTruncated=true;if(literal("true"))truncated=true;else if(!literal("false"))return false;}
            else if(key=="tree"){if(!character('['))return false;tree=true;if(!character(']')){do{Raw raw;if(!item(raw)||items.size()>=30000)return false;items.push_back(std::move(raw));if(character(']'))break;if(!character(','))return false;}while(true);}}
            else if(!skip())return false;
            if(character('}'))break;
            if(!character(','))return false;
        }while(true);
        ws();return p==s.size()&&tree&&haveTruncated&&!truncated&&hex(revision,40);
    }
};
uint64_t titleFromPath(const std::string &path,bool *ambiguous=nullptr,bool *updateTag=nullptr) {
    std::set<uint64_t> ids;bool invalid=false,update=false;
    for(size_t p=0;p+16<=path.size();++p){if(p&&std::isxdigit(static_cast<unsigned char>(path[p-1])))continue;if(p+16<path.size()&&std::isxdigit(static_cast<unsigned char>(path[p+16])))continue;std::string token=upper(path.substr(p,16));if(token.rfind("0100",0)||!hex(token,16))continue;uint64_t id=0;for(unsigned char c:token)id=(id<<4)|(c<='9'?c-'0':c-'A'+10);if(id>=0x0100000000010000ULL){const auto app=canonicalModApplicationId(id);if(!app)invalid=true;else ids.insert(app);update=update||modUsesUpdateTitleId(id);}}
    if(ambiguous)*ambiguous=invalid||ids.size()>1;
    if(updateTag)*updateTag=update;
    return !invalid&&ids.size()==1?*ids.begin():0;
}
ModFormat format(const std::string &path) {
    std::string value=upper(path);if(value.size()>=7&&value.substr(value.size()-7)==".PCHTXT")return ModFormat::Pchtxt;
    if((value.size()>=4&&value.substr(value.size()-4)==".IPS")||(value.size()>=6&&value.substr(value.size()-6)==".IPS32"))return ModFormat::Ips;
    if(value.find("/ROMFS/")!=std::string::npos)return ModFormat::Romfs;
    for(const char *suffix:{".ZIP",".RAR",".7Z"})if(value.size()>=std::char_traits<char>::length(suffix)&&value.substr(value.size()-std::char_traits<char>::length(suffix))==suffix)return ModFormat::Archive;
    return ModFormat::Unsupported;
}
std::string displayName(const std::string &path,ModFormat kind) {
    if(kind==ModFormat::Archive){auto slash=path.find_last_of('/');return path.substr(slash==std::string::npos?0:slash+1);}
    std::vector<std::string> parts;size_t start=path.find('/');if(start==std::string::npos)return path;++start;
    while(start<path.size()){auto end=path.find('/',start);std::string part=path.substr(start,end==std::string::npos?end:end-start);std::string cap=upper(part);
        bool generic=cap=="EXEFS"||cap=="EXEFS_PATCHES"||cap=="TITLES"||cap=="CONTENTS"||cap=="ATMOSPHERE";
        if(!generic&&!titleFromPath(part))parts.push_back(part);
        if(end==std::string::npos)break;
        start=end+1;
    }
    if(parts.empty())return path;
    auto &last=parts.back();auto dot=last.find_last_of('.');if(kind==ModFormat::Pchtxt&&dot!=std::string::npos)last.resize(dot);
    if(kind==ModFormat::Ips&&dot!=std::string::npos&&hex(last.substr(0,dot),dot))parts.pop_back();
    std::string result;for(const auto &part:parts){if(!result.empty())result+=" / ";result+=part;}return result.empty()?path:result;
}
std::string normalized(std::string value) {
    std::string out;for(unsigned char c:value)if(std::isalnum(c)&&c<128)out+=char(std::tolower(c));
    for(const std::string suffix:{"optimization","mods","mod"})if(out.size()>suffix.size()&&out.substr(out.size()-suffix.size())==suffix)out.resize(out.size()-suffix.size());
    auto version=out.find("v1");if(version==std::string::npos)version=out.find("v2");if(version==std::string::npos)version=out.find("v4");if(version!=std::string::npos)out.resize(version);
    return out;
}
bool dir(const std::string &path,bool create,std::string &error) {
    struct stat st{};if(lstat(path.c_str(),&st)!=0){if(errno!=ENOENT||!create){error="No existe la carpeta de mods.";return false;}
#ifdef _WIN32
        if(mkdir(path.c_str())!=0){error="No se pudo crear la carpeta de mods.";return false;}
#else
        if(mkdir(path.c_str(),0777)!=0){error="No se pudo crear la carpeta de mods.";return false;}
#endif
        if(lstat(path.c_str(),&st)!=0)return false;
    }
    if(S_ISLNK(st.st_mode)||!S_ISDIR(st.st_mode)){error="La carpeta de mods contiene una ruta no admitida.";return false;}return true;
}
bool ensureRoot(std::string &error) {
#ifndef NC_MODS_TEST
    if(!dir("sdmc:/config",true,error))return false;
#endif
    return dir(root(),true,error);
}
bool regular(const std::string &path,size_t maximum){struct stat st{};return lstat(path.c_str(),&st)==0&&S_ISREG(st.st_mode)&&!S_ISLNK(st.st_mode)&&st.st_size>=0&&uint64_t(st.st_size)<=maximum;}
bool read(const std::string &path,std::string &data,size_t maximum,std::string &error) {
    if(!regular(path,maximum)){error="Falta un archivo válido del catálogo de mods.";return false;}
    FILE *f=fopen(path.c_str(),"rb");if(!f){error="No se puede leer el catálogo de mods.";return false;}
    data.clear();std::array<char,16384> buffer{};size_t n;bool ok=true;
    while((n=fread(buffer.data(),1,buffer.size(),f))){if(data.size()+n>maximum){ok=false;break;}data.append(buffer.data(),n);}
    if(ferror(f))ok=false;
    if(fclose(f)!=0)ok=false;
    if(!ok)error="La lectura del catálogo quedó incompleta.";
    return ok;
}
bool write(const std::string &path,const std::string &data,std::string &error) {
    struct stat st{};if(lstat(path.c_str(),&st)==0&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode))){error="El registro de mods no es un archivo regular.";return false;}
    FILE *f=fopen(path.c_str(),"wb");if(!f){error="No se pudo guardar el catálogo de mods.";return false;}
    bool ok=fwrite(data.data(),1,data.size(),f)==data.size()&&fflush(f)==0&&fsync(fileno(f))==0;if(fclose(f)!=0)ok=false;if(!ok)error="No se pudo confirmar la escritura del catálogo.";return ok;
}
char active(){std::string s,e;return read(root()+"/mods-active.txt",s,8,e)&&!s.empty()&&s[0]=='b'?'b':'a';}
bool slot(char value,ModsCatalog &out,std::string &error) {
    std::string path=root()+"/mods-"+value,marker;if(!dir(path,false,error)||!read(path+"/complete.txt",marker,128,error)||marker.rfind("NMMODS1\n",0)!=0)return false;
    ModsCatalog all;unsigned valid=0;
    for(const auto &repo:Repos){std::string json,why;ModsCatalog one;SourceReport report;report.name=repo.name;report.url=std::string("https://github.com/")+repo.name;
        if(read(path+"/"+repo.file,json,MaxTree,why)&&parseModsTree(json,one,why,repo.name)){++valid;report.cached=true;report.entries=unsigned(one.entries.size());report.detail="Índice guardado; X/Y vuelve a comprobar.";all.entries.insert(all.entries.end(),one.entries.begin(),one.entries.end());}
        else report.detail="Fuente sin comprobar: "+why;
        all.sources.push_back(std::move(report));
    }
    if(!valid){error="No hay índices válidos de las fuentes.";return false;}
    all.ready=true;all.stamp=marker.substr(marker.find('\n')+1);while(!all.stamp.empty()&&(all.stamp.back()=='\r'||all.stamp.back()=='\n'))all.stamp.pop_back();all.detail=std::to_string(all.entries.size())+" opciones de "+std::to_string(valid)+" fuentes guardadas";out=std::move(all);error.clear();return true;
}
std::string encode(const std::string &path){std::string result;const char *digits="0123456789ABCDEF";for(unsigned char c:path){if(std::isalnum(c)||c=='-'||c=='_'||c=='.'||c=='~'||c=='/')result+=char(c);else{result+='%';result+=digits[c>>4];result+=digits[c&15];}}return result;}
uint32_t rotate(uint32_t value,unsigned bits){return (value<<bits)|(value>>(32-bits));}
std::string gitBlobSha(const std::string &bytes) {
    std::string header="blob "+std::to_string(bytes.size());header+='\0';
    std::vector<uint8_t> data(header.begin(),header.end());data.insert(data.end(),bytes.begin(),bytes.end());uint64_t length=uint64_t(data.size())*8;
    data.push_back(0x80);while(data.size()%64!=56)data.push_back(0);for(int n=7;n>=0;--n)data.push_back(uint8_t(length>>(n*8)));
    uint32_t h[]={0x67452301,0xefcdab89,0x98badcfe,0x10325476,0xc3d2e1f0};
    for(size_t block=0;block<data.size();block+=64){uint32_t words[80]{};for(unsigned n=0;n<16;++n)for(unsigned b=0;b<4;++b)words[n]=(words[n]<<8)|data[block+n*4+b];for(unsigned n=16;n<80;++n)words[n]=rotate(words[n-3]^words[n-8]^words[n-14]^words[n-16],1);uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4];
        for(unsigned n=0;n<80;++n){uint32_t f=n<20?((b&c)|(~b&d)):n<40?(b^c^d):n<60?((b&c)|(b&d)|(c&d)):(b^c^d);uint32_t k=n<20?0x5a827999:n<40?0x6ed9eba1:n<60?0x8f1bbcdc:0xca62c1d6;uint32_t next=rotate(a,5)+f+e+k+words[n];e=d;d=c;c=rotate(b,30);b=a;a=next;}h[0]+=a;h[1]+=b;h[2]+=c;h[3]+=d;h[4]+=e;}
    std::string result;const char *digits="0123456789abcdef";for(uint32_t word:h)for(int n=7;n>=0;--n)result+=digits[(word>>(n*4))&15];return result;
}
}

namespace {
std::vector<std::string> parts(const std::string&s){std::vector<std::string>out;size_t p=0;while(p<s.size()){auto end=s.find('/',p);out.push_back(s.substr(p,end==s.npos?end:end-p));if(end==s.npos)break;p=end+1;}return out;}
std::string gameGroup(const std::string&repo,const std::string&path){auto p=parts(path);if(p.empty())return{};if((repo=="yuzu-mirror/yuzu-mod-archive"||repo=="cucholix/NX-IPS-romfs-compilation")&&p.size()>1)return p[0]+"/"+p[1];return p[0];}
std::string groupName(const ModEntry&e){auto p=parts(gameGroup(e.repository,e.path));return p.empty()?std::string{}:p.back();}
bool gameVersion(const std::string&text){unsigned digits=0,dots=0;for(unsigned char c:text){if(c>='0'&&c<='9'){++digits;if(digits>8)return false;}else if(c=='.'&&digits){++dots;digits=0;}else return false;}return digits&&dots>=2&&dots<=3&&text.size()<=32;}
std::string pathVersion(const std::string&path){std::set<std::string>v;for(auto p:parts(path)){auto dot=p.find_last_of('.');if(dot!=p.npos){const auto ext=upper(p.substr(dot));if(ext==".PCHTXT"||ext==".IPS"||ext==".IPS32"||ext==".ZIP"||ext==".RAR")p.resize(dot);}if(upper(p).rfind("RELEASE_",0)==0)p.erase(0,8);else if(upper(p).rfind("RELEASES_",0)==0)p.erase(0,9);if(!p.empty()&&(p[0]=='v'||p[0]=='V'))p.erase(0,1);if(gameVersion(p))v.insert(p);}return v.size()==1?*v.begin():std::string{};}
std::string category(const std::string&path){auto p=upper(path);if(p.find("COSTUME")!=p.npos||p.find("OUTFIT")!=p.npos||p.find("HOOD DOWN")!=p.npos||p.find("CLOTH")!=p.npos)return "Ropa";if(p.find("PLAY AS")!=p.npos||p.find("CHARACTER")!=p.npos||p.find("LINKLE")!=p.npos||p.find("MODEL REPLAC")!=p.npos)return "Personajes";if(p.find("FPS")!=p.npos||p.find("FRAMERATE")!=p.npos||p.find("FRAME RATE")!=p.npos)return "FPS";return "Gráficos";}
std::string rawUrl(const ModEntry&e,const std::string&path){return "https://raw.githubusercontent.com/"+e.repository+"/"+e.branch+"/"+encode(path);}
std::string fullBid(std::string id){id=upper(id);if(id.size()<16||id.size()>64||!hex(id,id.size())||id.size()%2)return{};id.resize(64,'0');return id;}
bool contentIdentityValid(const Game&game){return game.contentIdentity.size()==64&&game.contentIdentity.find_first_not_of("0123456789abcdef")==game.contentIdentity.npos&&game.contentIdentity.find_first_not_of('0')!=game.contentIdentity.npos;}
bool sameIdentity(const Game&game){return game.id>=0x0100000000010000ULL&&!(game.id&0xfff)&&game.running&&game.processId&&game.buildVerified&&contentIdentityValid(game)&&hex(game.fullBuildId,64)&&hex(game.buildId,16)&&game.fullBuildId.find_first_not_of('0')!=game.fullBuildId.npos&&upper(game.fullBuildId).substr(0,16)==upper(game.buildId);}
bool resourceIdentity(const Game&game){return game.id>=0x0100000000010000ULL&&!(game.id&0xfff)&&game.versionKnown&&!game.version.empty()&&game.version.size()<=32&&std::none_of(game.version.begin(),game.version.end(),[](unsigned char c){return c<32||c==127;})&&contentIdentityValid(game);}
std::string staticIdentityError(const Game&game){return game.running&&game.processId&&game.buildVerified&&!contentIdentityValid(game)?"No se pudo verificar la identidad de contenido del juego. Abre NinMagic Mods desde Álbum dejando ese juego iniciado.":"Inicia este juego para comprobar su PID y Build ID completo; el parche se aplicará en el próximo inicio.";}
bool verifiedBytes(const ModEntry&e,std::string&bytes,std::string&error){
    const auto *provider=repoFor(e.repository);
    if(!provider||e.branch!=provider->branch||!pathValid(e.path)||!hex(e.blobSha,40)||e.size==0||e.size>MaxPayload){error="El archivo no tiene identidad/tamaño Git comprobables.";return false;}
    if(!ensureRoot(error)||!dir(root()+"/mod-files",true,error))return false;
    const auto hash=std::string(e.blobSha);const auto target=root()+"/mod-files/"+hash+".bin";
    if(read(target,bytes,size_t(e.size),error)&&bytes.size()==e.size&&gitBlobSha(bytes)==hash){error.clear();return true;}
    const auto pending=target+".pending";error.clear();
    if(!downloadModHttps(rawUrl(e,e.path),pending,e.size,error)||!read(pending,bytes,size_t(e.size),error))return false;
    if(bytes.size()!=e.size||gitBlobSha(bytes)!=hash){error="El archivo descargado cambió respecto al índice Git; sincroniza de nuevo.";return false;}
    struct stat st{};if(lstat(target.c_str(),&st)==0&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode))){error="La caché de mods no es un archivo normal.";return false;}
    if(regular(target,MaxPayload)&&unlink(target.c_str())!=0){error="No se pudo retirar la copia de caché inválida.";return false;}
    if(rename(pending.c_str(),target.c_str())!=0){error="No se pudo activar la copia verificada del mod.";return false;}return true;
}
bool allowedRomfs(const Game&game,const ModEntry&e,std::string&error){
    if(!allowsConsoleMod(e)){error="El origen no acredita este mod para Switch física; no se instalará.";return false;}
    if(!resourceIdentity(game)||canonicalModApplicationId(e.titleId)!=game.id){error="Title ID, versión o identidad de contenido del juego sin comprobar.";return false;}
    if(game.running||game.processId){error="Cierra este juego para preparar sus archivos RomFS.";return false;}
    if(e.version.empty()){error="Mod RomFS sin una versión de juego explícita: instalación bloqueada.";return false;}
    if(!game.versionKnown||game.version!=e.version){error="No compatible con esta versión. Requiere "+e.version+".";return false;}
    if(e.files.empty()||e.files.size()>512||e.size>128ULL*1024*1024){error="Grupo RomFS vacío o supera los límites de preparación.";return false;}
    if(!e.buildId.empty()){
        const auto required=fullBid(e.buildId);if(required.empty()){error="El autor declara un Build ID RomFS no válido.";return false;}
        if(!game.buildVerified||!hex(game.fullBuildId,64)||!hex(game.buildId,16)||upper(game.fullBuildId).substr(0,16)!=upper(game.buildId)){error="El autor exige un Build ID para este RomFS; el Build ID actual está sin verificar.";return false;}
        if(required!=upper(game.fullBuildId)){error="No compatible con el Build ID declarado por el autor. Requiere "+e.buildId+".";return false;}
    }
    return true;
}
}
bool parseModsTree(const std::string&json,ModsCatalog&catalog,std::string&error,const std::string&repository){
    catalog={};error.clear();const auto *repo=repoFor(repository);if(!repo){error="Fuente de mods no admitida.";return false;}
    std::vector<Raw>items;std::string revision;
    if(json.empty()||json.size()>MaxTree||!TreeJson(json).parse(revision,items)){error="Índice JSON de mods incompleto, truncado o inválido.";return false;}
    std::map<std::string,std::set<uint64_t>>groups;std::set<std::string>unique;
    for(const auto&r:items){if(!unique.insert(r.path).second){error="El índice repite una ruta.";return false;}if(r.type=="blob"){auto tid=titleFromPath(r.path);if(tid)groups[gameGroup(repository,r.path)].insert(tid);}}
    std::map<std::string,size_t>romfs;
    for(const auto&r:items)if(r.type=="blob"){
        const auto kind=format(r.path);if(kind==ModFormat::Unsupported)continue;
        const auto cap=upper(r.path);if(cap.find("/CHEATS/")!=cap.npos)continue;
        bool ambiguous=false,updateTag=false;ModEntry e;e.path=r.path;e.name=displayName(r.path,kind);e.titleId=titleFromPath(r.path,&ambiguous,&updateTag);
        const auto found=groups.find(gameGroup(repository,r.path));if(!e.titleId&&!ambiguous&&found!=groups.end()&&found->second.size()==1)e.titleId=*found->second.begin();
        e.blobSha=r.sha;e.size=r.size;e.format=kind;e.revision=revision;e.repository=repository;e.source=repository;e.branch=repo->branch;e.sourceUrl="https://github.com/"+repository+"/blob/"+repo->branch+"/"+encode(r.path);e.id=repository+"|"+r.path;e.category=category(r.path);e.version=pathVersion(r.path);e.consoleOnly=repo->hardware;
        e.detail="Fuente con instrucciones para Switch física. Revisa requisitos del autor; los FPS y el funcionamiento no están garantizados.";
        if(repository=="cucholix/NX-IPS-romfs-compilation")e.detail="El autor prueba en Mariko y exige requisitos de hardware y frecuencias para muchos mods. La app no modifica frecuencias. Consulta description.txt de ese juego.";
        if(updateTag)e.detail+=" Autor indica ID de actualización del mismo juego; se compara con su ApplicationID y no omite versión ni Build ID.";
        if(kind==ModFormat::Ips){auto leaf=parts(r.path).back();auto dot=leaf.find_last_of('.');leaf.resize(dot);e.buildId=fullBid(leaf);}
        if(kind==ModFormat::Romfs){
            auto at=cap.find("/ROMFS/");const auto tail=r.path.substr(at+7);auto leaf=upper(parts(tail).back());
            if(leaf.find("README")==0||leaf.find("LICENSE")==0||!r.size)continue;
            const auto key=r.path.substr(0,at+6);auto index=romfs.find(key);
            if(index==romfs.end()){e.name=displayName(key,kind);e.path=key;e.id=repository+"|"+key;e.size=0;e.blobSha.clear();e.reason="Debe comprobarse la versión del juego.";romfs[key]=catalog.entries.size();catalog.entries.push_back(std::move(e));index=romfs.find(key);}
            auto &group=catalog.entries[index->second];group.files.push_back({r.path,"https://raw.githubusercontent.com/"+repository+"/"+repo->branch+"/"+encode(r.path),r.sha,r.size});group.size+=r.size;continue;
        }
        e.reason=kind==ModFormat::Archive?"Pulsa A para descargar y revisar el contenido ZIP/RAR antes de seleccionarlo.":"Se comprobará el Build ID completo antes de permitir seleccionarlo.";
#ifndef NMM_OVERLAY
        if(kind==ModFormat::Archive)for(const auto&other:items)if(e.files.size()<32&&other.type=="blob"&&format(other.path)==ModFormat::Pchtxt&&gameGroup(repository,other.path)==gameGroup(repository,r.path)&&other.size>0&&other.size<=2*1024*1024)e.files.push_back({other.path,{},other.sha,other.size});
#endif
        if(allowsConsoleMod(e))catalog.entries.push_back(std::move(e));
    }
    if(repository=="h2y/BOTW-Chinese-Linkle"){
        ModEntry e;e.titleId=0x01007EF00011E000ULL;e.name="Linkle: diálogos chinos complementarios";e.path="readme.md";e.id=repository+"|readme.md";e.repository=e.source=repository;e.branch=repo->branch;e.revision=revision;e.sourceUrl="https://github.com/"+repository;e.category="Personajes";e.format=ModFormat::Unsupported;e.consoleOnly=true;e.reason="Proyecto complementario de Linkle, no incluye el modelo. Paquete 7z y versión sin comprobar: instalación bloqueada.";e.detail="El autor documenta Switch y ese Title ID. No declara una versión de juego; no se transforma esa ausencia en compatibilidad.";catalog.entries.push_back(std::move(e));
    }
    catalog.entries.erase(std::remove_if(catalog.entries.begin(),catalog.entries.end(),[](const ModEntry&e){return !allowsConsoleMod(e);}),catalog.entries.end());
    catalog.ready=true;catalog.revision=revision;catalog.detail=std::to_string(catalog.entries.size())+" opciones indexadas";return true;
}
bool loadModsCatalog(ModsCatalog&catalog,std::string&error){auto a=active();if(slot(a,catalog,error)||slot(a=='a'?'b':'a',catalog,error))return true;catalog={};error="No hay catálogo guardado. Y consulta las fuentes de mods.";return false;}
static bool synchronizeModsCatalog(ModsCatalog&catalog,std::string&error){
    error.clear();if(!ensureRoot(error))return false;auto current=active();ModsCatalog prior;std::string ignored;
    if(!slot(current,prior,ignored)&&slot(current=='a'?'b':'a',prior,ignored))current=current=='a'?'b':'a';
    const auto next=current=='a'?'b':'a';const auto folder=root()+"/mods-"+next;if(!dir(folder,true,error))return false;
    const auto marker=folder+"/complete.txt";if(regular(marker,128))unlink(marker.c_str());
    std::vector<SourceReport>reports;unsigned good=0;bool complete=true;
    for(const auto&repo:Repos){SourceReport report;report.name=repo.name;report.url=std::string("https://github.com/")+repo.name;
        const auto file=folder+"/"+repo.file,pending=file+".pending";std::string json,why;ModsCatalog parsed;
        if(downloadModHttps(std::string("https://api.github.com/repos/")+repo.name+"/git/trees/"+repo.branch+"?recursive=1",pending,MaxTree,why)&&read(pending,json,MaxTree,why)&&parseModsTree(json,parsed,why,repo.name)&&(!regular(file,MaxTree)||unlink(file.c_str())==0)&&rename(pending.c_str(),file.c_str())==0){++good;report.checked=true;report.entries=unsigned(parsed.entries.size());report.detail="Índice consultado y validado.";}
        else {complete=false;std::string saved;ModsCatalog old;std::string oldError;if(read(root()+"/mods-"+current+"/"+repo.file,saved,MaxTree,oldError)&&parseModsTree(saved,old,oldError,repo.name)&&write(file,saved,oldError)){++good;report.cached=true;report.entries=unsigned(old.entries.size());}else if(regular(file,MaxTree))unlink(file.c_str());report.detail="No se pudo comprobar: "+why+(report.cached?" Se conserva el índice guardado.":" Sin copia válida.");}
        reports.push_back(std::move(report));
    }
    if(!good){loadModsCatalog(catalog,ignored);catalog.sources=std::move(reports);error="Ninguna fuente pudo comprobarse; se conserva el catálogo anterior.";return false;}
    const auto stamp=std::to_string(std::time(nullptr));if(!write(marker,"NMMODS1\n"+stamp+"\n",error)||!write(root()+"/mods-active.pending",std::string(1,next)+"\n",error))return false;
    const auto activeFile=root()+"/mods-active.txt",previousFile=root()+"/mods-active.previous";
    struct stat state{};if(lstat(previousFile.c_str(),&state)==0&&(!regular(previousFile,8)||unlink(previousFile.c_str())!=0)){error="No se pudo conservar el selector anterior.";return false;}
    const bool had=regular(activeFile,8);if(lstat(activeFile.c_str(),&state)==0&&!had){error="Selector de catálogo no válido.";return false;}
    if(had&&rename(activeFile.c_str(),previousFile.c_str())!=0){error="No se pudo conservar el catálogo anterior.";return false;}
    if(rename((root()+"/mods-active.pending").c_str(),activeFile.c_str())!=0){if(had)rename(previousFile.c_str(),activeFile.c_str());error="No se pudo activar el catálogo preparado.";return false;}
    if(!slot(next,catalog,error))return false;
    catalog.sources=std::move(reports);
    if(complete)write(root()+"/mods-check.txt",stamp+"\n",ignored);
    else error="Algunas fuentes no respondieron. Se indican por separado y se conservan sus copias verificadas.";
    return complete;
}
bool refreshModsCatalog(ModsCatalog&catalog,bool force,std::string&error){
    std::string stamp,why;const bool have=loadModsCatalog(catalog,why);time_t checked=0;
    if(read(root()+"/mods-check.txt",stamp,32,why)){char*end=nullptr;const auto n=std::strtoll(stamp.c_str(),&end,10);if(n>0&&end&&(*end=='\n'||!*end))checked=time_t(n);}
    const auto now=std::time(nullptr);if(!force&&have&&checked>0&&now>=checked&&now-checked<6*60*60){error.clear();catalog.detail+=" · Comprobación guardada de menos de seis horas.";return true;}
    return synchronizeModsCatalog(catalog,error);
}
bool syncModsCatalog(ModsCatalog&catalog,std::string&error,bool force){return refreshModsCatalog(catalog,force,error);}
std::vector<ModEntry> findMods(const Game&game,const ModsCatalog&catalog){std::vector<ModEntry>out;const auto name=normalized(game.name);for(const auto&e:catalog.entries)if(allowsConsoleMod(e)&&(canonicalModApplicationId(e.titleId)==game.id||(!e.titleId&&!name.empty()&&normalized(groupName(e))==name))){auto copy=e;if(modUsesUpdateTitleId(copy.titleId)){copy.titleId=canonicalModApplicationId(copy.titleId);copy.detail+=" Autor indica ID de actualización del mismo juego.";}out.push_back(std::move(copy));}return out;}
bool prepareMod(const Game&game,const ModEntry&entry,ModPayload&payload,std::string&error){
    payload={};error.clear();
    if(entry.format==ModFormat::Archive){
#ifdef NMM_OVERLAY
        error="Revisa e instala el ZIP/RAR desde la aplicación NinMagic Mods.";return false;
#else
        return prepareArchiveMod(game,entry,payload,error);
#endif
    }
    if(entry.format==ModFormat::Unsupported){error="Este paquete no tiene un formato de instalación verificable admitido por la aplicación.";return false;}
    if(!allowsConsoleMod(entry)){error="El origen no acredita este mod para Switch física; no se instalará.";return false;}
    if(!repoFor(entry.repository)){error="Proveedor de mods sin verificar.";return false;}
    if((entry.format==ModFormat::Ips||entry.format==ModFormat::Pchtxt)&&entry.size>2ULL*1024*1024){error="El parche estático supera 2 MiB; no se descargará ni se cargará en memoria.";return false;}
    if(entry.format==ModFormat::Romfs){
        if(!allowedRomfs(game,entry,error))return false;
        payload.game=game;payload.entry=entry;if(modUsesUpdateTitleId(payload.entry.titleId)){payload.entry.titleId=canonicalModApplicationId(payload.entry.titleId);payload.entry.detail+=" Autor indica ID de actualización del mismo juego.";}payload.buildId.clear();uint64_t total=0;
        for(const auto&file:entry.files){if(file.path.rfind(entry.path+"/",0)!=0||titleFromPath(file.path)!=game.id){error="Un archivo RomFS no pertenece al grupo y Title ID declarados.";return false;}ModEntry one=entry;one.path=file.path;one.size=file.size;one.blobSha=file.blobSha;std::string bytes;if(!verifiedBytes(one,bytes,error))return false;total+=bytes.size();if(total>128ULL*1024*1024){error="El grupo RomFS supera 128 MiB.";return false;}
            auto at=upper(file.path).find("/ROMFS/");if(at==std::string::npos||!pathValid(file.path.substr(at+7))){error="Ruta RomFS no canónica.";return false;}PayloadFile output;output.path="atmosphere/contents/"+titleId(game.id)+"/romfs/"+file.path.substr(at+7);output.bytes.assign(bytes.begin(),bytes.end());payload.files.push_back(std::move(output));}
        payload.compatible=true;payload.names={entry.name};payload.detail="Versión RomFS declarada por el autor coincidente; funcionamiento en consola sin certificar.";return true;
    }
    if(!sameIdentity(game)){error=staticIdentityError(game);return false;}
    ModEntry verified=entry;const auto canonical=canonicalModApplicationId(verified.titleId);if(canonical&&canonical==game.id&&modUsesUpdateTitleId(verified.titleId)){verified.titleId=canonical;verified.detail+=" Autor indica ID de actualización del mismo juego.";}
    std::string bytes;if(!verifiedBytes(entry,bytes,error))return false;
    if(!verified.titleId&&entry.format==ModFormat::Pchtxt){bool updateTag=false;const auto declared=titleFromPath(bytes,nullptr,&updateTag);if(declared==game.id){verified.titleId=declared;if(updateTag)verified.detail+=" Autor indica ID de actualización del mismo juego; se conserva la comprobación del Build ID completo y la versión.";}}
    if(verified.titleId!=game.id){error="El mod no declara este Title ID; una coincidencia de nombre no lo habilita.";return false;}
    if(!entry.version.empty()&&(!game.versionKnown||entry.version!=game.version)){error="No compatible con esta versión. Requiere "+entry.version+".";return false;}
    return parseModPayload(game,verified,bytes,payload,error);
}
bool resolveGameMods(const Game&game,std::vector<ModEntry>&entries,std::string&error){
    entries.erase(std::remove_if(entries.begin(),entries.end(),[](const ModEntry&e){return !isBrowsableMod(e);}),entries.end());
    error.clear();bool complete=true;for(auto &e:entries){e.compatible=false;e.selected=false;
        if(e.format==ModFormat::Archive){e.reason="Pulsa A para revisar el ZIP/RAR, su destino y compatibilidad antes de seleccionarlo.";continue;}
        if(e.source=="GameBanana"){if(e.reason.empty())e.reason="GameBanana no declara la versión del juego ni un Build ID verificable: instalación bloqueada.";continue;}
        if(e.format==ModFormat::Archive||e.format==ModFormat::Unsupported)continue;
        if(e.format==ModFormat::Romfs){std::string why;e.compatible=allowedRomfs(game,e,why);e.reason=e.compatible?"Versión declarada coincidente. Revisa los requisitos antes de instalar.":why;continue;}
        if(!sameIdentity(game)){e.reason=staticIdentityError(game);continue;}
        if(!e.version.empty()&&(!game.versionKnown||e.version!=game.version)){e.reason="No compatible con esta versión. Requiere "+e.version+".";continue;}
        if(!e.buildId.empty()&&fullBid(e.buildId)!=upper(game.fullBuildId)){e.reason="No compatible con este Build ID. Requiere "+e.buildId+".";continue;}
        ModPayload payload;std::string why;e.compatible=prepareMod(game,e,payload,why);e.reason=e.compatible?"Build ID completo coincidente. Revisa los requisitos del autor.":why;
        if(e.compatible){e.buildId=payload.buildId;e.titleId=payload.game.id;}
        else if(why.find("HTTPS")!=why.npos||why.find("descarga")!=why.npos||why.find("conectar")!=why.npos)complete=false;
    }if(!complete)error="No se pudieron comprobar todos los archivos; las opciones sin verificar quedan bloqueadas.";return complete;
}
namespace {
// The overlay scans trees from FILE and retains only this game's bounded set.
// It validates the whole JSON document before allowing the small reconstructed
// tree through the same catalog parser as the application.
class FilteredTreeFile {
    FILE *file;const Game &game;const std::string &repository;
    std::array<unsigned char,4096> buffer{};size_t at=0,used=0,consumed=0,items=0,retainedBytes=0;
    bool inputError=false,overBudget=false;std::vector<Raw> matches;
    int peek(){if(inputError)return EOF;if(at==used){used=fread(buffer.data(),1,buffer.size(),file);at=0;if(!used){if(ferror(file))inputError=true;return EOF;}}return buffer[at];}
    int get(){const auto c=peek();if(c!=EOF){++at;if(++consumed>3*1024*1024)inputError=true;}return c;}
    void ws(){int c;while((c=peek())==' '||c=='\n'||c=='\r'||c=='\t')get();}
    bool chr(char c){ws();if(peek()!=c)return false;get();return true;}
    bool code(uint32_t &v){v=0;for(unsigned i=0;i<4;++i){int c=get();if(c==EOF||!std::isxdigit(static_cast<unsigned char>(c)))return false;v=(v<<4)|(c<='9'?c-'0':std::tolower(c)-'a'+10);}return true;}
    static void utf8(std::string &out,uint32_t cp){if(cp<128)out+=char(cp);else if(cp<2048){out+=char(0xc0|(cp>>6));out+=char(0x80|(cp&63));}else if(cp<65536){out+=char(0xe0|(cp>>12));out+=char(0x80|((cp>>6)&63));out+=char(0x80|(cp&63));}else{out+=char(0xf0|(cp>>18));out+=char(0x80|((cp>>12)&63));out+=char(0x80|((cp>>6)&63));out+=char(0x80|(cp&63));}}
    bool string(std::string &out){out.clear();if(!chr('"'))return false;for(;;){const int c=get();if(c==EOF||c<32)return false;if(c=='"')return true;if(c=='\\'){const int e=get();if(e=='"'||e=='\\'||e=='/')out+=char(e);else if(e=='b')out+='\b';else if(e=='f')out+='\f';else if(e=='n')out+='\n';else if(e=='r')out+='\r';else if(e=='t')out+='\t';else if(e=='u'){uint32_t cp=0;if(!code(cp))return false;if(cp>=0xd800&&cp<=0xdbff){if(get()!='\\'||get()!='u')return false;uint32_t low=0;if(!code(low)||low<0xdc00||low>0xdfff)return false;cp=0x10000+((cp-0xd800)<<10)+(low-0xdc00);}else if(cp>=0xdc00&&cp<=0xdfff)return false;utf8(out,cp);}else return false;}else out+=char(c);if(out.size()>8192)return false;}}
    bool number(uint64_t &value){ws();value=0;bool have=false;const bool zero=peek()=='0';while(peek()>='0'&&peek()<='9'){if(zero&&have)return false;unsigned n=unsigned(get()-'0');if(value>(UINT64_MAX-n)/10)return false;value=value*10+n;have=true;}return have;}
    bool literal(const char *word){ws();for(;*word;++word)if(get()!=*word)return false;return true;}
    bool skip(unsigned depth=0){if(depth>32||inputError)return false;ws();const int c=peek();if(c=='"'){std::string ignored;return string(ignored);}if(c=='{'){get();if(chr('}'))return true;do{std::string key;if(!string(key)||!chr(':')||!skip(depth+1))return false;if(chr('}'))return true;}while(chr(','));return false;}if(c=='['){get();if(chr(']'))return true;do{if(!skip(depth+1))return false;if(chr(']'))return true;}while(chr(','));return false;}if(c=='t')return literal("true");if(c=='f')return literal("false");if(c=='n')return literal("null");uint64_t ignored=0;return number(ignored);}
    bool item(Raw &out){if(!chr('{'))return false;std::set<std::string> keys;if(chr('}'))return false;do{std::string key;if(!string(key)||keys.size()>=32||!keys.insert(key).second||!chr(':'))return false;if(key=="path"){if(!string(out.path))return false;}else if(key=="sha"){if(!string(out.sha))return false;}else if(key=="type"){if(!string(out.type))return false;}else if(key=="size"){if(!number(out.size))return false;}else if(!skip())return false;if(chr('}'))return pathValid(out.path)&&hex(out.sha,40)&&!out.type.empty()&&(out.type!="blob"||keys.count("size"));}while(chr(','));return false;}
    bool wanted(const Raw &entry){if(entry.type!="blob")return false;const auto title=titleFromPath(entry.path);if(title)return title==game.id;ModEntry candidate;candidate.path=entry.path;candidate.repository=repository;return normalized(groupName(candidate))==normalized(game.name);}
    static std::string quoted(const std::string &value){std::string out="\"";for(char c:value){if(c=='"'||c=='\\')out+='\\';out+=c;}out+='"';return out;}
public:
    FilteredTreeFile(FILE *input,const Game &selected,const std::string &source):file(input),game(selected),repository(source){}
    bool parse(std::string &small){if(!chr('{'))return false;bool haveTree=false,haveTruncated=false,truncated=false;std::string revision;std::set<std::string> keys;
        do{std::string key;if(!string(key)||keys.size()>=64||!keys.insert(key).second||!chr(':'))return false;if(key=="sha"){if(!string(revision))return false;}else if(key=="truncated"){haveTruncated=true;ws();if(peek()=='t'){if(!literal("true"))return false;truncated=true;}else if(!literal("false"))return false;}else if(key=="tree"){haveTree=true;if(!chr('['))return false;if(!chr(']')){do{Raw entry;if(!item(entry)||++items>30000)return false;const bool relevant=wanted(entry);if(relevant&&matches.size()<128&&!overBudget){const size_t cost=sizeof(Raw)+entry.path.capacity()+entry.sha.capacity()+entry.type.capacity();if(cost>32*1024-retainedBytes)overBudget=true;else{retainedBytes+=cost;matches.push_back(std::move(entry));}}if(chr(']'))break;if(!chr(','))return false;}while(true);}}else if(!skip())return false;if(chr('}'))break;if(!chr(','))return false;}while(true);
        ws();if(inputError||peek()!=EOF||!haveTree||!haveTruncated||truncated||!hex(revision,40)||overBudget)return false;
        small="{\"sha\":"+quoted(revision)+",\"truncated\":false,\"tree\":[";bool first=true;for(const auto &v:matches){if(!first)small+=',';first=false;small+="{\"path\":"+quoted(v.path)+",\"sha\":"+quoted(v.sha)+",\"type\":\"blob\",\"size\":"+std::to_string(v.size)+"}";}small+="]}";return true;
    }
    bool budgetExceeded()const{return overBudget;}
};
bool filteredFile(const std::string &path,const Game &game,const std::string &repository,ModsCatalog &out,std::string &error){
    if(!regular(path,3*1024*1024)){error="El índice del overlay falta o supera 3 MiB.";return false;}FILE *file=fopen(path.c_str(),"rb");if(!file){error="No se pudo abrir el índice del overlay.";return false;}std::string small;bool valid=false,overBudget=false;{FilteredTreeFile parser(file,game,repository);valid=parser.parse(small);overBudget=parser.budgetExceeded();}const bool closed=fclose(file)==0;
    if(overBudget){error="Los metadatos de este juego superan el presupuesto del overlay. Consulta la fuente desde la aplicación.";return false;}
    if(!valid||!closed){error="Índice Git incompleto, truncado o inválido; el overlay no lo utilizará.";return false;}return parseModsTree(small,out,error,repository);
}
}
#ifndef NMM_OVERLAY
bool resolveArchiveModMetadata(const Game&game,ModEntry&entry,std::string&error){
    error.clear();if(entry.source=="GameBanana")return refreshGameBananaMod(game,entry,error);
    if(!canInspectConsoleArchive(entry)){error="No se puede revisar la procedencia de este paquete.";return false;}
    if(entry.titleId)return canonicalModApplicationId(entry.titleId)==game.id;
    // A sibling PCHTXT is the author's identity declaration, not a name match.
    // Only a version-labelled file from the same repository/game folder may
    // establish the archive's Title ID; its content hash is checked separately.
    for(const auto&file:entry.files){const auto declaredVersion=pathVersion(file.path);if(declaredVersion.empty()||!game.versionKnown||declaredVersion!=game.version||(!entry.version.empty()&&entry.version!=declaredVersion)||gameGroup(entry.repository,file.path)!=gameGroup(entry.repository,entry.path)||format(file.path)!=ModFormat::Pchtxt)continue;ModEntry one=entry;one.path=file.path;one.blobSha=file.blobSha;one.size=file.size;std::string bytes;if(!verifiedBytes(one,bytes,error))return false;bool ambiguous=false;const auto tid=titleFromPath(bytes,&ambiguous);if(ambiguous||(tid&&tid!=game.id)){error="El PCHTXT del autor declara otro Title ID.";return false;}if(tid==game.id){entry.titleId=tid;entry.version=declaredVersion;entry.detail+=" Title ID declarado en PCHTXT del mismo autor, carpeta y versión, con hash Git comprobado.";return true;}}
    // Archives can still declare their own exact ID in an Atmosphere root.
    return true;
}
bool obtainArchiveModFile(const Game&game,const ModEntry&entry,std::string&path,std::string&error){
    path.clear();error.clear();if(!canInspectConsoleArchive(entry)){error="Fuente o formato ZIP/RAR sin verificar.";return false;}
    if(entry.source=="GameBanana")return obtainGameBananaArchive(game,entry,path,error);
    const auto *provider=repoFor(entry.repository);
    if(!provider||entry.branch!=provider->branch||!pathValid(entry.path)||!hex(entry.blobSha,40)||!hex(entry.revision,40)||!entry.size||entry.size>MaxModArchive){error="Paquete Git sin identidad o tamaño comprobable (máximo 128 MiB).";return false;}
    if(!ensureRoot(error)||!dir(root()+"/mod-archives",true,error))return false;
    const auto target=root()+"/mod-archives/"+entry.blobSha+".archive",pending=target+".pending";
    const auto matches=[&](const std::string&file){std::string sha,git;uint64_t bytes=0;return hashModArchiveFile(file,sha,git,bytes,error)&&bytes==entry.size&&git==entry.blobSha;};
    if(matches(target)){path=target;error.clear();return true;}error.clear();
    const auto url="https://raw.githubusercontent.com/"+entry.repository+"/"+entry.revision+"/"+encode(entry.path);
    if(!downloadModArchiveHttps(url,pending,entry.size,error))return false;
    if(!matches(pending)){if(regular(pending,MaxModArchive))unlink(pending.c_str());error="El ZIP/RAR no coincide con su tamaño y SHA Git. Actualiza las fuentes.";return false;}
    struct stat st{};if(lstat(target.c_str(),&st)==0&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode))){error="La caché del paquete no es un archivo normal.";return false;}
    if(regular(target,MaxModArchive)&&unlink(target.c_str())){error="No se pudo retirar la caché inválida.";return false;}
    if(rename(pending.c_str(),target.c_str())){error="No se pudo conservar el ZIP/RAR verificado.";return false;}path=target;return true;
}
#endif
bool loadOverlayMods(const Game&game,std::vector<ModEntry>&entries,std::string&error,bool force){
    constexpr size_t TreeLimit=3*1024*1024,EntryLimit=128,PatchLimit=128*1024;
    entries.clear();error.clear();if(!ensureRoot(error))return false;
    const auto selected=active();const auto folder=root()+"/mods-"+selected;if(!dir(folder,true,error))return false;
    unsigned valid=0,failed=0,stale=0;bool capped=false;std::set<std::string>seen;
    for(const auto &provider:Repos){
        if(entries.size()==EntryLimit){capped=true;break;}
        const auto file=folder+"/"+provider.file,pending=file+".pending",previous=file+".previous";
        std::string why;ModsCatalog one;bool have=filteredFile(file,game,provider.name,one,why);
        struct stat state{};
        if(force||!have){
            // Release the prior parsed source before receiving another large tree.
            one={};ModsCatalog checked;
            if(downloadModHttps(std::string("https://api.github.com/repos/")+provider.name+"/git/trees/"+provider.branch+"?recursive=1",pending,TreeLimit,why)&&filteredFile(pending,game,provider.name,checked,why)){
                bool committed=true;const bool prior=regular(file,MaxTree);
                if(lstat(file.c_str(),&state)==0&&!prior)committed=false;
                if(lstat(previous.c_str(),&state)==0&&(!regular(previous,MaxTree)||unlink(previous.c_str())!=0))committed=false;
                if(committed&&prior&&rename(file.c_str(),previous.c_str())!=0)committed=false;
                if(committed&&rename(pending.c_str(),file.c_str())!=0){if(prior)rename(previous.c_str(),file.c_str());committed=false;}
                if(committed){if(prior)unlink(previous.c_str());one=std::move(checked);have=true;}
                else {checked={};have=filteredFile(file,game,provider.name,one,why);if(have)++stale;}
            }else {checked={};have=filteredFile(file,game,provider.name,one,why);if(have)++stale;}
            if(regular(pending,TreeLimit))unlink(pending.c_str());
        }
        if(!have){++failed;continue;}++valid;
        const auto name=normalized(game.name);
        for(auto &candidate:one.entries){if(!allowsConsoleMod(candidate)||(canonicalModApplicationId(candidate.titleId)!=game.id&&(candidate.titleId||name.empty()||normalized(groupName(candidate))!=name)))continue;if(entries.size()==EntryLimit){capped=true;break;}if(!seen.insert(candidate.id).second)continue;if(modUsesUpdateTitleId(candidate.titleId)){candidate.titleId=canonicalModApplicationId(candidate.titleId);candidate.detail+=" Autor indica ID de actualización del mismo juego.";}entries.push_back(std::move(candidate));}
    }
    if(!valid){error="No se pudo comprobar un índice Git válido: red, formato o presupuesto del overlay. Usa la aplicación para consultar las fuentes completas; este error no significa que no existan mods.";return false;}
    // Complete markers are written only after at least one validated tree exists.
    std::string ignored;write(folder+"/complete.txt","NMMODS1\n"+std::to_string(std::time(nullptr))+"\n",ignored);
    for(auto &entry:entries){entry.compatible=false;entry.selected=false;
        if(entry.format==ModFormat::Archive||entry.format==ModFormat::Unsupported)continue;
        if(entry.format==ModFormat::Romfs){entry.reason="Paquete RomFS: usa la aplicación NinMagic Mods para verificar e instalar todos sus archivos.";continue;}
        if(!entry.size||entry.size>PatchLimit){entry.reason="Parche de más de 128 KiB: revísalo desde la aplicación NinMagic Mods.";continue;}
        if(!entry.version.empty()&&(!game.versionKnown||entry.version!=game.version)){entry.reason="No compatible con esta versión. Requiere "+entry.version+".";continue;}
        ModPayload payload;std::string why;entry.compatible=prepareMod(game,entry,payload,why)&&payload.ips.size()<=PatchLimit;
        entry.reason=entry.compatible?"Build ID completo coincidente. Seleccionar prepara la instalación; aún no está aplicado.":(why.empty()?"El parche convertido supera el límite del overlay; usa la aplicación.":why);
        if(entry.compatible){entry.buildId=payload.buildId;entry.titleId=payload.game.id;}
    }
    if(failed)error=std::to_string(failed)+" fuentes no se pudieron comprobar o superan los límites de memoria del overlay. Consulta las fuentes completas desde la aplicación.";
    if(stale){if(!error.empty())error+=' ';error+=std::to_string(stale)+" fuentes no respondieron; se conservan sus índices guardados.";}
    if(capped){if(!error.empty())error+=' ';error+="Se muestran hasta 128 opciones; consulta el catálogo completo desde la aplicación.";}
    return true;
}
}
