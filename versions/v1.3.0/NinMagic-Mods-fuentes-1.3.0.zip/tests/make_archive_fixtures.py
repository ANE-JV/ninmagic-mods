"""Generate tiny, original archive fixtures; never contains game data.
RAR4 STORE is constructed from the documented headers. RAR5 fixtures are made
with WinRAR when present and are committed so running tests needs no WinRAR.
"""
from pathlib import Path
import os, stat, struct, subprocess, zipfile, zlib
root=Path(__file__).resolve().parent/'fixtures'/'archives'
root.mkdir(parents=True,exist_ok=True)
bid='112233445566778899AABBCCDDEEFF00'+'0'*32
tid='0100300012F2A000'
patch=f'@nsobid-{bid}\n# Demo [{tid}]\n@flag offset_shift 0x100\n@enabled\n00001000 20008052\n@stop\n'.encode()
resource=f'wrap/1.0.0/atmosphere/contents/{tid}/romfs/model/test.bin'
def zipmake(name,items):
    with zipfile.ZipFile(root/name,'w',compression=zipfile.ZIP_DEFLATED) as f:
        for key,value in items:f.writestr(key,value)
zipmake('patch.zip',[('wrap/exefs/1.0.0.pchtxt',patch)])
zipmake('contradictory-title.zip',[('wrap/exefs/1.0.0.pchtxt',patch.replace(tid.encode(),b'0100300012F2B000'))])
ips=b'IPS32'+struct.pack('>IH',0x1100,4)+bytes.fromhex('20008052')+b'EEOF'
zipmake('author-release.zip',[('atmosphere/exefs_patches/Demo/'+bid+'.ips',ips)])
zipmake('romfs.zip',[(resource,b'original test data')])
zipmake('mixed.zip',[('wrap/exefs/1.0.0.pchtxt',patch),(resource,b'test')])
zipmake('traversal.zip',[('../'+resource,b'test')])
zipmake('backslash-traversal.zip',[(r'wrap\..\romfs\x.bin',b'test')])
zipmake('absolute.zip',[('/romfs/x.bin',b'test')])
zipmake('colon.zip',[('romfs/x.bin:stream',b'test')])
zipmake('alias.zip',[(resource,b'x'),(resource.upper(),b'y')])
zipmake('duplicate-target.zip',[(resource,b'x'),('other/'+resource,b'y')])
zipmake('file-parent.zip',[(resource,b'x'),(resource+'/child.bin',b'y')])
zipmake('wrong-title.zip',[(resource.replace(tid,'0100300012F2B000'),b'test')])
zipmake('plugin.zip',[('atmosphere/contents/'+tid+'/exefs/main.nso',b'NSO0')])
zipmake('cheats.zip',[('atmosphere/contents/'+tid+'/cheats/'+bid[:16]+'.txt',b'[Cheat]\n')])
zipmake('nested.zip',[(resource, b'x'),('inner.zip',b'PK00')])
zipmake('emulator.zip',[(resource,b'x'),('README.txt',b'This mod is emulator only.')])
zipmake('unversioned.zip',[('romfs/model/test.bin',b'x')])
zipmake('multi-version.zip',[(resource,b'x'),('wrap/2.0.0/romfs/model/other.bin',b'y')])
zipmake('unknown.zip',[('payload.dat',b'x')])
with zipfile.ZipFile(root/'symlink.zip','w') as f:
    s=zipfile.ZipInfo('romfs/model/link');s.create_system=3;s.external_attr=(stat.S_IFLNK|0o777)<<16;f.writestr(s,'../../outside')
data=(root/'patch.zip').read_bytes();(root/'truncated.zip').write_bytes(data[:-5])
data=bytearray(data);local=data.index(b'PK\x03\x04');central=data.index(b'PK\x01\x02');data[local+6]|=1;data[central+8]|=1;(root/'encrypted.zip').write_bytes(data)
data=bytearray((root/'patch.zip').read_bytes());data[-22+4]=1;(root/'split.zip').write_bytes(data)
data=bytearray((root/'patch.zip').read_bytes());central=data.index(b'PK\x01\x02');struct.pack_into('<I',data,central+24,33*1024*1024);(root/'oversized.zip').write_bytes(data)
data=bytearray((root/'patch.zip').read_bytes());central=data.index(b'PK\x01\x02');data[14]^=1;data[central+16]^=1;(root/'crc.zip').write_bytes(data)
def block(body):return struct.pack('<H',zlib.crc32(body)&0xffff)+body
def rar4(items):
    out=b'Rar!\x1a\x07\0'+block(struct.pack('<BHH6s',0x73,0,13,b'\0'*6))
    for name,data in items:
        name=name.encode();head=struct.pack('<BHHIIBIIBBHI',0x74,0x8000,32+len(name),len(data),len(data),3,zlib.crc32(data),0,20,0x30,len(name),0o100644)+name
        out+=block(head)+data
    return out+block(struct.pack('<BHH',0x7b,0,7))
(root/'romfs-rar4.rar').write_bytes(rar4([(resource,b'original test data')]))
(root/'patch-rar4.rar').write_bytes(rar4([('wrap/exefs/1.0.0.pchtxt',patch)]))
data=bytearray((root/'patch-rar4.rar').read_bytes());data[10]|=1;(root/'split-rar4.rar').write_bytes(data)
rar=Path(os.environ.get('NMM_RAR_EXE',r'C:\Program Files\WinRAR\Rar.exe'))
if rar.is_file():
    stage=root/'rar-source';(stage/'wrap/exefs').mkdir(parents=True,exist_ok=True);(stage/'wrap/exefs/1.0.0.pchtxt').write_bytes(patch)
    for name,extra in [('patch-rar5.rar',[]),('encrypted-rar5.rar',['-pfixture-password']),('large-dictionary-rar5.rar',['-md64m'])]:
        subprocess.run([str(rar),'a','-ma5','-m3','-md4m','-idq','-o+',*extra,str(root/name),'wrap'],cwd=stage,check=True)
    # WinRAR shrinks dictionaries for tiny files. Forge only the declared
    # dictionary and recompute the header CRC so preflight sees a real 64MiB
    # request before any decompressor allocation.
    data=bytearray((root/'patch-rar5.rar').read_bytes())
    def vint(at):
        value=0;shift=0
        while True:
            b=data[at];at+=1;value|=(b&127)<<shift
            if not b&128:return value,at
            shift+=7
    def encode(value):
        out=bytearray()
        while value>=128:out.append((value&127)|128);value>>=7
        out.append(value);return out
    pos=8
    while pos<len(data):
        length,begin=vint(pos+4);typ,at=vint(begin);flags,at=vint(at);extra=packed=0
        if flags&1:extra,at=vint(at)
        if flags&2:packed,at=vint(at)
        if typ==2:
            fileflags,at=vint(at);unpacked,at=vint(at);attributes,at=vint(at)
            if fileflags&2:at+=4
            if fileflags&4:at+=4
            start=at;compression,at=vint(at)
            replacement=encode((compression&~(15<<10))|(9<<10))
            if len(replacement)==at-start:
                data[start:at]=replacement
                struct.pack_into('<I',data,pos,zlib.crc32(data[pos+4:begin+length]));break
        pos=begin+length+packed
    (root/'large-dictionary-rar5.rar').write_bytes(data)
print(root)
