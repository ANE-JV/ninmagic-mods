#define _POSIX_C_SOURCE 200809L
#define NM_GAMEBANANA_TEST
#include <cstddef>
#include <cstdlib>
#include <new>
#include <algorithm>
namespace allocation_meter {struct alignas(std::max_align_t) Header{size_t bytes;};size_t live=0,peak=0;}
void *operator new(size_t n){using namespace allocation_meter;auto*h=static_cast<Header*>(std::malloc(sizeof(Header)+n));if(!h)throw std::bad_alloc();h->bytes=n;live+=n;peak=std::max(peak,live);return h+1;}
void operator delete(void*p)noexcept{if(p){using namespace allocation_meter;auto*h=static_cast<Header*>(p)-1;live-=h->bytes;std::free(h);}}
void *operator new[](size_t n){return ::operator new(n);}void operator delete[](void*p)noexcept{::operator delete(p);}void operator delete(void*p,size_t)noexcept{::operator delete(p);}void operator delete[](void*p,size_t)noexcept{::operator delete(p);}
#include "../source/gamebanana.cpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <chrono>
namespace fs=std::filesystem;
namespace nmm {unsigned queries=0,downloads=0;bool failNetwork=false,invalidReply=false;std::string indexFixture,detailFixture,archiveBody;
bool downloadGameBananaHttps(const std::string&url,const std::string&path,uint64_t cap,std::string&error){++queries;if(failNetwork){error="network offline";return false;}const auto &data=invalidReply?std::string("{bad json"):url.find("/Index?")!=url.npos?indexFixture:detailFixture;if(data.size()>cap){error="response too large";return false;}std::ofstream(path,std::ios::binary)<<data;return true;}
bool downloadGameBananaArchiveHttps(const std::string&,const std::string&path,uint64_t cap,std::string&error){++downloads;if(failNetwork||archiveBody.size()>cap){error="archive offline or large";return false;}std::ofstream(path,std::ios::binary)<<archiveBody;return true;}}
namespace {unsigned checks=0;void check(bool ok,const char*why){++checks;if(!ok)throw std::runtime_error(std::string(why)+" (#"+std::to_string(checks)+")");}
std::string read(const std::string&p){std::ifstream f(p,std::ios::binary);std::ostringstream s;s<<f.rdbuf();return s.str();}
void replace(std::string&s,const std::string&a,const std::string&b){auto p=s.find(a);if(p==s.npos)throw std::runtime_error("fixture marker absent: "+a);s.replace(p,a.size(),b);}
std::string md5(const std::string&s){nmm::gb::Md5 h;h.add(reinterpret_cast<const uint8_t*>(s.data()),s.size());return h.finish();}
nmm::Game game(){nmm::Game g;g.id=0x010015100B514000ULL;g.name="Super Mario Bros. Wonder";g.version="1.2.1";g.versionKnown=true;return g;}
std::string minimal(const std::string&description="",const std::string&file="a.zip"){
return "{\"_idRow\":556710,\"_sName\":\"Vegeta\",\"_sProfileUrl\":\"https://gamebanana.com/mods/556710\",\"_sVersion\":\"9.9.9\",\"_aGame\":{\"_idRow\":18604,\"_sName\":\"Super Mario Bros. Wonder\"},\"_aSubmitter\":{\"_sName\":\"Author\"},\"_sText\":\""+description+"\",\"_aFiles\":[{\"_idRow\":1325083,\"_sFile\":\""+file+"\",\"_nFilesize\":"+std::to_string(nmm::archiveBody.size())+",\"_sDownloadUrl\":\"https://gamebanana.com/dl/1325083\",\"_sMd5Checksum\":\""+md5(nmm::archiveBody)+"\"}]}";}
}
int main(){try{
    auto g=game();std::string error;nmm::ModEntry e;std::vector<nmm::ModEntry> list;
    nmm::indexFixture=read("tests/fixtures/gamebanana-wonder-index.json");nmm::detailFixture=read("tests/fixtures/gamebanana-vegeta.json");check(!nmm::indexFixture.empty()&&!nmm::detailFixture.empty(),"live fixtures present");
    check(md5("")=="d41d8cd98f00b204e9800998ecf8427e"&&md5("abc")=="900150983cd24fb0d6963f7d28e17f72","published checksum known answers");
    check(md5(std::string(1000000,'a'))=="7707d6ae4e027c70eea2a935c2296f21","streamed checksum large input");
    size_t base=allocation_meter::live;allocation_meter::peak=base;
    check(nmm::parseGameBananaMods(g,18604,nmm::indexFixture,list,error)&&list.size()==15,"real paginated index");
    auto peak=allocation_meter::peak-base;check(peak<768*1024,"real index retained memory bound");
    check(list[0].format==nmm::ModFormat::Archive&&!list[0].compatible&&!list[0].consoleOnly&&nmm::canInspectConsoleArchive(list[0]),"index is inspectable not installable");
    check(nmm::parseGameBananaMod(g,18604,556710,nmm::detailFixture,e,error)&&e.gbFileId==1325083&&e.fileName=="vegeta_0b8dc.rar"&&e.gbFileMd5=="8daa677c3e26eeaa5b2a0ff9cfaf2919","real Vegeta RAR and published file identity");
    check(e.version.empty()&&e.modVersion=="1.0"&&!e.compatible&&!e.consoleOnly&&!nmm::allowsConsoleMod(e),"mod version and platform category never authorize install");
    auto wrong=g;wrong.id=0x010093801237C000ULL;check(!nmm::parseGameBananaMod(wrong,18604,556710,nmm::detailFixture,e,error),"wrong title mapping rejected");
    std::string bad=nmm::detailFixture;replace(bad,"gamebanana.com","evil.test");check(!nmm::parseGameBananaMod(g,18604,556710,bad,e,error),"wrong source host rejected");
    nmm::archiveBody=std::string("PK\3\4",4)+std::string(4000,'a');
    check(nmm::parseGameBananaMod(g,18604,556710,minimal("Game version: 1.2.1. Tested on real hardware."),e,error)&&e.version=="1.2.1"&&e.consoleOnly&&!e.compatible,"explicit author platform and game version only metadata");
    check(nmm::parseGameBananaMod(g,18604,556710,minimal("Not supported game version: 1.2.1. Tested on real hardware."),e,error)&&e.version.empty(),"negated game version ignored");
    check(nmm::parseGameBananaMod(g,18604,556710,minimal("Game version: 1.2.1 - 1.4.0. Tested on real hardware."),e,error)&&e.version.empty(),"version range not guessed");
    check(nmm::parseGameBananaMod(g,18604,556710,minimal("Game version: 1.2.1. Not tested on real hardware."),e,error)&&!e.consoleOnly,"negated physical statement");
    check(nmm::parseGameBananaMod(g,18604,556710,minimal("Do not copy to atmosphere/contents/010015100B514000."),e,error)&&!e.consoleOnly,"negated installation path");
    check(nmm::parseGameBananaMod(g,18604,556710,minimal("Copy files to atmosphere/contents/010015100B514000. Game version: 1.2.1"),e,error)&&e.consoleOnly,"author exact title installation path");
    check(!nmm::parseGameBananaMod(g,18604,556710,minimal("Yuzu only. Game version: 1.2.1"),e,error),"emulator exclusive excluded");
    check(nmm::parseGameBananaMod(g,18604,556710,minimal("Tested on real hardware. "+std::string(1500,'x')+". Not tested on Switch hardware."),e,error)&&!e.consoleOnly&&nmm::hasRejectedConsoleProvenance(e),"negative provenance beyond UI summary preserved");
    check(nmm::parseGameBananaMod(g,18604,556710,minimal("","../a.zip"),e,error)&&e.gbFileId==0&&e.format==nmm::ModFormat::Unsupported,"archive filename traversal rejected");
    check(nmm::parseGameBananaMod(g,18604,556710,minimal("","a.exe"),e,error)&&e.gbFileId==0,"nonarchive excluded");
    bad=minimal();replace(bad,"https://gamebanana.com/dl/1325083","https://gamebanana.com.evil.test/dl/1325083");check(nmm::parseGameBananaMod(g,18604,556710,bad,e,error)&&e.gbFileId==0,"download host rejected");
    bad=minimal();replace(bad,"\"_idRow\":556710","\"_idRow\":556710,\"_idRow\":556710");check(!nmm::parseGameBananaMod(g,18604,556710,bad,e,error),"duplicate identity key rejected");
    bad=minimal();replace(bad,"\"Vegeta\"","\"\\uD800\"");check(!nmm::parseGameBananaMod(g,18604,556710,bad,e,error),"invalid unicode rejected");
    check(!nmm::parseGameBananaMods(g,18604,std::string(nmm::gb::MaxJson+1,' '),list,error),"oversize body rejected");
    std::string adversary="{\"_aRecords\":[";for(unsigned i=0;i<1590;++i){if(i)adversary+=',';adversary+="{\"_sName\":\"x\"}";}adversary+="]}";
    base=allocation_meter::live;allocation_meter::peak=base;check(!nmm::parseGameBananaMods(g,18604,adversary,list,error),"adversarial retained nodes bounded");peak=std::max(peak,allocation_meter::peak-base);check(peak<768*1024,"malformed DOM peak bounded");
    const auto cache=fs::absolute(fs::path("dist")/("gamebanana-cache-130-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count())));fs::create_directories(cache);setenv("NM_GAMEBANANA_ROOT",cache.generic_string().c_str(),1);
    nmm::detailFixture=minimal("Game version: 1.2.1. Tested on real hardware.");
    base=allocation_meter::live;allocation_meter::peak=base;check(nmm::loadGameBananaMods(g,list,error,true)&&!list.empty(),"live provider indexing and cache write");peak=std::max(peak,allocation_meter::peak-base);check(peak<768*1024,"full provider peak bounded");
    auto before=nmm::queries;check(nmm::loadGameBananaMods(g,list,error,false)&&nmm::queries==before,"fresh metadata cached");
    nmm::invalidReply=true;check(nmm::loadGameBananaMods(g,list,error,true)&&!list.empty()&&!error.empty(),"invalid network response preserves valid cache");nmm::invalidReply=false;
    nmm::failNetwork=true;check(nmm::loadGameBananaMods(g,list,error,true)&&!list.empty()&&!error.empty(),"offline fallback preserves cached game metadata");nmm::failNetwork=false;
    const std::string single=nmm::detailFixture,filesKey="\"_aFiles\":[";const auto begin=single.find(filesKey)+filesKey.size();auto file=single.substr(begin,single.size()-begin-2);replace(file,"1325083","1325084");replace(file,"1325083","1325084");replace(file,"a.zip","alternate.zip");std::string variants=single;variants.insert(variants.size()-2,","+file);
    check(nmm::parseGameBananaMod(g,18604,556710,variants,e,error)&&e.gbFileId==0&&e.format==nmm::ModFormat::Archive,"multiple downloads stay unchosen");
    nmm::detailFixture=variants;std::vector<nmm::ModEntry> files;check(nmm::loadGameBananaModFiles(g,e,files,error,true)&&files.size()==2&&files[1].gbFileId==1325084&&files[1].id=="GameBanana|556710|1325084","all active archive variants enumerated");
    check(!nmm::refreshGameBananaMod(g,e,error,true),"parent with alternatives never silently picks first");e=files[1];check(nmm::refreshGameBananaMod(g,e,error,true)&&e.gbFileId==1325084,"selected variant refreshed by exact file ID");
    nmm::detailFixture=single;
    check(nmm::parseGameBananaMod(g,18604,556710,nmm::detailFixture,e,error)&&nmm::refreshGameBananaMod(g,e,error,true),"detail refresh before inspection");
    const auto reviewed=e;check(e.gbRequirementsHash.size()==64,"complete author requirements fingerprint recorded");
    for(const auto &changed:{std::string("Game version: 2.0.0. Tested on real hardware."),std::string("Tested on real hardware."),std::string("Game version: 1.2.1."),std::string("Game version: 1.2.1. Tested on real hardware. Requires another mod."),std::string("Game version: 1.2.1. Tested on real hardware. ")+std::string(1500,'x')+" Not tested on Switch hardware."}){
        nmm::detailFixture=minimal(changed);e=reviewed;e.archiveInspected=true;check(!nmm::refreshGameBananaMod(g,e,error,true)&&e.gbRequirementsHash==reviewed.gbRequirementsHash,"same file with changed/removed requirements invalidates reviewed approval");
#ifndef NMM_OVERLAY
        e.archiveInspected=false;std::string stalePath;check(!nmm::obtainGameBananaArchive(g,e,stalePath,error)&&stalePath.empty(),"old archive approval cannot bypass changed requirements");
#endif
    }
    nmm::detailFixture=minimal("Game version: 2.0.0. Tested on real hardware.");e=reviewed;e.archiveInspected=false;check(nmm::refreshGameBananaMod(g,e,error,true)&&e.version=="2.0.0"&&e.gbRequirementsHash!=reviewed.gbRequirementsHash,"explicit new inspection can load corrected requirements");
    nmm::detailFixture=single;e=reviewed;
    std::string path;
#ifdef NMM_OVERLAY
    check(!nmm::obtainGameBananaArchive(g,e,path,error)&&nmm::downloads==0,"overlay cannot download archives");
#else
    check(nmm::obtainGameBananaArchive(g,e,path,error)&&fs::exists(path)&&nmm::downloads==1,"verified private archive acquisition");
    nmm::failNetwork=true;check(nmm::obtainGameBananaArchive(g,e,path,error)&&nmm::downloads==1,"verified existing archive works offline");nmm::failNetwork=false;
    nmm::detailFixture=minimal("Game version: 1.2.1. Tested on real hardware.");nmm::detailFixture.insert(1,"\"_bIsTrashed\":true,");check(!nmm::obtainGameBananaArchive(g,e,path,error)&&path.empty(),"author withdrawal cannot resurrect cached package");
    nmm::detailFixture=minimal("Game version: 1.2.1. Tested on real hardware.");replace(nmm::detailFixture,md5(nmm::archiveBody),std::string(32,'0'));check(!nmm::obtainGameBananaArchive(g,e,path,error)&&path.empty(),"changed upstream fingerprint blocks stale file");
    nmm::detailFixture=minimal("Game version: 1.2.1. Tested on real hardware.");nmm::archiveBody[7]='b';fs::remove(cache/(nmm::titleId(g.id)+"-556710-1325083-"+e.gbFileMd5+".archive"));check(!nmm::obtainGameBananaArchive(g,e,path,error)&&path.empty(),"corrupt download rejected");
#endif
    std::cout<<"GameBanana: "<<checks<<" identity, ZIP/RAR, cache, platform/version and checksum checks PASS; peak increment "<<peak<<" bytes\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
