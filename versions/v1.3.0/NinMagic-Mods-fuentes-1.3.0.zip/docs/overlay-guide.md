# NinMagic Mods 1.3.0: overlay

El paquete instala `switch/.overlays/ninmagic-mods.ovl`. Se necesita un cargador de overlays compatible, como Ultrahand o Tesla. El paquete no cambia el cargador ni su combinación de botones.

En la 1.2.1, el control de memoria usa el heap real del allocator aunque el cargador no declare un descriptor HBABI. Conserva los límites y el margen de memoria; cuando no cabe una operación, muestra la capacidad, el uso y el presupuesto requerido en KiB. La versión del overlay aparece en el encabezado para comprobar que se renovó después de actualizar el NRO.

1. Abre el juego y el menú de Ultrahand. Elige **NinMagic Mods**.
2. **X** consulta Git y GameBanana para el proceso abierto. **R** muestra fuente, tipo y requisitos. Un ZIP/RAR pendiente indica **ABRIR EN APLICACIÓN** para revisar su contenido.
3. **A** marca parches compatibles. **Y** vuelve a preparar los archivos pequeños, comprueba los conflictos y muestra la revisión. **A** confirma la escritura del IPS en la microSD.
4. **Cierra y vuelve a abrir el juego**: Atmosphère carga ese IPS durante el siguiente inicio. Guardarlo no modifica la memoria del juego abierto.
5. Los recursos **RomFS** se instalan desde el NRO en modo aplicación con el juego cerrado. Para retirar mods usa también la aplicación con el juego cerrado.

**Arriba/abajo** mueve la selección. **B** vuelve o esconde el panel para jugar. **ZL** cambia de lado. **ZR** guarda una selección opcional para revisar en la aplicación; los IPS necesitan que el juego siga abierto cuando la abras desde Álbum. **L** limpia esa cola, conservando los mods instalados. **−** muestra ayuda. **+** sale al menú de overlays cuando termina la operación. Durante una consulta, **X** solicita cancelarla. Una transacción ya confirmada debe terminar antes de salir.

El overlay no hace búsquedas de RAM ni escribe memoria del juego. Solo prepara IPS/IPS32 para el siguiente inicio y conserva copias y recibos. Cada escritura revalida el PID, el Build ID completo y los contenidos actuales; si cambian, bloquea la confirmación o conserva un registro de recuperación. Los archivos ajenos modificados no se sobrescriben durante la retirada. Un IPS de NinMagic nunca se renombra para otra versión.

La revisión comprueba identidad y conflictos estáticos; no demuestra que el autor haya probado el efecto en esa consola. Las entradas con datos de compatibilidad ausentes siguen bloqueadas. ZIP/RAR se consultan como metadatos y se revisan desde el NRO; nunca se descomprimen en el overlay. No se admiten 7z ni dependencias no soportadas.

Límites del overlay: 128 resultados, 32 opciones, 128 KiB de archivos de parche y 8 KiB de escrituras estáticas combinadas. Los modelos no se descargan desde él. Los respaldos de otros dominios se verifican y conservan por bloques sin cargarlos completos en RAM. Si un parche o respaldo individual excede el límite del overlay, indica que se use la aplicación.

La caché compacta tiene 256 KiB como máximo. Una lista antigua sin huella de contenidos se invalida. Los IDs de una cola no autorizan una instalación: se vuelven a comprobar los archivos, el contexto y el Build ID. Una lista guardada necesita **X** para volver a habilitar parches en el proceso actual. La reserva de memoria del cargador no se modifica; si falta memoria, se conserva la caché y se indica que se use la aplicación.

## Código y atribuciones

La interfaz usa [libtesla de WerWolv](https://github.com/WerWolv/libtesla), distribuida bajo **GNU GPL v2 o posterior**. Se conserva su código y licencia en `overlay/deps/libtesla`. Su rasterizador usa `stb_truetype.h`, con la licencia incluida en ese mismo archivo. El código fuente correspondiente se distribuye con la aplicación.

El adaptador HTTPS nativo y el armazón de renderizado se adaptaron del proyecto NinMagic Cheats del mismo autor. Este overlay usa el espacio de nombres `nmm` y sus propios destinos y controles; no modifica la aplicación Cheats.

El logo y el icono son los recursos de **NinMagic Mods**. La licencia de la fuente incluida se conserva en `romfs/FONT-LICENSE.txt`. Los mods continúan perteneciendo a sus autores; el catálogo muestra las fuentes y no redistribuye paquetes de GameBanana.
