# ZIP/RAR in NinMagic Mods 1.3.0

The application inspects one selected download; catalog discovery does not
download every package. The overlay lists packages and directs the player to
the NRO. It never links libarchive, decompresses archives, or installs them.

Supported readers are ZIP stored/deflate, RAR4, and RAR5. The pinned libarchive
3.8.10 build links only zlib; optional crypto, XML and other compression
dependencies are disabled. `tools/build-libarchive-switch.sh` verifies the
upstream tarball SHA-256 and builds the static Switch library. Newlib declares
`fchdir` without providing the linker symbol and names its timezone global
`_timezone`; the build flags avoid conflicting fallback declarations in unused
disk-extraction/writer objects. Those objects are not used by this application.

The application never extracts an archive directly into SD or game paths.
Downloads are private cache files with exact published size and source hash:
Git blob SHA-1 for an immutable Git tree revision; file MD5 published by
GameBanana plus HTTPS and current file metadata. The actual archive SHA-256 is
bound to the user's inspection. Preparation reads and checks the package again,
including current GameBanana game-version/provenance declarations.

Paths must be relative, ASCII, and unambiguous on the SD filesystem. Traversal,
absolute paths, links, sparse files, duplicate case aliases, file/directory
collisions and duplicate final destinations are rejected. Recognized wrapper
directories can contain `romfs`, `exefs`, or native Atmosphere paths. All declared
Title IDs must resolve to the selected game's Application ID. Executables,
runtime plugins, cheats, saves, unexpected configuration roots and nested
archives are not automatically installed. Small readme/license/description
documents are read for explicit emulator-only restrictions and then discarded.

Limits are 128 MiB compressed, 128 MiB decoded total, 32 MiB per resource,
1024 archive entries, 512 installed files, and 32 MiB for a declared RAR5
dictionary. Inspection streams RomFS through a 64 KiB scratch buffer and retains
no aggregate resource data. libarchive checks decoded sizes and checksums; an
interrupted or damaged member aborts the whole preparation. RAR5's decoder may
allocate both a dictionary and a same-sized filter buffer. Split, encrypted,
self-extracting, ZIP64 and unsupported-compression packages are refused.

RomFS requires a verified installed Title ID/content identity and an explicit,
matching author game version. A mod's own revision is never a game version.
Static IPS/PCHTXT requires the live game's PID and complete NSO Build ID. A
matching name is only discovery. If a Cucholix release archive lacks a Title ID,
a content-addressed PCHTXT from the same author's game directory and exact
version may establish the Title ID. Archives can also declare their exact ID
internally. Native Atmosphere layout can establish physical-console package
provenance; emulator-only declarations still reject the package.

Packages mixing static patches and RomFS are refused with an explanation to use
separate packages. Several conflicting versions are likewise not guessed.
Prepared single-domain payloads use the existing installer, conflict review,
backups and removal receipts. Compatibility metadata does not certify effects,
performance or absence of crashes.

Tests: `tests/mod_archive_test.cpp` exercises original ZIP/RAR4/RAR5 fixtures and
adversarial paths, CRC, split/encrypted archives, dictionary bounds, identity and
version checks. `tests/mod_archive_catalog_test.cpp` covers content-addressed
download, cache revalidation, inspection binding, and author companion metadata.
The latter optionally accepts the author's Metroid Dread 2.1.0 RAR and PCHTXT as
two arguments; the real package was checked against full BID
`646761F643AFEBB379EDD5E6A5151AF2CEF93DC1000000000000000000000000`
and Title ID `010093801237C000`. Real author files are research inputs in `dist`,
not redistributed as test fixtures.
