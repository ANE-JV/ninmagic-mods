#include "controller.hpp"
#include "platform.hpp"
#include "mod_queue.hpp"
#include "mod_install.hpp"
#include "mod_policy.hpp"
#include "mods.hpp"
#include "gamebanana.hpp"
#include "update_network.hpp"
#include "memory_budget.hpp"
#include <algorithm>
#include <atomic>
#include <set>
#ifdef __SWITCH__
#include <switch.h>
#include <malloc.h>
#endif
namespace nmm::overlay {namespace {
enum class Action {None,Refresh,Search,Move,Toggle,Prepare,Apply,Save,Clear};
struct Command{Action action=Action::None;Game expected;int delta=0;size_t index=0;};
Snapshot view;std::vector<ModEntry>mods;std::vector<ModPayload>prepared;InstalledInfo preparedInfo;Game current;Environment environment;Command pending;size_t highlighted=0;bool created=false,services=false,workerAvailable=false;std::atomic<bool>stopping{false},cancelled{false};
#ifdef __SWITCH__
Mutex mutex{};UEvent wake{};Thread worker{};struct Guard{Guard(){mutexLock(&mutex);}~Guard(){mutexUnlock(&mutex);}};
#else
struct Guard{};
#endif
bool same(const Game&a,const Game&b){return a.id&&a.id==b.id&&a.buildVerified&&b.buildVerified&&a.fullBuildId==b.fullBuildId&&a.processId==b.processId&&a.contentIdentity==b.contentIdentity&&a.contentVersion==b.contentVersion&&a.versionKnown==b.versionKnown&&a.version==b.version;}
bool overlayPatch(const ModEntry&m){return m.format==ModFormat::Ips||m.format==ModFormat::Pchtxt;}
void requireApplication(ModEntry&m){m.compatible=false;m.selected=false;if(m.format==ModFormat::Archive)m.reason="ZIP/RAR: abre NinMagic Mods para inspeccionar el paquete y comprobar su compatibilidad.";else if(m.format==ModFormat::Romfs)m.reason="RomFS requiere la aplicación con el juego cerrado.";}
void publish(const std::string&s,const std::string&e={}){Guard guard;(void)guard;view.game=current;view.highlighted=highlighted;view.totalItems=mods.size();view.firstItem=(highlighted/8)*8;view.items.clear();view.selectedCount=0;for(const auto&m:mods)if(m.selected)++view.selectedCount;for(size_t i=view.firstItem;i<mods.size()&&i<view.firstItem+8;++i){view.items.push_back(mods[i]);view.items.back().files.clear();}view.ready=current.buildVerified&&current.running;view.status=s;view.error=e;view.initialized=services;}
bool reopen(std::string&e){platformExit();services=platformInit(environment,e);return services;}
bool identify(std::string&e){Game next;if(!services&&!reopen(e)){current={};return false;}const bool ok=resolveRunningGame(next,environment,e);current=std::move(next);return ok;}
void clearPrepared(){prepared.clear();preparedInfo={};Guard g;(void)g;view.prepared=false;view.preparedFiles=0;view.review.clear();}
void blockCached(){for(auto&m:mods){requireApplication(m);if(overlayPatch(m))m.reason="Lista guardada: X vuelve a comprobar el parche pequeño para este proceso.";}}
void selectSaved(){std::vector<std::string>ids;std::string why;if(loadModSelection(current,ids,why))for(auto&m:mods)m.selected=overlayPatch(m)&&allowsConsoleMod(m)&&m.compatible&&std::find(ids.begin(),ids.end(),m.id)!=ids.end();}
bool refreshList(std::string&e){const auto previous=current;if(!identify(e)){mods.clear();highlighted=0;return false;}if(same(previous,current)&&!mods.empty())return true;mods.clear();highlighted=0;std::string why;if(loadModMenuCache(current,mods,why)){blockCached();return true;}e.clear();return true;}
bool searchList(std::string&status,std::string&e){if(!identify(e))return false;const auto requested=current;platformExit();services=false;updateNetworkExit();publish("Consultando fuentes de Nintendo Switch física. Solo se leen índices y parches pequeños.");std::vector<ModEntry>found,banana;std::string gitError,bananaError;const bool gitOk=!shouldCancel()&&checkMemoryBudget(MemoryPhase::Git,gitError)&&loadOverlayMods(requested,found,gitError,true);updateNetworkExit();const bool bananaOk=!shouldCancel()&&checkMemoryBudget(MemoryPhase::GameBanana,bananaError)&&loadGameBananaMods(requested,banana,bananaError,true);updateNetworkExit();if(stopping.load()){e="Consulta cancelada al salir.";return false;}if(!reopen(e)||!identify(e))return false;if(!same(requested,current)){mods.clear();highlighted=0;e="El juego o su versión cambió durante la consulta. Se descartó la respuesta.";return false;}if(shouldCancel()){e="Consulta cancelada; se conserva la lista anterior.";return false;}
 if(!gitOk&&!bananaOk&&found.empty()&&banana.empty()){e=gitError;if(!bananaError.empty())e+=(e.empty()?"":" ")+bananaError;return false;}
 std::set<std::string>ids;std::vector<ModEntry>combined;
 for(auto*source:{&found,&banana})for(auto&m:*source){if(!isBrowsableMod(m)||m.titleId!=current.id||m.id.empty()||combined.size()>=128||!ids.insert(m.id).second)continue;m.selected=false;m.files.clear();if(!overlayPatch(m))requireApplication(m);combined.push_back(std::move(m));}
 found.clear();banana.clear();mods=std::move(combined);highlighted=0;selectSaved();std::string cacheError;if(!saveModMenuCache(current,mods,cacheError)&&current.versionKnown)e=cacheError;status=std::to_string(mods.size())+" mods encontrados. Y revisa IPS pequeños para el próximo inicio. ZIP, RAR y RomFS se revisan desde la aplicación.";for(const auto*why:{&gitError,&bananaError})if(!why->empty())e+=(e.empty()?"":" ")+*why;return true;
}
bool prepareSelected(const Game&expected,std::string&status,std::string&e){clearPrepared();if(!identify(e))return false;if(!same(expected,current)){e="El proceso o sus contenidos cambiaron antes de revisar.";return false;}if(!validateRunningGame(current,e))return false;if(!checkMemoryBudget(MemoryPhase::Prepare,e))return false;const auto requested=current;std::vector<ModEntry>selected;for(const auto&m:mods)if(m.selected)selected.push_back(m);if(selected.empty()||selected.size()>32){e="Marca entre1 y32 parches compatibles.";return false;}platformExit();services=false;updateNetworkExit();size_t total=0;bool valid=true;
 for(const auto&m:selected){if(shouldCancel()||!allowsConsoleMod(m)||!m.compatible||(m.format!=ModFormat::Ips&&m.format!=ModFormat::Pchtxt)||m.branch.empty()){e="X comprueba primero los parches. RomFS se instala desde la aplicación con el juego cerrado.";valid=false;break;}if(!checkMemoryBudget(MemoryPhase::Prepare,e)){valid=false;break;}ModPayload payload;if(!prepareMod(requested,m,payload,e)||!payload.compatible||!payload.files.empty()||payload.ips.size()>128*1024-total){if(e.empty())e="Esta selección supera el límite del overlay. Usa la aplicación.";valid=false;break;}total+=payload.ips.size();prepared.push_back(std::move(payload));}
 updateNetworkExit();std::string reopenError;if(!reopen(reopenError)||!identify(reopenError)){e=reopenError;valid=false;}if(valid&&!same(requested,current)){e="El proceso o sus contenidos cambiaron durante la revisión.";valid=false;}if(valid&&shouldCancel()){e="Revisión cancelada antes de escribir parches.";valid=false;}ModPayload combined;if(valid&&!checkMemoryBudget(MemoryPhase::Combine,e))valid=false;if(valid&&(!combineMods(current,prepared,combined,e)||combined.ips.empty()||!combined.files.empty()||!inspectPreparedMods(current,prepared,preparedInfo,e)))valid=false;
 if(!valid){clearPrepared();return false;}status="Parches revisados para el próximo inicio. A confirma; no cambia la RAM del juego abierto.";{Guard g;(void)g;view.prepared=true;view.preparedFiles=preparedInfo.files;view.replacing=preparedInfo.exists;view.review=preparedInfo.detail;}return true;}
void perform(const Command&c){std::string e,status;bool ok=false;if(c.action==Action::Refresh||c.action==Action::Search||c.action==Action::Toggle||c.action==Action::Clear)clearPrepared();if(c.action==Action::Refresh){ok=refreshList(e);status=mods.empty()?"X consulta fuentes para el juego abierto. No se modifican sus archivos.":"Lista guardada para este juego y Build ID. X vuelve a consultar fuentes.";}
 else if(c.action==Action::Search)ok=searchList(status,e);
 else if(c.action==Action::Prepare){ok=prepareSelected(c.expected,status,e);Guard g;(void)g;view.lastSaveKnown=true;view.lastSaveOk=ok;view.lastSave=ok?status:e;}
 else if(c.action==Action::Apply){if(!view.prepared||prepared.empty()||!identify(e)||!same(c.expected,current)||!same(prepared.front().game,current)){e="La revisión del proceso caducó. Vuelve a revisar conY.";}else if(shouldCancel())e="Instalación cancelada antes de escribir.";else if(!checkMemoryBudget(MemoryPhase::Prepare,e)){}else{const auto outcome=installMods(current,prepared,preparedInfo.exists,preparedInfo.fingerprint);ok=outcome.ok;status=outcome.message;if(!ok)e=status;}clearPrepared();Guard g;(void)g;view.lastSaveKnown=true;view.lastSaveOk=ok;view.lastSave=ok?status:e;}
 else if(c.action==Action::Move){if(!mods.empty()){auto n=int64_t(mods.size());highlighted=size_t((int64_t(highlighted)+c.delta%n+n)%n);}ok=true;status="A marca opciones compatibles. R muestra los requisitos.";}
 else if(c.action==Action::Toggle){if(c.index>=mods.size())e="Opción fuera de la lista actual.";else{auto&m=mods[c.index];if((!overlayPatch(m)||!allowsConsoleMod(m)||!m.compatible)&&!m.selected)e=m.reason.empty()?"Compatibilidad sin comprobar: selección bloqueada.":m.reason;else if(!m.selected&&std::count_if(mods.begin(),mods.end(),[](const auto&v){return v.selected;})>=32)e="La cola admite hasta 32 mods.";else{m.selected=!m.selected;highlighted=c.index;ok=true;status="Selección local. Y revisa los parches para el próximo inicio; ZR guarda una cola opcional.";}}}
 else if(c.action==Action::Save||c.action==Action::Clear){const auto expected=current;if(!identify(e)||!same(expected,current)||!same(c.expected,current)){e="Cambió el juego, la versión o el Build ID. Vuelve a consultar antes de guardar.";mods.clear();highlighted=0;}else if(shouldCancel())e="Operación cancelada antes de escribir la selección.";else if(c.action==Action::Clear){ok=clearModSelection(current,e);if(ok){for(auto&m:mods)m.selected=false;status="Selección pendiente retirada. Los archivos instalados no se han modificado.";}}
 else{std::vector<ModEntry>selected;for(const auto&m:mods)if(m.selected)selected.push_back(m);ok=saveModSelection(current,selected,e);if(ok)status="Selección guardada. Para IPS deja el juego abierto y abre NinMagic Mods desde Álbum; RomFS requiere cerrarlo.";}Guard guard;(void)guard;view.lastSaveKnown=true;view.lastSaveOk=ok;view.lastSave=ok?status:e;}
 if(!ok&&e.empty())e="No se pudo completar la operación.";
 publish(ok?status:e,e);
}
#ifdef __SWITCH__
void run(void*){std::string e;const bool sm=R_SUCCEEDED(smInitialize()),sd=sm&&R_SUCCEEDED(fsdevMountSdmc());workerAvailable=sm&&sd;if(workerAvailable)services=platformInit(environment,e);else e="No se pudieron abrir los servicios y la microSD.";if(services){Command c;c.action=Action::Refresh;perform(c);}else publish(e,e);{Guard g;view.busy=false;}while(!stopping.load()){waitSingle(waiterForUEvent(&wake),UINT64_MAX);if(stopping.load())break;Command c;{Guard g;c=std::move(pending);pending={};}if(c.action!=Action::None)perform(c);{Guard g;view.busy=view.searching=view.applying=false;}}updateNetworkExit();platformExit();services=false;mods.clear();clearPrepared();if(sd)fsdevUnmountDevice("sdmc");if(sm)smExit();}
#endif
bool enqueue(Command c){{Guard g;(void)g;if(!created||stopping.load()||view.busy||!workerAvailable)return false;c.expected=view.game;pending=std::move(c);view.busy=true;view.searching=pending.action==Action::Search||pending.action==Action::Prepare;view.applying=pending.action==Action::Apply;view.error.clear();view.status=view.searching?"Consultando las fuentes de mods...":"Comprobando la selección...";cancelled.store(false);}
#ifdef __SWITCH__
ueventSignal(&wake);
#else
Command command=std::move(pending);pending={};perform(command);view.busy=view.searching=view.applying=false;
#endif
return true;}
}
bool init(std::string&e){e.clear();if(created)return true;view={};view.busy=true;stopping.store(false);cancelled.store(false);
#ifdef __SWITCH__
mutexInit(&mutex);ueventCreate(&wake,true);auto rc=threadCreate(&worker,run,nullptr,nullptr,0x40000,0x3B,-2);if(R_FAILED(rc)){e="No se pudo reservar el hilo del overlay.";return false;}rc=threadStart(&worker);if(R_FAILED(rc)){threadClose(&worker);e="No se pudo iniciar el hilo del overlay.";return false;}created=true;
#else
created=workerAvailable=true;services=platformInit(environment,e);Command c;c.action=Action::Refresh;perform(c);view.busy=false;
#endif
return true;}
void shutdown(){if(!created)return;stopping.store(true);cancelled.store(true);
#ifdef __SWITCH__
ueventSignal(&wake);threadWaitForExit(&worker);threadClose(&worker);
#else
updateNetworkExit();platformExit();mods.clear();clearPrepared();services=false;
#endif
created=workerAvailable=false;view.initialized=view.busy=view.searching=view.applying=false;pending={};}
Snapshot snapshot(){Guard g;(void)g;return view;}
bool refresh(){Command c;c.action=Action::Refresh;return enqueue(c);}bool search(){Command c;c.action=Action::Search;return enqueue(c);}bool move(int d){Command c;c.action=Action::Move;c.delta=d;return enqueue(c);}bool toggle(size_t i){Command c;c.action=Action::Toggle;c.index=i;return enqueue(c);}bool prepare(){Command c;c.action=Action::Prepare;return enqueue(c);}bool apply(){Command c;c.action=Action::Apply;return enqueue(c);}bool save(){Command c;c.action=Action::Save;return enqueue(c);}bool clear(){Command c;c.action=Action::Clear;return enqueue(c);}void cancel(){cancelled.store(true);}bool shouldCancel(){return cancelled.load()||stopping.load();}
}
