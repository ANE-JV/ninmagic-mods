"""Embed the independently built, verified OVL in the next NRO, without a loader."""
from pathlib import Path
import hashlib
import json
from verify_nro import verify

ROOT = Path(__file__).resolve().parent.parent
VERSION = "1.3.0"

def main():
    source = ROOT / "dist/overlay/ninmagic-mods.ovl"
    report = verify(source, expected_version=VERSION)
    data = source.read_bytes()
    if not 0x4000 <= len(data) <= 8 * 1024 * 1024:
        raise ValueError("Overlay outside bundle limits")
    digest = hashlib.sha256(data).hexdigest()
    target = ROOT / "romfs/ninmagic-mods.ovl"
    target.write_bytes(data)
    manifest = f"NMMODS-OVERLAY-1\nversion={VERSION}\nsha256={digest}\nsize={len(data)}\n"
    (ROOT / "romfs/overlay-info.txt").write_text(manifest, encoding="ascii", newline="\n")
    if target.read_bytes() != data:
        raise ValueError("Embedded overlay copy differs")
    report["embedded_in_nro"] = True
    (ROOT / "dist/overlay-bundle-input.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"version": VERSION, "bytes": len(data), "sha256": digest}))

if __name__ == "__main__":
    main()
