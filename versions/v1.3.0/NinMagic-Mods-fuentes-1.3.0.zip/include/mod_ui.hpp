#pragma once
#include "model.hpp"
#include "mod_policy.hpp"
namespace nmm {
inline ModFormat effectiveModFormat(const ModEntry&m){return m.format==ModFormat::Archive?(m.archiveInspected?m.archiveFormat:ModFormat::Unsupported):m.format;}
inline bool canMarkMod(const ModEntry&m){const auto f=effectiveModFormat(m);if(m.format==ModFormat::Archive&&(!m.archiveInspected||!m.archiveFiles||m.archiveSha256.size()!=64||m.archiveSha256.find_first_not_of("0123456789abcdef")!=m.archiveSha256.npos))return false;return m.compatible&&allowsConsoleMod(m)&&(f==ModFormat::Ips||f==ModFormat::Pchtxt||f==ModFormat::Romfs);}
inline bool canInspectMod(const ModEntry&m){return canInspectConsoleArchive(m)&&!canMarkMod(m);}
inline std::vector<size_t> visibleMods(const View&v){std::vector<size_t> out;for(size_t i=0;i<v.mods.size();++i)if(isBrowsableMod(v.mods[i])&&(!v.filter||canMarkMod(v.mods[i])))out.push_back(i);return out;}
inline unsigned selectedMods(const View&v){unsigned n=0;for(const auto&m:v.mods)n+=m.selected&&canMarkMod(m);return n;}
}
