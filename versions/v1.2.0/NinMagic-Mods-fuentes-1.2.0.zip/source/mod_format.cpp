#include "mods.hpp"
#include "mod_identity.hpp"
#include "mod_policy.hpp"
#include <algorithm>
#include <cctype>
#include <map>
#include <sstream>

namespace nmm {
namespace {
#ifdef NMM_OVERLAY
constexpr size_t MaxStaticWrites=8*1024;
#else
constexpr size_t MaxStaticWrites=1024*1024;
#endif
std::string trim(const std::string &s){auto a=s.find_first_not_of(" \t\r\n");return a==std::string::npos?std::string():s.substr(a,s.find_last_not_of(" \t\r\n")-a+1);}
std::string upper(std::string s){for(char &c:s)c=char(std::toupper(static_cast<unsigned char>(c)));return s;}
bool hexadecimal(const std::string &s){return !s.empty()&&std::all_of(s.begin(),s.end(),[](unsigned char c){return std::isxdigit(c)!=0;});}
uint32_t number(const std::string &s){uint32_t value=0;for(unsigned char c:s)value=(value<<4)|(c<='9'?c-'0':std::tolower(c)-'a'+10);return value;}
void put32(std::vector<uint8_t> &out,uint32_t value){for(int n=3;n>=0;--n)out.push_back(uint8_t(value>>(8*n)));}
void put16(std::vector<uint8_t> &out,uint16_t value){out.push_back(uint8_t(value>>8));out.push_back(uint8_t(value));}
bool fullBuild(const std::string &s){return s.size()>=2&&s.size()<=64&&s.size()%2==0&&hexadecimal(s)&&s.find_first_not_of('0')!=std::string::npos;}
bool matchesFullBuild(std::string source,const Game &game){if(!fullBuild(source)||game.fullBuildId.size()!=64||!hexadecimal(game.fullBuildId))return false;source=upper(source);source.resize(64,'0');return source==upper(game.fullBuildId);}
bool pchtxt(const std::string &data,const Game &game,ModPayload &payload,std::string &error) {
    if(data.empty()||data.size()>2*1024*1024||data.find('\0')!=std::string::npos){error="El PCHTXT está vacío o contiene datos no admitidos.";return false;}
    std::string text=data;if(text.rfind("\xef\xbb\xbf",0)==0)text.erase(0,3);
    std::istringstream input(text);std::string line,build;bool enabled=false,stopped=false,seenEnabled=false;uint32_t shift=0;size_t lines=0;
    std::map<uint32_t,uint8_t> bytes;
    while(std::getline(input,line)) {
        if(++lines>100000||line.size()>16384){error="El PCHTXT supera los límites de revisión.";return false;}
        if(stopped)continue;
        line=trim(line);if(line.empty()||line[0]=='#'||line[0]==';'||line.rfind("//",0)==0)continue;
        auto comment=line.find("//");if(comment!=std::string::npos)line=trim(line.substr(0,comment));
        if(line.rfind("@nsobid-",0)==0) {if(!build.empty()){error="El mod declara más de un Build ID.";return false;}build=upper(trim(line.substr(8)));if(!fullBuild(build)){error="Build ID del PCHTXT inválido.";return false;}continue;}
        if(line=="@flag print_values")continue;
        if(line.rfind("@flag offset_shift ",0)==0) {auto value=trim(line.substr(19));if(value.rfind("0x",0)==0||value.rfind("0X",0)==0)value.erase(0,2);if(!hexadecimal(value)||value.size()>8){error="Desplazamiento de PCHTXT no admitido.";return false;}shift=number(value);continue;}
        if(line=="@enabled"){enabled=true;seenEnabled=true;continue;}
        if(line=="@disabled"){enabled=false;continue;}
        if(line=="@stop"){stopped=true;continue;}
        if(!line.empty()&&line[0]=='@'){error="El mod utiliza una directiva PCHTXT no admitida: "+line;return false;}
        // Disabled sections may contain alternatives. Validate their syntax too,
        // but preserve only the explicitly enabled static patch from the author.
        std::istringstream words(line);std::string offset,value,extra;
        if(!(words>>offset>>value)||(words>>extra)||offset.size()!=8||!hexadecimal(offset)||!hexadecimal(value)||value.size()%2||value.empty()||value.size()>131070){error="El PCHTXT contiene una instrucción no estática o no admitida.";return false;}
        if(!enabled)continue;
        uint64_t address=uint64_t(number(offset))+shift;size_t count=value.size()/2;
        if(address<0x100||address+count>0x80000000ULL){error="El parche intenta escribir en la cabecera NSO o fuera del rango admitido.";return false;}
        for(size_t n=0;n<count;++n){uint32_t at=uint32_t(address+n);uint8_t v=uint8_t(number(value.substr(n*2,2)));auto old=bytes.find(at);if(old!=bytes.end()&&old->second!=v){error="El PCHTXT contiene escrituras incompatibles en una misma dirección.";return false;}if(old==bytes.end()&&bytes.size()>=MaxStaticWrites){error="El mod supera el límite de escrituras estáticas de esta aplicación.";return false;}bytes[at]=v;}
    }
    if(build.empty()||build.substr(0,16)!=upper(game.buildId)||!matchesFullBuild(build,game)){error="El Build ID completo del mod no coincide con el NSO instalado. No se instalará.";return false;}
    if(!seenEnabled||bytes.empty()){error="El PCHTXT no contiene un parche estático habilitado.";return false;}
    payload.buildId=upper(game.fullBuildId);payload.ips={'I','P','S','3','2'};
    for(auto i=bytes.begin();i!=bytes.end();) {
        uint32_t start=i->first;std::vector<uint8_t> block;block.push_back(i->second);++i;
        while(i!=bytes.end()&&i->first==uint64_t(start)+block.size()&&block.size()<65535){block.push_back(i->second);++i;}
        put32(payload.ips,start);put16(payload.ips,uint16_t(block.size()));payload.ips.insert(payload.ips.end(),block.begin(),block.end());
    }
    payload.ips.insert(payload.ips.end(),{'E','E','O','F'});return true;
}
}
bool validateModIps(const std::vector<uint8_t> &data,std::string &error) {
    error.clear();if(data.size()<8||data.size()>2*1024*1024){error="El archivo IPS está vacío o es demasiado grande.";return false;}
    bool extended=data.size()>=9&&std::equal(data.begin(),data.begin()+5,"IPS32");bool legacy=std::equal(data.begin(),data.begin()+5,"PATCH");
    if(!extended&&!legacy){error="Cabecera IPS/IPS32 inválida.";return false;}
    size_t p=5,records=0;const unsigned offsetBytes=extended?4:3;const char *end=extended?"EEOF":"EOF";
    std::vector<std::pair<uint32_t,uint8_t>> writes;
    while(p<data.size()) {
        if(data.size()-p>=offsetBytes&&std::equal(data.begin()+p,data.begin()+p+offsetBytes,end)){p+=offsetBytes;if(p!=data.size()){error="El IPS incluye datos de truncado o bytes finales no admitidos.";return false;}if(!records){error="El IPS no contiene registros de parche.";return false;}std::sort(writes.begin(),writes.end());for(size_t n=1;n<writes.size();++n)if(writes[n-1].first==writes[n].first&&writes[n-1].second!=writes[n].second){error="El IPS contiene escrituras incompatibles en una misma dirección.";return false;}return true;}
        if(data.size()-p<offsetBytes+2){error="Registro IPS incompleto.";return false;}
        uint32_t address=0;for(unsigned n=0;n<offsetBytes;++n)address=(address<<8)|data[p++];uint32_t size=(uint32_t(data[p])<<8)|data[p+1];p+=2;
        uint32_t bytes=size;size_t valueOffset=p;uint8_t repeat=0;
        if(!size){if(data.size()-p<3){error="Registro IPS RLE incompleto.";return false;}bytes=(uint32_t(data[p])<<8)|data[p+1];repeat=data[p+2];p+=3;if(!bytes){error="Registro IPS RLE vacío.";return false;}}
        else {if(size>data.size()-p){error="Contenido IPS incompleto.";return false;}p+=size;}
        if(address<0x100||uint64_t(address)+bytes>0x80000000ULL||++records>100000){error="El IPS escribe en la cabecera NSO o fuera de los límites admitidos.";return false;}
        if(writes.size()+bytes>MaxStaticWrites){error="El IPS supera el límite de escrituras estáticas de esta aplicación.";return false;}
        for(uint32_t n=0;n<bytes;++n)writes.emplace_back(address+n,size?data[valueOffset+n]:repeat);
    }
    error="El IPS no contiene su marcador final.";return false;
}
bool parseModPayload(const Game &game,const ModEntry &entry,const std::string &bytes,ModPayload &payload,std::string &error) {
    payload={};payload.game=game;payload.entry=entry;error.clear();
    if(!game.buildVerified||!hexadecimal(game.buildId)||game.buildId.size()!=16||game.id<0x0100000000010000ULL||canonicalModApplicationId(entry.titleId)!=game.id||!entry.titleId){error="Falta verificar el Title ID y Build ID exactos del mod.";return false;}
    if(game.fullBuildId.size()!=64||!hexadecimal(game.fullBuildId)||upper(game.fullBuildId).substr(0,16)!=upper(game.buildId)){error="No se ha comprobado el Build ID completo de 32 bytes del NSO. Vuelve a seleccionar el juego.";return false;}
    if(!entry.version.empty()&&(!game.versionKnown||entry.version!=game.version)){error="La versión declarada por el mod no coincide con la versión instalada.";return false;}
    if(!entry.buildId.empty()&&!matchesFullBuild(entry.buildId,game)){error="El Build ID declarado en el índice no coincide con el ejecutable instalado.";return false;}
    bool ok=false;
    if(entry.format==ModFormat::Pchtxt)ok=pchtxt(bytes,game,payload,error);
    else if(entry.format==ModFormat::Ips){if(!fullBuild(entry.buildId)||upper(entry.buildId).substr(0,16)!=upper(game.buildId)||!matchesFullBuild(entry.buildId,game)){error="El Build ID completo del IPS no coincide con el NSO instalado.";return false;}payload.buildId=upper(game.fullBuildId);payload.ips.assign(bytes.begin(),bytes.end());ok=true;}
    else {error=entry.detail.empty()?"Este formato de mod no permite comprobar su Build ID.":entry.detail;return false;}
    if(!ok||!validateModIps(payload.ips,error)){payload.ips.clear();return false;}
    if(isEmulatorOnlyText(bytes))payload.entry.detail+=" Destino declarado: exclusivo de emulador; prueba en consola sin verificar.";
    payload.entry.titleId=game.id;payload.compatible=true;payload.detail="Formato convertible a Atmosphère; funcionamiento en consola sin verificar. Build ID coincidente. Se aplicará al reiniciar el juego.";return true;
}
}
