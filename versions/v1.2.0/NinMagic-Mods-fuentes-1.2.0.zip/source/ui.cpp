#include "ui.hpp"
#include "app_update_ui.hpp"
#include "ui_text.hpp"
#include "mod_ui.hpp"
#include "mod_labels.hpp"
#include "mod_policy.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <map>
#include <sstream>

namespace nmm {
namespace {
constexpr int W=1280, H=720;
using Color=uint32_t;
constexpr Color rgb(unsigned r,unsigned g,unsigned b) { return r|(g<<8)|(b<<16)|0xff000000u; }
constexpr Color ink=rgb(227,239,254), muted=rgb(143,164,192), dim=rgb(85,113,146);
constexpr Color cyan=rgb(71,227,240), violet=rgb(176,131,255), pink=rgb(255,116,158);
constexpr Color green=rgb(177,255,87), orange=rgb(255,174,72), blue=rgb(77,151,255);
constexpr Color panel=rgb(12,24,44), raised=rgb(18,36,61), border=rgb(32,57,82);
struct Glyph {int w=0,h=0,advance=0;std::vector<uint8_t> alpha;};
struct Font {std::array<Glyph,224> glyphs;};
std::map<int,Font> fonts;
std::vector<uint8_t> rawFont, logo;
std::array<uint8_t,224> advances{};
std::vector<Color> background;
Color *fb=nullptr;
int pitch=W;

void pixel(int x,int y,Color c) {if(x>=0&&x<W&&y>=0&&y<H) fb[y*pitch+x]=c;}
void rect(int x,int y,int w,int h,Color c) {
    int x0=std::max(0,x),x1=std::min(W,x+w),y0=std::max(0,y),y1=std::min(H,y+h);
    if(x1<=x0||y1<=y0) return;
    for(int yy=y0;yy<y1;++yy) std::fill(fb+yy*pitch+x0,fb+yy*pitch+x1,c);
}
Color blend(Color dst,Color src,unsigned a) {
    unsigned r=(((dst&255)*(255-a)+(src&255)*a)+127)/255;
    unsigned g=((((dst>>8)&255)*(255-a)+((src>>8)&255)*a)+127)/255;
    unsigned b=((((dst>>16)&255)*(255-a)+((src>>16)&255)*a)+127)/255;
    return rgb(r,g,b);
}
void alphaPixel(int x,int y,Color c,unsigned a) {
    if(x>=0&&x<W&&y>=0&&y<H&&a) {
        Color &p=fb[y*pitch+x];p=a==255?c:blend(p,c,a);
    }
}
void line(int x0,int y0,int x1,int y1,Color c) {
    int dx=std::abs(x1-x0),sx=x0<x1?1:-1,dy=-std::abs(y1-y0),sy=y0<y1?1:-1,err=dx+dy;
    for(;;){pixel(x0,y0,c);if(x0==x1&&y0==y1)break;int e2=2*err;if(e2>=dy){err+=dy;x0+=sx;}if(e2<=dx){err+=dx;y0+=sy;}}
}
void box(int x,int y,int w,int h,Color fill=panel,Color edge=border) {
    rect(x,y,w,h,fill);rect(x,y,w,1,edge);rect(x,y+h-1,w,1,edge);
    rect(x,y,1,h,edge);rect(x+w-1,y,1,h,edge);
    // Cut corners and short highlights give the panels their circuit-board shape.
    line(x,y+7,x+7,y,edge);line(x+w-8,y+h-1,x+w-1,y+h-8,edge);
    rect(x+1,y+1,6,2,fill);rect(x+1,y+3,4,2,fill);rect(x+1,y+5,2,2,fill);
}
std::vector<uint32_t> decode(const std::string&s) { return ui_text::displayCodepoints(s); }
std::string encode(const std::vector<uint32_t>&v) {
    std::string s;for(auto cp:v) {if(cp<128)s+=static_cast<char>(cp);else{s+=static_cast<char>(0xc0|(cp>>6));s+=static_cast<char>(0x80|(cp&63));}}return s;
}
Font& font(int size) {
    auto it=fonts.find(size);if(it!=fonts.end())return it->second;
    Font scaled;
    for(unsigned i=0;i<224;++i) {
        auto &g=scaled.glyphs[i];g.w=size;g.h=(34*size+12)/24;g.advance=(advances[i]*size+12)/24;
        g.alpha.resize(g.w*g.h);
        for(int y=0;y<g.h;++y)for(int x=0;x<g.w;++x)
            g.alpha[y*g.w+x]=rawFont.empty()?0:rawFont[i*24*34+(y*34/g.h)*24+x*24/g.w];
    }
    return fonts.emplace(size,std::move(scaled)).first->second;
}
int width(const std::string&s,int size) {
    auto &f=font(size);int w=0;for(auto cp:decode(s))w+=f.glyphs[cp-32].advance;return w;
}
void text(const std::string&s,int x,int y,int size=18,Color c=ink) {
    auto &f=font(size);int offset=(5*size+12)/24;
    for(auto cp:decode(s)) {
        const auto &g=f.glyphs[cp-32];
        for(int yy=0;yy<g.h;++yy) {
            int py=y+yy-offset;if(py<0||py>=H)continue;
            for(int xx=0;xx<g.w;++xx)if(g.alpha[yy*g.w+xx])alphaPixel(x+xx,py,c,g.alpha[yy*g.w+xx]);
        }
        x+=g.advance;
    }
}
std::string fit(const std::string&s,int maxw,int size) {
    if(width(s,size)<=maxw)return s;
    auto chars=decode(s);while(!chars.empty()&&width(encode(chars)+"...",size)>maxw)chars.pop_back();
    return encode(chars)+"...";
}
void fitted(const std::string&s,int x,int y,int maxw,int size=18,Color c=ink) {text(fit(s,maxw,size),x,y,size,c);}
void wrapped(const std::string&s,int x,int y,int maxw,int size,int maxlines,Color c=ink) {
    std::istringstream words(s);std::string word,current;int n=0;
    while(words>>word) {
        std::string trial=current.empty()?word:current+" "+word;
        if(width(trial,size)>maxw&&!current.empty()) {
            fitted(current,x,y+n*(size+9),maxw,size,c);if(++n>=maxlines)return;current=word;
        } else current=trial;
        if(n==maxlines-1) {
            std::string rest;std::getline(words,rest);fitted(current+rest,x,y+n*(size+9),maxw,size,c);return;
        }
    }
    if(!current.empty())fitted(current,x,y+n*(size+9),maxw,size,c);
}
// File paths must remain exact: wrap at character boundaries, never abbreviate.
std::vector<std::string> pathLines(const std::string&s,int maxw,int size) {
    std::vector<std::string> lines;std::vector<uint32_t> current;
    for(auto cp:decode(s)) {
        auto trial=current;trial.push_back(cp);
        if(!current.empty()&&width(encode(trial),size)>maxw){lines.push_back(encode(current));current.clear();}
        current.push_back(cp);
    }
    if(!current.empty())lines.push_back(encode(current));
    return lines;
}
void exactPath(const std::string&s,int x,int y,int maxw,int size,int maxlines,Color c=muted) {
    const auto lines=pathLines(s,maxw,size);
    for(int i=0;i<std::min(maxlines,static_cast<int>(lines.size()));++i)text(lines[i],x,y+i*(size+7),size,c);
    if(static_cast<int>(lines.size())>maxlines)text("Continúa en el resumen de rutas.",x,y+maxlines*(size+7),12,dim);
}
std::string bytes(uint64_t n) {
    char s[40];double g=static_cast<double>(n)/(1024.0*1024.0*1024.0);
    if(n>=1024ull*1024*1024)std::snprintf(s,sizeof(s),"%.1f GiB",g);
    else if(n>=1024ull*1024)std::snprintf(s,sizeof(s),"%.1f MiB",g*1024);
    else if(n>=1024)std::snprintf(s,sizeof(s),"%.0f KiB",g*1024*1024);
    else std::snprintf(s,sizeof(s),"%llu B",static_cast<unsigned long long>(n));
    return s;
}
void badge(const std::string&s,int x,int y,Color c=cyan,int maxw=300) {
    int w=std::min(maxw,width(s,14)+24);box(x,y,w,27,rgb(14,37,55),rgb(32,75,95));fitted(s,x+12,y+5,w-24,14,c);
}
void logoAt(int x,int y,int size) {
    if(logo.size()!=256*256*4){box(x,y,size,size,raised,cyan);text("NM",x+size/8,y+size/4,size/3,cyan);return;}
    for(int yy=0;yy<size;++yy)for(int xx=0;xx<size;++xx) {
        size_t p=((yy*256/size)*256+xx*256/size)*4;
        alphaPixel(x+xx,y+yy,rgb(logo[p],logo[p+1],logo[p+2]),logo[p+3]);
    }
}
void key(const std::string&k,const std::string&label,int x,int y,Color c=muted) {
    int kw=std::max(23,width(k,13)+14);box(x,y,kw,25,rgb(19,34,55),rgb(46,71,100));text(k,x+(kw-width(k,13))/2,y+5,13,ink);text(label,x+kw+9,y+5,14,c);
}
void footer(const std::vector<std::pair<std::string,std::string>>&items) {
    rect(32,662,1216,1,border);int x=32;
    for(auto &p:items){key(p.first,p.second,x,681);x+=std::max(23,width(p.first,13)+14)+width(p.second,14)+34;}
    text("NINMAGIC / 1.2.0",1090,686,12,dim);
}
void smallLabel(const std::string&s,int x,int y,Color c=muted){text(s,x,y,12,c);}
void neonLine(int x,int y,int w){rect(x,y,w,2,cyan);rect(x+w/3,y,w/3,2,violet);rect(x+2*w/3,y,w-2*w/3,2,pink);}

void header(const View&v){
    logoAt(30,11,68);text("NINMAGIC",111,17,27);text("MODS DE JUEGOS",113,53,13,pink);
    rect(337,22,1,43,border);text("GRÁFICOS / 60 FPS / ROPA / PERSONAJES",359,29,15,muted);
    badge(v.env.applet?"MODO APPLET":"MODO APLICACIÓN",1020,28,v.env.applet?orange:cyan,228);
    neonLine(32,89,1216);text("FW",33,109,12,dim);fitted(v.env.firmware.empty()?"Sin comprobar":v.env.firmware,65,106,176,14,muted);
    text("ATMOSPHÈRE",266,109,12,dim);fitted(v.env.atmosphere.empty()?"Sin comprobar":v.env.atmosphere,365,106,182,14,muted);
    fitted(std::to_string(v.catalog.entries.size())+" archivos en el catálogo",585,106,360,14,cyan);fitted("MODS PUBLICADOS",1028,106,220,13,violet);
}
void title(const std::string&large,const std::string&small=""){fitted(large,32,145,1214,27);if(!small.empty())fitted(small,34,184,1212,15,muted);}
void gameIdentity(const Game&g,int x,int y,int w){
    wrapped(g.name.empty()?"Juego sin nombre":g.name,x,y,w,27,2);
    fitted(g.author.empty()?"Editor no indicado":g.author,x,y+85,w,15,muted);
    fitted("Versión: "+(g.version.empty()?std::string("sin comprobar"):g.version),x,y+118,w,18,cyan);
    fitted("TITLE ID  "+titleId(g.id),x,y+153,w,13,dim);
    fitted(g.buildVerified?"BUILD ID  "+g.buildId:"Build ID: se lee con el juego abierto",x,y+180,w,13,g.buildVerified?violet:orange);
}
void library(const View&v){
    title("Tu biblioteca de mods","Selecciona un juego para comprobar sus mods y su compatibilidad.");
    box(32,222,426,409,panel,border);neonLine(32,222,426);
    if(v.games.empty())wrapped("No hay juegos accesibles. Y vuelve a leer la biblioteca.",57,269,377,20,5,muted);
    const int rows=7,start=std::max(0,v.selected-rows/2);
    for(int i=start;i<std::min(int(v.games.size()),start+rows);++i){const auto&g=v.games[i];int y=236+(i-start)*53;if(i==v.selected){box(40,y,410,50,raised,rgb(93,64,146));rect(40,y,4,50,pink);}fitted(g.name,57,y+6,377,17,i==v.selected?ink:muted);fitted((g.version.empty()?std::string("Versión sin comprobar"):"v"+g.version)+(g.running?" · ABIERTO":""),57,y+30,377,12,g.running?orange:cyan);}
    box(480,222,768,409,panel,border);neonLine(480,222,768);
    if(!v.games.empty()){const auto&g=v.games[std::clamp(v.selected,0,int(v.games.size())-1)];gameIdentity(g,506,249,711);}
    else {logoAt(749,250,157);text("NINMAGIC MODS",699,432,25,pink);}
    rect(506,462,715,1,border);smallLabel("EL ESTADO DEL JUEGO DEPENDE DEL TIPO DE MOD",506,481,pink);wrapped("Parches: inicia el juego y abre NinMagic desde Álbum o el overlay. RomFS y retirada: cierra el juego y usa modo aplicación.",506,505,715,17,3,muted);
    box(506,579,715,35,raised,rgb(90,49,128));key("A","BUSCAR MODS DEL JUEGO",521,584,cyan);
    fitted(v.status,34,641,1210,13,muted);footer({{"D-PAD","Mover"},{"A","Mods"},{"Y","Juegos"},{"X","Catálogo"},{"L","Fuentes"},{"R","Actualizar"},{"-","Ayuda"},{"+","Salir"}});
}
void mods(const View&v){
    title(v.game.name,"Parches: juego abierto y reinicio posterior. RomFS: juego cerrado. Y revisa antes de confirmar.");
    box(32,222,715,409,panel,border);neonLine(32,222,715);const auto ids=visibleMods(v);
    smallLabel(v.filter?"SOLO COMPATIBLES":"TODOS LOS RESULTADOS",55,238,cyan);fitted(std::to_string(selectedMods(v))+" marcados",531,236,194,14,pink);
    if(ids.empty())wrapped(v.filter?"No hay mods comprobados en esta lista. X muestra también los resultados bloqueados.":v.catalog.ready?"No hay mods identificados para este juego en el catálogo guardado. X en la biblioteca vuelve a consultar las fuentes.":"Todavía no hay un catálogo verificado. Actualiza las fuentes desde la biblioteca.",58,291,659,21,6,muted);
    const int start=std::max(0,v.modSelected-3);
    for(int row=start;row<std::min(int(ids.size()),start+7);++row){const auto&m=v.mods[ids[row]];const int y=268+(row-start)*49;bool active=row==v.modSelected;if(active)box(41,y,697,47,raised,m.compatible?cyan:rgb(107,67,102));box(53,y+9,19,19,m.selected?rgb(27,115,125):panel,m.compatible?cyan:dim);if(m.selected)rect(58,y+14,9,9,cyan);fitted(modDisplayName(m),84,y+5,473,17,m.compatible?ink:muted);fitted(m.category+" · "+m.source,84,y+29,473,11,m.compatible?cyan:dim);const bool needsLive=!v.game.running&&(m.format==ModFormat::Ips||m.format==ModFormat::Pchtxt)&&(m.version.empty()||m.version==v.game.version);fitted(m.compatible?"COINCIDE":needsLive?"ABRE EL JUEGO":"BLOQUEADO",562,y+17,160,12,m.compatible?green:needsLive?cyan:orange);}
    box(769,222,479,409,panel,border);neonLine(769,222,479);smallLabel("MOD SELECCIONADO",793,241,violet);
    if(!ids.empty()){const auto&m=v.mods[ids[std::clamp(v.modSelected,0,int(ids.size())-1)]];wrapped(modDisplayName(m),793,273,430,22,3);fitted(m.version.empty()?"Versión de juego: sin verificar":"Versión de juego: "+m.version,793,369,430,14,muted);fitted(m.format==ModFormat::Romfs&&m.buildId.empty()?"RomFS: requiere versión y contenido coincidentes":m.buildId.empty()?"Build ID del autor: sin comprobar":"Build ID: "+m.buildId.substr(0,16),793,396,430,13,dim);smallLabel(m.compatible?"IDENTIDAD / VERSIÓN COINCIDENTES":"INSTALACIÓN BLOQUEADA",793,438,m.compatible?green:orange);std::string explanation=m.reason.empty()?m.detail:m.reason;if(m.compatible&&m.repository=="cucholix/NX-IPS-romfs-compilation")explanation="El autor indica Mariko y overclock. NinMagic no cambia frecuencias. "+explanation;wrapped(explanation,793,462,430,16,5,m.compatible?muted:orange);}
    fitted(v.detail.empty()?"L permite retirar la última selección instalada por NinMagic Mods.":v.detail,34,641,1210,13,v.detail.empty()?muted:orange);
    fitted("ZR: qué cambia este mod y requisitos",793,600,430,13,cyan);
    footer({{"D-PAD","Mover"},{"A","Marcar"},{"Y","Revisar"},{"X","Filtrar"},{"L","Retirar"},{"ZR","Detalle"},{"B","Volver"}});
}
void modDetail(const View&v){
    title("Qué cambia este mod", "Consulta el efecto, la versión requerida y el nombre original del autor.");
    box(32,222,426,409,panel,border);neonLine(32,222,426);gameIdentity(v.game,56,248,378);
    if(!v.game.buildVerified&&!v.game.detail.empty())wrapped(v.game.detail,56,482,378,14,5,muted);
    const auto ids=visibleMods(v);box(480,222,768,409,panel,border);neonLine(480,222,768);
    if(!ids.empty()){
        const auto&m=v.mods[ids[std::clamp(v.modSelected,0,int(ids.size())-1)]];
        fitted(isEmulatorOnly(m)?"Destino declarado: emulador":m.consoleOnly?"Destino declarado: Switch física":"Destino sin especificar",56,604,378,13,isEmulatorOnly(m)?orange:muted);
        if(v.modDetailsOriginal){smallLabel("DESCRIPCIÓN ORIGINAL DEL AUTOR",505,245,pink);wrapped(m.detail.empty()?"Esta fuente no aporta una descripción adicional. Consulta el enlace del autor.":m.detail,505,280,713,15,12,muted);fitted(m.sourceUrl,505,601,713,12,dim);}
        else {
        wrapped(modDisplayName(m),505,242,713,24,2);wrapped(modExplanation(m),505,308,713,17,3,muted);
        smallLabel("NOMBRE ORIGINAL / AUTOR",505,389,pink);fitted(m.name+(m.author.empty()?"":" · "+m.author),505,412,713,15,muted);
        fitted("Juego requerido: "+(m.version.empty()?std::string("sin verificar"):m.version)+(m.modVersion.empty()?"":" · Versión del mod: "+m.modVersion),505,447,713,14,cyan);
        wrapped(m.reason.empty()?m.detail:m.reason,505,478,713,15,3,m.compatible?muted:orange);
        exactPath(m.sourceUrl.empty()?m.source:m.sourceUrl,505,566,713,12,2,dim);
        }
    }
    fitted("Una versión del mod no equivale a una versión compatible del juego.",34,641,1210,13,orange);footer({{"B","Volver a la lista"},{"X",v.modDetailsOriginal?"Explicación":"Texto del autor"},{"ZR","Volver"}});
}
void confirm(const View&v){
    title(v.remove?"Retirar los mods de NinMagic":"Revisa los mods seleccionados",v.remove?"Se recuperarán los archivos anteriores cuando se puedan verificar.":"Confirma únicamente después de comprobar el juego y las opciones.");
    box(32,222,427,409,panel,border);neonLine(32,222,427);gameIdentity(v.game,56,251,379);
    const bool codeOnly=!v.remove&&!v.payloads.empty()&&std::all_of(v.payloads.begin(),v.payloads.end(),[](const ModPayload&p){return !p.ips.empty()&&p.files.empty();});
    const bool emulator=std::any_of(v.payloads.begin(),v.payloads.end(),[](const ModPayload&p){return isEmulatorOnly(p.entry);});
    badge(codeOnly?"SE CARGA AL REINICIAR":"JUEGO CERRADO COMPROBADO",56,570,codeOnly?pink:cyan,379);
    box(481,222,767,409,panel,border);neonLine(481,222,767);smallLabel(v.remove?"ARCHIVOS QUE RETIRARÁ LA APLICACIÓN":"SELECCIÓN PREPARADA",506,241,pink);
    if(v.remove)wrapped(v.installed.detail.empty()?"Solo se retirarán archivos registrados y sin cambios ajenos. Se conservarán las copias anteriores.":v.installed.detail,506,278,714,19,6,muted);
    else {int y=274;for(const auto&p:v.payloads){if(y>410){fitted("Más mods incluidos en la selección...",506,454,714,15,muted);break;}fitted("• "+p.entry.name,506,y,714,18);y+=34;}wrapped(v.installed.exists?"Ya existen mods o archivos en los destinos seleccionados. Se conservará una copia antes de sustituirlos. Los conflictos bloquean la instalación.":"Se comprobarán de nuevo el juego, los archivos y sus destinos antes de instalar.",506,491,714,16,3,v.installed.exists?orange:muted);}
    if(!v.remove)fitted(emulator?"Incluye un mod de emulador: su efecto en hardware no está comprobado.":codeOnly?"No cambia la partida actual. Cierra el juego y vuelve a abrirlo después.":"La coincidencia de versión no garantiza el funcionamiento de terceros.",506,573,714,13,emulator?orange:muted);
    fitted(v.detail,34,641,1210,13,orange);footer({{"A",v.remove?"Confirmar retirada":codeOnly?"Preparar próximo inicio":"Confirmar instalación"},{"B","Cancelar"}});
}
void loading(const View&v,bool busy){title(busy?"Operación en curso":"Preparando NinMagic Mods");logoAt(113,277,188);box(350,239,863,335,panel,border);neonLine(350,239,863);wrapped(v.status,375,291,813,24,6);rect(375,510,812,4,border);const int pos=int((v.frame*5)%640);rect(375+pos,510,172,4,pink);fitted("Espera a que termine la operación.",375,540,810,14,muted);footer({});}
void result(const View&v){title(v.outcome.ok?"Operación completada":"Revisa el resultado","Los detalles indican qué se pudo aplicar o recuperar.");box(32,222,365,409,panel,border);logoAt(124,254,181);badge(v.outcome.ok?"COMPLETADO":"REQUIERE ATENCIÓN",55,552,v.outcome.ok?green:orange,318);box(420,222,828,409,panel,border);smallLabel("INFORME",444,244,pink);wrapped(v.outcome.message,444,284,777,20,8,muted);footer({{"A","Volver"},{"B","Volver"},{"+","Salir"}});}
void sources(const View&v){title("Fuentes de mods","Cada fuente conserva su resultado y el estado de su última consulta.");box(32,222,1216,409,panel,border);const int start=std::max(0,v.sourceSelected-3);for(int i=start;i<std::min(int(v.catalog.sources.size()),start+7);++i){const auto&s=v.catalog.sources[i];int y=238+(i-start)*52;if(i==v.sourceSelected)box(41,y,1198,49,raised,border);fitted(s.name,57,y+5,468,18);fitted(s.checked?"CONSULTADO":s.cached?"CACHÉ GUARDADA":"SIN COMPROBAR",940,y+8,275,12,s.checked?green:orange);fitted(std::to_string(s.entries)+" archivos · "+s.detail,57,y+31,1158,12,muted);}fitted(v.catalog.detail,34,641,1210,13,muted);footer({{"D-PAD","Mover"},{"B","Volver"}});}
void appUpdate(const View&v) {
    const auto&u=v.appUpdate;const auto&r=v.completedUpdate;const auto action=appUpdateAction(u,r,v.appUpdateDetail);const bool canInstall=action==AppUpdateAction::Install;
    const bool canReview=action==AppUpdateAction::ReviewCompletedRecord,blocked=r.state==CompletedUpdateState::Blocked,sdDiff=differentAppOnSd(u),onSd=publishedAppOnSd(u);
    const bool unconfirmed=!v.appUpdateDetail.empty()&&!u.installed,current=currentPublishedApp(u,v.appUpdateDetail);
    const std::string detail=v.appUpdateDetail.empty()?u.detail:v.appUpdateDetail;
    title("Actualizar NinMagic Mods","Distingue el programa abierto del NRO que hay en la microSD.");
    box(32,229,367,397,panel,border);neonLine(32,229,367);logoAt(139,251,154);
    smallLabel("PROGRAMA EN EJECUCIÓN",56,430,blue);fitted(u.runningVersion.empty()?"1.2.0":u.runningVersion,56,451,319,31);
    smallLabel("ARCHIVO NRO EN LA SD",56,501,pink);fitted(u.sdVerified?u.sdVersion:"SIN COMPROBAR",56,523,319,24,u.sdVerified?cyan:violet);
    badge(canReview?"REGISTRO ANTIGUO TERMINADO":u.installed||sdDiff?"CIERRA Y VUELVE A ABRIR":blocked||unconfirmed?"REQUIERE REVISIÓN":u.available?"HAY UNA NUEVA VERSIÓN":"NINMAGIC MODS",56,580,canReview||u.installed||sdDiff||blocked||unconfirmed?orange:u.available?green:cyan,319);
    box(423,229,825,397,panel,border);rect(423,229,110,2,u.configured&&!unconfirmed?cyan:orange);
    if(canReview){smallLabel("REGISTRO ANTIGUO TERMINADO",449,249,orange);text("Revisa el registro antes de archivarlo",449,286,27);
        wrapped(r.detail.empty()?"Se encontró un registro terminado que puede archivarse tras revisar el archivo actual y las copias conservadas.":r.detail,449,343,770,19,4,muted);
        smallLabel("REVISIÓN PREVIA A CUALQUIER CAMBIO",449,470,blue);wrapped("A muestra las versiones y la huella del NRO. Después podrás confirmar el archivado del registro. Se conservan el ejecutable y las copias anteriores.",449,493,770,15,3,muted);
        box(449,553,772,57,rgb(15,43,55),rgb(35,122,136));key("A","REVISAR REGISTRO TERMINADO",469,569,cyan);
    }else if(blocked){smallLabel("REGISTRO NO ARCHIVABLE",449,249,orange);text("No se puede archivar este registro",449,286,27);
        wrapped(r.detail.empty()?detail:r.detail,449,343,770,19,6,muted);wrapped(sdDiff?"El archivo de la SD difiere del programa abierto. Cierra NinMagic y vuelve a abrirlo desde hbmenu.":"Se conserva el registro para revisar su estado; no se preparará otra instalación desde esta pantalla.",449,514,770,16,3,orange);badge("REVISA EL INFORME",449,580,orange,770);
    }else if(sdDiff||u.installed||onSd){smallLabel(current?"APLICACIÓN ACTUALIZADA":onSd?"PUBLICACIÓN YA PRESENTE EN LA SD":"ARCHIVO DE LA SD DISTINTO AL PROGRAMA ABIERTO",449,249,current?green:orange);text(current?"No hay actualizaciones pendientes":sdDiff||u.installed?"Cierra NinMagic y vuelve a abrirlo":"El archivo publicado ya está en la SD",449,286,27);
        wrapped(sdDiff?"La versión del NRO de la SD y la que sigue ejecutándose son distintas. Sal completamente y abre NinMagic desde hbmenu para cargar el archivo de la SD.":u.installed?"La instalación terminó. Esta sesión sigue usando el programa anterior hasta que cierres NinMagic y lo abras de nuevo.":"El tamaño, la huella SHA-256 y la versión del NRO de la SD coinciden con la publicación consultada. No hace falta descargarlo otra vez.",449,343,770,19,4,muted);
        smallLabel(onSd?"SHA-256 COINCIDENTE CON LA PUBLICACIÓN":"SHA-256 DEL ARCHIVO DE LA SD",449,460,blue);exactPath(u.sdVerified?u.sdSha256:"Sin comprobar",449,483,770,12,1,muted);
        if(!v.appUpdateDetail.empty())wrapped(v.appUpdateDetail,449,521,770,14,2,orange);
        badge(current?"ÚLTIMA VERSIÓN COMPROBADA":sdDiff||u.installed?"ABRE EL ARCHIVO DE LA SD DESDE HBMENU":"SIN DESCARGA PENDIENTE",449,580,current?green:orange,770);
    }else if(unconfirmed){smallLabel("ACTUALIZACIÓN SIN COMPROBAR",449,249,orange);text("No se pudo comprobar la versión",449,286,27);
        wrapped(detail,449,343,770,19,5,muted);
        wrapped("El informe de error no permite saber si hay una versión más reciente. Revisa la conexión o el canal configurado y vuelve a comprobar.",449,502,770,16,3,muted);
        badge("CONSULTA PENDIENTE",449,580,orange,770);
    }else if(!u.configured){smallLabel("CONSULTA PENDIENTE",449,249,blue);text("Comprueba las actualizaciones",449,286,27);
        wrapped("El canal oficial de GitHub viene integrado. Pulsa X para consultar si existe una versión nueva de NinMagic Mods.",449,343,770,19,4,muted);
        badge("SIN CONSULTAR",449,580,blue,770);
    }else{smallLabel(u.installed?"ARCHIVO INSTALADO Y COMPROBADO":u.prepared?"DESCARGA VERIFICADA":u.available?"NUEVA VERSIÓN PUBLICADA":"SIN ACTUALIZACIÓN PENDIENTE",449,249,u.installed||u.available?green:blue);
        fitted(u.version.empty()?"Versión no indicada":u.version,449,280,500,31);fitted(u.size?bytes(u.size):"Tamaño no indicado",982,295,239,17,muted);
        smallLabel("ARCHIVO NRO · HTTPS",449,334,blue);exactPath(u.url.empty()?"Dirección no disponible":u.url,449,357,770,13,2,muted);
        smallLabel(u.prepared||u.installed?"SHA-256 COMPROBADO":"SHA-256 PUBLICADO",449,415,violet);exactPath(u.sha256.empty()?"Sin huella disponible":u.sha256,449,437,770,12,1,muted);
        wrapped(detail.empty()?(u.available?"A confirma la descarga e instalación. Se comprobarán el archivo NRO y su huella antes de sustituir la aplicación.":"No hay una versión más reciente disponible en el canal configurado."):detail,449,474,770,16,2,u.installed?green:muted);
        if(canInstall){box(449,553,772,57,rgb(15,43,55),rgb(35,122,136));key("A",u.prepared?"INSTALAR DESCARGA VERIFICADA":"DESCARGAR E INSTALAR",469,569,cyan);}
        else badge(u.installed?"CIERRA NINMAGIC Y ÁBRELO DE NUEVO":"SIN DESCARGAS PENDIENTES",449,576,u.installed?orange:blue,770);
    }
    fitted(canReview?"A abre una revisión de sólo lectura; archivar requiere una segunda confirmación.":sdDiff||u.installed?"Cierra NinMagic y vuelve a abrirlo desde hbmenu. No se preparará otra descarga en esta sesión.":blocked?"El registro y el archivo actual se conservan. X vuelve a comprobar su estado.":unconfirmed?"X vuelve a comprobar la actualización. El estado actual de la publicación sigue sin verificar.":!u.configured?"X consulta el canal oficial de actualizaciones de NinMagic Mods.":!u.available?"X vuelve a consultar el canal de versiones configurado.":"La consulta comprueba versiones. La instalación comienza únicamente al confirmarla con A.",34,641,1214,13,canReview||sdDiff||u.installed||blocked||unconfirmed?orange:muted);
    if(canReview)footer({{"A","Revisar registro"},{"X","Comprobar"},{"B","Volver"},{"+","Cerrar"}});
    else if(u.installed||sdDiff)footer({{"+","Cerrar NinMagic"},{"B","Volver"}});
    else if(canInstall)footer({{"A","Descargar e instalar"},{"X","Volver a comprobar"},{"B","Volver"}});
    else footer({{"X","Volver a comprobar"},{"B","Volver"}});
}
void appUpdateRecord(const View&v){
    const auto&r=v.completedUpdate;const bool ready=completedReviewReady(r);title("Revisa el registro terminado","Comprueba estos datos antes de confirmar el archivado del registro.");
    box(32,229,367,397,panel,border);neonLine(32,229,367);smallLabel("NRO ACTUAL EN LA SD",56,249,cyan);fitted(r.currentVersion.empty()?"SIN COMPROBAR":r.currentVersion,56,282,319,31);fitted(r.currentSize?bytes(r.currentSize):"Tamaño sin comprobar",56,330,319,17,muted);
    smallLabel("SHA-256 LEÍDO DEL ARCHIVO",56,383,blue);exactPath(r.currentSha256.empty()?"Sin comprobar":r.currentSha256,56,410,319,12,3,muted);smallLabel("RUTA DEL EJECUTABLE",56,512,pink);exactPath("sdmc:/switch/NinMagicMods/NinMagic-Mods.nro",56,540,319,13,3,muted);
    box(423,229,825,397,panel,border);rect(423,229,110,2,ready?cyan:orange);smallLabel(ready?"REGISTRO ANTIGUO TERMINADO":r.state==CompletedUpdateState::Blocked?"REGISTRO NO ARCHIVABLE":"NO HAY UN REGISTRO PARA ARCHIVAR",449,249,ready?cyan:orange);
    smallLabel("VERSIÓN ANTERIOR REGISTRADA",449,294,blue);fitted(r.oldVersion.empty()?"Sin datos":r.oldVersion,449,320,350,24);smallLabel("VERSIÓN OBJETIVO REGISTRADA",836,294,violet);fitted(r.newVersion.empty()?"Sin datos":r.newVersion,836,320,380,24);
    fitted("Registro "+(r.token.empty()?std::string("sin identificar"):r.token)+" · "+(r.journalState=="committed"?"instalación terminada":r.journalState=="restored"?"recuperación terminada":"estado sin confirmar"),449,373,770,15,orange);
    wrapped(r.detail.empty()?v.appUpdateDetail:r.detail,449,413,770,17,ready?3:6,muted);
    if(ready){wrapped("Se archivará únicamente el registro terminado. El NRO de la SD y sus copias anteriores se conservan.",449,508,770,15,2,muted);box(449,553,772,57,rgb(15,43,55),rgb(35,122,136));key("A","CONFIRMAR ARCHIVADO DEL REGISTRO",469,569,cyan);footer({{"A","Archivar registro"},{"B","Cancelar"}});}
    else footer({{"X","Volver a comprobar"},{"B","Volver"}});
}
void appUpdateResult(const View&v){
    const bool ok=v.appUpdateResultOk,archived=v.appUpdateArchiveResult,installed=ok&&v.appUpdate.installed;
    title(archived?(ok?"Registro terminado archivado":"No se pudo archivar el registro"):installed?"Mods actualizado":"Resultado de la actualización",installed?"Cierra Mods y vuelve a abrirlo para utilizar la nueva versión.":"Revisa el informe antes de continuar.");
    box(32,229,367,397,panel,border);neonLine(32,229,367);logoAt(127,258,177);fitted(ok?"COMPLETADO":"REQUIERE ATENCIÓN",56,476,319,22,ok?green:orange);
    fitted(archived?"Registro de actualización":v.appUpdate.version.empty()?"Consulta el informe":v.appUpdate.version,56,522,319,22,muted);badge(installed?"CIERRA Y VUELVE A ABRIR":"INFORME DE ACTUALIZACIÓN",56,581,ok?cyan:orange,319);
    box(423,229,825,397,panel,border);smallLabel("INFORME",449,249,pink);wrapped(v.appUpdateResultMessage.empty()?"No hay un informe disponible.":v.appUpdateResultMessage,449,286,770,19,8,muted);
    if(installed)footer({{"+","Cerrar Mods"}});else footer({{"A","Volver"},{"B","Volver"},{"+","Salir"}});
}

void help(const View&){title("Elige, comprueba e instala","Mods publicados para la identidad real del juego.");box(32,222,365,409,panel,border);logoAt(111,253,207);text("NINMAGIC MODS",73,503,25,pink);box(420,222,828,409,panel,border);const char*lines[]={"A en biblioteca: consultar y comprobar los mods del juego.","Parches: inicia el juego y abre NinMagic desde Álbum o el overlay.","A marca; Y revisa; A prepara. Cierra y vuelve a iniciar el juego.","RomFS: juego cerrado y modo aplicación; requiere versión declarada.","El overlay instala solo parches pequeños para el próximo inicio.","L retira mods con el juego cerrado y recupera sus copias.","R en biblioteca actualiza NinMagic. X actualiza el catálogo.","ZR explica el mod; X muestra el autor. El destino se conserva."};for(int i=0;i<8;++i)wrapped(lines[i],445,245+i*44,778,15,2,i==3?orange:muted);footer({{"A","Volver"},{"B","Volver"}});}
uint32_t le32(const uint8_t*p){return p[0]|uint32_t(p[1])<<8|uint32_t(p[2])<<16|uint32_t(p[3])<<24;}
std::vector<uint8_t> readFile(const std::string&path) {
    std::ifstream in(path,std::ios::binary);if(!in)return{};
    in.seekg(0,std::ios::end);auto n=in.tellg();if(n<0||n>4000000)return{};in.seekg(0);std::vector<uint8_t>data(static_cast<size_t>(n));in.read(reinterpret_cast<char*>(data.data()),n);return in?data:std::vector<uint8_t>{};
}
} // namespace

bool uiInit(const std::string&assetRoot) {
    uiExit();auto data=readFile(assetRoot+"/font.bin");logo=readFile(assetRoot+"/logo.rgba");
    if(data.size()!=32+224+224*24*34||le32(data.data())!=0x54464D4E||le32(data.data()+4)!=32||le32(data.data()+8)!=224||le32(data.data()+12)!=24||le32(data.data()+16)!=34)return false;
    std::copy(data.begin()+32,data.begin()+256,advances.begin());rawFont.assign(data.begin()+256,data.end());
    for(int size:{11,12,13,14,15,16,17,18,19,20,21,22,23,24,27,28,29})font(size);
    background.resize(W*H);Color *oldfb=fb;int oldpitch=pitch;fb=background.data();pitch=W;
    for(int y=0;y<H;++y)for(int x=0;x<W;++x){unsigned glow=static_cast<unsigned>(std::max(0,250-(std::abs(x-1110)+std::abs(y-170))/2));pixel(x,y,rgb(5+glow/30,11+glow/17,24+glow/12));}
    // Static circuit traces are rendered once and copied with the background.
    Color trace=rgb(15,35,53),node=rgb(24,62,78);
    for(int i=0;i<5;++i){int x=718+i*108;line(x,0,x,32+i*12,trace);line(x,32+i*12,x+22,54+i*12,trace);line(x+22,54+i*12,1279,54+i*12,trace);rect(x-2,30+i*12,5,5,node);}
    for(int i=0;i<4;++i){int x=757+i*126;line(x,719,x,652-i*9,trace);line(x,652-i*9,x+19,633-i*9,trace);line(x+19,633-i*9,1279,633-i*9,trace);}
    fb=oldfb;pitch=oldpitch;return logo.size()==256*256*4;
}
void uiDraw(uint32_t*pixels,int stride,const View&v){if(!pixels||stride<W)return;fb=pixels;pitch=stride;if(background.size()==W*H)for(int y=0;y<H;++y)std::memcpy(fb+y*pitch,background.data()+y*W,W*sizeof(Color));else rect(0,0,W,H,rgb(5,11,24));header(v);switch(v.screen){case Screen::Library:library(v);break;case Screen::Mods:mods(v);break;case Screen::ModDetail:modDetail(v);break;case Screen::Confirm:case Screen::RemoveConfirm:confirm(v);break;case Screen::Sources:sources(v);break;case Screen::Help:help(v);break;case Screen::Loading:loading(v,false);break;case Screen::Busy:loading(v,true);break;case Screen::Result:result(v);break;case Screen::AppUpdate:appUpdate(v);break;case Screen::AppUpdateRecord:appUpdateRecord(v);break;case Screen::AppUpdateResult:appUpdateResult(v);break;}}
void uiExit(){fonts.clear();rawFont.clear();logo.clear();background.clear();fb=nullptr;pitch=W;}
} // namespace nmm
