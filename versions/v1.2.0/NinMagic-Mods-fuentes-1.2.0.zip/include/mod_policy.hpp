#pragma once
#include "model.hpp"
#include <cctype>
#include <string>

namespace nmm {
// Destination label only: never use this helper as a visibility or compatibility
// gate. All destinations remain available for an informed test. A repository
// name or "tested on emulators" does not establish execution exclusivity.
inline std::string emulatorPolicyWords(const std::string &input){
    std::string out=" ";bool space=true;
    for(unsigned char c:input){
        if(c=='.'||c=='\n'||c=='\r'||c==';'||c=='!'||c=='/'||c=='\\'){out+=" | ";space=true;}
        else if(c<128&&std::isalnum(c)){out+=char(std::tolower(c));space=false;}
        else if(c>=128){out+=char(c);space=false;}
        else if(!space){out+=' ';space=true;}
    }
    if(!space)out+=' ';
    return out;
}
inline bool isEmulatorOnlyText(const std::string &input){
    const auto text=emulatorPolicyWords(input);
    for(const char *label:{"emulator only","emulators only","emulation only","yuzu only","ryujinx only","only for yuzu","only for ryujinx","only on yuzu","only on ryujinx","emulator exclusive","exclusively for emulators","solo para emulador","solo para emuladores","solo emulador","exclusivo de emulador","exclusivos de emulador","exclusivamente para emuladores","does not work on switch","not compatible with switch hardware","not supported on physical switch"}){
        const std::string phrase=std::string(" ")+label+" ";size_t at=0;
        while((at=text.find(phrase,at))!=std::string::npos){
            const auto clause=text.rfind('|',at);const size_t start=clause==text.npos?0:clause+1;
            const auto before=text.substr(start,at-start+1);
            const bool testing=before.find(" tested ")!=before.npos||before.find(" testing ")!=before.npos||before.find(" probado ")!=before.npos||before.find(" probados ")!=before.npos;
            const bool negated=before.find(" not ")!=before.npos||before.find(" isn t ")!=before.npos||before.find(" isn’t ")!=before.npos||before.find(" no es ")!=before.npos;
            if(!testing&&!negated)return true;
            at+=phrase.size();
        }
    }
    return false;
}
inline bool isEmulatorOnly(const ModEntry &entry){
    if(isEmulatorOnlyText(entry.name)||isEmulatorOnlyText(entry.path)||isEmulatorOnlyText(entry.detail)||isEmulatorOnlyText(entry.reason))return true;
    for(const auto &file:entry.files)if(isEmulatorOnlyText(file.path))return true;
    return false;
}
}
