#define NC_MODS_TEST
#include "../source/mods.cpp"
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
namespace fs=std::filesystem;
namespace nmm {unsigned policyQueries=0;bool downloadModHttps(const std::string&,const std::string&,uint64_t,std::string&error){++policyQueries;error="offline test";return false;}}
namespace {
unsigned checks=0;fs::path sandbox;
void check(bool x,const char*label){++checks;if(!x)throw std::runtime_error(label);}
#define CHECK(x) check((x),#x)
void put(const fs::path&p,const std::string&s){fs::create_directories(p.parent_path());std::ofstream f(p,std::ios::binary);f<<s;CHECK(bool(f));}
std::string raw(const std::string&path){return "{\"path\":\""+path+"\",\"sha\":\""+std::string(40,'a')+"\",\"type\":\"blob\",\"size\":1}";}
std::string tree(const std::string&rows){return "{\"sha\":\""+std::string(40,'b')+"\",\"truncated\":false,\"tree\":["+rows+"]}";}
}
int main(int argc,char**argv){try{
    for(const char*s:{"emulator-only","Only for Yuzu","Yuzu only","Only on Ryujinx","exclusivo de emulador","Solo para emuladores","does not work on Switch","not supported on physical Switch","Not Tonight/0100000001110000/Yuzu only/1.0.0.pchtxt"})CHECK(nmm::isEmulatorOnlyText(s));
    for(const char*s:{"platform unknown","for Yuzu/Ryujinx","tested on emulators","tested only on emulators","tested on emulator only","not emulator-only","not only for Yuzu","isn't emulator-only","No es exclusivo de emulador","ADEMOLA200/Switch-Emulator-Mod-Database","yuzu-mirror/yuzu-mod-archive"})CHECK(!nmm::isEmulatorOnlyText(s));
    nmm::Game game;game.id=0x0100300012F2A000ULL;game.name="Demo";const std::string base="Demo/[0100300012F2A000]/";
    const auto json=tree(raw(base+"Yuzu only/exefs/1.0.0.pchtxt")+","+raw(base+"Unknown/exefs/1.0.0.pchtxt")+","+raw(base+"Tested on emulators/exefs/1.0.0.pchtxt"));
    nmm::ModsCatalog catalog;std::string error;CHECK(nmm::parseModsTree(json,catalog,error,"ADEMOLA200/Switch-Emulator-Mod-Database")&&catalog.entries.size()==3);CHECK(nmm::isEmulatorOnly(catalog.entries[0]));for(const auto&e:catalog.entries)CHECK(!e.compatible&&!e.selected);
    nmm::ModEntry declared=catalog.entries[0];nmm::ModsCatalog old;old.entries=catalog.entries;old.entries.push_back(declared);CHECK(nmm::findMods(game,old).size()==4);auto mods=old.entries;CHECK(nmm::resolveGameMods(game,mods,error)&&mods.size()==4&&nmm::policyQueries==0);nmm::ModPayload payload;CHECK(!nmm::prepareMod(game,declared,payload,error)&&error.find("Inicia")!=error.npos&&nmm::policyQueries==0);
    sandbox=fs::temp_directory_path()/("nmm-mod-policy-"+std::to_string(getpid())+"-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));fs::create_directories(sandbox);setenv("NC_MODS_ROOT",sandbox.generic_string().c_str(),1);
    for(const auto&provider:nmm::Repos)put(sandbox/"mods-a"/provider.file,json);
    put(sandbox/"mods-a/complete.txt","NMMODS1\n1\n");put(sandbox/"mods-active.txt","a\n");CHECK(nmm::loadModsCatalog(catalog,error));CHECK(std::any_of(catalog.entries.begin(),catalog.entries.end(),[](const nmm::ModEntry&e){return nmm::isEmulatorOnly(e);}));
    const auto input=sandbox/"stream.json";put(input,json);CHECK(nmm::filteredFile(input.generic_string(),game,"ADEMOLA200/Switch-Emulator-Mod-Database",catalog,error)&&catalog.entries.size()==3);
    const auto rom=tree(raw("Demo/1.0.0/titles/0100300012F2A000/romfs/normal.bin")+","+raw("Demo/1.0.0/titles/0100300012F2A000/romfs/emulator-only.bin"));CHECK(nmm::parseModsTree(rom,catalog,error,"masagrator/NXGraphicsPatches")&&catalog.entries.size()==1&&catalog.entries[0].files.size()==2&&nmm::isEmulatorOnly(catalog.entries[0]));put(input,rom);CHECK(nmm::filteredFile(input.generic_string(),game,"masagrator/NXGraphicsPatches",catalog,error)&&catalog.entries.size()==1&&catalog.entries[0].files.size()==2);
    game.version="1.0.0";game.versionKnown=game.buildVerified=game.running=true;game.processId=42;game.contentIdentity=std::string(64,'d');game.fullBuildId=std::string(64,'a');game.buildId=game.fullBuildId.substr(0,16);const auto bytes="@nsobid-"+game.fullBuildId+"\n# Demo [0100300012F2A000]\n# emulator-only\n@enabled\n00001000 20008052\n@stop\n";declared.size=bytes.size();declared.blobSha=nmm::gitBlobSha(bytes);put(sandbox/"mod-files"/(declared.blobSha+".bin"),bytes);CHECK(nmm::prepareMod(game,declared,payload,error)&&payload.compatible);
    if(argc==2){setenv("NC_MODS_ROOT",argv[1],1);CHECK(nmm::loadModsCatalog(catalog,error)&&catalog.sources.size()==10&&catalog.entries.size()==3420);CHECK(std::count_if(catalog.entries.begin(),catalog.entries.end(),[](const nmm::ModEntry&e){return e.path.find("1998p (yuzu only)")!=e.path.npos;})==2);}
    auto absolute=fs::weakly_canonical(sandbox);CHECK(absolute.parent_path()==fs::weakly_canonical(fs::temp_directory_path())&&absolute.filename().string().rfind("nmm-mod-policy-",0)==0);fs::remove_all(absolute);
    std::cout<<"mod destination labels: "<<checks<<" explicit, ambiguous, preserved legacy cache and streaming checks PASS\n";return 0;
}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<" sandbox "<<sandbox<<'\n';return 1;}}
