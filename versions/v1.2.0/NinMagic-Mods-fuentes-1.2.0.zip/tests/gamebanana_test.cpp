#define NM_GAMEBANANA_TEST
#include "../source/gamebanana.cpp"
#include <chrono>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iostream>
#include <new>
#include <stdexcept>
namespace {size_t liveBytes=0,peakBytes=0;struct alignas(std::max_align_t) Allocation {size_t size;};}
[[gnu::noinline]] void *operator new(size_t size){auto*p=static_cast<Allocation*>(std::malloc(sizeof(Allocation)+size));if(!p)throw std::bad_alloc();p->size=size;liveBytes+=size;peakBytes=std::max(peakBytes,liveBytes);return p+1;}
[[gnu::noinline]] void *operator new[](size_t size){return ::operator new(size);}
[[gnu::noinline]] void operator delete(void *p)noexcept{if(p){auto*h=static_cast<Allocation*>(p)-1;liveBytes-=h->size;std::free(h);}}
[[gnu::noinline]] void operator delete[](void *p)noexcept{::operator delete(p);}
[[gnu::noinline]] void operator delete(void *p,size_t)noexcept{::operator delete(p);}
[[gnu::noinline]] void operator delete[](void *p,size_t)noexcept{::operator delete(p);}
namespace fs=std::filesystem;
namespace nmm {std::function<bool(const std::string&,const std::string&,uint64_t,std::string&)> gbDownload;bool downloadGameBananaHttps(const std::string&u,const std::string&p,uint64_t m,std::string&e){return gbDownload&&gbDownload(u,p,m,e);}}
namespace {
unsigned checks=0;fs::path sandbox;
void check(bool ok,const char*s){++checks;if(!ok)throw std::runtime_error(s);}
#define CHECK(x) check((x),#x)
std::string readFile(const fs::path&p){std::ifstream f(p,std::ios::binary);CHECK(bool(f));return std::string((std::istreambuf_iterator<char>(f)),{});}
void write(const fs::path&p,const std::string&s){fs::create_directories(p.parent_path());std::ofstream f(p,std::ios::binary);f<<s;CHECK(bool(f));}
std::string item(uint64_t id=1,uint64_t game=18604,const std::string&name="Super Mario Bros. Wonder"){return "{\"_idRow\":"+std::to_string(id)+",\"_sModelName\":\"Mod\",\"_sName\":\"Test\",\"_sProfileUrl\":\"https://gamebanana.com/mods/"+std::to_string(id)+"\",\"_aGame\":{\"_idRow\":"+std::to_string(game)+",\"_sName\":\""+name+"\"}}";}
std::string feed(const std::string&items,unsigned count=1){return "{\"_aMetadata\":{\"_nRecordCount\":"+std::to_string(count)+",\"_nPerpage\":15,\"_bIsComplete\":true},\"_aRecords\":["+items+"]}";}
}
int main(int argc,char**argv){try{
    const fs::path fixtures=argc==2?argv[1]:"tests/fixtures/gamebanana";const auto real=readFile(fixtures/"vegeta-556710.json"),page=readFile(fixtures/"wonder-page.json");
    nmm::Game game;game.id=0x010015100B514000ULL;game.name="Super Mario Bros. Wonder";game.version="1.2.1";game.versionKnown=game.buildVerified=true;game.fullBuildId="FF773E90972D544E"+std::string(48,'0');game.buildId=game.fullBuildId.substr(0,16);
    nmm::ModEntry mod;std::string error;CHECK(nmm::parseGameBananaMod(game,18604,556710,real,mod,error));CHECK(mod.name=="Vegeta"&&mod.gbGameId==18604&&mod.gbModId==556710&&mod.titleId==game.id);CHECK(mod.author=="diegoforfun"&&mod.category=="Personajes");CHECK(mod.modVersion=="1.0"&&mod.version.empty()&&mod.buildId.empty()&&!mod.compatible&&!mod.selected);CHECK(mod.size==4135114&&mod.fileName=="vegeta_0b8dc.rar"&&mod.downloadUrl=="https://gamebanana.com/dl/1325083");CHECK(mod.reason.find("bloqueada")!=error.npos);
    auto other=game;other.id=0x0100F2C0115B6000ULL;other.name="The Legend of Zelda: Tears of the Kingdom";CHECK(!nmm::parseGameBananaMod(other,18604,556710,real,mod,error));CHECK(!nmm::parseGameBananaMod(game,999,556710,real,mod,error));CHECK(!nmm::parseGameBananaMod(game,18604,123,real,mod,error));
    game.version="1.0";CHECK(nmm::parseGameBananaMod(game,18604,556710,real,mod,error)&&!mod.compatible&&mod.version.empty());game.version="1.2.1";
    std::vector<nmm::ModEntry> entries;CHECK(nmm::parseGameBananaMods(game,18604,page,entries,error)&&entries.size()==15);for(const auto&e:entries)CHECK(!e.compatible&&!e.selected&&e.titleId==game.id&&e.gbGameId==18604&&e.version.empty());
    CHECK(!nmm::parseGameBananaMods(other,18604,page,entries,error));CHECK(!nmm::parseGameBananaMods(game,18604,feed(item(1,999)),entries,error));CHECK(!nmm::parseGameBananaMods(game,18604,feed(item(1,18604,"Super Mario Bros. Wonder 2")),entries,error));CHECK(!nmm::parseGameBananaMods(game,18604,feed(item()+","+item()),entries,error));
    auto exclusive=item();exclusive.replace(exclusive.find("\"Test\""),6,"\"Yuzu only\"");CHECK(nmm::parseGameBananaMods(game,18604,feed(exclusive),entries,error)&&entries.size()==1&&!entries[0].compatible);CHECK(nmm::parseGameBananaMod(game,18604,1,exclusive,mod,error)&&!mod.compatible);
    auto ambiguous=item();ambiguous.insert(ambiguous.size()-1,",\"_sText\":\"Tested on emulators; Switch hardware unknown.\"");CHECK(nmm::parseGameBananaMods(game,18604,feed(ambiguous),entries,error)&&entries.size()==1&&!entries[0].compatible);
    std::string many;for(unsigned n=1;n<=16;++n){if(n>1)many+=',';many+=item(n);}CHECK(!nmm::parseGameBananaMods(game,18604,feed(many,16),entries,error));CHECK(!nmm::parseGameBananaMods(game,18604,"{\"_aRecords\":[],\"_aMetadata\":{}}",entries,error));CHECK(!nmm::parseGameBananaMods(game,18604,std::string(512*1024+1,' '),entries,error));CHECK(!nmm::parseGameBananaMods(game,18604,"{\"x\":1,\"x\":2}",entries,error));CHECK(!nmm::parseGameBananaMods(game,18604,"{\"x\":\"\\uD800x\"}",entries,error));
    nmm::gb::Json json;CHECK(nmm::gb::Parser("{\"float\":1.25e-2,\"emoji\":\"\\uD83D\\uDE00\"}").parse(json));CHECK(!nmm::gb::Parser("{\"n\":01}").parse(json));CHECK(!nmm::gb::Parser("{\"n\":1.}").parse(json));
    other=game;other.id=0x0100000001110000ULL;other.name="Example";uint64_t mapped=0;CHECK(nmm::gb::identify(other,"{\"_aRecords\":[{\"_idRow\":123,\"_sName\":\"Example (Switch)\",\"_sProfileUrl\":\"https://gamebanana.com/games/123\"}]}",mapped,error)&&mapped==123);CHECK(!nmm::gb::identify(other,"{\"_aRecords\":[{\"_idRow\":123,\"_sName\":\"Example\",\"_sProfileUrl\":\"https://gamebanana.com/games/123\"}]}",mapped,error));CHECK(!nmm::gb::identify(other,"{\"_aRecords\":[{\"_idRow\":123,\"_sName\":\"Example 2 (Switch)\",\"_sProfileUrl\":\"https://gamebanana.com/games/123\"}]}",mapped,error));
    other.name=u8"日本語";CHECK(!nmm::gb::validGame(other,123,u8"中国語 (Switch)"));CHECK(nmm::gb::validGame(other,123,u8"日本語 (Switch)"));other.name=u8"日本語1";CHECK(!nmm::gb::validGame(other,123,u8"中国語1 (Switch)"));other.name="!!!";CHECK(!nmm::gb::validGame(other,123,"??? (Switch)"));
    sandbox=fs::temp_directory_path()/("nmm-gamebanana-test-"+std::to_string(getpid())+"-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));fs::create_directories(sandbox);setenv("NM_GAMEBANANA_ROOT",sandbox.generic_string().c_str(),1);
    unsigned queries=0;nmm::gbDownload=[&](const std::string&url,const std::string&path,uint64_t maximum,std::string&){CHECK(maximum==nmm::gb::MaxJson);CHECK(url.rfind("https://gamebanana.com/apiv11/",0)==0);++queries;write(path,url.find("/Mod/556710?")!=url.npos?real:page);return true;};
    const auto baseline=liveBytes;peakBytes=liveBytes;CHECK(nmm::loadGameBananaMods(game,entries,error)&&entries.size()==16&&queries==7&&error.empty());const auto loadPeak=peakBytes-baseline;CHECK(loadPeak<2*1024*1024);const auto original=entries.size();CHECK(nmm::loadGameBananaMods(game,entries,error)&&entries.size()==original&&queries==7);
    nmm::gbDownload=[&](const std::string&,const std::string&,uint64_t,std::string&e){++queries;e="TLS offline";return false;};CHECK(nmm::loadGameBananaMods(game,entries,error,true)&&entries.size()==original&&queries==14&&!error.empty());CHECK(readFile(sandbox/"010015100B514000-featured.json")==real);
    nmm::gbDownload=[&](const std::string&,const std::string&path,uint64_t,std::string&){++queries;write(path,feed(item(1,999)));return true;};CHECK(nmm::loadGameBananaMods(game,entries,error,true)&&entries.size()==original&&!error.empty());CHECK(readFile(sandbox/"010015100B514000-featured.json")==real);for(const auto&e:entries)CHECK(!e.compatible&&!e.selected&&e.titleId==game.id);
    other=game;other.id=0x010093801237C000ULL;other.name="Metroid Dread";CHECK(!nmm::loadGameBananaMods(other,entries,error,true)&&entries.empty()&&!error.empty());
    std::string bomb="{\"bomb\":[";for(unsigned n=0;n<1024;++n){if(n)bomb+=',';bomb+='{';for(unsigned k=0;k<12;++k){if(k)bomb+=',';bomb+="\"k"+std::to_string(k)+"\":0";}bomb+='}';}bomb+="]}";const auto adversarialBaseline=liveBytes;peakBytes=liveBytes;nmm::gb::Json bombRoot;CHECK(!nmm::gb::Parser(bomb).parse(bombRoot));const auto adversarialPeak=peakBytes-adversarialBaseline;
#ifdef NMM_OVERLAY
    CHECK(adversarialPeak<1024*1024);
#else
    CHECK(adversarialPeak<4*1024*1024);
#endif
    auto absolute=fs::weakly_canonical(sandbox);CHECK(absolute.parent_path()==fs::weakly_canonical(fs::temp_directory_path())&&absolute.filename().string().rfind("nmm-gamebanana-test-",0)==0);fs::remove_all(absolute);
    std::cout<<"GameBanana: "<<checks<<" real metadata, identity, bounds, cache and offline checks PASS; load peak="<<loadPeak<<" bytes; rejected node-bomb peak="<<adversarialPeak<<" bytes\n";return 0;
}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<" fixtures "<<sandbox<<'\n';return 1;}}
