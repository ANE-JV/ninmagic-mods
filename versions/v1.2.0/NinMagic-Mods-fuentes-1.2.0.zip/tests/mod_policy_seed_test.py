"""All original indexes and emulator-labelled entries remain available."""
from pathlib import Path
import hashlib
import json
ROOT = Path(__file__).resolve().parents[1]
report = json.loads((ROOT / "dist/mods-seed/verification.json").read_text())
checks = 0
labelled = []
def check(ok):
    global checks
    checks += 1
    if not ok:
        raise AssertionError("preserved source seed")
check(len(report["sources"]) == 10)
for row in report["sources"]:
    data = (ROOT / "dist/mods-seed/config/NinMagicMods/mods-a" / row["file"]).read_bytes()
    check(hashlib.sha256(data).hexdigest() == row["sha256"])
    original = ROOT / "dist/research" / (row["repository"].replace("/", "-") + ".json")
    check(original.read_bytes() == data)
    tree = json.loads(data)
    check(tree["truncated"] is False)
    labelled.extend((row["repository"], entry["path"]) for entry in tree["tree"]
                    if entry["type"] == "blob" and "1998p (yuzu only)" in entry["path"].lower()
                    and entry["path"].endswith(".pchtxt"))
check(len(labelled) == 2)
check({repo for repo, _ in labelled} == {"ADEMOLA200/Switch-Emulator-Mod-Database", "Kenji-NX/switch-pchtxt-mods"})
print(f"seed preservation: {checks} original-index and emulator-labelled entry checks PASS")
