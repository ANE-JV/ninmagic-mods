#define NMM_OVERLAY_BUNDLE_TEST
#include "../source/overlay_bundle.cpp"
#include "mod_hash.hpp"
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
namespace fs=std::filesystem;
namespace nmm {bool downloadHttpsFile(const std::string&,const std::string&,std::string&){return false;}}
namespace {
unsigned checks=0,scenarios=0;fs::path sandbox,current;std::string body,oldBody,detail;
void check(bool b,const char*s){++checks;if(!b)throw std::runtime_error(s);}
#define CHECK(x) check((x),#x)
void p32(std::string&s,size_t at,uint32_t n){for(unsigned i=0;i<4;++i)s[at+i]=char(n>>(8*i));}
void p64(std::string&s,size_t at,uint64_t n){for(unsigned i=0;i<8;++i)s[at+i]=char(n>>(8*i));}
std::string nro(const std::string&version){constexpr size_t code=0x1000,nacp=72;std::string s(code+nacp+0x4000+80,0);s.replace(0x10,4,"NRO0");p32(s,0x18,code);p32(s,0x20,0);p32(s,0x24,0x800);p32(s,0x28,0x800);p32(s,0x2c,0x400);p32(s,0x30,0xc00);p32(s,0x34,0x400);s.replace(code,4,"ASET");p64(s,code+8,56);p64(s,code+16,16);p64(s,code+24,nacp);p64(s,code+32,0x4000);p64(s,code+40,nacp+0x4000);p64(s,code+48,80);s.replace(code+nacp,13,"NinMagic Mods");s.replace(code+nacp+0x200,8,"NinMagic");s.replace(code+nacp+0x3060,version.size(),version);return s;}
fs::path target(){return current/"sd/switch/.overlays/ninmagic-mods.ovl";}
fs::path pending(){return current/"sd/switch/.overlays/.ninmagic-mods.ovl.pending";}
fs::path previous(){return current/"sd/switch/.overlays/.ninmagic-mods.ovl.previous";}
fs::path backup(unsigned n=1){char s[40];std::snprintf(s,sizeof(s),"backup-%08u.ovl",n);return current/"sd/config/NinMagicMods/overlay-update"/s;}
void put(const fs::path&p,const std::string&s){fs::create_directories(p.parent_path());std::ofstream f(p,std::ios::binary);CHECK(bool(f));f.write(s.data(),std::streamsize(s.size()));CHECK(bool(f));}
std::string get(const fs::path&p){std::ifstream f(p,std::ios::binary);return std::string(std::istreambuf_iterator<char>(f),{});}
std::string manifest(const std::string&s){return "NMMODS-OVERLAY-1\nversion=1.2.0\nsha256="+nmm::mod_hash::shaText(s)+"\nsize="+std::to_string(s.size())+"\n";}
void next(bool installed=false){++scenarios;current=sandbox/("case-"+std::to_string(scenarios));fs::create_directories(current/"rom");fs::create_directories(current/"sd/switch/.overlays");setenv("NMM_OVERLAY_BUNDLE_ROOT",current.generic_string().c_str(),1);body=nro("1.2.0");oldBody=nro("1.1.0");nmm::bundleFailure.clear();nmm::bundleHook={};put(current/"rom/ninmagic-mods.ovl",body);put(current/"rom/overlay-info.txt",manifest(body));put(current/"sd/switch/.overlays/ninmagic-cheats.ovl","cheats overlay");put(current/"sd/config/NinMagicCheats/keep","cheats settings");put(current/"sd/Nintendo/keep","installed games");if(installed)put(target(),oldBody);}
void untouched(){CHECK(get(current/"sd/switch/.overlays/ninmagic-cheats.ovl")=="cheats overlay");CHECK(get(current/"sd/config/NinMagicCheats/keep")=="cheats settings");CHECK(get(current/"sd/Nintendo/keep")=="installed games");}
void cleanup(){const auto a=fs::weakly_canonical(sandbox),p=fs::weakly_canonical(fs::temp_directory_path());CHECK(a.parent_path()==p&&a.filename().string().rfind("ninmagic-overlay-test-",0)==0);fs::remove_all(a);}
}
int main(int argc,char**argv){sandbox=fs::temp_directory_path()/("ninmagic-overlay-test-"+std::to_string(getpid())+"-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));try{CHECK(fs::create_directory(sandbox));
    next();{std::string v,h,e;uint64_t size=0;CHECK(nmm::inspectNinMagicExecutable((current/"rom/ninmagic-mods.ovl").generic_string(),v,h,size,e)&&v=="1.2.0"&&h==nmm::mod_hash::shaText(body)&&size==body.size());CHECK(nmm::ensureBundledOverlay(detail)&&get(target())==body&&!fs::exists(pending())&&!fs::exists(previous()));CHECK(nmm::ensureBundledOverlay(detail)&&!fs::exists(backup()));untouched();}
    next(true);{CHECK(nmm::ensureBundledOverlay(detail)&&get(target())==body&&get(backup())==oldBody&&!fs::exists(previous()));CHECK(nmm::ensureBundledOverlay(detail)&&!fs::exists(backup(2)));untouched();}
    for(const char*ver:{"1.2.1","1.3.0","1.10.0","2.0.0","10.0.0"}){next(true);const auto future=nro(ver);put(target(),future);CHECK(!nmm::ensureBundledOverlay(detail)&&get(target())==future&&!fs::exists(pending()));untouched();}
    next(true);{put(target(),"foreign bytes");CHECK(!nmm::ensureBundledOverlay(detail)&&get(target())=="foreign bytes"&&!fs::exists(backup()));untouched();}
    next(true);{auto foreign=nro("1.0.0");foreign[0x1000+72]='X';put(target(),foreign);CHECK(!nmm::ensureBundledOverlay(detail)&&get(target())==foreign);}
    for(const std::string&bad:{std::string("wrong magic\n"),manifest(body)+"extra=1\n",std::string("NMMODS-OVERLAY-1\nversion=1.2.0\nsha256=")+std::string(64,'A')+"\nsize=20632\n",manifest(body.substr(0,100))}){next(true);put(current/"rom/overlay-info.txt",bad);CHECK(!nmm::ensureBundledOverlay(detail)&&get(target())==oldBody&&!fs::exists(pending()));untouched();}
    next(true);{put(current/"rom/ninmagic-mods.ovl",nro("1.0.0"));CHECK(!nmm::ensureBundledOverlay(detail)&&get(target())==oldBody);}
    next(true);{put(pending(),"foreign pending");CHECK(!nmm::ensureBundledOverlay(detail)&&get(target())==oldBody&&get(pending())=="foreign pending");untouched();}
    next(true);{put(pending(),body.substr(0,body.size()/2));CHECK(nmm::ensureBundledOverlay(detail)&&get(target())==body&&get(backup())==oldBody);untouched();}
    next(true);{put(pending(),"");CHECK(nmm::ensureBundledOverlay(detail)&&get(target())==body);}
    next(true);{nmm::bundleFailure="copy-short";CHECK(!nmm::ensureBundledOverlay(detail)&&get(target())==oldBody&&fs::file_size(pending())<body.size());CHECK(nmm::ensureBundledOverlay(detail)&&get(target())==body&&get(backup())==oldBody);untouched();}
    next(true);{nmm::bundleFailure="commit";CHECK(!nmm::ensureBundledOverlay(detail)&&get(target())==oldBody&&get(pending())==body);CHECK(nmm::ensureBundledOverlay(detail)&&get(target())==body);untouched();}
    next(true);{put(previous(),oldBody.substr(0,100));CHECK(nmm::ensureBundledOverlay(detail)&&get(target())==body&&get(backup())==oldBody);}
    next(true);{put(previous(),"foreign previous");CHECK(!nmm::ensureBundledOverlay(detail)&&get(target())==oldBody&&get(previous())=="foreign previous");untouched();}
    next();{put(previous(),oldBody);put(pending(),body);CHECK(nmm::ensureBundledOverlay(detail)&&get(target())==body&&get(backup())==oldBody&&!fs::exists(previous()));untouched();}
    next();{put(target(),body);put(previous(),oldBody);CHECK(nmm::ensureBundledOverlay(detail)&&get(target())==body&&get(backup())==oldBody&&!fs::exists(previous()));untouched();}
    next(true);{put(previous(),nro("0.9.0"));CHECK(!nmm::ensureBundledOverlay(detail)&&get(target())==oldBody&&get(previous())==nro("0.9.0"));untouched();}
    next(true);{nmm::bundleFailure="after-old-unlink";CHECK(!nmm::ensureBundledOverlay(detail)&&!fs::exists(target())&&get(previous())==oldBody&&get(backup())==oldBody);CHECK(nmm::ensureBundledOverlay(detail)&&get(target())==body&&!fs::exists(previous()));untouched();}
    next(true);{nmm::bundleFailure="after-activate";CHECK(!nmm::ensureBundledOverlay(detail)&&get(target())==body&&get(previous())==oldBody);CHECK(nmm::ensureBundledOverlay(detail)&&get(target())==body&&!fs::exists(previous()));untouched();}
    next(true);{nmm::bundleFailure="activate-rename";CHECK(!nmm::ensureBundledOverlay(detail)&&get(target())==oldBody&&get(backup())==oldBody&&!fs::exists(previous()));CHECK(nmm::ensureBundledOverlay(detail)&&get(target())==body);untouched();}
    next(true);{nmm::bundleFailure="activate-commit";CHECK(!nmm::ensureBundledOverlay(detail)&&get(target())==oldBody&&get(backup())==oldBody&&get(backup().parent_path()/"rejected-00000001.ovl")==body);untouched();}
    next();{nmm::bundleFailure="activate-commit";CHECK(!nmm::ensureBundledOverlay(detail)&&!fs::exists(target())&&!fs::exists(previous())&&get(backup().parent_path()/"rejected-00000001.ovl")==body);untouched();}
    next(true);{const auto appeared=nro("2.0.0");nmm::bundleFailure="activate-rename";nmm::bundleHook=[&](const char*stage){if(std::string(stage)=="activated")put(target(),appeared);};CHECK(!nmm::ensureBundledOverlay(detail)&&get(target())==appeared&&get(previous())==oldBody&&get(backup())==oldBody&&!fs::exists(backup().parent_path()/"rejected-00000001.ovl"));untouched();}
    next(true);{nmm::bundleHook=[](const char*stage){if(std::string(stage)=="prepared")nmm::bundleFailure="copy-short";};CHECK(!nmm::ensureBundledOverlay(detail)&&get(target())==oldBody&&fs::file_size(backup())<oldBody.size()&&!fs::exists(previous()));nmm::bundleHook={};CHECK(nmm::ensureBundledOverlay(detail)&&get(target())==body&&get(backup(2))==oldBody);untouched();}
    next(true);{nmm::bundleHook=[](const char*stage){if(std::string(stage)=="activated")put(target(),"corrupt new file");};CHECK(!nmm::ensureBundledOverlay(detail)&&get(target())==oldBody&&get(backup().parent_path()/"rejected-00000001.ovl")=="corrupt new file");untouched();}
    next(true);{const auto changed=nro("2.0.0");nmm::bundleHook=[&](const char*stage){if(std::string(stage)=="prepared")put(target(),changed);};CHECK(!nmm::ensureBundledOverlay(detail)&&get(target())==changed&&!fs::exists(backup()));untouched();}
    next(true);{put(backup(),"pre-existing backup");CHECK(nmm::ensureBundledOverlay(detail)&&get(backup())=="pre-existing backup"&&get(backup(2))==oldBody);untouched();}
    for(const char*leaf:{"target","pending","previous","manifest","overlay-dir","config-dir"}){next(true);const auto outside=current/"outside";put(outside,"outside unchanged");fs::path link;if(std::string(leaf)=="target"){link=target();fs::remove(link);}else if(std::string(leaf)=="pending")link=pending();else if(std::string(leaf)=="previous")link=previous();else if(std::string(leaf)=="manifest"){link=current/"rom/overlay-info.txt";fs::remove(link);}else if(std::string(leaf)=="overlay-dir"){link=current/"sd/switch/.overlays";fs::rename(link,current/"saved-overlays");}else{link=current/"sd/config/NinMagicMods";fs::create_directories(link.parent_path());}fs::create_symlink(outside,link);CHECK(!nmm::ensureBundledOverlay(detail)&&get(outside)=="outside unchanged"&&fs::is_symlink(link));}
    next(true);{fs::create_directory(pending());CHECK(!nmm::ensureBundledOverlay(detail)&&get(target())==oldBody&&fs::is_directory(pending()));untouched();}
    next(true);{const auto oversized=body+std::string(8*1024*1024,'x');put(current/"rom/ninmagic-mods.ovl",oversized);put(current/"rom/overlay-info.txt",manifest(oversized));CHECK(!nmm::ensureBundledOverlay(detail)&&get(target())==oldBody&&!fs::exists(pending()));untouched();}
    if(argc==2){next();body=get(argv[1]);put(current/"rom/ninmagic-mods.ovl",body);put(current/"rom/overlay-info.txt",manifest(body));CHECK(nmm::ensureBundledOverlay(detail)&&get(target())==body);std::cout<<"actual embedded OVL validated and deployed in isolated PC fixture\n";}
    cleanup();std::cout<<"overlay bundle: "<<scenarios<<" scenarios / "<<checks<<" checks PASS\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<" fixtures="<<sandbox<<'\n';return 1;}}
