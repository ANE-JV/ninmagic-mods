#define NMM_MOD_INSTALL_TEST
#include "../source/mod_install.cpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <chrono>
namespace fs=std::filesystem;
namespace nmm {Game observed;bool validateRunningGame(const Game&g,std::string&e){e.clear();return g.running&&g.processId==observed.processId&&g.fullBuildId==observed.fullBuildId&&g.contentIdentity==observed.contentIdentity;}bool validateClosedResources(const Game&,std::string&e){e="Resources blocked in overlay";return false;}}
using namespace nmm;using B=std::vector<uint8_t>;int checks=0;fs::path current,sandbox;void need(bool b,const char*s){++checks;if(!b){std::cerr<<"FAIL "<<s<<"\n";std::exit(1);}}
Game game(){Game g;g.id=0x010015100B514000ULL;g.name="Wonder";g.version="1.2.1";g.versionKnown=g.buildVerified=g.running=true;g.processId=1234;g.contentVersion=196608;g.contentIdentity=std::string(64,'c');g.buildId="FF773E90972D544E";g.fullBuildId=g.buildId+std::string(48,'0');return g;}
ModPayload patch(unsigned count=1,uint32_t address=0x1000){ModPayload p;p.game=game();p.entry.titleId=game().id;p.entry.name="60FPS";p.entry.buildId=game().fullBuildId;p.entry.format=ModFormat::Ips;p.compatible=true;p.buildId=game().fullBuildId;p.ips={'I','P','S','3','2',uint8_t(address>>24),uint8_t(address>>16),uint8_t(address>>8),uint8_t(address),0,0,uint8_t(count>>8),uint8_t(count),1,'E','E','O','F'};return p;}
std::string patchPath(){return "atmosphere/exefs_patches/NinMagicMods_"+titleId(game().id)+"/"+game().fullBuildId+".ips";}
std::string model(){return "atmosphere/contents/"+titleId(game().id)+"/romfs/Model/character.bin";}
void put(const std::string&p,const B&b){auto f=current/fs::u8path(p);fs::create_directories(f.parent_path());std::ofstream out(f,std::ios::binary);out.write(reinterpret_cast<const char*>(b.data()),std::streamsize(b.size()));need(bool(out),"fixture write");}
B get(const std::string&p){std::ifstream f(current/fs::u8path(p),std::ios::binary);return {std::istreambuf_iterator<char>(f),{}};}
void use(int n){current=sandbox/std::to_string(n);fs::create_directories(current);setenv("NMM_MOD_INSTALL_ROOT",current.generic_string().c_str(),1);observed=game();}
int main(){auto parent=fs::temp_directory_path();sandbox=parent/("nmm-overlay-install-"+std::to_string(std::chrono::high_resolution_clock::now().time_since_epoch().count()));fs::create_directories(sandbox);std::string e;
 use(1);{auto payload=patch();need(installMods(game(),{payload},false).ok,"overlay schedules exact live IPS");need(!removeMods(game()).ok,"overlay cannot remove resources or active ownership live");}
 use(2);{need(!installMods(game(),{patch(5000),patch(5000,0x4000)},false).ok,"overlay8KiB combined expansion enforced");need(!fs::exists(current/"atmosphere"),"overlarge combined selection has no target writes");}
 use(3);{B foreign(128*1024+1,7);put(patchPath(),foreign);need(!installMods(game(),{patch()},true).ok&&get(patchPath())==foreign,"large earlier IPS asks for NRO and stays intact");}
 use(4);{B foreign(128*1024+1,7);const auto temp=patchPath()+".ninmagic-mods-00000001.tmp";put(temp,foreign);need(!installMods(game(),{patch()},true).ok&&get(temp)==foreign,"large foreign temp is bounded and preserved");}
 use(5);{B large(2*1024*1024,9);Receipt old;old.game=game();old.token="00000001";old.installing=true;old.hasResourceContext=true;old.resourceContext=game();old.resourceContext.running=false;old.resourceContext.processId=0;Change c;c.path=model();c.after=state(large,true);c.original={};c.before={};c.owned=true;old.changes.push_back(c);put(model(),large);put(dataPath(old,0,'a'),large);put(dir(old)+"/receipt.bin",encode(old));const auto ready=phaseText("ready"),committed=phaseText("committed"),active=pointerText(game().id,old.token);put(dir(old)+"/phase-ready.txt",B(ready.begin(),ready.end()));put(dir(old)+"/phase-committed.txt",B(committed.begin(),committed.end()));put(base(game().id)+"/active.txt",B(active.begin(),active.end()));need(installMods(game(),{patch()},true).ok,"overlay streams preserved2MiB RomFS backup");need(get(model())==large,"overlay never changes retained live RomFS");}
 use(6);{put(base(game().id)+"/00000001/receipt.bin",B(64*1024+1,'x'));const auto active=pointerText(game().id,"00000001");put(base(game().id)+"/active.txt",B(active.begin(),active.end()));need(!installMods(game(),{patch()},true).ok,"oversized old receipt stays bounded");need(!fs::exists(current/fs::u8path(patchPath())),"oversized receipt cannot schedule a patch");}
 const auto resolved=fs::weakly_canonical(sandbox);need(resolved.parent_path()==fs::weakly_canonical(parent)&&resolved.filename().string().rfind("nmm-overlay-install-",0)==0,"safe cleanup");fs::remove_all(resolved);std::cout<<checks<<" overlay installer bound checks passed\n";}
