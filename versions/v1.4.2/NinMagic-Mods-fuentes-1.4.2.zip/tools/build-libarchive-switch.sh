#!/usr/bin/env bash
# Run in devkitPro MSYS2. Pinned upstream source, static reader dependency.
set -euo pipefail
cd "$(dirname "$0")/.."
export DEVKITPRO="${DEVKITPRO:-/opt/devkitpro}"
version=3.8.10
sha256=56cad765459d5ee25a3b761f90c47d99379d28297fbfb72d908880d6b875fb96
mkdir -p dist/deps third_party/libarchive-switch
archive="dist/deps/libarchive-$version.tar.xz"
if [[ ! -f "$archive" ]]; then
  curl --fail --location --proto '=https' --tlsv1.2 "https://www.libarchive.org/downloads/libarchive-$version.tar.xz" -o "$archive"
fi
printf '%s  %s\n' "$sha256" "$archive" | sha256sum --check -
if [[ ! -d "dist/deps/libarchive-$version" ]]; then
  bsdtar -xf "$archive" -C dist/deps
fi
cmake -S "dist/deps/libarchive-$version" -B "dist/deps/libarchive-switch-$version" -G 'Unix Makefiles' \
  -DCMAKE_TOOLCHAIN_FILE="$DEVKITPRO/cmake/Switch.cmake" -DCMAKE_BUILD_TYPE=MinSizeRel \
  -DCMAKE_INSTALL_PREFIX="$PWD/third_party/libarchive-switch" -DBUILD_SHARED_LIBS=OFF \
  -DHAVE_FCHDIR=1 -DCMAKE_DEPENDS_USE_COMPILER=FALSE \
  -DCMAKE_C_FLAGS=-Dtimezone=_timezone \
  -DENABLE_TEST=OFF -DENABLE_TAR=OFF -DENABLE_CPIO=OFF -DENABLE_CAT=OFF -DENABLE_UNZIP=OFF \
  -DENABLE_OPENSSL=OFF -DENABLE_MBEDTLS=OFF -DENABLE_NETTLE=OFF -DENABLE_CNG=OFF \
  -DENABLE_LIBXML2=OFF -DENABLE_EXPAT=OFF -DENABLE_LZMA=OFF -DENABLE_BZip2=OFF \
  -DENABLE_LZ4=OFF -DENABLE_ZSTD=OFF -DENABLE_LIBB2=OFF -DENABLE_ACL=OFF \
  -DENABLE_XATTR=OFF -DENABLE_ICONV=OFF
cmake --build "dist/deps/libarchive-switch-$version" -j "${NMM_BUILD_JOBS:-4}"
cmake --install "dist/deps/libarchive-switch-$version"
cp "dist/deps/libarchive-$version/COPYING" third_party/libarchive-switch/LICENSE
printf 'libarchive %s\nsource_sha256=%s\nformats=ZIP stored/deflate,RAR4,RAR5\ndependencies=zlib\n' "$version" "$sha256" > third_party/libarchive-switch/BUILD-INFO.txt
