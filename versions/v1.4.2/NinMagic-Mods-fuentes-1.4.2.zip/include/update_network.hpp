#pragma once
#include <string>
#include <cstdint>
namespace nmm {
// Downloads only the updater-owned manifest/download temporary paths. HTTPS,
// certificate/host validation and bounded bodies remain mandatory.
bool downloadHttpsFile(const std::string &url,const std::string &path,std::string &error);
// Catalog trees and content-addressed mod payloads only; cannot target games.
bool downloadModHttps(const std::string &url,const std::string &path,uint64_t maximum,std::string &error);
// Immutable Git source archives; private archive cache only, up to 128 MiB.
bool downloadModArchiveHttps(const std::string &url,const std::string &path,uint64_t maximum,std::string &error);
// GameBanana JSON API only; private, bounded metadata paths and verified HTTPS.
bool downloadGameBananaHttps(const std::string &url,const std::string &path,uint64_t maximum,std::string &error);
// Published GameBanana files only. Every redirect stays on verified HTTPS and
// the provider's download hosts; cannot target installed game files.
bool downloadGameBananaArchiveHttps(const std::string &url,const std::string &path,uint64_t maximum,std::string &error);
// Call only after the updater worker has ended.
void updateNetworkExit();
}
