#pragma once
#include "model.hpp"
namespace nmm {
inline constexpr const char*GameBananaBatchProperties="_idRow,_sName,_sProfileUrl,_aGame,_aSubmitter,_aRootCategory,_aCategory,_aFiles,_sText,_bIsTrashed,_bIsObsolete,_bIsWithheld";
// Discovery metadata only. Selection does not certify game compatibility.
// Requests are per selected game, bounded, and privately cached for six hours.
// Batch details exclude declared desktop builders before the mod list is shown.
bool loadGameBananaMods(const Game&,std::vector<ModEntry>&,std::string&error,bool force=false);
// Bounded pure parsers also used with captured, real provider responses in tests.
bool parseGameBananaMods(const Game&,uint64_t gameBananaId,const std::string&,std::vector<ModEntry>&,std::string&error);
bool parseGameBananaMod(const Game&,uint64_t gameBananaId,uint64_t modId,const std::string&,ModEntry&,std::string&error);
bool parseGameBananaModFiles(const Game&,uint64_t gameBananaId,uint64_t modId,const std::string&,std::vector<ModEntry>&,std::string&error);
// Enumerate the author's active ZIP/RAR variants; never choose an arbitrary
// first file when a publication contains several downloads.
bool loadGameBananaModFiles(const Game&,const ModEntry&,std::vector<ModEntry>&,std::string&error,bool force=false);
// Fetch the author's current file metadata before inspecting a selected package.
// This does not enable installation or download archives during list discovery.
bool refreshGameBananaMod(const Game&,ModEntry&,std::string&error,bool force=false);
// NRO-only: revalidate source identity, size and published file checksum, then
// return a private verified archive. The archive inspector still checks payload,
// paths, target title, format, integrity and the author patch destination.
bool obtainGameBananaArchive(const Game&,const ModEntry&,std::string&localPath,std::string&error);
}
