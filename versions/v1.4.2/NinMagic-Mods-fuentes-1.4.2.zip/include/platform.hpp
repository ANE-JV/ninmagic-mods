#pragma once
#include "model.hpp"
namespace nmm {
bool platformInit(Environment&,std::string&error);
void platformExit();
bool scanGames(std::vector<Game>&,Environment&,std::string&error);
// Captures installed resource identity and, when available, the full Build ID.
// A true result for a closed title can be resource-only; inspect buildVerified.
bool resolveBuild(Game&,Environment&,std::string&error);
// Read-only current-game identity for an overlay; never attaches to the cheat service.
// The PID is required; Build ID is optional metadata and never mod authorization.
bool resolveRunningGame(Game&,Environment&,std::string&error);
// Static executable patches are only scheduled on SD for the next launch.
// This proves the current process/content snapshot, including a BID if captured.
bool validateRunningGame(const Game&expected,std::string&error);
// Closed installations/removal require a fresh NCM content identity;
// a missing display version or Build ID does not block user-selected mods.
bool validateClosedResources(const Game&expected,std::string&error);
// Must obtain a fresh effective content/version/build and prove the title is closed.
bool validateClosedGame(const Game&expected,std::string&error);
}
