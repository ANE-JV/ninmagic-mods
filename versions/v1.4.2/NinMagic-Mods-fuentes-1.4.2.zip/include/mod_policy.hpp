#pragma once
#include "model.hpp"
#include <cctype>
#include <string>

namespace nmm {
// Source identity and admitted formats are mandatory. Platform/version evidence
// is informational for user-chosen installation; explicit emulator-only mods
// remain excluded. This policy never certifies compatibility or performance.
inline std::string emulatorPolicyWords(const std::string &input){
    std::string out=" ";bool space=true;
    for(unsigned char c:input){
        if(c=='.'||c=='\n'||c=='\r'||c==';'||c=='!'||c=='/'||c=='\\'){out+=" | ";space=true;}
        else if(c<128&&std::isalnum(c)){out+=char(std::tolower(c));space=false;}
        else if(c>=128){out+=char(c);space=false;}
        else if(!space){out+=' ';space=true;}
    }
    if(!space)out+=' ';
    return out;
}
inline bool isEmulatorOnlyText(const std::string &input){
    const auto text=emulatorPolicyWords(input);
    for(const char *label:{"emulator only","emulators only","emulation only","yuzu only","ryujinx only","only for yuzu","only for ryujinx","only on yuzu","only on ryujinx","emulator exclusive","exclusively for emulators","solo para emulador","solo para emuladores","solo emulador","exclusivo de emulador","exclusivos de emulador","exclusivamente para emuladores","does not work on switch","not compatible with switch hardware","not supported on physical switch"}){
        const std::string phrase=std::string(" ")+label+" ";size_t at=0;
        while((at=text.find(phrase,at))!=std::string::npos){
            const auto clause=text.rfind('|',at);const size_t start=clause==text.npos?0:clause+1;
            const auto before=text.substr(start,at-start+1);
            const bool testing=before.find(" tested ")!=before.npos||before.find(" testing ")!=before.npos||before.find(" probado ")!=before.npos||before.find(" probados ")!=before.npos;
            const bool negated=before.find(" not ")!=before.npos||before.find(" isn t ")!=before.npos||before.find(" isn’t ")!=before.npos||before.find(" no es ")!=before.npos;
            if(!testing&&!negated)return true;
            at+=phrase.size();
        }
    }
    return false;
}
inline bool isEmulatorOnly(const ModEntry &entry){
    if(isEmulatorOnlyText(entry.name)||isEmulatorOnlyText(entry.path)||isEmulatorOnlyText(entry.detail)||isEmulatorOnlyText(entry.reason))return true;
    for(const auto &file:entry.files)if(isEmulatorOnlyText(file.path))return true;
    return false;
}
// A builder is a desktop program producing a mod, not the installable mod.
// Require an explicit workflow declaration: merely mentioning PC, Blender,
// a character called Builder or Dragon Quest Builders does not exclude a skin.
inline std::string pcToolWords(std::string text){for(auto&c:text)c=char(std::tolower(static_cast<unsigned char>(c)));return text;}
inline bool pcBuilderFilename(std::string name){
    name=pcToolWords(name);const auto dot=name.find_last_of('.');if(dot!=name.npos)name.resize(dot);
    for(const char*word:{"builder","generator","converter","toolkit"}){const auto at=name.rfind(word);if(at==name.npos)continue;const auto tail=name.substr(at+std::char_traits<char>::length(word));if(tail.empty())return true;if(tail.find_first_not_of(" _-.v0123456789")==tail.npos)return true;}return false;
}
inline bool declaresReadySwitchPackage(const std::string&description){
    const auto s=pcToolWords(description);
    for(const char*phrase:{"prebuilt switch mod","pre-built switch mod","ready-to-install switch","ready to install on switch","prebuilt atmosphere","pre-built atmosphere"})if(s.find(phrase)!=s.npos)return true;
    return false;
}
inline bool declaresPcModBuilder(const std::string&name,const std::string&description,const std::string&file={}){
    const auto s=pcToolWords(description);bool program=false,needsData=false,needsPc=false;
    for(const char*phrase:{"this is a builder","this is a mod builder","this is a pc tool","this is a desktop tool","this download is a builder","this is a mod generation tool","this is a mod-building tool","herramienta para crear el mod","programa para generar el mod"}){const auto at=s.find(phrase);if(at==s.npos)continue;const auto end=at+std::char_traits<char>::length(phrase);if(end==s.size()||s.find_first_of(".:;,!",end)==end||s.compare(end,5," that")==0||s.compare(end,6," which")==0||s.compare(end,13," for building")==0||s.compare(end,12," to generate")==0)program=true;}
    for(const char*phrase:{"from your own copies","from your own romfs","requires your own","no game files are included","no game assets are included","no game assets are being distributed","de tus propias copias","requiere tus propios"})if(s.find(phrase)!=s.npos)needsData=true;
    for(const char*phrase:{"run the builder","run builder.exe","requires python","run the python","on your pc","on windows","ejecuta el programa","necesita python"})if(s.find(phrase)!=s.npos)needsPc=true;
    const bool fileTool=pcBuilderFilename(file),namedTool=pcBuilderFilename(name);
    const bool tool=(program&&(needsData||needsPc))||((fileTool||namedTool)&&needsData&&needsPc);
    // A publication may offer both a builder and a prebuilt Switch variant.
    // The builder filename remains excluded; a ready variant stays available.
    return tool&&(fileTool||!declaresReadySwitchPackage(description));
}
inline bool isPcModTool(const ModEntry&entry){return declaresPcModBuilder(entry.name,entry.detail+" "+entry.reason,entry.fileName.empty()?entry.path:entry.fileName);}
inline const char *consoleRepositoryBranch(const std::string &repository){
    if(repository=="masagrator/NXGraphicsPatches")return "master";
    if(repository=="cucholix/NX-IPS-romfs-compilation")return "main";
    if(repository=="h2y/BOTW-Chinese-Linkle")return "master";
    return nullptr;
}
inline bool hasUnknownConsoleProvenance(const std::string &input){
    const auto words=emulatorPolicyWords(input);
    for(const char *label:{"tested only on emulators","tested on emulators only","tested only on emulator","tested on emulator only","tested only on yuzu","tested only on ryujinx","not tested on switch","not tested on hardware","not tested on real hardware","not tested on switch hardware","not tested on a real switch","never tested on a real switch","never tested on switch hardware","never tested on real hardware","not compatible with real switch","not compatible with a real switch","does not work on real hardware","switch hardware unknown","hardware switch sin comprobar","hardware desconocido"})
        if(words.find(std::string(" ")+label+" ")!=words.npos)return true;
    return false;
}
inline bool supportedModArchiveName(std::string name){
    for(auto &c:name)c=char(std::tolower(static_cast<unsigned char>(c)));
    return name.size()>4&&(name.compare(name.size()-4,4,".zip")==0||name.compare(name.size()-4,4,".rar")==0);
}
inline bool gameBananaIdentity(const ModEntry &entry){
    return entry.repository=="GameBanana"&&entry.source=="GameBanana"&&entry.branch.empty()&&entry.titleId&&entry.gbGameId&&entry.gbModId
        &&entry.id=="GameBanana|"+std::to_string(entry.gbModId)+(entry.gbFileId?"|"+std::to_string(entry.gbFileId):"")&&entry.sourceUrl=="https://gamebanana.com/mods/"+std::to_string(entry.gbModId);
}
inline bool hasRejectedConsoleProvenance(const ModEntry &entry){
    return isEmulatorOnly(entry)||isPcModTool(entry);
}
// Selection is separate from file preparation. ZIP/RAR contents are validated
// automatically after the user chooses installation, without a review gate.
inline bool canInspectConsoleArchive(const ModEntry &entry){
    if(entry.format!=ModFormat::Archive||hasRejectedConsoleProvenance(entry))return false;
    if(gameBananaIdentity(entry))return entry.fileName.empty()||supportedModArchiveName(entry.fileName);
    const auto *branch=consoleRepositoryBranch(entry.repository);
    return branch&&entry.branch==branch&&supportedModArchiveName(entry.path);
}
inline bool allowsConsoleMod(const ModEntry &entry){
    if(entry.format!=ModFormat::Pchtxt&&entry.format!=ModFormat::Ips&&entry.format!=ModFormat::Romfs&&entry.format!=ModFormat::Archive)return false;
    if(hasRejectedConsoleProvenance(entry))return false;
    if(entry.format==ModFormat::Archive&&!canInspectConsoleArchive(entry))return false;
    if(gameBananaIdentity(entry))return true;
    const auto *branch=consoleRepositoryBranch(entry.repository);
    if(!branch||entry.branch!=branch)return false;
    return true;
}
inline bool isBrowsableMod(const ModEntry &entry){return allowsConsoleMod(entry)||canInspectConsoleArchive(entry);}
}
