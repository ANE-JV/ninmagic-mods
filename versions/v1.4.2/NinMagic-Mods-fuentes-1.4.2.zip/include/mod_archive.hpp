#pragma once
#include "model.hpp"
namespace nmm {
inline constexpr uint64_t MaxModArchive = 128ULL*1024*1024;
// Inspection decodes only into bounded buffers, never into game/SD paths.
bool inspectArchiveMod(const Game&,ModEntry&,std::string&error);
bool prepareArchiveMod(const Game&,const ModEntry&,ModPayload&,std::string&error);
// Shared cache transport. Source metadata/hash is revalidated before parsing.
bool obtainArchiveModFile(const Game&,const ModEntry&,std::string&path,std::string&error);
bool resolveArchiveModMetadata(const Game&,ModEntry&,std::string&error);
bool hashModArchiveFile(const std::string&,std::string&sha256,std::string&gitSha1,uint64_t&size,std::string&error);
// Pure file boundary used by tests and the cache-backed production entrypoints.
// keepResources=false retains no aggregate RomFS data during inspection.
bool readModArchiveFile(const Game&,const ModEntry&,const std::string&,ModPayload&,bool keepResources,std::string&error);
}
