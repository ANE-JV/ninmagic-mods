#pragma once
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
namespace nmm::gb {
// MD5 is used only to compare the file fingerprint published by GameBanana.
// Archive preparation independently records SHA-256 before any installation.
class Md5 {
    uint32_t h[4]={0x67452301,0xefcdab89,0x98badcfe,0x10325476};
    std::array<uint8_t,64> pending{};size_t used=0;uint64_t length=0;
    static uint32_t rotate(uint32_t x,unsigned n){return (x<<n)|(x>>(32-n));}
    void block(const uint8_t *p){
        static constexpr uint32_t k[64]={0xd76aa478,0xe8c7b756,0x242070db,0xc1bdceee,0xf57c0faf,0x4787c62a,0xa8304613,0xfd469501,0x698098d8,0x8b44f7af,0xffff5bb1,0x895cd7be,0x6b901122,0xfd987193,0xa679438e,0x49b40821,0xf61e2562,0xc040b340,0x265e5a51,0xe9b6c7aa,0xd62f105d,0x02441453,0xd8a1e681,0xe7d3fbc8,0x21e1cde6,0xc33707d6,0xf4d50d87,0x455a14ed,0xa9e3e905,0xfcefa3f8,0x676f02d9,0x8d2a4c8a,0xfffa3942,0x8771f681,0x6d9d6122,0xfde5380c,0xa4beea44,0x4bdecfa9,0xf6bb4b60,0xbebfbc70,0x289b7ec6,0xeaa127fa,0xd4ef3085,0x04881d05,0xd9d4d039,0xe6db99e5,0x1fa27cf8,0xc4ac5665,0xf4292244,0x432aff97,0xab9423a7,0xfc93a039,0x655b59c3,0x8f0ccc92,0xffeff47d,0x85845dd1,0x6fa87e4f,0xfe2ce6e0,0xa3014314,0x4e0811a1,0xf7537e82,0xbd3af235,0x2ad7d2bb,0xeb86d391};
        static constexpr unsigned shift[64]={7,12,17,22,7,12,17,22,7,12,17,22,7,12,17,22,5,9,14,20,5,9,14,20,5,9,14,20,5,9,14,20,4,11,16,23,4,11,16,23,4,11,16,23,4,11,16,23,6,10,15,21,6,10,15,21,6,10,15,21,6,10,15,21};
        uint32_t w[16];for(unsigned i=0;i<16;++i)w[i]=uint32_t(p[i*4])|(uint32_t(p[i*4+1])<<8)|(uint32_t(p[i*4+2])<<16)|(uint32_t(p[i*4+3])<<24);
        uint32_t a=h[0],b=h[1],c=h[2],d=h[3];for(unsigned i=0;i<64;++i){uint32_t f;unsigned g;if(i<16){f=(b&c)|(~b&d);g=i;}else if(i<32){f=(d&b)|(~d&c);g=(5*i+1)%16;}else if(i<48){f=b^c^d;g=(3*i+5)%16;}else{f=c^(b|~d);g=(7*i)%16;}const auto next=b+rotate(a+f+k[i]+w[g],shift[i]);a=d;d=c;c=b;b=next;}h[0]+=a;h[1]+=b;h[2]+=c;h[3]+=d;
    }
public:
    void add(const uint8_t*p,size_t n){length+=n;while(n){const size_t take=std::min(n,64-used);std::memcpy(pending.data()+used,p,take);used+=take;p+=take;n-=take;if(used==64){block(pending.data());used=0;}}}
    std::string finish(){const auto bits=length*8;pending[used++]=0x80;if(used>56){std::fill(pending.begin()+used,pending.end(),0);block(pending.data());used=0;}std::fill(pending.begin()+used,pending.begin()+56,0);for(unsigned i=0;i<8;++i)pending[56+i]=uint8_t(bits>>(i*8));block(pending.data());char out[33]{};for(unsigned i=0;i<16;++i)std::snprintf(out+i*2,3,"%02x",unsigned(uint8_t(h[i/4]>>((i%4)*8))));return out;}
};
}
