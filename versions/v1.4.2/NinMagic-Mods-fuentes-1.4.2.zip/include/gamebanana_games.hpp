#pragma once
#include <cstdint>

namespace nmm { namespace gb {
struct Mapping {uint64_t title,id;const char*name;};
// Canonical Switch application IDs and reviewed GameBanana game identities.
// These are title mappings, not statements that every mod works on hardware.
// In combined Pokemon categories, archive destinations still have to match the
// selected application's Title ID. BOTW deliberately uses the Switch category.
// Evidence and official NameMatch fixtures: gamebanana-games-verification-1.4.2.json.
inline constexpr Mapping Known[]={
    {0x010015100B514000ULL,18604,"Super Mario Bros. Wonder"},
    {0x010093801237C000ULL,14275,"Metroid Dread"},
    {0x0100F2C0115B6000ULL,7617,"The Legend of Zelda: Tears of the Kingdom"},
    {0x0100000000010000ULL,6376,"Super Mario Odyssey"},
    {0x0100152000022000ULL,6507,"Mario Kart 8 Deluxe"},
    {0x01006A800016E000ULL,6498,"Super Smash Bros. Ultimate"},
    {0x01004D300C5AE000ULL,15908,"Kirby and the Forgotten Land"},
    {0x0100DCA0064A6000ULL,7659,"Luigi's Mansion 3"},
    {0x01007EF00011E000ULL,6386,"The Legend of Zelda: Breath of the Wild (Switch)"},
    {0x01001F5010DFA000ULL,15053,"Pokémon Legends: Arceus"},
    {0x0100A3D008C5C000ULL,17220,"Pokemon Scarlet & Violet"},
    {0x01008F6008C5E000ULL,17220,"Pokemon Scarlet & Violet"},
    {0x0100ABF008968000ULL,7676,"Pokemon Sword & Shield"},
    {0x01008DB008C2C000ULL,7676,"Pokemon Sword & Shield"},
    {0x01006F8002326000ULL,7923,"Animal Crossing: New Horizons"}
};
inline const Mapping*known(uint64_t title){for(const auto&m:Known)if(m.title==title)return &m;return nullptr;}
} }
