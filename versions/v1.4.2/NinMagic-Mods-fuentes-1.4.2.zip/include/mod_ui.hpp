#pragma once
#include "model.hpp"
#include "mod_policy.hpp"
#include "mod_install.hpp"
#include <algorithm>
namespace nmm {
inline ModFormat effectiveModFormat(const ModEntry&m){return m.format==ModFormat::Archive?(m.archiveInspected?m.archiveFormat:ModFormat::Archive):m.format;}
// Selection expresses the user's choice, never verified game compatibility.
// Download integrity, payload format and destinations are validated at prepare.
inline bool canChooseModFile(const ModEntry&m){return m.format==ModFormat::Archive&&canInspectConsoleArchive(m)&&gameBananaIdentity(m)&&!m.gbFileId;}
inline bool canMarkMod(const ModEntry&m){if(!isBrowsableMod(m)||canChooseModFile(m))return false;return m.format==ModFormat::Ips||m.format==ModFormat::Pchtxt||m.format==ModFormat::Romfs||(m.format==ModFormat::Archive&&canInspectConsoleArchive(m));}
inline bool canInspectMod(const ModEntry&m){return canChooseModFile(m);}
inline std::vector<size_t> visibleMods(const View&v){std::vector<size_t> out;for(size_t i=0;i<v.mods.size();++i)if(isBrowsableMod(v.mods[i])&&(!v.filter||canMarkMod(v.mods[i])||canChooseModFile(v.mods[i])))out.push_back(i);return out;}
inline bool pendingMod(const ModEntry&m){return m.selected&&!m.installed&&canMarkMod(m);}
inline bool checkedMod(const ModEntry&m){return m.installed||pendingMod(m);}
inline bool installedRecordMatches(const ModEntry&m,const InstalledModRecord&r){
    if(m.id.empty())return false;
    if(m.id==r.id)return true;
    // Only a verified GameBanana parent aggregates its installed file variants.
    if(!canChooseModFile(m)||r.id.compare(0,m.id.size()+1,m.id+"|")!=0)return false;
    const auto suffix=r.id.substr(m.id.size()+1);
    return !suffix.empty()&&suffix.size()<=10&&suffix[0]!='0'&&std::all_of(suffix.begin(),suffix.end(),[](unsigned char c){return c>='0'&&c<='9';});
}
inline void applyInstalledSelection(std::vector<ModEntry>&mods,const InstalledModSelection&state){
    for(auto&m:mods){const auto found=std::find_if(state.mods.begin(),state.mods.end(),[&](const InstalledModRecord&r){return installedRecordMatches(m,r);});m.installed=found!=state.mods.end();m.installedName=m.installed?found->name:std::string{};if(m.installed)m.selected=false;}
}
inline void applyPendingSelection(std::vector<ModEntry>&mods,const std::vector<std::string>&ids){for(auto&m:mods)m.selected=!m.installed&&canMarkMod(m)&&std::find(ids.begin(),ids.end(),m.id)!=ids.end();}
inline bool savedVariantChoice(const ModEntry&m,const std::vector<std::string>&ids){return !m.installed&&canChooseModFile(m)&&std::any_of(ids.begin(),ids.end(),[&](const std::string&id){InstalledModRecord record;record.id=id;return installedRecordMatches(m,record);});}
inline unsigned selectedMods(const View&v){unsigned n=0;for(const auto&m:v.mods)n+=pendingMod(m);return n;}
}
