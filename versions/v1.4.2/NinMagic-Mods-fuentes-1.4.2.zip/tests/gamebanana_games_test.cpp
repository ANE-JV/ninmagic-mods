#define NM_GAMEBANANA_TEST
#include "../source/gamebanana.cpp"
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>

namespace nmm {
bool downloadGameBananaHttps(const std::string&,const std::string&,uint64_t,std::string&e){e="offline test";return false;}
bool downloadGameBananaArchiveHttps(const std::string&,const std::string&,uint64_t,std::string&e){e="archives not used by identity tests";return false;}
}
namespace {
unsigned checks=0;
void check(bool ok,const char*message){++checks;if(!ok)throw std::runtime_error(message);}
std::string fixture(uint64_t id){std::ifstream f("tests/fixtures/gamebanana-games/"+std::to_string(id)+".json",std::ios::binary);std::ostringstream out;out<<f.rdbuf();check(bool(f),"official NameMatch fixture exists");return out.str();}
}
int main(){try{
    std::set<uint64_t>titles,categories;
    for(const auto&m:nmm::gb::Known){
        check(m.title>=0x0100000000010000ULL&&!(m.title&0xfff)&&titles.insert(m.title).second,"unique canonical Switch application identity");
        check(m.id&&m.id<1000000000ULL&&m.name&&*m.name,"bounded named GameBanana identity");
        nmm::Game game;game.id=m.title;game.name="Nombre localizado de la consola";
        uint64_t found=0;std::string error;
        check(nmm::gb::identify(game,fixture(m.id),found,error)&&found==m.id,"official NameMatch response agrees with selected Switch TitleID independent of locale");
        check(nmm::gb::validGame(game,m.id,m.name),"mapped official category accepted without artificial Switch suffix");
        for(const auto&other:nmm::gb::Known)if(other.id!=m.id)check(!nmm::gb::validGame(game,other.id,other.name),"another game's official category is not an alias");
        check(nmm::gb::known(m.title+0x800)==nullptr&&nmm::gb::known(m.title+1)==nullptr,"update and program-index IDs are not silently registered as games");
        categories.insert(m.id);
    }
    check(titles.size()==15&&categories.size()==13,"fifteen reviewed Switch editions in thirteen game categories");
    nmm::Game botw;botw.id=0x01007EF00011E000ULL;botw.name="The Legend of Zelda: Breath of the Wild";
    check(!nmm::gb::validGame(botw,5866,"The Legend of Zelda: Breath of the Wild (WiiU)"),"WiiU BOTW category excluded");
    check(!nmm::gb::validGame(botw,6386,"The Legend of Zelda: Breath of the Wild (WiiU)"),"forged Switch ID with WiiU name excluded");
    nmm::Game unknown;unknown.id=0x0100000001230000ULL;unknown.name="Super Mario Odyssey";
    check(nmm::gb::known(unknown.id)==nullptr&&!nmm::gb::validGame(unknown,6376,"Super Mario Odyssey"),"unknown TitleID cannot impersonate known game based on similar name");
    unknown.name="Example Game";
    check(nmm::gb::validGame(unknown,123456,"Example Game (Switch)")&&!nmm::gb::validGame(unknown,123456,"Example Game (PC)"),"existing strict fallback for explicitly Switch-labeled categories preserved");
    nmm::Game sword; sword.id=0x0100ABF008968000ULL;
    nmm::Game violet; violet.id=0x01008F6008C5E000ULL;
    check(nmm::gb::validGame(sword,7676,"Pokemon Sword & Shield")&&!nmm::gb::validGame(sword,17220,"Pokemon Scarlet & Violet"),"shared Pokemon group is specific to its reviewed editions");
    check(nmm::gb::validGame(violet,17220,"Pokemon Scarlet & Violet")&&!nmm::gb::validGame(violet,7676,"Pokemon Sword & Shield"),"other Pokemon generation rejected");
    std::cout<<"GameBanana games: "<<checks<<" official identity, edition and cross-platform checks PASS\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
