"""Small original ZIP fixtures for precise package diagnostics; no game assets."""
from pathlib import Path
import struct, zipfile
root=Path(__file__).resolve().parent/'fixtures'/'archives'
root.mkdir(parents=True,exist_ok=True)
def make(name,items,compression=zipfile.ZIP_DEFLATED):
    with zipfile.ZipFile(root/name,'w',compression=compression) as z:
        for path,data in items:
            item=zipfile.ZipInfo(path,date_time=(2020,1,1,0,0,0));item.compress_type=compression
            z.writestr(item,data)
make('pc-builder.zip',[('Builder/Builder.exe',b'MZ fixture only')])
make('pc-runtime-over-limit.zip',[('Builder/_internal/_asyncio.pyd',b'fixture only')]+[(f'Builder/data/file{i}.bin',b'x') for i in range(1421)])
make('many-entries.zip',[(f'romfs/data/file{i}.bin',b'x') for i in range(1025)])
make('pc-mentioned-readme.zip',[('romfs/model/test.bin',b'fixture data'),('README.txt',b'This mod was made on a PC with a builder. Copy the romfs directory.')])
make('zip-bzip2.zip',[('romfs/model/test.bin',b'fixture data')],zipfile.ZIP_BZIP2)
data=bytearray((root/'pc-mentioned-readme.zip').read_bytes());end=data.rfind(b'PK\x05\x06');struct.pack_into('<H',data,end+8,65535);struct.pack_into('<H',data,end+10,65535);(root/'zip64-entries.zip').write_bytes(data)

make('pc-name-directory.zip',[('romfs/assets/Builder.exe/',b''),('romfs/assets/Builder.exe/data.bin',b'fixture data')])

with zipfile.ZipFile(root/'backslash-directory.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    directory=zipfile.ZipInfo('romfs\\assets\\',date_time=(2020,1,1,0,0,0));directory.create_system=3;directory.external_attr=(0o40755<<16)|0x10
    z.writestr(directory,b'')
    z.writestr('romfs\\assets\\test.bin',b'fixture data')

make('pc-long-path.zip',[('Nested/'+('directory/'*30)+'tool_'+('x'*150)+'.pyd',b'fixture only')])
