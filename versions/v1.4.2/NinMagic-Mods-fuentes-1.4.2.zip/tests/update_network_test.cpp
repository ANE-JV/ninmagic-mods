#define NM_UPDATE_NETWORK_TEST
#include "../source/update_network.cpp"
#include <iostream>
#include <stdexcept>

namespace {unsigned checks=0;void check(bool value){++checks;if(!value)throw std::runtime_error("update HTTPS policy check");}}
int main(){try{
    for(const std::string url:{"https://raw.githubusercontent.com/ANE-JV/ninmagic-mods/main/update.txt","https://example.test:443/versions/v1.2.0/NinMagic-Mods.nro"})check(nmm::safeUrl(url));
    for(const std::string url:{"http://example.test/update.txt","https://u:p@example.test/update.txt","https:///update.txt","https://example.test/a#fragment","https://example.test/a b","https://example.test/a\nb","https://example.test/a\\b"})check(!nmm::safeUrl(url));
    check(!nmm::safeUrl(std::string(2049,'a')));
    check(nmm::bodyLimit("sdmc:/config/NinMagicMods/app-update/manifest.pending")==4096);
    check(nmm::bodyLimit("sdmc:/config/NinMagicMods/app-update/download.pending")==16ULL*1024*1024);
    for(const std::string path:{"sdmc:/config/NinMagicMods/bindings.bin","sdmc:/config/NinMagicCheats/app-update/manifest.pending","sdmc:/switch/NinMagicMods/NinMagic-Mods.nro","sdmc:/config/NinMagicMods/app-update/../bindings.bin","sdmc:/Nintendo/Contents/any"})check(nmm::bodyLimit(path)==0);
    FILE *file=std::tmpfile();check(file!=nullptr);nmm::Download d{file,0,5,false};char bytes[]="abcdef";
    check(nmm::receive(bytes,1,3,&d)==3&&d.written==3&&!d.overflow);
    check(nmm::receive(bytes+3,1,2,&d)==2&&d.written==5&&!d.overflow);
    check(nmm::receive(bytes,1,1,&d)==0&&d.written==5&&d.overflow);
    check(std::fflush(file)==0&&std::fseek(file,0,SEEK_END)==0&&std::ftell(file)==5);check(std::fclose(file)==0);
    file=std::tmpfile();check(file!=nullptr);d={file,0,5,false};check(nmm::receive(bytes,SIZE_MAX,2,&d)==0&&d.written==0);check(std::fclose(file)==0);
    std::string error="stale";check(!nmm::downloadHttpsFile("https://example.test/update.txt","sdmc:/config/NinMagicMods/bindings.bin",error)&&error.find("temporales")!=error.npos);
    check(!nmm::downloadHttpsFile("http://example.test/update.txt","sdmc:/config/NinMagicMods/app-update/manifest.pending",error)&&error.find("HTTPS válida")!=error.npos);
    const std::string batchPrefix="https://gamebanana.com/apiv6/Mod/ByGame?_aGameRowIds%5B%5D=";
#ifdef NMM_OVERLAY
    const std::string perPage="5",otherPerPage="15";
#else
    const std::string perPage="15",otherPerPage="5";
#endif
    const auto batchUrl=[&](const std::string&id,const std::string&page){return batchPrefix+id+"&_nPerpage="+perPage+"&_nPage="+page+"&_csvProperties="+nmm::GameBananaBatchProperties;};
    const auto batchPath=[&](const std::string&page){return "sdmc:/config/NinMagicMods/gamebanana/010015100B514000-mods"+perPage+"-page"+page+".json.pending";};
    unsigned page=0;
    for(const auto&id:{"1","18604","999999999"})for(const auto&number:{"1","9"}){const auto url=batchUrl(id,number);check(nmm::gameBananaBatchUrl(url,page)&&page==unsigned(number[0]-'0'));check(!nmm::downloadGameBananaHttps(url,batchPath(number),512*1024,error)&&error.find("consola")!=error.npos);}
    for(const auto&id:{"","0","01","1000000000","-1","1,2","1%26x=2","1&x=2","1/../2"})check(!nmm::gameBananaBatchUrl(batchUrl(id,"1"),page));
    for(const auto&number:{"","0","01","10","-1","1&x=2"})check(!nmm::gameBananaBatchUrl(batchUrl("18604",number),page));
    const auto valid=batchUrl("18604","1");
    for(auto bad:{valid+"&extra=1",valid+"#fragment",valid+" ",valid+",_sSecret",valid.substr(0,valid.size()-1),std::string("http")+valid.substr(5)})check(!nmm::gameBananaBatchUrl(bad,page));
    for(const auto&change:std::vector<std::pair<std::string,std::string>>{{"https://gamebanana.com/","https://gamebanana.com.evil.test/"},{"https://gamebanana.com/","https://user@gamebanana.com/"},{"/apiv6/","/apiv11/"},{"/ByGame?","/ByGame/../Index?"},{"%5B%5D","[]"},{"%5B%5D","%5b%5d"},{"&_nPerpage="+perPage,"&_nPerpage="+otherPerPage},{"&_nPerpage="+perPage,"&_nPerpage=50"},{"&_nPerpage="+perPage,"&_nPerpage=0"},{"&_nPage=1","&_nPage=1&_nPage=1"},{"&_csvProperties=","&_csvProperties=x&_csvProperties="}}){auto bad=valid;auto at=bad.find(change.first);check(at!=bad.npos);bad.replace(at,change.first.size(),change.second);check(!nmm::gameBananaBatchUrl(bad,page));check(!nmm::downloadGameBananaHttps(bad,batchPath("1"),4096,error)&&error.find("consola")==error.npos);}
    for(const auto&bad:{batchPath("0"),batchPath("01"),batchPath("10"),batchPath("1")+"/extra",std::string("sdmc:/config/NinMagicMods/gamebanana/010015100B514000-mods-page1.json"),std::string("sdmc:/config/NinMagicMods/gamebanana/010015100b514000-mods-page1.json.pending"),std::string("sdmc:/config/NinMagicMods/gamebanana/010015100B514000/../mods-page1.json.pending"),std::string("sdmc:/config/NinMagicCheats/gamebanana/010015100B514000-mods-page1.json.pending")})check(!nmm::downloadGameBananaHttps(valid,bad,4096,error)&&error.find("consola")==error.npos);
    check(!nmm::downloadGameBananaHttps(valid,"sdmc:/config/NinMagicMods/gamebanana/010015100B514000-mods"+otherPerPage+"-page1.json.pending",4096,error)&&error.find("consola")==error.npos);
    check(!nmm::downloadGameBananaHttps(valid,"sdmc:/config/NinMagicMods/gamebanana/010015100B514000-mods-page1.json.pending",4096,error)&&error.find("consola")==error.npos);
    check(!nmm::downloadGameBananaHttps(valid,batchPath("2"),4096,error)&&error.find("consola")==error.npos);
    check(!nmm::downloadGameBananaHttps(valid,"sdmc:/config/NinMagicMods/gamebanana/010015100B514000-page1.json.pending",4096,error)&&error.find("consola")==error.npos);
    check(!nmm::downloadGameBananaHttps("https://gamebanana.com/apiv11/Mod/Index?_nPage=1",batchPath("1"),4096,error)&&error.find("consola")==error.npos);
    check(!nmm::downloadGameBananaHttps(valid,batchPath("1"),0,error)&&error.find("consola")==error.npos);
    check(!nmm::downloadGameBananaHttps(valid,batchPath("1"),512*1024+1,error)&&error.find("consola")==error.npos);
    nmm::updateNetworkExit();std::cout<<"NinMagic HTTPS: "<<checks<<" URL, path isolation and bounded receive checks PASS\n";return 0;
}catch(const std::exception &e){std::cerr<<e.what()<<'\n';return 1;}}
