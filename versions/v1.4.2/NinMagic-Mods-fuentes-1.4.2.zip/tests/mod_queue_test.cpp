#define _POSIX_C_SOURCE 200809L
#include "mod_queue.hpp"
#include "mod_hash.hpp"
#include "mod_ui.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <cstdlib>
#include <chrono>
namespace fs=std::filesystem;
using namespace nmm;
int checks=0;void need(bool b,const char*s){++checks;if(!b){std::cerr<<"FAIL "<<s<<"\n";std::exit(1);}}
Game game(){Game g;g.id=0x010015100B514000ULL;g.name="Super Mario Bros. Wonder";g.version="1.2.1";g.versionKnown=g.buildVerified=g.running=true;g.contentVersion=196608;g.contentIdentity=std::string(64,'c');g.fullBuildId="FF773E90972D544E"+std::string(48,'0');g.buildId=g.fullBuildId.substr(0,16);return g;}
ModEntry mod(const Game&g){ModEntry m;m.branch="master";m.consoleOnly=true;m.titleId=g.id;m.id="masagrator/NXGraphicsPatches|game/fps.pchtxt";m.name="60 FPS";m.category="60 FPS";m.source=m.repository="masagrator/NXGraphicsPatches";m.sourceUrl="https://github.com/masagrator/NXGraphicsPatches";m.buildId=g.fullBuildId;m.version=g.version;m.compatible=true;m.format=ModFormat::Pchtxt;return m;}
void env(const std::string&s){
#ifdef _WIN32
_putenv_s("NMM_QUEUE_ROOT",s.c_str());
#else
setenv("NMM_QUEUE_ROOT",s.c_str(),1);
#endif
}
int main(){const auto parent=fs::temp_directory_path();const auto sandbox=parent/("nmm-queue-"+std::to_string(std::chrono::high_resolution_clock::now().time_since_epoch().count()));fs::create_directories(sandbox);env((sandbox/"config"/"NinMagicMods").generic_string());Game g=game();auto m=mod(g);m.installed=true;std::string e;std::vector<std::string>ids;std::vector<ModEntry>out;
 need(saveModSelection(g,{m},e),"save exact running game");need(loadModSelection(g,ids,e)&&ids==std::vector<std::string>{m.id},"roundtrip ids only");
 need(saveModMenuCache(g,{m},e),"cache save");need(loadModMenuCache(g,out,e)&&out.size()==1&&!out[0].compatible&&!out[0].selected&&!out[0].installed&&out[0].files.empty(),"menu strips payload selection");
 const auto oldMenuPath=sandbox/"config"/"NinMagicMods"/"overlay"/titleId(g.id)/"menu.bin";
 std::string oldMenu;{std::ifstream f(oldMenuPath,std::ios::binary);oldMenu.assign(std::istreambuf_iterator<char>(f),{});}
 need(oldMenu.substr(0,8)=="NMMMENU3","new compact cache uses refreshed schema");
 oldMenu.resize(oldMenu.size()-64);oldMenu.replace(0,8,"NMMMENU2");oldMenu+=mod_hash::shaText(oldMenu);
 {std::ofstream f(oldMenuPath,std::ios::binary|std::ios::trunc);f.write(oldMenu.data(),std::streamsize(oldMenu.size()));}
 need(saveAppModSelection(g,{m.id},e),"pending app choices exist before old menu invalidation");
 need(!loadModMenuCache(g,out,e)&&out.empty()&&e.find("Pulsa X")!=std::string::npos,"old menu cannot show unfiltered PC builder and asks normal refresh");
 need(loadModSelection(g,ids,e)&&ids==std::vector<std::string>{m.id},"invalidating old menu preserves overlay selection");
 need(loadAppModSelection(g,ids,e)&&ids==std::vector<std::string>{m.id},"invalidating old menu preserves app selection");
 need(saveModMenuCache(g,{m},e)&&loadModMenuCache(g,out,e)&&out.size()==1,"new schema menu loads after refreshing sources");
 need(clearAppModSelection(g,e),"test cleanup keeps later first-launch fixture valid");
 auto bad=g;bad.fullBuildId[63]='1';need(!loadModSelection(bad,ids,e)&&ids.empty(),"stale full build blocked");bad=g;bad.contentIdentity[0]='d';need(!loadModSelection(bad,ids,e)&&ids.empty(),"changed NCM content with same version rejected");bad=g;bad.buildId="0000000000000000";need(!saveModSelection(bad,{m},e),"short/full build mismatch blocked");bad=g;bad.version="1.2.2";need(!loadModSelection(bad,ids,e),"stale display version blocked");bad=g;++bad.contentVersion;need(!loadModSelection(bad,ids,e),"stale content version blocked");bad=g;bad.buildVerified=false;need(!loadModSelection(bad,ids,e),"unverified identity blocked");bad=g;bad.versionKnown=false;need(saveModSelection(bad,{m},e),"unknown game version does not block an explicit choice");bad=g;bad.id=0;need(!saveModSelection(bad,{m},e),"unknown title blocked");
 auto unknown=g;unknown.buildVerified=unknown.versionKnown=false;unknown.buildId.clear();unknown.fullBuildId.clear();unknown.version.clear();auto noRequirements=m;noRequirements.compatible=false;noRequirements.buildId.clear();noRequirements.version.clear();need(saveModSelection(unknown,{noRequirements},e)&&loadModSelection(unknown,ids,e)&&ids==std::vector<std::string>{m.id},"game and author may both lack version and BID");
 auto blocked=m;blocked.compatible=false;need(saveModSelection(g,{blocked},e),"legacy incompatible flag does not block a choice");blocked=m;++blocked.titleId;need(!saveModSelection(g,{blocked},e),"foreign title rejected");blocked=m;blocked.buildId[0]='1';need(saveModSelection(g,{blocked},e),"author build difference does not block a choice");blocked=m;blocked.version="1.0.0";need(saveModSelection(g,{blocked},e),"author version difference does not block a choice");need(!saveModSelection(g,{},e),"empty selection rejected");need(!saveModSelection(g,{m,m},e),"duplicate ids rejected");auto authorPatch=m;authorPatch.titleId=g.id^0x800;need(saveModSelection(g,{authorPatch},e),"formal author update TitleID accepted for base");authorPatch.titleId=g.id+1;need(!saveModSelection(g,{authorPatch},e),"program index not guessed into base");std::vector<ModEntry>many;for(int i=0;i<33;++i){auto v=m;v.id+=std::to_string(i);many.push_back(v);}need(!saveModSelection(g,many,e),"32 id limit");many.resize(32);need(saveModSelection(g,many,e)&&loadModSelection(g,ids,e)&&ids.size()==32,"32 unique allowed");
 auto rom=m;rom.format=ModFormat::Romfs;rom.buildId.clear();rom.consoleOnly=true;need(saveModSelection(g,{rom},e),"exact physical romfs metadata allowed");rom.consoleOnly=false;need(saveModSelection(g,{rom},e),"unknown hardware evidence does not block known-source choice");
 auto informational=m;informational.compatible=false;informational.repository="";informational.id="GameBanana|556710";informational.gbModId=556710;informational.gbGameId=18604;informational.author="diegoforfun";informational.modVersion="1.0";informational.reason="Versión de juego sin comprobar";need(saveModMenuCache(g,{informational},e)&&loadModMenuCache(g,out,e)&&out.empty(),"unknown GB excluded from cache");

 auto pending=informational;pending.source=pending.repository="GameBanana";pending.sourceUrl="https://gamebanana.com/mods/556710";pending.branch.clear();pending.format=ModFormat::Archive;pending.compatible=true;pending.selected=true;pending.consoleOnly=false;pending.downloadUrl.clear();pending.fileName.clear();pending.archiveInspected=true;pending.archiveFormat=ModFormat::Romfs;pending.archiveSha256=std::string(64,'a');pending.archiveExpandedSize=64;pending.archiveFiles=1;need(saveModMenuCache(g,{m,pending},e)&&loadModMenuCache(g,out,e)&&out.size()==2,"pending GameBanana archive visible in compact cache");need(!out[1].compatible&&!out[1].selected&&!out[1].archiveInspected&&out[1].archiveSha256.empty()&&out[1].gbGameId==18604&&out[1].sourceUrl==pending.sourceUrl,"archive cache retains query identity but no selection authority");need(!saveModSelection(g,{pending},e),"archive cannot enter overlay selection queue even if provider marks compatible");
 pending.name="Yuzu only";need(saveModMenuCache(g,{pending},e)&&loadModMenuCache(g,out,e)&&out.empty(),"emulator-only archive excluded from cached discovery");pending.name="Vegeta";pending.sourceUrl="https://gamebanana.com/mods/556711";need(saveModMenuCache(g,{pending},e)&&loadModMenuCache(g,out,e)&&out.empty(),"mismatched GameBanana source identity excluded");
 pending.sourceUrl="https://gamebanana.com/mods/556710";pending.gbFileId=123;pending.id="GameBanana|556710|123";pending.fileName="variant.zip";need(saveModMenuCache(g,{pending},e)&&loadModMenuCache(g,out,e)&&out.size()==1&&out[0].gbFileId==123&&out[0].id==pending.id&&out[0].fileName=="variant.zip","resolved GameBanana variant identity survives menu3 roundtrip");need(!out[0].installed&&!out[0].selected&&!out[0].compatible&&!out[0].archiveInspected,"resolved variant cache grants no installation or preparation authority");
 auto otherFile=out[0];otherFile.gbFileId=124;otherFile.id="GameBanana|556710|124";out.push_back(otherFile);InstalledModSelection installedVariant;installedVariant.mods.push_back({pending.id,"Vegeta original",pending.sourceUrl,false});applyInstalledSelection(out,installedVariant);need(out[0].installed&&!out[1].installed&&out[0].installedName=="Vegeta original","receipt restores exact installed variant after cache reopen, not its sibling");pending.gbFileId=0;pending.id="GameBanana|556710|arbitrary";need(saveModMenuCache(g,{pending},e)&&loadModMenuCache(g,out,e)&&out.empty(),"arbitrary GameBanana ID suffix excluded from cache");

 need(loadAppModSelection(g,ids,e)&&ids.empty(),"first launch has no pending app choices");
 const std::vector<std::string>appIds={m.id,"GameBanana|556710|123"};
 need(saveModSelection(g,{m},e)&&saveAppModSelection(g,appIds,e),"app and overlay selections coexist");
 need(loadAppModSelection(g,ids,e)&&ids==appIds,"app restores exact archive variant and Git keys");
 need(loadModSelection(g,ids,e)&&ids==std::vector<std::string>{m.id},"app saving never overwrites overlay queue");
 auto closed=g;closed.running=false;closed.processId=0;closed.buildVerified=false;closed.fullBuildId.clear();closed.buildId.clear();
 need(loadAppModSelection(closed,ids,e)&&ids==appIds,"closed game missing optional BID retains pending choices");
 need(saveAppModSelection(closed,appIds,e)&&loadAppModSelection(g,ids,e)&&ids==appIds,"opening game and learning BID retains pending choices");
 need(!saveAppModSelection(g,{"GameBanana|556710|arbitrary"},e),"arbitrary variant suffix rejected");
 need(!saveAppModSelection(g,{"GameBanana|556710|123|456"},e),"additional variant suffix rejected");
 need(!saveAppModSelection(g,{"GameBanana|556710|0123"},e),"noncanonical variant rejected");
 need(!saveAppModSelection(g,{m.id,m.id},e),"duplicate pending choices rejected");
 auto changed=g;++changed.contentVersion;need(!loadAppModSelection(changed,ids,e)&&ids.empty(),"pending choices cannot migrate to another installed context");
 need(saveAppModSelection(g,{},e)&&loadAppModSelection(g,ids,e)&&ids.empty(),"unmarking all clears app intent");
 need(loadModSelection(g,ids,e)&&ids==std::vector<std::string>{m.id},"clearing app intent preserves overlay queue");
 const auto dir=sandbox/"config"/"NinMagicMods"/"overlay"/titleId(g.id);const auto path=dir/"selection.bin";{std::fstream f(path,std::ios::in|std::ios::out|std::ios::binary);f.seekp(9);f.put('x');}need(!loadModSelection(g,ids,e)&&ids.empty(),"modified digest rejected");need(clearModSelection(g,e),"clear corrupt exact regular queue");need(!loadModSelection(g,ids,e),"cleared queue missing");
 need(saveModSelection(g,{m},e),"resave");{std::ofstream f(dir/"selection.bin.previous");f<<"foreign preserved";}need(!saveModSelection(g,{m},e),"pending previous blocks overwrite");need(fs::file_size(dir/"selection.bin.previous")==17,"foreign previous preserved");fs::remove(dir/"selection.bin.previous");
 fs::remove(path);const auto foreign=sandbox/"untouched";{std::ofstream f(foreign);f<<"foreign";}std::error_code ec;fs::create_symlink(foreign,path,ec);if(!ec){need(!saveModSelection(g,{m},e),"queue symlink rejected");need(!clearModSelection(g,e),"queue symlink not removed");need(fs::file_size(foreign)==7,"symlink target untouched");fs::remove(path);}else std::cout<<"symlink fixture unavailable: "<<ec.message()<<"\n";
 many.assign(129,m);need(!saveModMenuCache(g,many,e),"128 menu limit");auto text=m;text.reason=std::string(2049,'x');need(!saveModMenuCache(g,{text},e),"bounded menu text");
 for(const auto&entry:fs::recursive_directory_iterator(sandbox)){const auto rel=entry.path().lexically_relative(sandbox).generic_string();need(rel=="untouched"||rel.rfind("config",0)==0,"writes confined private config");}
 const auto resolved=fs::weakly_canonical(sandbox);need(resolved.parent_path()==fs::weakly_canonical(parent)&&resolved.filename().string().rfind("nmm-queue-",0)==0,"cleanup sandbox resolved");fs::remove_all(resolved);std::cout<<checks<<" queue checks passed\n";return 0;}
