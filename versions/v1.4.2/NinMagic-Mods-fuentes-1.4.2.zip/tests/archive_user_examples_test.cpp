#define NC_MODS_TEST
#include "../source/mods.cpp"
#include "mod_ui.hpp"
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
namespace fs=std::filesystem;
namespace {unsigned checks=0;std::map<std::string,std::string> responses;unsigned metadataRequests=0,archiveRequests=0;
void need(bool value,const std::string&why){++checks;if(!value)throw std::runtime_error(why);}
std::string readFile(const fs::path&path){std::ifstream f(path,std::ios::binary);if(!f)throw std::runtime_error("missing input "+path.string());return {std::istreambuf_iterator<char>(f),{}};}
bool transfer(const std::string&url,const std::string&path,uint64_t limit,std::string&error){auto found=responses.find(url);if(found==responses.end()||found->second.size()>limit){error="unexpected fixture URL or size";return false;}std::ofstream f(path,std::ios::binary);f.write(found->second.data(),found->second.size());return bool(f);}
}
namespace nmm {
bool downloadModHttps(const std::string&,const std::string&,uint64_t,std::string&error){error="Git is outside these GameBanana examples";return false;}
bool downloadModArchiveHttps(const std::string&,const std::string&,uint64_t,std::string&error){error="Git is outside these GameBanana examples";return false;}
bool downloadGameBananaHttps(const std::string&u,const std::string&p,uint64_t n,std::string&e){++metadataRequests;return transfer(u,p,n,e);}
bool downloadGameBananaArchiveHttps(const std::string&u,const std::string&p,uint64_t n,std::string&e){++archiveRequests;return transfer(u,p,n,e);}
}
int main(int argc,char**argv){try{
    if(argc!=5)throw std::runtime_error("arguments: ultrawide.json ultrawide.zip vegeta.json vegeta.rar; author files remain external test inputs");
    const auto parent=fs::temp_directory_path();const auto sandbox=parent/("nmm-user-examples-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));fs::create_directories(sandbox);
    setenv("NC_MODS_ROOT",sandbox.generic_string().c_str(),1);setenv("NM_GAMEBANANA_ROOT",(sandbox/"gamebanana").generic_string().c_str(),1);
    nmm::Game game;game.id=0x010015100B514000ULL;game.name="Super Mario Bros. Wonder";game.contentIdentity=std::string(64,'a');
    const auto properties="?_csvProperties=_idRow,_sName,_sProfileUrl,_sVersion,_aGame,_aSubmitter,_aRootCategory,_aCategory,_aFiles,_sText,_bIsTrashed,_bIsObsolete,_bIsWithheld";
    const std::string authorBid="FF773E90972D544EB79406EAA65396D53C43EFB9"+std::string(24,'0');
    for(unsigned example=0;example<2;++example){const uint64_t modId=example?556710:690034;const auto metadata=readFile(argv[1+example*2]),archive=readFile(argv[2+example*2]);std::vector<nmm::ModEntry>files;std::string error;
        need(nmm::parseGameBananaModFiles(game,18604,modId,metadata,files,error),"parse real metadata: "+error);need(files.size()==1,"one author download in each example");auto chosen=files.front();
        need(!chosen.archiveInspected&&nmm::canMarkMod(chosen),"user can choose the uninspected real archive");
        responses["https://gamebanana.com/apiv11/Mod/"+std::to_string(modId)+properties]=metadata;responses[chosen.downloadUrl]=archive;
        nmm::ModPayload prepared;need(nmm::prepareMod(game,chosen,prepared,error),"prepare real archive with unknown game version/BID: "+error);
        need(prepared.compatible&&prepared.game.fullBuildId.empty()&&!prepared.game.buildVerified&&!prepared.game.versionKnown&&!prepared.game.running,"preserve real unknown closed game context");
        if(example){need(prepared.files.size()==8&&prepared.ips.empty(),"Vegeta prepares eight RomFS resources");for(const auto&file:prepared.files)need(file.path.rfind("atmosphere/contents/010015100B514000/romfs/",0)==0,"Vegeta only maps to selected Wonder RomFS");}
        else{need(prepared.files.empty()&&!prepared.ips.empty()&&prepared.buildId==authorBid,"Ultrawide uses author's full target BID without rebinding game");}
        nmm::ModPayload combined;need(nmm::combineMods(game,{prepared},combined,error),"real example combines for confirmation: "+error);
        if(!example){need(combined.buildId==authorBid,"combined target retains author BID");auto different=game;different.versionKnown=true;different.version="9.9.9";different.fullBuildId=std::string(64,'b');different.buildId=different.fullBuildId.substr(0,16);different.buildVerified=true;nmm::ModPayload other;
            need(nmm::prepareMod(different,chosen,other,error)&&other.buildId==authorBid&&other.game.fullBuildId==different.fullBuildId,"different current BID/version does not block or alter author target");}
        std::cout<<(example?"Vegeta":"Ultrawide")<<": prepared for explicit confirmation; compatibility and game effect NOT tested\n";
    }
    need(metadataRequests>=4&&archiveRequests==2,"production provider refreshes metadata and verifies cached archive reuse");
    for(const auto&entry:fs::recursive_directory_iterator(sandbox))need(entry.path().lexically_relative(sandbox).generic_string().rfind("gamebanana",0)==0,"preparation does not write game install paths");
    const auto resolved=fs::weakly_canonical(sandbox);need(resolved.parent_path()==fs::weakly_canonical(parent)&&resolved.filename().string().rfind("nmm-user-examples-",0)==0,"checked fixture cleanup");fs::remove_all(resolved);
    std::cout<<checks<<" real author example checks passed\n";
}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}}
