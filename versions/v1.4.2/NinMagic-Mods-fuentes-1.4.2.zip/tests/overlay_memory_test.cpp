#define _POSIX_C_SOURCE 200809L
#include "memory_budget.hpp"
#include "controller.hpp"
#include "mods.hpp"
#include "mod_install.hpp"
#include <filesystem>
#include <iostream>
#include <fstream>
#include <chrono>
#include <cstdlib>
namespace fs=std::filesystem;
using namespace nmm;
unsigned checks=0;
void need(bool value,const char*why){++checks;if(!value){std::cerr<<"FAIL "<<why<<'\n';std::exit(1);}}
namespace nmm::overlay {
HeapObservation observed{0x7100000000ULL,0x7100000000ULL+2560*1024,1700*1024,1536*1024,164*1024};
HeapObservation observeOverlayHeap(){return observed;}
}
namespace nmm {
Game live;unsigned gitCalls=0,gbCalls=0,writes=0;
bool platformInit(Environment&,std::string&e){e.clear();return true;}void platformExit(){}
bool resolveRunningGame(Game&g,Environment&,std::string&e){g=live;e.clear();return true;}
bool validateRunningGame(const Game&g,std::string&e){e.clear();return g.processId==live.processId&&g.fullBuildId==live.fullBuildId;}
bool loadOverlayMods(const Game&g,std::vector<ModEntry>&out,std::string&e,bool){++gitCalls;e.clear();out.clear();ModEntry m;m.titleId=g.id;m.id="masagrator/NXGraphicsPatches|fps.pchtxt";m.repository="masagrator/NXGraphicsPatches";m.branch="master";m.consoleOnly=true;m.name="60 FPS";m.buildId=g.fullBuildId;m.format=ModFormat::Pchtxt;m.compatible=true;out.push_back(m);m.id="Kenji-NX/switch-pchtxt-mods|unknown";m.repository="Kenji-NX/switch-pchtxt-mods";out.push_back(m);m.id="masagrator/NXGraphicsPatches|emulator";m.repository="masagrator/NXGraphicsPatches";m.name="Yuzu only";out.push_back(m);return true;}
bool loadGameBananaMods(const Game&,std::vector<ModEntry>&,std::string&,bool){++gbCalls;return false;}
bool prepareMod(const Game&g,const ModEntry&m,ModPayload&p,std::string&e){return parseModPayload(g,m,"@nsobid-"+g.fullBuildId+"\n@enabled\n00001000 01020304\n@stop\n",p,e);}
bool inspectInstalledModSelection(const Game&,InstalledModSelection&out,std::string&e){out={};e.clear();return true;}
bool inspectPreparedMods(const Game&,const std::vector<ModPayload>&,InstalledInfo&i,std::string&e){e.clear();i={};i.valid=true;i.fingerprint="review";return true;}
Outcome installMods(const Game&,const std::vector<ModPayload>&,bool,const std::string&){++writes;Outcome o;o.ok=true;return o;}
void updateNetworkExit(){}
}
std::string readFile(const fs::path&p){std::ifstream f(p,std::ios::binary);return {std::istreambuf_iterator<char>(f),{}};}
int main(){using namespace nmm::overlay;
 need(!heapCapacity({0,0,0,0,0}).valid,"unknown heap rejected");
 need(!heapCapacity({10,10,0,0,0}).valid,"empty heap rejected");
 need(!heapCapacity({20,10,0,0,0}).valid,"reversed heap rejected");
 need(!heapCapacity({1,101,101,0,0}).valid,"arena cannot exceed heap");
 need(!heapCapacity({1,101,90,91,0}).valid,"allocated cannot exceed arena");
 need(!heapCapacity({1,101,100,90,90}).valid,"inconsistent allocated plus free rejected");
 auto memory=heapCapacity({1,1001,600,500,50});need(memory.valid&&memory.available==450,"uncommitted plus allocator free, unexplained gap excluded");
 memory=heapCapacity({1,UINTPTR_MAX,UINT64_MAX-2,UINT64_MAX-3,1});need(memory.valid&&memory.available==2,"near integer maximum has no overflow");
 need(!admitsMemory({},MemoryPhase::Git),"unverified sample cannot authorize provider");
 const auto original=observed;memory=heapCapacity(original);
 need(memory.total==2560*1024&&memory.available==1024*1024,"actual 2.5MiB range rather than configured4MiB");
 need(admitsMemory(memory,MemoryPhase::Git)&&admitsMemory(memory,MemoryPhase::Prepare),"measured phases fit1MiB incremental headroom");
 need(!withinMemoryBudget(memory.total,memory.used,1536*1024),"old minimum fails this same valid heap");
 need(!admitsMemory(memory,static_cast<MemoryPhase>(999)),"unknown phase rejected without overflow");
 const auto parent=fs::temp_directory_path();const auto sandbox=parent/("nmm-heap-"+std::to_string(std::chrono::high_resolution_clock::now().time_since_epoch().count()));fs::create_directories(sandbox);setenv("NMM_QUEUE_ROOT",sandbox.generic_string().c_str(),1);
 live.id=0x010093801237C000ULL;live.name="Metroid Dread";live.version="2.1.0";live.versionKnown=live.buildVerified=live.running=true;live.processId=1234;live.buildId="646761F643AFEBB3";live.fullBuildId=live.buildId+std::string(48,'0');live.contentIdentity=std::string(64,'c');
 std::string error;need(init(error),"controller initializes");need(search()&&gitCalls==1,"X reaches hardware providers on real2.5MiB range");
 auto state=snapshot();need(state.totalItems==1&&gbCalls==1,"unknown/emulator excluded and bounded GameBanana metadata queried");
 const auto menu=sandbox/"overlay"/titleId(live.id)/"menu.bin";const auto before=readFile(menu);need(!before.empty(),"hardware list cached");
 need(toggle(0)&&prepare()&&snapshot().prepared,"Y prepares real static parser under bounded heap");
 observed={original.begin,original.end,2000*1024,1800*1024,200*1024};
 need(search()&&gitCalls==1&&gbCalls==1,"low-memory X rejected before both providers");state=snapshot();need(state.totalItems==1&&state.selectedCount==1&&readFile(menu)==before,"low-memory rejection preserves list, selection and exact cache");
 need(state.error.find("libres 760 KiB")!=state.error.npos&&state.error.find("necesita 640 + reserva 256 KiB")!=state.error.npos,"visible available/required metrics");
 need(state.error.find("Fuentes Switch")==state.error.rfind("Fuentes Switch"),"one phase error, no duplicate generic paragraph");
 need(prepare()&&!snapshot().prepared&&writes==0,"low memory cannot prepare or install");
 observed={original.begin,original.end,1700*1024,1600*1024,200*1024};need(search()&&gitCalls==1&&snapshot().error.find("no se pudo comprobar")!=std::string::npos,"inconsistent allocator stats rejected");
 observed={original.begin,original.end,1800*1024,1600*1024,200*1024};
 need(search()&&gitCalls==2&&gbCalls==1,"independent GameBanana budget keeps smaller Git query available");
 state=snapshot();need(state.totalItems==1&&state.error.find("GameBanana: libres 960 KiB")!=state.error.npos,"partial query displays GameBanana heap requirement and retains Git results");
 observed=original;need(search()&&gitCalls==3&&gbCalls==2&&snapshot().error.empty(),"recovered heap can retry both providers");
 shutdown();const auto resolved=fs::weakly_canonical(sandbox);need(resolved.parent_path()==fs::weakly_canonical(parent)&&resolved.filename().string().rfind("nmm-heap-",0)==0,"safe sandbox cleanup");fs::remove_all(resolved);
 std::cout<<checks<<" memory/controller checks passed\n";
}
