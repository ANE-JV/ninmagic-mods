#define NC_MODS_TEST
#include "../source/mods.cpp"
#include <chrono>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <new>
#include <stdexcept>
namespace allocation {struct alignas(std::max_align_t) Header{size_t size;};size_t live=0,peak=0;}
void*operator new(size_t n){auto*h=static_cast<allocation::Header*>(std::malloc(sizeof(allocation::Header)+n));if(!h)throw std::bad_alloc();h->size=n;allocation::live+=n;allocation::peak=std::max(allocation::peak,allocation::live);return h+1;}
void operator delete(void*p)noexcept{if(p){auto*h=static_cast<allocation::Header*>(p)-1;allocation::live-=h->size;std::free(h);}}
void*operator new[](size_t n){return ::operator new(n);}void operator delete[](void*p)noexcept{::operator delete(p);}void operator delete(void*p,size_t)noexcept{::operator delete(p);}void operator delete[](void*p,size_t)noexcept{::operator delete(p);}
namespace nmm {bool downloadModHttps(const std::string&,const std::string&,uint64_t,std::string&e){e="offline fixture";return false;}}
namespace fs=std::filesystem;
int main(){const auto parent=fs::temp_directory_path();const auto folder=parent/("nmm-overlay-archives-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));try{
    fs::create_directories(folder);const auto path=folder/"tree.json";
    std::string data="{\"sha\":\""+std::string(40,'a')+"\",\"truncated\":false,\"tree\":[";
    for(unsigned n=0;n<128;++n){if(n)data+=',';data+="{\"path\":\"Mods/Demo/[010015100B514000]/1.0.0/"+std::to_string(n)+(n<96?".zip":".pchtxt")+"\",\"type\":\"blob\",\"sha\":\""+std::string(40,'b')+"\",\"size\":64}";}data+="]}";
    {std::ofstream file(path,std::ios::binary);file<<data;if(!file)throw std::runtime_error("fixture write");}
    nmm::Game game;game.id=0x010015100B514000ULL;game.name="Demo";nmm::ModsCatalog catalog;std::string error;
    const auto baseline=allocation::live;allocation::peak=baseline;
    const bool ok=nmm::filteredFile(path.generic_string(),game,"cucholix/NX-IPS-romfs-compilation",catalog,error);
    const auto peak=allocation::peak-baseline;size_t archives=0,companions=0;for(const auto&m:catalog.entries)if(m.format==nmm::ModFormat::Archive){++archives;companions+=m.files.size();if(m.compatible||m.selected)throw std::runtime_error("unreviewed archive enabled");}
    std::cout<<"overlay archive metadata peak="<<peak<<" bytes; archives="<<archives<<"; retained companions="<<companions<<'\n';
    if(!ok||archives!=96||catalog.entries.size()!=128)throw std::runtime_error("bounded fixture should preserve discovery: "+error);
    if(companions)throw std::runtime_error("overlay retains NRO-only companion vectors");
    if(peak>=512*1024)throw std::runtime_error("metadata exceeds 512 KiB envelope");
    const auto resolved=fs::weakly_canonical(folder);if(resolved.parent_path()!=fs::weakly_canonical(parent)||resolved.filename().string().rfind("nmm-overlay-archives-",0)!=0)throw std::runtime_error("cleanup path");fs::remove_all(resolved);
    std::cout<<"overlay archive memory/provenance checks PASS\n";
}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<"; fixture="<<folder<<'\n';return 1;}}
