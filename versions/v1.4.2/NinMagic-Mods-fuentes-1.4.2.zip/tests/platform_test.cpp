#define NMM_PLATFORM_TEST
#include "../source/platform.cpp"
#include <iostream>
#include <stdexcept>

namespace {
unsigned checks=0,scenarios=0;constexpr uint64_t Title=0x010015100B514000ULL;
std::vector<nmm::Status> statuses;std::vector<uint64_t> ids;std::array<uint8_t,0x4000> control;std::vector<nmm::Status> readAttempts;
void check(bool b,const char*message){++checks;if(!b)throw std::runtime_error(std::string(message)+" [scenario "+std::to_string(scenarios)+"]");}
#define CHECK(v) check((v),#v)
void text(size_t offset,const std::string&s){std::copy(s.begin(),s.end(),control.begin()+offset);}
void reset(){++scenarios;nmm::testApi={};ids={Title};statuses={{Title,0,5,0x80},{Title^0x800ULL,2,5,0x81}};control.fill(0);text(0,"English title");text(6*0x300,u8"Super Mario Bros.™ Wonder");text(6*0x300+0x200,"Nintendo");text(0x3060,"1.2.1");readAttempts.clear();
    nmm::testApi.records=[](auto&out,auto&){out=ids;return true;};nmm::testApi.statuses=[](uint64_t,auto&out,auto&){out=statuses;return true;};nmm::testApi.control=[](uint64_t,auto&out){out=control;return true;};nmm::testApi.main=[](uint64_t,const auto&s,auto&out,auto&){readAttempts.push_back(s);out.fill(0xA5);std::memcpy(out.data(),"NSO0",4);return true;};nmm::testApi.process=[](uint64_t,uint64_t&){return nmm::PmProcessNotFound;};nmm::testApi.running=[](uint64_t&out,std::string&){out=0;return true;};nmm::testApi.loader=[](uint64_t,std::string&,std::string&){return false;};nmm::testApi.liveProcess=[](uint64_t,uint64_t&pid,std::string&){pid=55;return true;};nmm::testApi.programRecord=[](const auto&s,std::string&out,std::string&){out=std::to_string(s.id)+":"+std::to_string(s.version)+":"+std::to_string(s.type)+":"+std::to_string(s.storage)+"\n";return true;};nmm::Environment env;std::string error;CHECK(nmm::platformInit(env,error));
}
nmm::Game resolve(){nmm::Game g;g.id=Title;nmm::Environment env;std::string error;CHECK(nmm::resolveBuild(g,env,error));CHECK(g.buildVerified&&g.fullBuildId.size()==64&&g.buildId==g.fullBuildId.substr(0,16));return g;}
}
int main(){try{std::string error;nmm::Environment env;std::vector<nmm::Game> games;
    reset();CHECK(nmm::scanGames(games,env,error)&&games.size()==1);CHECK(games[0].name==u8"Super Mario Bros.™ Wonder"&&games[0].author=="Nintendo");CHECK(games[0].versionKnown&&games[0].version=="1.2.1"&&games[0].contentVersion==2);CHECK(games[0].sd&&!games[0].nand&&!games[0].card);
    reset();ids={Title,Title,0x0100000000001000ULL,Title+1};CHECK(nmm::scanGames(games,env,error)&&games.size()==1);
    reset();statuses={{Title,0,5,0x80},{Title^0x800ULL,3,4,0x81},{Title^0x800ULL,8,2,0x81},{Title^0x800ULL,7,5,0x81},{Title+0x10000,999,5,0x81}};auto g=resolve();CHECK(g.contentVersion==8&&readAttempts.size()==1&&readAttempts[0].storage==2&&readAttempts[0].version==8);CHECK(nmm::validateClosedGame(g,error));
    reset();nmm::testApi.main=[](uint64_t,const auto&s,auto&,auto&e){readAttempts.push_back(s);e="latest patch unreadable";return false;};g={};g.id=Title;CHECK(nmm::resolveBuild(g,env,error));CHECK(readAttempts.size()==1&&readAttempts[0].type==0x81&&readAttempts[0].version==2&&!g.buildVerified&&g.buildId.empty()&&g.contentIdentity.size()==64);CHECK(nmm::validateClosedResources(g,error));
    reset();statuses.push_back({Title^0x800ULL,2,4,0x81});nmm::testApi.main=[](uint64_t,const auto&s,auto&out,auto&){readAttempts.push_back(s);out.fill(0xA5);std::memcpy(out.data(),"NSO0",4);return s.storage==4;};g=resolve();CHECK(readAttempts.size()==2&&readAttempts[0].storage==5&&readAttempts[1].storage==4);CHECK(g.fullBuildId==std::string("A5A5A5A5A5A5A5A5A5A5A5A5A5A5A5A5A5A5A5A5A5A5A5A5A5A5A5A5A5A5A5A5"));
    reset();statuses={{Title,4,4,0x80},{Title,2,5,0x80}};g=resolve();CHECK(g.contentVersion==4&&g.nand&&g.sd&&readAttempts.size()==1&&readAttempts[0].storage==4);
    reset();statuses={{Title,0,1,0x80},{Title^0x800ULL,2,5,0x82},{Title+0x1000,2,5,0x81}};CHECK(nmm::scanGames(games,env,error)&&games.empty());g={};g.id=Title;CHECK(!nmm::resolveBuild(g,env,error)&&!g.buildVerified);
    reset();nmm::testApi.records=[](auto&,auto&e){e="NS denied";return false;};CHECK(!nmm::scanGames(games,env,error)&&games.empty()&&error=="NS denied");
    reset();nmm::testApi.control=[](uint64_t,auto&){return false;};g=resolve();CHECK(g.name.empty()&&!g.versionKnown&&g.version.empty());CHECK(nmm::scanGames(games,env,error)&&games[0].name=="Juego "+nmm::titleId(Title)&&!games[0].versionKnown);CHECK(nmm::validateClosedGame(g,error));
    reset();control[0x3215]=2;g=resolve();CHECK(!g.versionKnown||g.version=="1.2.1");CHECK(nmm::scanGames(games,env,error)&&games[0].name=="Juego "+nmm::titleId(Title));
    reset();nmm::testApi.language=0;g=resolve();CHECK(g.name=="English title");
    reset();control.fill(0);text(0,"English fallback");text(0x3060,"1.0.0");g=resolve();CHECK(g.name=="English fallback"&&g.version=="1.0.0");
    reset();g=resolve();CHECK(nmm::validateClosedGame(g,error)&&error.empty());
    reset();g=resolve();nmm::testApi.process=[](uint64_t,uint64_t&pid){pid=100;return 0;};CHECK(!nmm::validateClosedGame(g,error)&&error.find("Cierra")!=error.npos);
    reset();g=resolve();nmm::testApi.process=[](uint64_t,uint64_t&pid){pid=0;return 0;};CHECK(!nmm::validateClosedGame(g,error)&&error.find("demostrar")!=error.npos);
    reset();g=resolve();for(const uint32_t rc:{0xFFFFFFFFU,0x1234U,0x20EU,0x40FU}){nmm::testApi.process=[&](uint64_t,uint64_t&){return rc;};CHECK(!nmm::validateClosedGame(g,error)&&error.find("PM")!=error.npos);}
    reset();g=resolve();unsigned probes=0;nmm::testApi.process=[&](uint64_t id,uint64_t&pid){CHECK(id==Title);if(++probes==1)return nmm::PmProcessNotFound;pid=200;return 0U;};CHECK(!nmm::validateClosedGame(g,error)&&probes==2);
    reset();g=resolve();statuses[1].version++;CHECK(!nmm::validateClosedGame(g,error)&&error.find("cambió")!=error.npos);
    reset();g=resolve();text(0x3060,"1.2.2");CHECK(!nmm::validateClosedGame(g,error)&&error.find("cambió")!=error.npos);
    reset();g=resolve();nmm::testApi.control=[](uint64_t,auto&){return false;};CHECK(!nmm::validateClosedGame(g,error)&&error.find("cambió")!=error.npos);
    reset();g=resolve();nmm::testApi.main=[](uint64_t,const auto&,auto&out,auto&){out.fill(0xAA);std::memcpy(out.data(),"NSO0",4);return true;};CHECK(!nmm::validateClosedGame(g,error)&&error.find("cambió")!=error.npos);
    reset();g=resolve();g.buildId="1234567890ABCDEF";CHECK(!nmm::validateClosedGame(g,error)&&error.find("identidad")!=error.npos);
    reset();g=resolve();g.buildVerified=false;CHECK(!nmm::validateClosedGame(g,error));
    reset();g=resolve();g.fullBuildId=std::string(64,'0');g.buildId=std::string(16,'0');CHECK(!nmm::validateClosedGame(g,error));
    reset();g=resolve();g.id=0x0100000000001000ULL;CHECK(!nmm::validateClosedGame(g,error));
    reset();nmm::testApi.main=[](uint64_t,const auto&,auto&out,auto&){out.fill(0);std::memcpy(out.data(),"NSO0",4);return true;};g={};g.id=Title;CHECK(nmm::resolveBuild(g,env,error)&&!g.buildVerified&&g.contentIdentity.size()==64);
    reset();nmm::testApi.main=[](uint64_t,const auto&,auto&out,auto&){out.fill(0xFF);std::memcpy(out.data(),"NSO0",4);return true;};g={};g.id=Title;CHECK(nmm::resolveBuild(g,env,error)&&!g.buildVerified);
    reset();nmm::testApi.main=[](uint64_t,const auto&,auto&out,auto&){out.fill(0xAB);std::memcpy(out.data(),"XXXX",4);return true;};g={};g.id=Title;CHECK(nmm::resolveBuild(g,env,error)&&!g.buildVerified);
    reset();nmm::testApi.running=[](uint64_t&out,std::string&){out=Title;return true;};nmm::testApi.main=[](uint64_t,const auto&,auto&,auto&){return false;};nmm::testApi.loader=[](uint64_t id,std::string&bid,std::string&){CHECK(id==Title);bid=std::string(64,'B');return true;};g=resolve();CHECK(g.running&&g.fullBuildId==std::string(64,'B'));CHECK(!nmm::validateClosedGame(g,error));
    reset();nmm::testApi.running=[](uint64_t&out,std::string&e){out=0;e="PM unverified";return false;};g={};g.id=Title;CHECK(!nmm::resolveBuild(g,env,error)&&!g.running&&error=="PM unverified");nmm::testApi.process=[](uint64_t,uint64_t&){return 0x1234;};CHECK(!nmm::validateClosedGame(g,error));
    reset();g=resolve();nmm::testApi.running=[](uint64_t&out,std::string&){out=Title+1;return true;};CHECK(!nmm::validateClosedGame(g,error)&&error.find("Cierra")!=error.npos);CHECK(nmm::scanGames(games,env,error)&&games[0].running);
    reset();g=resolve();nmm::testApi.running=[](uint64_t&out,std::string&e){out=0;e="PM failed";return false;};CHECK(!nmm::validateClosedGame(g,error)&&error.find("aplicación")!=error.npos);
    reset();g=resolve();unsigned activeProbes=0;nmm::testApi.running=[&](uint64_t&out,std::string&){out=++activeProbes==1?0:Title+2;return true;};CHECK(!nmm::validateClosedGame(g,error)&&activeProbes==2);
    reset();g=resolve();nmm::testApi.running=[](uint64_t&out,std::string&){out=Title+0x10000;return true;};CHECK(nmm::validateClosedGame(g,error));
    reset();nmm::testApi.statuses=[](uint64_t,auto&out,auto&){out.assign(nmm::MaxRecords+1,{Title,0,5,0x80});return true;};CHECK(nmm::scanGames(games,env,error)&&games.empty());
    reset();nmm::testApi.records=[](auto&out,auto&){out.assign(nmm::MaxRecords+1,Title);return true;};CHECK(!nmm::scanGames(games,env,error)&&games.empty());
    reset();g=resolve();nmm::testApi.applet=true;CHECK(nmm::platformInit(env,error)&&env.applet);CHECK(!nmm::validateClosedGame(g,error)&&error.find("modo aplicación")!=error.npos);CHECK(nmm::scanGames(games,env,error)&&games.size()==1);
    reset();nmm::testApi.running=[](uint64_t&out,std::string&){out=Title;return true;};nmm::testApi.loader=[](uint64_t id,std::string&bid,std::string&){CHECK(id==Title);bid=std::string(64,'B');return true;};nmm::testApi.records=[](auto&,auto&){CHECK(false);return false;};CHECK(nmm::resolveRunningGame(g,env,error)&&g.id==Title&&g.running&&g.buildVerified&&g.fullBuildId==std::string(64,'B')&&g.version=="1.2.1"&&env.runningTitle==Title);
    reset();nmm::nsReady=false;nmm::testApi.running=[](uint64_t&out,std::string&){out=Title;return true;};nmm::testApi.loader=[](uint64_t,std::string&bid,std::string&){bid=std::string(64,'B');return true;};CHECK(nmm::resolveRunningGame(g,env,error)&&g.buildVerified&&!g.versionKnown&&g.name=="Juego "+nmm::titleId(Title));CHECK(!nmm::validateClosedGame(g,error));
    reset();nmm::testApi.running=[](uint64_t&out,std::string&){out=Title;return true;};nmm::testApi.loader=[](uint64_t,std::string&bid,std::string&){bid="1234";return true;};CHECK(nmm::resolveRunningGame(g,env,error)&&g.id==Title&&!g.buildVerified&&g.fullBuildId.empty()&&g.version=="1.2.1");
    reset();unsigned currentProbes=0;nmm::testApi.running=[&](uint64_t&out,std::string&){out=++currentProbes==1?Title:Title+0x1000;return true;};nmm::testApi.loader=[](uint64_t,std::string&bid,std::string&){bid=std::string(64,'B');return true;};CHECK(!nmm::resolveRunningGame(g,env,error)&&!g.buildVerified&&g.fullBuildId.empty()&&error.find("cambió")!=error.npos);
    reset();nmm::testApi.running=[](uint64_t&out,std::string&){out=Title+1;return true;};CHECK(!nmm::resolveRunningGame(g,env,error)&&!g.buildVerified&&g.id==0);
    reset();CHECK(!nmm::resolveRunningGame(g,env,error)&&g.id==0&&!g.buildVerified);
    reset();nmm::testApi.running=[](uint64_t&out,std::string&e){out=0;e="PM failure";return false;};CHECK(!nmm::resolveRunningGame(g,env,error)&&!g.buildVerified&&error=="PM failure");
    reset();nmm::testApi.running=[](uint64_t&out,std::string&){out=Title;return true;};nmm::testApi.loader=[](uint64_t,std::string&bid,std::string&){bid=std::string(64,'0');return true;};CHECK(nmm::resolveRunningGame(g,env,error)&&!g.buildVerified&&g.id==Title);
    reset();g=resolve();readAttempts.clear();nmm::testApi.main=[](uint64_t,const auto&,auto&,auto&){CHECK(false);return false;};g.buildVerified=false;g.buildId.clear();g.fullBuildId.clear();CHECK(nmm::validateClosedResources(g,error)&&readAttempts.empty());
    reset();g=resolve();g.versionKnown=false;g.version.clear();CHECK(!nmm::validateClosedResources(g,error));
    reset();g=resolve();g.contentIdentity.clear();CHECK(!nmm::validateClosedResources(g,error));
    reset();g=resolve();g.contentIdentity=std::string(64,'0');CHECK(!nmm::validateClosedResources(g,error));
    reset();g=resolve();g.contentIdentity=std::string(64,'A');CHECK(!nmm::validateClosedResources(g,error));
    reset();g=resolve();nmm::testApi.programRecord=[](const auto&,std::string&out,std::string&){out="same metadata but another Program content ID";return true;};CHECK(!nmm::validateClosedResources(g,error)&&error.find("cambió")!=error.npos);
    reset();g=resolve();nmm::testApi.programRecord=[](const auto&,std::string&,std::string&e){e="NCM unavailable";return false;};CHECK(!nmm::validateClosedResources(g,error)&&error=="NCM unavailable");
    reset();g=resolve();nmm::testApi.process=[](uint64_t,uint64_t&pid){pid=0;return 0;};CHECK(!nmm::validateClosedResources(g,error)&&error.find("demostrar")!=error.npos);
    reset();unsigned snapshots=0;nmm::testApi.programRecord=[&](const auto&,std::string&out,std::string&){out=std::to_string(++snapshots);return true;};g={};g.id=Title;CHECK(!nmm::resolveBuild(g,env,error)&&g.contentIdentity.empty()&&error.find("cambió")!=error.npos);
    reset();unsigned nacpReads=0;nmm::testApi.control=[&](uint64_t,auto&out){out=control;if(++nacpReads==2)out[0x3060]='9';return true;};g={};g.id=Title;CHECK(!nmm::resolveBuild(g,env,error)&&g.contentIdentity.empty()&&error.find("versión declarada")!=error.npos);
    const auto live=[&](){nmm::testApi.running=[](uint64_t&out,std::string&){out=Title;return true;};nmm::testApi.loader=[](uint64_t,std::string&out,std::string&){out=std::string(64,'B');return true;};nmm::Game current;CHECK(nmm::resolveRunningGame(current,env,error));CHECK(current.processId==55&&current.contentIdentity.size()==64);return current;};
    reset();g=live();CHECK(nmm::validateRunningGame(g,error));CHECK(!nmm::validateClosedResources(g,error));
    reset();nmm::testApi.applet=true;CHECK(nmm::platformInit(env,error));g=live();CHECK(nmm::validateRunningGame(g,error));CHECK(!nmm::validateClosedResources(g,error)&&error.find("modo aplicación")!=error.npos);
    reset();g=live();g.processId=0;CHECK(!nmm::validateRunningGame(g,error));
    reset();g=live();g.running=false;CHECK(!nmm::validateRunningGame(g,error));
    reset();g=live();g.buildId="1234567890ABCDEF";CHECK(!nmm::validateRunningGame(g,error));
    reset();g=live();g.contentIdentity.clear();CHECK(!nmm::validateRunningGame(g,error));
    reset();g=live();nmm::testApi.liveProcess=[](uint64_t,uint64_t&pid,std::string&){pid=56;return true;};CHECK(!nmm::validateRunningGame(g,error)&&error.find("proceso")!=error.npos);
    reset();g=live();nmm::testApi.loader=[](uint64_t,std::string&out,std::string&){out=std::string(64,'C');return true;};CHECK(!nmm::validateRunningGame(g,error)&&error.find("Build ID")!=error.npos);
    reset();g=live();text(0x3060,"1.2.2");CHECK(!nmm::validateRunningGame(g,error)&&error.find("contenido instalado")!=error.npos);
    reset();g=live();unsigned pidReads=0;nmm::testApi.liveProcess=[&](uint64_t,uint64_t&pid,std::string&){pid=++pidReads>=3?56:55;return true;};CHECK(!nmm::validateRunningGame(g,error)&&error.find("proceso")!=error.npos);
    reset();g=live();nmm::testApi.loader=[](uint64_t,std::string&out,std::string&){out=std::string(64,'B');nmm::testApi.programRecord=[](const auto&,std::string&record,std::string&){record="new content installed while reading loader metadata";return true;};return true;};CHECK(!nmm::validateRunningGame(g,error)&&error.find("contenido instalado cambió")!=error.npos);
    reset();nmm::testApi.control=[](uint64_t,auto&){return false;};nmm::testApi.main=[](uint64_t,const auto&,auto&,auto&){return false;};g={};g.id=Title;CHECK(nmm::resolveBuild(g,env,error)&&!g.versionKnown&&!g.buildVerified);CHECK(nmm::validateClosedResources(g,error));statuses[1].version++;CHECK(!nmm::validateClosedResources(g,error));
    reset();nmm::testApi.running=[](uint64_t&out,std::string&){out=Title;return true;};CHECK(nmm::resolveRunningGame(g,env,error)&&!g.buildVerified&&g.processId==55);CHECK(nmm::validateRunningGame(g,error));nmm::testApi.liveProcess=[](uint64_t,uint64_t&pid,std::string&){pid=56;return true;};CHECK(!nmm::validateRunningGame(g,error));
    reset();nmm::testApi.running=[](uint64_t&out,std::string&){out=Title;return true;};g={};g.id=Title;CHECK(nmm::resolveBuild(g,env,error)&&!g.buildVerified&&g.processId==55);CHECK(nmm::validateRunningGame(g,error));nmm::testApi.liveProcess=[](uint64_t,uint64_t&,std::string&e){e="process unavailable";return false;};CHECK(!nmm::validateRunningGame(g,error));
    reset();g=resolve();nmm::platformExit();CHECK(!nmm::validateClosedGame(g,error)&&!nmm::scanGames(games,env,error)&&!nmm::validateClosedResources(g,error)&&!nmm::validateRunningGame(g,error));
    std::cout<<"mods platform: "<<scenarios<<" read-only metadata/build/closed-game scenarios, "<<checks<<" checks PASS\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
