// Unit boundary for the legacy Git catalog tests. Archive parser/transport
// behavior is exercised separately by mod_archive[_catalog]_test.cpp.
#include "gamebanana.hpp"
#include "update_network.hpp"
namespace nmm {
bool downloadModArchiveHttps(const std::string&,const std::string&,uint64_t,std::string&error){error="Archive transport is outside this catalog test.";return false;}
bool refreshGameBananaMod(const Game&,ModEntry&,std::string&error,bool){error="GameBanana is outside this Git catalog test.";return false;}
bool obtainGameBananaArchive(const Game&,const ModEntry&,std::string&,std::string&error){error="GameBanana is outside this Git catalog test.";return false;}
}
