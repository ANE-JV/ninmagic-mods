#include <switch.h>
#include <algorithm>
#include <atomic>
#include <iterator>
#include "model.hpp"
#include "ui.hpp"
#include "mod_ui.hpp"
#include "mods.hpp"
#include "gamebanana.hpp"
#include "mod_archive.hpp"
#include "mod_install.hpp"
#include "platform.hpp"
#include "app_update_ui.hpp"
#include "update_network.hpp"
#include "mod_queue.hpp"
#include "overlay_bundle.hpp"

namespace {
enum class Kind {Init,Scan,Sync,Search,ChooseFile,Prepare,Install,ReviewRemove,Remove,CheckUpdate,PrepareUpdate,InstallUpdate,ReviewRecord,ArchiveRecord};
constexpr const char *AppPath="sdmc:/switch/NinMagicMods/NinMagic-Mods.nro";
struct Job {Kind kind=Kind::Init;Thread thread{};std::atomic<bool>done{false};bool active=false,ok=false;nmm::View data;std::string error,recoveryError;}job;
nmm::Screen sourcesBack=nmm::Screen::Library,resultBack=nmm::Screen::Mods;
void refreshInstalled(nmm::View&v){
    nmm::InstalledModSelection state;std::string error;
    const bool ok=nmm::inspectInstalledModSelection(v.game,state,error);
    if(!ok)state={};
    nmm::applyInstalledSelection(v.mods,state);v.installedModCount=unsigned(state.mods.size());v.installedLegacy=state.unidentifiedLegacy;v.installedCheckFailed=!ok;
    v.installedDetail=!ok?"No se pudo verificar lo instalado: "+error:state.unidentifiedLegacy?"Hay mods de una versión anterior instalados sin identificación individual. L permite retirarlos.":state.mods.empty()?std::string{}:std::to_string(state.mods.size())+" mods instalados. La casilla permanece marcada; L permite retirarlos.";
    const auto previousPending=v.pendingModIds.size();
    v.pendingModIds.erase(std::remove_if(v.pendingModIds.begin(),v.pendingModIds.end(),[&](const std::string&id){return std::any_of(state.mods.begin(),state.mods.end(),[&](const nmm::InstalledModRecord&r){return r.id==id;});}),v.pendingModIds.end());
    nmm::applyPendingSelection(v.mods,v.pendingModIds);
    if(previousPending!=v.pendingModIds.size()){std::string e;if(!nmm::saveAppModSelection(v.game,v.pendingModIds,e))v.detail="No se pudo guardar la selección restante: "+e;}
}
void savePending(nmm::View&v){std::string e;if(!nmm::saveAppModSelection(v.game,v.pendingModIds,e))v.detail="La elección no se pudo guardar: "+e;}
void changePending(nmm::View&v,nmm::ModEntry&m){
    if(m.installed){v.detail="Este mod ya está instalado. Cierra el juego y pulsa L para retirar los mods instalados.";return;}
    if(!m.selected&&v.pendingModIds.size()>=32){v.detail="Hay 32 elecciones pendientes. Desmarca alguna antes de añadir otra.";return;}
    m.selected=!m.selected;auto&ids=v.pendingModIds;ids.erase(std::remove(ids.begin(),ids.end(),m.id),ids.end());if(m.selected)ids.push_back(m.id);v.detail.clear();savePending(v);
}
void reviewRecord(){auto&v=job.data;std::string e;nmm::canArchiveCompletedUpdate(AppPath,v.completedUpdate,e);if(!v.completedUpdate.currentVersion.empty()&&!v.completedUpdate.currentSha256.empty()){v.appUpdate.sdVerified=true;v.appUpdate.sdVersion=v.completedUpdate.currentVersion;v.appUpdate.sdSha256=v.completedUpdate.currentSha256;v.appUpdate.sdSize=v.completedUpdate.currentSize;}if(v.completedUpdate.state==nmm::CompletedUpdateState::Blocked&&v.appUpdateDetail.empty())v.appUpdateDetail=e;}
bool checkUpdate(){auto&v=job.data;std::string e;bool ok=nmm::checkAppUpdate(v.appUpdate,e);v.appUpdateDetail=ok?std::string{}:e;reviewRecord();if(!job.recoveryError.empty()&&v.appUpdateDetail.empty())v.appUpdateDetail=job.recoveryError;return ok;}
void work(void*){
    auto&v=job.data;job.ok=false;job.error.clear();
    switch(job.kind){
    case Kind::Init:{job.ok=nmm::platformInit(v.env,job.error);if(job.ok)job.ok=nmm::scanGames(v.games,v.env,job.error);std::string e;nmm::loadModsCatalog(v.catalog,e);if(!e.empty())v.catalog.detail=e;nmm::ensureBundledOverlay(v.overlayDetail);checkUpdate();break;}
    case Kind::Scan:job.ok=nmm::scanGames(v.games,v.env,job.error);break;
    case Kind::Sync:job.ok=nmm::syncModsCatalog(v.catalog,job.error,true);v.env.network=job.ok;v.outcome={};v.outcome.ok=job.ok;v.outcome.message=job.ok?v.catalog.detail:job.error+" Se conserva el catálogo anterior.";break;
    case Kind::Search:{
        std::string buildError;nmm::resolveBuild(v.game,v.env,buildError);v.mods=nmm::findMods(v.game,v.catalog);
        std::vector<nmm::ModEntry> gb;std::string gbError;const bool gbOk=nmm::loadGameBananaMods(v.game,gb,gbError);
        v.catalog.sources.erase(std::remove_if(v.catalog.sources.begin(),v.catalog.sources.end(),[](const nmm::SourceReport&s){return s.name=="GameBanana";}),v.catalog.sources.end());
        v.catalog.sources.push_back({"GameBanana","https://gamebanana.com",gbError.empty()?"Consulta del juego seleccionado; A elige, Y prepara la instalación.":gbError,unsigned(gb.size()),gbOk,!gbOk&&!gb.empty()});
        for(auto&m:gb)if(nmm::isBrowsableMod(m))v.mods.push_back(std::move(m));
        std::string e;nmm::resolveGameMods(v.game,v.mods,e);v.detail=buildError;if(!e.empty()){if(!v.detail.empty())v.detail+=" ";v.detail+=e;}
        if(!gbError.empty()){if(!v.detail.empty())v.detail+=" ";v.detail+="GameBanana: "+gbError;}
        v.pendingModIds.clear();std::string appSelectionError;
        if(!nmm::loadAppModSelection(v.game,v.pendingModIds,appSelectionError)&&!appSelectionError.empty())v.detail+=" "+appSelectionError;
        std::vector<std::string> chosen;std::string queueError;
        if(nmm::loadModSelection(v.game,chosen,queueError))for(const auto&id:chosen)if(v.pendingModIds.size()<32&&std::find(v.pendingModIds.begin(),v.pendingModIds.end(),id)==v.pendingModIds.end())v.pendingModIds.push_back(id);
        refreshInstalled(v);
        if(!v.pendingModIds.empty())v.detail+=" "+std::to_string(v.pendingModIds.size())+" elecciones pendientes guardadas. Abre el mod para ver su variante; Y instala las visibles marcadas.";
        std::vector<nmm::ModEntry> menu;menu.reserve(std::min<size_t>(128,v.mods.size()));for(size_t i=0;i<std::min<size_t>(128,v.mods.size());++i)menu.push_back(v.mods[i]);
        std::string menuError;if(v.game.running&&!nmm::saveModMenuCache(v.game,menu,menuError)&&!menuError.empty()){if(!v.detail.empty())v.detail+=" ";v.detail+="Overlay: "+menuError;}
        v.payloads.clear();v.modSelected=0;v.filter=0;job.ok=true;break;}

    case Kind::ChooseFile:{
        const auto ids=nmm::visibleMods(v);if(ids.empty()){job.error="La lista cambió; vuelve a buscar los mods del juego.";break;}
        const auto index=ids[std::clamp(v.modSelected,0,int(ids.size())-1)];
        if(!nmm::canChooseModFile(v.mods[index])){job.error="Selecciona el archivo del mod que deseas instalar.";break;}
        std::vector<nmm::ModEntry>files;
        if(!nmm::loadGameBananaModFiles(v.game,v.mods[index],files,job.error)){v.detail=job.error;break;}
        if(files.empty()){job.error="El autor no publica un ZIP/RAR admitido para este mod.";break;}
        if(files.size()>1){
            v.mods.erase(v.mods.begin()+index);v.mods.insert(v.mods.begin()+index,std::make_move_iterator(files.begin()),std::make_move_iterator(files.end()));
            v.detail="El autor ofrece varios archivos. A marca la variante que quieres instalar.";
        }else{v.mods[index]=std::move(files.front());}
        refreshInstalled(v);
        if(files.size()==1&&!v.mods[index].installed&&!v.mods[index].selected&&nmm::canMarkMod(v.mods[index]))changePending(v,v.mods[index]);
        if(files.size()==1&&v.mods[index].installed)v.detail="Este archivo ya está instalado. La casilla se conserva marcada; L permite retirarlo con el juego cerrado.";
        job.ok=true;break;}

    case Kind::Prepare:{
        v.payloads.clear();v.detail.clear();bool code=false,resources=false,archives=false;unsigned count=0;uint64_t selectedInput=0,selectedResources=0,preparedCode=0,preparedResources=0;job.ok=true;
        constexpr uint64_t MaxResources=128ULL*1024*1024;
        for(const auto&m:v.mods)if(nmm::pendingMod(m)){
            if(!nmm::canMarkMod(m)||++count>32){job.error="Selecciona hasta 32 mods de formatos admitidos.";job.ok=false;break;}
            if(m.format==nmm::ModFormat::Archive){archives=true;continue;}
            if(m.format==nmm::ModFormat::Romfs){
                resources=true;uint64_t size=0;for(const auto&f:m.files){if(f.size>MaxResources-size){size=MaxResources+1;break;}size+=f.size;}
                if(size>MaxResources-selectedResources){job.error="La selección de recursos supera 128 MiB. Elige menos paquetes.";job.ok=false;break;}selectedResources+=size;
            }else if(m.format==nmm::ModFormat::Ips||m.format==nmm::ModFormat::Pchtxt){code=true;if(m.size>2ULL*1024*1024){job.error="El parche supera 2 MiB; elige un paquete más pequeño.";job.ok=false;break;}selectedInput+=m.size;}
            else{job.error="Formato de mod no admitido.";job.ok=false;break;}
        }
        if(!count){job.ok=false;job.error=v.installedModCount?"Los mods marcados INSTALADO ya están presentes. Elige un mod nuevo o usa L para retirar con el juego cerrado.":"Marca al menos un mod con A. Si guardaste una variante, abre su mod para mostrarla.";}
        if(v.env.applet&&(archives||resources)){job.ok=false;job.error="Para instalar ZIP/RAR o RomFS, cierra este juego y abre NinMagic en modo aplicación desde otro título.";}
        if(v.env.applet&&code&&selectedInput>8ULL*1024*1024){job.ok=false;job.error="La selección de parches supera el límite de Álbum. Elige menos opciones.";}
        if(code&&resources){job.ok=false;job.error="Instala los parches de código y los archivos RomFS por separado.";}
        if(job.ok)job.ok=resources?nmm::validateClosedResources(v.game,job.error):v.game.running?nmm::validateRunningGame(v.game,job.error):nmm::validateClosedResources(v.game,job.error);
        if(job.ok)for(const auto&m:v.mods)if(nmm::pendingMod(m)){
            nmm::ModPayload p;if(!nmm::prepareMod(v.game,m,p,job.error)){job.ok=false;break;}
            preparedCode+=p.ips.size();if(v.env.applet&&preparedCode>4ULL*1024*1024){job.error="Los parches preparados superan la memoria de Álbum. Elige menos opciones.";job.ok=false;break;}
            for(const auto&f:p.files){if(f.bytes.size()>MaxResources-preparedResources){job.error="Los recursos preparados superan 128 MiB. Elige menos paquetes.";job.ok=false;break;}preparedResources+=f.bytes.size();}
            if(!job.ok)break;
            v.payloads.push_back(std::move(p));
        }
        if(job.ok){nmm::ModPayload combined;job.ok=nmm::combineMods(v.game,v.payloads,combined,job.error);}
        if(job.ok)job.ok=nmm::inspectPreparedMods(v.game,v.payloads,v.installed,job.error);
        v.remove=false;break;}
    case Kind::Install:v.outcome=nmm::installMods(v.game,v.payloads,v.installed.exists,v.installed.fingerprint);job.ok=v.outcome.ok;if(job.ok){std::string e;nmm::clearModSelection(v.game,e);v.pendingModIds.erase(std::remove_if(v.pendingModIds.begin(),v.pendingModIds.end(),[&](const std::string&id){return std::any_of(v.payloads.begin(),v.payloads.end(),[&](const nmm::ModPayload&p){return p.entry.id==id;});}),v.pendingModIds.end());}refreshInstalled(v);if(job.ok)savePending(v);break;
    case Kind::ReviewRemove:if(v.env.applet){job.error="Retira los mods desde el modo aplicación de hbmenu.";break;}job.ok=nmm::validateClosedResources(v.game,job.error)&&nmm::inspectInstalledMods(v.game,v.installed,job.error);if(job.ok&&!v.installed.exists){job.ok=false;job.error="NinMagic Mods no tiene una instalación registrada para este juego.";}v.remove=true;break;
    case Kind::Remove:v.outcome=nmm::removeMods(v.game);job.ok=v.outcome.ok;refreshInstalled(v);break;
    case Kind::CheckUpdate:job.ok=checkUpdate();break;
    case Kind::PrepareUpdate:job.ok=nmm::prepareAppUpdate(v.appUpdate,AppPath,job.error);if(!job.ok)v.appUpdateDetail=job.error;break;
    case Kind::InstallUpdate:job.ok=nmm::installPreparedAppUpdate(v.appUpdate,AppPath,job.error);if(!job.ok)v.appUpdateDetail=job.error;reviewRecord();v.appUpdateResultOk=job.ok;v.appUpdateResultMessage=job.ok?"NinMagic Mods actualizado y verificado. Cierra la aplicación y vuelve a abrirla.":job.error;break;
    case Kind::ReviewRecord:reviewRecord();job.ok=nmm::completedReviewReady(v.completedUpdate);break;
    case Kind::ArchiveRecord:job.ok=nmm::archiveCompletedUpdate(AppPath,v.completedUpdate,job.error);v.appUpdateArchiveResult=true;v.appUpdateResultOk=job.ok;if(job.ok){job.recoveryError.clear();nmm::recoverAppUpdate(AppPath,job.recoveryError);checkUpdate();v.appUpdateResultMessage="Registro terminado archivado. Se conservan el NRO actual y sus copias anteriores.";}else {v.appUpdateResultMessage=job.error;v.appUpdateDetail=job.error;reviewRecord();}break;
    }
    job.done.store(true,std::memory_order_release);
}
bool start(Kind k,nmm::View&v){job.kind=k;job.data=std::move(v);v={};v.env=job.data.env;v.screen=job.data.screen;v.status=job.data.status;job.error.clear();job.ok=false;job.done.store(false);Result rc=threadCreate(&job.thread,work,nullptr,nullptr,768*1024,0x2c,-2);if(R_SUCCEEDED(rc)){rc=threadStart(&job.thread);if(R_FAILED(rc))threadClose(&job.thread);}if(R_FAILED(rc)){v=std::move(job.data);v.outcome={};v.outcome.message="No se pudo iniciar la operación. Los archivos actuales se conservan.";v.screen=nmm::Screen::Result;return false;}job.active=true;appletSetAutoSleepDisabled(true);return true;}
void begin(Kind k,nmm::View&v,const char*message){v.screen=nmm::Screen::Busy;v.status=message;start(k,v);}
}
int main(int,char**){
    nmm::recoverAppUpdate(AppPath,job.recoveryError);const Result rom=romfsInit();bool romMounted=R_SUCCEEDED(rom);
    if(!romMounted||!nmm::uiInit("romfs:"))return 1;
    Framebuffer fb{};if(R_FAILED(framebufferCreate(&fb,nwindowGetDefault(),1280,720,PIXEL_FORMAT_RGBA_8888,2))){nmm::uiExit();romfsExit();return 1;}if(R_FAILED(framebufferMakeLinear(&fb))){framebufferClose(&fb);nmm::uiExit();romfsExit();return 1;}
    PadState pad;padConfigureInput(1,HidNpadStyleSet_NpadStandard);padInitializeDefault(&pad);nmm::View v;start(Kind::Init,v);bool quit=false;uint64_t repeatStart=0,lastRepeat=0,lastDirection=0;
    while(appletMainLoop()&&!quit){padUpdate(&pad);uint64_t down=padGetButtonsDown(&pad),held=padGetButtons(&pad),now=armTicksToNs(armGetSystemTick());
        if(job.active&&job.done.load(std::memory_order_acquire)){threadWaitForExit(&job.thread);threadClose(&job.thread);job.active=false;appletSetAutoSleepDisabled(false);const auto k=job.kind;v=std::move(job.data);
            if(k==Kind::Init||k==Kind::Scan){if(job.ok){v.selected=std::clamp(v.selected,0,std::max(0,int(v.games.size())-1));v.status=v.games.empty()?"No hay juegos instalados accesibles.":"X actualiza las fuentes; A busca mods. "+v.overlayDetail;v.screen=nmm::Screen::Library;}else {v.outcome={};v.outcome.message=job.error;v.screen=nmm::Screen::Result;resultBack=nmm::Screen::Library;}}
            else if(k==Kind::Search||k==Kind::ChooseFile){v.screen=nmm::Screen::Mods;if(k==Kind::ChooseFile&&!job.ok&&!job.error.empty())v.detail=job.error;}
            else if(k==Kind::Prepare||k==Kind::ReviewRemove){if(job.ok)v.screen=k==Kind::Prepare?nmm::Screen::Confirm:nmm::Screen::RemoveConfirm;else {v.outcome={};v.outcome.message=job.error;v.screen=nmm::Screen::Result;resultBack=nmm::Screen::Mods;}}
            else if(k==Kind::CheckUpdate)v.screen=nmm::Screen::AppUpdate;
            else if(k==Kind::ReviewRecord)v.screen=nmm::Screen::AppUpdateRecord;
            else if(k==Kind::PrepareUpdate){if(!job.ok)v.screen=nmm::Screen::AppUpdate;else {if(romMounted){romfsExit();romMounted=false;}begin(Kind::InstallUpdate,v,"Instalando la descarga verificada de NinMagic Mods...");}}
            else if(k==Kind::InstallUpdate||k==Kind::ArchiveRecord)v.screen=nmm::Screen::AppUpdateResult;
            else {v.screen=nmm::Screen::Result;resultBack=k==Kind::Sync?nmm::Screen::Library:nmm::Screen::Mods;}
            down=0;
        }
        if(!job.active){using nmm::Screen;uint64_t direction=held&(HidNpadButton_AnyUp|HidNpadButton_AnyDown);bool move=(down&(HidNpadButton_AnyUp|HidNpadButton_AnyDown))!=0;if(direction!=lastDirection){repeatStart=lastRepeat=now;lastDirection=direction;}else if(direction&&now-repeatStart>350000000&&now-lastRepeat>100000000){move=true;lastRepeat=now;}int delta=direction&HidNpadButton_AnyDown?1:-1;
            if(v.screen==Screen::Library){if(move&&!v.games.empty())v.selected=(v.selected+delta+int(v.games.size()))%int(v.games.size());if(down&HidNpadButton_Plus)quit=true;else if(down&HidNpadButton_R)begin(Kind::CheckUpdate,v,"Comprobando las actualizaciones de NinMagic Mods...");else if(down&HidNpadButton_Y)begin(Kind::Scan,v,"Leyendo la biblioteca de juegos...");else if(down&HidNpadButton_X)begin(Kind::Sync,v,"Comprobando los catálogos de las fuentes de mods...");else if(down&HidNpadButton_L){sourcesBack=v.screen;v.sourceSelected=0;v.screen=Screen::Sources;}else if(down&HidNpadButton_Minus)v.screen=Screen::Help;else if((down&HidNpadButton_A)&&!v.games.empty()){v.game=v.games[v.selected];v.detail.clear();begin(Kind::Search,v,"Buscando los mods del juego...");}}
            else if(v.screen==Screen::Mods){const auto ids=nmm::visibleMods(v);if(move&&!ids.empty())v.modSelected=(v.modSelected+delta+int(ids.size()))%int(ids.size());if(down&HidNpadButton_B)v.screen=Screen::Library;else if((down&HidNpadButton_ZR)&&!ids.empty()){v.modDetailsOriginal=false;v.screen=Screen::ModDetail;}else if(down&HidNpadButton_X){v.filter=!v.filter;v.modSelected=0;}else if(down&HidNpadButton_R){sourcesBack=v.screen;v.sourceSelected=0;v.screen=Screen::Sources;}else if(down&HidNpadButton_L)begin(Kind::ReviewRemove,v,"Comprobando la instalación registrada y sus copias anteriores...");else if(down&HidNpadButton_Y)begin(Kind::Prepare,v,"Descargando y verificando los mods seleccionados...");else if((down&HidNpadButton_A)&&!ids.empty()){auto&m=v.mods[ids[std::clamp(v.modSelected,0,int(ids.size())-1)]];if(nmm::canMarkMod(m)){changePending(v,m);}else if(nmm::canInspectMod(m))begin(Kind::ChooseFile,v,"Consultando los archivos publicados por el autor...");else v.detail=m.reason.empty()?"Este formato no se puede instalar desde NinMagic.":m.reason;}}
            else if(v.screen==Screen::Confirm||v.screen==Screen::RemoveConfirm){if(down&HidNpadButton_B)v.screen=Screen::Mods;else if(down&HidNpadButton_A)begin(v.screen==Screen::RemoveConfirm?Kind::Remove:Kind::Install,v,v.screen==Screen::RemoveConfirm?"Retirando los mods registrados y restaurando sus archivos anteriores...":"Instalando los mods elegidos y conservando los archivos anteriores...");}
            else if(v.screen==Screen::ModDetail){if(down&(HidNpadButton_B|HidNpadButton_ZR))v.screen=Screen::Mods;else if(down&HidNpadButton_X)v.modDetailsOriginal=!v.modDetailsOriginal;}
            else if(v.screen==Screen::Sources){if(move&&!v.catalog.sources.empty())v.sourceSelected=(v.sourceSelected+delta+int(v.catalog.sources.size()))%int(v.catalog.sources.size());if(down&HidNpadButton_B)v.screen=sourcesBack;}
            else if(v.screen==Screen::Result){if(down&HidNpadButton_Plus)quit=true;else if(down&(HidNpadButton_A|HidNpadButton_B))v.screen=resultBack;}
            else if(v.screen==Screen::Help){if(down&(HidNpadButton_A|HidNpadButton_B|HidNpadButton_Minus))v.screen=Screen::Library;}
            else if(v.screen==Screen::AppUpdate){if(down&HidNpadButton_Plus)quit=true;else if(down&HidNpadButton_B)v.screen=Screen::Library;else if(down&HidNpadButton_X){if(!v.appUpdate.installed)begin(Kind::CheckUpdate,v,"Comprobando el canal de actualizaciones de NinMagic Mods...");}else if(down&HidNpadButton_A){auto a=nmm::appUpdateAction(v.appUpdate,v.completedUpdate,v.appUpdateDetail);if(a==nmm::AppUpdateAction::Install){v.appUpdateArchiveResult=false;begin(Kind::PrepareUpdate,v,"Descargando y verificando la nueva versión de NinMagic Mods...");}else if(a==nmm::AppUpdateAction::ReviewCompletedRecord)begin(Kind::ReviewRecord,v,"Revisando el registro terminado y el NRO...");}}
            else if(v.screen==Screen::AppUpdateRecord){if(down&HidNpadButton_B)v.screen=Screen::AppUpdate;else if(down&HidNpadButton_X)begin(Kind::ReviewRecord,v,"Comprobando el registro de actualizaciones...");else if((down&HidNpadButton_A)&&nmm::completedReviewReady(v.completedUpdate))begin(Kind::ArchiveRecord,v,"Archivando el registro terminado comprobado...");}
            else if(v.screen==Screen::AppUpdateResult){if(down&HidNpadButton_Plus)quit=true;else if(down&(HidNpadButton_A|HidNpadButton_B))v.screen=Screen::AppUpdate;}
        }
        u32 stride=0;auto*p=static_cast<uint32_t*>(framebufferBegin(&fb,&stride));nmm::uiDraw(p,int(stride/4),v);framebufferEnd(&fb);++v.frame;
    }
    if(job.active){threadWaitForExit(&job.thread);threadClose(&job.thread);}appletSetAutoSleepDisabled(false);nmm::updateNetworkExit();nmm::platformExit();nmm::uiExit();framebufferClose(&fb);if(romMounted)romfsExit();return 0;
}
