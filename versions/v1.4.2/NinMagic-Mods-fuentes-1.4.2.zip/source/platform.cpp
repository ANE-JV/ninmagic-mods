#include "platform.hpp"
#include "title_metadata.hpp"
#include "ui_text.hpp"
#include "mod_hash.hpp"
#include <algorithm>
#include <array>
#include <cstdio>
#include <cstring>
#include <new>
#include <set>
#ifdef __SWITCH__
#include <switch.h>
#include "platform_native.hpp"
#include "platform_content_native.hpp"
#endif
#ifdef NMM_PLATFORM_TEST
#include <functional>
#endif

namespace nmm {
namespace {
constexpr uint64_t MinUser=0x0100000000010000ULL;
constexpr size_t MaxRecords=16384;
constexpr uint32_t PmProcessNotFound=15U|(1U<<9); // pm::ProcessNotFound, not an arbitrary IPC failure.
constexpr uint8_t UserStorage=4,SdStorage=5,CardStorage=2,ApplicationMeta=0x80,PatchMeta=0x81;
struct Status {uint64_t id=0;uint32_t version=0;uint8_t storage=0,type=0;};
bool nsReady=false,fsldrReady=false,ncmReady=false,pmReady=false,ldrReady=false;
bool applicationMode=false;
[[maybe_unused]] uint32_t fsldrResult=0;
[[maybe_unused]] uint32_t ncmResult=0;
[[maybe_unused]] std::string fsldrDiagnostic;
uint64_t selfPid=0;
std::string rcText(uint32_t rc){char s[16];std::snprintf(s,sizeof(s),"0x%08lX",static_cast<unsigned long>(rc));return s;}
[[maybe_unused]] std::string bounded(const char*p,size_t n){size_t z=0;while(z<n&&p[z])++z;return std::string(p,z);}
bool validFull(const std::string&s){return s.size()==64&&s.find_first_not_of("0123456789ABCDEF")==s.npos&&s!=std::string(64,'0')&&s!=std::string(64,'F');}
std::string fullBuild(const uint8_t*p){std::string out;static constexpr char h[]="0123456789ABCDEF";for(unsigned i=0;i<32;++i){out+=h[p[i]>>4];out+=h[p[i]&15];}return out;}
#ifdef NMM_PLATFORM_TEST
struct TestApi {
    std::function<bool(std::vector<uint64_t>&,std::string&)> records;
    std::function<bool(uint64_t,std::vector<Status>&,std::string&)> statuses;
    std::function<bool(uint64_t,std::array<uint8_t,0x4000>&)> control;
    std::function<bool(uint64_t,const Status&,std::array<uint8_t,0x60>&,std::string&)> main;
    std::function<uint32_t(uint64_t,uint64_t&)> process;
    std::function<bool(uint64_t&,std::string&)> running;
    std::function<bool(uint64_t,std::string&,std::string&)> loader;
    std::function<bool(uint64_t,uint64_t&,std::string&)> liveProcess;
    std::function<bool(const Status&,std::string&,std::string&)> programRecord;
    int language=6;
    bool applet=false;
} testApi;
#endif
int titleLanguage(){
#ifdef NMM_PLATFORM_TEST
    return testApi.language;
#elif defined(__SWITCH__)
    if(R_FAILED(setInitialize()))return -1;
    u64 code=0;SetLanguage language=SetLanguage_ENUS;
    Result rc=setGetSystemLanguage(&code);if(R_SUCCEEDED(rc))rc=setMakeLanguage(code,&language);setExit();
    static constexpr int indices[]={2,0,3,4,7,6,14,12,8,10,11,13,1,9,5,14,13,15};
    const int index=static_cast<int>(language);return R_SUCCEEDED(rc)&&index>=0&&index<18?indices[index]:-1;
#else
    return -1;
#endif
}
bool readRecords(std::vector<uint64_t>&ids,std::string&error){
#ifdef NMM_PLATFORM_TEST
    return testApi.records&&testApi.records(ids,error);
#elif defined(__SWITCH__)
    ids.clear();for(s32 offset=0;;){NsApplicationRecord records[32]{};s32 count=0;const auto rc=nsListApplicationRecord(records,32,offset,&count);if(R_FAILED(rc)||count<0||count>32||static_cast<size_t>(offset+count)>MaxRecords){error="No se pudo enumerar la biblioteca: "+rcText(rc);return false;}if(!count)break;for(s32 i=0;i<count;++i)ids.push_back(records[i].application_id);offset+=count;}return true;
#else
    (void)ids;error="Los servicios de biblioteca solo están disponibles en la consola.";return false;
#endif
}
bool readStatuses(uint64_t id,std::vector<Status>&statuses,std::string&error){
    statuses.clear();
#ifdef NMM_PLATFORM_TEST
    if(!testApi.statuses||!testApi.statuses(id,statuses,error))return false;
#elif defined(__SWITCH__)
    for(s32 offset=0;;){NsApplicationContentMetaStatus batch[32]{};s32 count=0;const auto rc=nsListApplicationContentMetaStatus(id,offset,batch,32,&count);if(R_FAILED(rc)||count<0||count>32||static_cast<size_t>(offset+count)>MaxRecords){error="No se pudieron leer los contenidos instalados: "+rcText(rc);return false;}if(!count)break;for(s32 i=0;i<count;++i)statuses.push_back({batch[i].application_id,batch[i].version,batch[i].storageID,batch[i].meta_type});offset+=count;}
#else
    (void)id;error="Los contenidos instalados solo se consultan en la consola.";return false;
#endif
    if(statuses.size()>MaxRecords){error="El inventario de contenidos supera el límite.";return false;}
    statuses.erase(std::remove_if(statuses.begin(),statuses.end(),[&](const Status&s){return (s.storage!=SdStorage&&s.storage!=UserStorage&&s.storage!=CardStorage)||!((s.type==ApplicationMeta&&s.id==id)||(s.type==PatchMeta&&s.id==(id^0x800ULL)));}),statuses.end());
    if(statuses.empty()){error="El título no tiene contenido instalado accesible.";return false;}
    std::stable_sort(statuses.begin(),statuses.end(),[](const Status&a,const Status&b){if(a.type!=b.type)return a.type==PatchMeta;if(a.version!=b.version)return a.version>b.version;return a.storage>b.storage;});return true;
}
bool readControl(uint64_t id,std::array<uint8_t,0x4000>&bytes){
    bytes.fill(0);
#ifdef NMM_PLATFORM_TEST
    return testApi.control&&testApi.control(id,bytes);
#elif defined(__SWITCH__)
    static_assert(sizeof(NacpStruct)==0x4000,"Review the control metadata wire layout before changing SDK");
    auto*control=new(std::nothrow) NsApplicationControlData{};if(!control)return false;u64 actual=0;const auto rc=nsGetApplicationControlData(NsApplicationControlSource_Storage,id,control,sizeof(*control),&actual);const bool ok=R_SUCCEEDED(rc)&&actual>=bytes.size()&&actual<=sizeof(*control);if(ok)std::memcpy(bytes.data(),&control->nacp,bytes.size());delete control;return ok;
#else
    (void)id;return false;
#endif
}
bool metadata(Game&game){
    std::array<uint8_t,0x4000> bytes{};game.version.clear();game.versionKnown=false;if(!readControl(game.id,bytes))return false;
    TitleMetadata m;std::string error;const bool parsed=parseTitleMetadata(bytes.data(),bytes.size(),m,error,titleLanguage());
    if(m.versionValid){game.version=m.version;game.versionKnown=true;}
    if(!parsed)return false;
    int chosen=-1;const auto usable=[&](int i){return i>=0&&static_cast<unsigned>(i)<m.languageCount&&m.languages[i].nameValid&&ui_text::canDisplayUtf8(m.languages[i].name);};
    if(usable(m.selectedLanguage))chosen=m.selectedLanguage;else for(int i:{0,1,6,5})if(usable(i)){chosen=i;break;}
    if(chosen<0)for(unsigned i=0;i<m.languageCount;++i)if(usable(static_cast<int>(i))){chosen=static_cast<int>(i);break;}
    if(chosen<0)return false;
    const auto&entry=m.languages[chosen];game.name=entry.name;
    if(entry.authorValid&&ui_text::canDisplayUtf8(entry.author))game.author=entry.author;
    return true;
}
void locations(Game&game,const std::vector<Status>&statuses){game.sd=game.nand=game.card=false;for(const auto&s:statuses){game.sd|=s.storage==SdStorage;game.nand|=s.storage==UserStorage;game.card|=s.storage==CardStorage;}game.contentVersion=statuses.front().version;}
bool validIdentity(const std::string&value){return value.size()==64&&value.find_first_not_of("0123456789abcdef")==value.npos&&value!=std::string(64,'0');}
bool contentIdentity(uint64_t id,const std::vector<Status>&initial,std::string&identity,std::string&error){
    identity.clear();std::string first;
    const auto capture=[&](const std::vector<Status>&statuses,std::string&out){
        std::vector<std::string>records;for(const auto&s:statuses){std::string record;
#ifdef NMM_PLATFORM_TEST
            if(!testApi.programRecord||!testApi.programRecord(s,record,error))return false;
#elif defined(__SWITCH__)
            if(!ncmReady){error="NCM/iniciar "+rcText(ncmResult);return false;}
            if(!platform_content_native::readProgramRecord(s,record,error))return false;
#else
            (void)s;error="La identidad del contenido requiere la consola.";return false;
#endif
            records.push_back(std::move(record));}
        std::sort(records.begin(),records.end());records.erase(std::unique(records.begin(),records.end()),records.end());
        out="NMMODS-NCM-PROGRAM-1\n"+titleId(id)+"\n";for(const auto&record:records)out+=std::to_string(record.size())+":"+record;return true;
    };
    if(!capture(initial,first))return false;
    std::vector<Status>after;if(!readStatuses(id,after,error))return false;std::string second;if(!capture(after,second))return false;
    if(first!=second){error="El contenido instalado cambió durante su comprobación. Vuelve a elegir el juego.";return false;}
    identity=mod_hash::shaText(first);return true;
}
uint32_t processId(uint64_t id,uint64_t&pid){
    pid=0;
#ifdef NMM_PLATFORM_TEST
    return testApi.process?testApi.process(id,pid):0xDEAD;
#elif defined(__SWITCH__)
    if(!pmReady)return 0xFFFFFFFFU;
    return pmdmntGetProcessId(&pid,id);
#else
    (void)id;return 0xFFFFFFFFU;
#endif
}
bool runningTitle(uint64_t&title,std::string&error){
    title=0;
#ifdef NMM_PLATFORM_TEST
    return testApi.running&&testApi.running(title,error);
#elif defined(__SWITCH__)
    if(!pmReady){error="PM no está disponible para comprobar el juego abierto.";return false;}u64 pid=0;auto rc=pmdmntGetApplicationProcessId(&pid);if(rc==PmProcessNotFound)return true;if(R_FAILED(rc)||!pid){error="No se pudo comprobar el proceso de la aplicación: "+rcText(rc);return false;}rc=pmdmntGetProgramId(&title,pid);if(R_FAILED(rc)||!title){error="No se pudo comprobar el identificador del proceso: "+rcText(rc);return false;}u64 after=0;if(R_FAILED(pmdmntGetApplicationProcessId(&after))||after!=pid){title=0;error="El proceso cambió durante su comprobación.";return false;}return true;
#else
    error="PM solo está disponible en la consola.";return false;
#endif
}
#ifdef __SWITCH__
bool nativeProgramPath(const Status&s,std::string&path,std::string&error){
    path.clear();if(!ncmReady){error="NCM/iniciar "+rcText(ncmResult);return false;}
    NcmContentMetaDatabase db{};NcmContentStorage cs{};auto rc=ncmOpenContentMetaDatabase(&db,static_cast<NcmStorageId>(s.storage));if(R_FAILED(rc)){error="NCM/abrir metadatos "+rcText(rc);return false;}
    NcmContentMetaKey key{};key.id=s.id;key.version=s.version;key.type=s.type;NcmContentId content{};rc=ncmContentMetaDatabaseGetContentIdByTypeAndIdOffset(&db,&content,&key,NcmContentType_Program,0);ncmContentMetaDatabaseClose(&db);if(R_FAILED(rc)){error="NCM/Program de la versión efectiva "+rcText(rc);return false;}
    rc=ncmOpenContentStorage(&cs,static_cast<NcmStorageId>(s.storage));if(R_FAILED(rc)){error="NCM/abrir almacenamiento "+rcText(rc);return false;}char value[FS_MAX_PATH]{};rc=ncmContentStorageGetPath(&cs,value,sizeof(value),&content);ncmContentStorageClose(&cs);if(R_FAILED(rc)){error="NCM/ruta Program "+rcText(rc);return false;}path=bounded(value,sizeof(value));if(path.empty()||path.size()>=sizeof(value)||std::any_of(path.begin(),path.end(),[](unsigned char c){return c<32||c==127;})){error="NCM devolvió una ruta Program no válida.";path.clear();return false;}return true;
}
#endif
bool readMain(uint64_t id,const Status&s,std::array<uint8_t,0x60>&bytes,std::string&error){
#ifdef NMM_PLATFORM_TEST
    return testApi.main&&testApi.main(id,s,bytes,error);
#elif defined(__SWITCH__)
    return platform_native::readInstalledHeader(id,s.id,static_cast<NcmStorageId>(s.storage),fsldrReady,hosversionBefore(20,0,0),fsldrDiagnostic,[&](std::string& path,std::string& why){return nativeProgramPath(s,path,why);},bytes,error);
#else
    (void)id;(void)s;(void)bytes;error="La lectura del NSO requiere la consola.";return false;
#endif
}
bool installedBuild(Game&game,const std::vector<Status>&statuses,std::string&error){
    const auto&effective=statuses.front();for(const auto&s:statuses){if(s.type!=effective.type||s.version!=effective.version)continue;std::array<uint8_t,0x60> bytes{};if(!readMain(game.id,s,bytes,error))continue;if(std::memcmp(bytes.data(),"NSO0",4)){error="main no tiene una cabecera NSO válida.";continue;}const auto full=fullBuild(bytes.data()+0x40);if(!validFull(full)){error="El Build ID completo del ejecutable no es válido.";continue;}game.fullBuildId=full;game.buildId=full.substr(0,16);game.buildVerified=true;game.detail="Build ID completo leído del ejecutable efectivo instalado.";error.clear();return true;}if(error.empty())error="No se pudo comprobar el Build ID efectivo. No se usará el ejecutable base de una versión anterior.";return false;
}
bool liveProcess(uint64_t title,uint64_t&pid,std::string&error){
    pid=0;
#ifdef NMM_PLATFORM_TEST
    return testApi.liveProcess&&testApi.liveProcess(title,pid,error)&&pid;
#elif defined(__SWITCH__)
    if(!pmReady){error="PM no está disponible para comprobar el proceso exacto.";return false;}
    u64 value=0,actual=0,after=0;auto rc=pmdmntGetApplicationProcessId(&value);
    if(R_FAILED(rc)||!value||value==selfPid){error="No hay un proceso de juego abierto verificable (PM "+rcText(rc)+").";return false;}
    rc=pmdmntGetProgramId(&actual,value);if(R_FAILED(rc)||actual!=title){error="El proceso abierto no corresponde al juego seleccionado.";return false;}
    rc=pmdmntGetApplicationProcessId(&after);if(R_FAILED(rc)||after!=value){error="El proceso cambió durante su comprobación.";return false;}pid=value;return true;
#else
    (void)title;error="La comprobación del proceso requiere la consola.";return false;
#endif
}
bool loaderBuild(uint64_t title,std::string&build,uint64_t&verifiedPid,std::string&error){
    build.clear();verifiedPid=0;uint64_t pid=0;if(!liveProcess(title,pid,error))return false;
#ifdef NMM_PLATFORM_TEST
    if(!testApi.loader||!testApi.loader(title,build,error)||!validFull(build))return false;
#elif defined(__SWITCH__)
    if(!ldrReady||!pmReady)return false;
    LoaderModuleInfo modules[2]{};s32 count=0;const auto rc=ldrDmntGetProcessModuleInfo(pid,modules,2,&count);if(R_FAILED(rc)||count!=2){error="No se pudo comprobar el módulo principal del juego abierto.";return false;}build=fullBuild(modules[1].build_id);if(!validFull(build))return false;
#else
    (void)title;(void)error;return false;
#endif
    uint64_t after=0;if(!liveProcess(title,after,error)||after!=pid){build.clear();error="El proceso cambió al leer su Build ID completo.";return false;}verifiedPid=pid;return true;
}
bool closed(uint64_t id,std::string&error){
    // A title can run a different program index (base Title ID + 1, etc.). The
    // application query must also rule out that family before an exact lookup.
    uint64_t active=0;if(!runningTitle(active,error)){error="No se pudo comprobar la aplicación en ejecución. "+error;return false;}
    if(active&&(active&~0xFFFULL)==id){error="Cierra este juego antes de instalar o retirar sus mods.";return false;}
    uint64_t pid=0;const auto rc=processId(id,pid);if(rc==PmProcessNotFound)return true;if(rc==0&&pid){error="Cierra este juego antes de instalar o retirar sus mods.";return false;}error="No se pudo demostrar que este juego está cerrado (PM "+rcText(rc)+"). No se modificarán sus archivos.";return false;
}
bool installedMetadata(Game&game,std::vector<Status>&statuses,std::string&error){
    if(!readStatuses(game.id,statuses,error))return false;
    locations(game,statuses);metadata(game);
    if(!contentIdentity(game.id,statuses,game.contentIdentity,error))return false;
    Game second;second.id=game.id;metadata(second);
    if(second.versionKnown!=game.versionKnown||(game.versionKnown&&second.version!=game.version)){game.contentIdentity.clear();error="La versión declarada cambió durante la comprobación. Vuelve a elegir el juego.";return false;}return true;
}
bool sameInstalledMetadata(const Game&a,const Game&b){return a.id==b.id&&a.contentVersion==b.contentVersion&&a.versionKnown==b.versionKnown&&(!a.versionKnown||a.version==b.version)&&a.contentIdentity==b.contentIdentity;}
}
bool platformInit(Environment&env,std::string&error){
    error.clear();env={};
#ifdef NMM_PLATFORM_TEST
    nsReady=true;fsldrReady=ncmReady=pmReady=ldrReady=true;env.applet=testApi.applet;applicationMode=!env.applet;env.firmware="Prueba sin consola";env.atmosphere="Prueba sin consola";return true;
#elif defined(__SWITCH__)
    static_assert(NcmStorageId_BuiltInUser==UserStorage&&NcmStorageId_SdCard==SdStorage&&NcmStorageId_GameCard==CardStorage,"Review storage policy for changed SDK");
    static_assert(NcmContentMetaType_Application==ApplicationMeta&&NcmContentMetaType_Patch==PatchMeta,"Review content selection policy for changed SDK");
    static_assert(sizeof(NcmContentMetaKey)==16&&sizeof(NcmContentInfo)==24&&NcmContentInstallType_Full==0&&NcmContentType_Program==1,"Review exact NCM wire inventory for changed SDK");
    env.applet=appletGetAppletType()!=AppletType_Application;applicationMode=!env.applet;svcGetProcessId(&selfPid,CUR_PROCESS_HANDLE);SetSysFirmwareVersion firmware{};auto rc=setsysInitialize();if(R_SUCCEEDED(rc)){rc=setsysGetFirmwareVersion(&firmware);setsysExit();}env.firmware=R_SUCCEEDED(rc)?bounded(firmware.display_version,sizeof(firmware.display_version)):"No disponible";
    env.atmosphere=hosversionIsAtmosphere()?"Atmosphère detectado":"Sin Atmosphère";rc=splInitialize();if(R_SUCCEEDED(rc)){u64 value=0;if(R_SUCCEEDED(splGetConfig(static_cast<SplConfigItem>(65000),&value))){char text[64];std::snprintf(text,sizeof(text),"Atmosphere %u.%u.%u",unsigned((value>>56)&255),unsigned((value>>48)&255),unsigned((value>>40)&255));env.atmosphere=text;}splExit();}
    nsReady=R_SUCCEEDED(rc=nsInitialize());if(!nsReady)error="No se pudo abrir NS para leer los juegos: "+rcText(rc);
    fsldrReady=R_SUCCEEDED(fsldrResult=fsldrInitialize());fsldrDiagnostic="fsp-ldr/iniciar "+rcText(fsldrResult);
    if(!fsldrReady){const auto probe=platform_native::probeLoader();fsldrDiagnostic+="; "+std::string(platform_native::stageName(probe.stage))+" "+rcText(probe.result);if(probe.stage==platform_native::LoaderStage::Ready){fsldrReady=R_SUCCEEDED(fsldrResult=fsldrInitialize());if(!fsldrReady)fsldrDiagnostic+="; reintento "+rcText(fsldrResult);}}
    ncmReady=R_SUCCEEDED(ncmResult=ncmInitialize());pmReady=R_SUCCEEDED(pmdmntInitialize());ldrReady=R_SUCCEEDED(ldrDmntInitialize());
    std::string why;runningTitle(env.runningTitle,why);env.detail=env.applet?"Modo Álbum: consulta disponible. Abre en modo aplicación para instalar mods.":"Instalación de mods con el juego cerrado.";if(!fsldrReady)env.detail+=" Se intentará comprobar el ejecutable por otra vía de lectura.";if(!why.empty())env.detail+=" "+why;return nsReady||(pmReady&&ldrReady);
#else
    error="La plataforma Switch no está disponible en este ejecutable.";return false;
#endif
}
void platformExit(){
#ifdef __SWITCH__
    if(ldrReady)ldrDmntExit();
    if(pmReady)pmdmntExit();
    if(ncmReady)ncmExit();
    if(fsldrReady)fsldrExit();
    if(nsReady)nsExit();
#endif
    nsReady=fsldrReady=ncmReady=pmReady=ldrReady=applicationMode=false;selfPid=0;
}
bool scanGames(std::vector<Game>&games,Environment&env,std::string&error){
    games.clear();error.clear();if(!nsReady){error="El servicio de juegos no está disponible.";return false;}std::vector<uint64_t> ids;if(!readRecords(ids,error)||ids.size()>MaxRecords){if(error.empty())error="La biblioteca supera el límite.";return false;}std::string runningError;runningTitle(env.runningTitle,runningError);std::set<uint64_t> seen;unsigned skipped=0,names=0;
    for(const auto id:ids){if(id<MinUser||(id&0xFFFULL)||!seen.insert(id).second)continue;Game game;game.id=id;game.name="Juego "+titleId(id);std::vector<Status> statuses;std::string why;if(!readStatuses(id,statuses,why)){++skipped;continue;}locations(game,statuses);if(!metadata(game))++names;game.running=env.runningTitle&&(env.runningTitle&~0xFFFULL)==id;games.push_back(std::move(game));}
    std::sort(games.begin(),games.end(),[](const Game&a,const Game&b){if(a.running!=b.running)return a.running;return a.name==b.name?a.id<b.id:a.name<b.name;});
    if(skipped)error=std::to_string(skipped)+" títulos sin contenido accesible omitidos.";
    if(names){if(!error.empty())error+=" ";error+=std::to_string(names)+" nombres no disponibles; se muestra el Title ID.";}if(!runningError.empty()){if(!error.empty())error+=" ";error+=runningError;}return true;
}
bool resolveBuild(Game&game,Environment&env,std::string&error){
    error.clear();game.buildVerified=game.running=false;game.processId=0;game.contentIdentity.clear();game.buildId.clear();game.fullBuildId.clear();game.detail.clear();game.version.clear();game.versionKnown=false;
    if(!nsReady||game.id<MinUser||(game.id&0xFFFULL)){error="El título seleccionado no es una aplicación de usuario.";return false;}
    std::vector<Status>statuses;if(!installedMetadata(game,statuses,error)){game.detail=error;return false;}
    std::string runningError;if(!runningTitle(env.runningTitle,runningError)){game.detail=error=runningError;return false;}game.running=env.runningTitle==game.id;
    if(game.running){std::string build;if(loaderBuild(game.id,build,game.processId,error)){game.fullBuildId=build;game.buildId=build.substr(0,16);game.buildVerified=true;game.detail="Build ID completo del proceso abierto. Los parches IPS se preparan para el próximo arranque, sin modificar este proceso.";return true;}if(!liveProcess(game.id,game.processId,error)){game.detail=error;return false;}error.clear();game.detail="Juego identificado; Build ID no disponible. El parche conserva el Build ID del autor.";return true;}
    if(installedBuild(game,statuses,error))return true;
    game.detail="Contenido instalado identificado. Los mods se instalan por elección del usuario; su compatibilidad no está garantizada.";
    error.clear();return true;
}
bool resolveRunningGame(Game&game,Environment&env,std::string&error){
    game={};error.clear();uint64_t active=0;if(!runningTitle(active,error)){env.runningTitle=0;return false;}env.runningTitle=active;
    if(active<MinUser||(active&0xFFFULL)){error="No hay un juego principal compatible abierto para comprobar su identidad.";return false;}
    game.id=active;game.running=true;game.name="Juego "+titleId(active);
    if(nsReady){std::vector<Status>statuses;if(!installedMetadata(game,statuses,error)){game.detail=error;return false;}}
    std::string build;const bool haveBuild=loaderBuild(active,build,game.processId,error);if(!haveBuild){build.clear();if(!liveProcess(active,game.processId,error)){game.detail=error;return false;}error.clear();}
    uint64_t after=0;std::string why;if(!runningTitle(after,why)||after!=active){error="El juego cambió durante la comprobación. Vuelve a abrir el panel.";game.processId=0;game.buildVerified=false;game.detail=error;return false;}
    game.fullBuildId=build;game.buildId=build.substr(0,16);game.buildVerified=haveBuild;game.detail="Juego identificado. Los parches conservan el Build ID del autor y se escriben en la SD para el próximo arranque.";return true;
}
bool validateRunningGame(const Game&expected,std::string&error){
    error.clear();if(!nsReady||!expected.running||!expected.processId||(expected.buildVerified&&(!validFull(expected.fullBuildId)||expected.buildId!=expected.fullBuildId.substr(0,16)))||(!expected.buildVerified&&(!expected.fullBuildId.empty()||!expected.buildId.empty()))||!validIdentity(expected.contentIdentity)||expected.id<MinUser||(expected.id&0xFFFULL)){error="No se ha comprobado la identidad del proceso exacto y del contenido instalado. Abre el juego y vuelve a seleccionarlo.";return false;}
    uint64_t before=0;if(!liveProcess(expected.id,before,error)||before!=expected.processId){error="El proceso del juego cambió desde la selección. Vuelve a abrir su lista de mods.";return false;}
    Game current;current.id=expected.id;std::vector<Status>statuses;if(!installedMetadata(current,statuses,error))return false;
    if(!sameInstalledMetadata(expected,current)){error="La versión o el contenido instalado cambió desde la selección.";return false;}
    if(expected.buildVerified){std::string build;uint64_t pid=0;if(!loaderBuild(expected.id,build,pid,error))return false;
    if(pid!=expected.processId||build!=expected.fullBuildId){error="El proceso o su Build ID completo cambió desde la selección.";return false;}}
    Game finalMetadata;finalMetadata.id=expected.id;if(!installedMetadata(finalMetadata,statuses,error))return false;
    if(!sameInstalledMetadata(expected,finalMetadata)){error="La versión o el contenido instalado cambió al comprobar el Build ID.";return false;}
    uint64_t after=0;if(!liveProcess(expected.id,after,error)||after!=expected.processId){error="El proceso cambió durante la comprobación final.";return false;}return true;
}
bool validateClosedResources(const Game&expected,std::string&error){
    error.clear();if(!applicationMode){error="Abre NinMagic Mods en modo aplicación antes de instalar o retirar recursos.";return false;}
    if(!nsReady||!validIdentity(expected.contentIdentity)||expected.id<MinUser||(expected.id&0xFFFULL)){error="No se pudo identificar el contenido instalado del juego.";return false;}
    if(!closed(expected.id,error))return false;
    Game current;current.id=expected.id;std::vector<Status>statuses;if(!installedMetadata(current,statuses,error))return false;
    if(!sameInstalledMetadata(expected,current)){error="La versión o el contenido instalado cambió desde la selección.";return false;}return closed(expected.id,error);
}
bool validateClosedGame(const Game&expected,std::string&error){
    if(!applicationMode){error="Abre NinMagic Mods en modo aplicación (mantén R al abrir hbmenu) antes de instalar o retirar mods.";return false;}
    error.clear();if(!nsReady||!expected.buildVerified||!validFull(expected.fullBuildId)||expected.buildId!=expected.fullBuildId.substr(0,16)||expected.id<MinUser||(expected.id&0xFFFULL)){error="La identidad del juego no está completamente comprobada.";return false;}
    if(!closed(expected.id,error))return false;
    Game current;current.id=expected.id;current.name=expected.name;std::vector<Status> statuses;if(!readStatuses(current.id,statuses,error))return false;locations(current,statuses);metadata(current);if(!installedBuild(current,statuses,error))return false;
    if(current.fullBuildId!=expected.fullBuildId||current.contentVersion!=expected.contentVersion||current.versionKnown!=expected.versionKnown||(expected.versionKnown&&current.version!=expected.version)){error="La versión o el Build ID instalado cambió desde la selección. Vuelve a elegir el juego.";return false;}return closed(expected.id,error);
}
}
