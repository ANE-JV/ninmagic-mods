#ifndef _POSIX_C_SOURCE

#define _POSIX_C_SOURCE 200809L

#endif

#include "mod_queue.hpp"

#include "mod_hash.hpp"

#include "mod_identity.hpp"

#include "mod_policy.hpp"

#include "ui_text.hpp"

#include <algorithm>

#include <cerrno>

#include <cctype>

#include <cstdio>

#include <cstdlib>

#include <cstring>

#include <fcntl.h>

#include <set>

#include <sys/stat.h>

#include <unistd.h>

#ifdef __SWITCH__

#include <switch.h>

#endif

namespace nmm { namespace queue {

constexpr size_t MaxBytes=256*1024,MaxItems=128,MaxIds=32;

std::string root(){

#ifdef NMM_QUEUE_TEST

 const char*p=std::getenv("NMM_QUEUE_ROOT");return p?p:"queue-test";

#else

 return "sdmc:/config/NinMagicMods";

#endif

}

std::string upper(std::string s){for(auto&c:s)c=char(std::toupper(static_cast<unsigned char>(c)));return s;}

bool hex(const std::string&s,size_t n){return s.size()==n&&std::all_of(s.begin(),s.end(),[](unsigned char c){return std::isxdigit(c)!=0;});}

bool text(const std::string&s,size_t n,bool empty=true){return (empty||!s.empty())&&s.size()<=n&&ui_text::validUtf8(s)&&std::none_of(s.begin(),s.end(),[](unsigned char c){return c<32||c==127;});}

bool identity(const Game&g,std::string&e){if(g.id<0x0100000000010000ULL||(g.id&0xFFFULL)||!text(g.version,96)|| (g.versionKnown&&g.version.empty())||!hex(g.contentIdentity,64)||g.contentIdentity==std::string(64,'0')||(!g.fullBuildId.empty()&&(!g.buildVerified||!hex(g.fullBuildId,64)||!hex(g.buildId,16)||upper(g.fullBuildId).substr(0,16)!=upper(g.buildId)))){e="Falta comprobar el Title ID y los contenidos actuales del juego.";return false;}return true;}

bool safeDir(const std::string&p,bool create,std::string&e){

 if(p.empty()||p.find('\\')!=std::string::npos){e="Ruta privada no válida.";return false;}

 size_t start=p[0]=='/'?1:0;for(size_t n=start;n<=p.size();++n){if(n<p.size()&&p[n]!='/')continue;auto component=p.substr(start,n-start);if(component=="."||component==".."||component.empty()){e="Ruta privada no válida.";return false;}start=n+1;

  auto prefix=p.substr(0,n);if(prefix.empty()||prefix.back()==':')continue;struct stat st{};

  if(lstat(prefix.c_str(),&st)){if(errno!=ENOENT||!create||mkdir(prefix.c_str(),0700)){e="No se pudo abrir la carpeta privada de selecciones.";return false;}if(lstat(prefix.c_str(),&st)){e="No se pudo verificar la carpeta privada.";return false;}}

  if(!S_ISDIR(st.st_mode)||S_ISLNK(st.st_mode)){e="La carpeta privada contiene un enlace o un archivo ajeno.";return false;}

 }return true;

}

bool regular(const std::string&p,bool&exists,std::string&e){struct stat s{};exists=false;if(lstat(p.c_str(),&s)){if(errno==ENOENT)return true;e="No se pudo comprobar el archivo privado.";return false;}exists=true;if(!S_ISREG(s.st_mode)||S_ISLNK(s.st_mode)||s.st_size<0||uint64_t(s.st_size)>MaxBytes){e="Archivo privado no válido, demasiado grande o enlazado.";return false;}return true;}

bool commit(){

#ifdef __SWITCH__

 return R_SUCCEEDED(fsdevCommitDevice("sdmc"));

#else

 return true;

#endif

}

std::string folder(const Game&g){return root()+"/overlay/"+titleId(g.id);}

void integer(std::string&s,uint64_t n,unsigned bytes=4){for(unsigned i=0;i<bytes;++i)s+=char(n>>(i*8));}

void field(std::string&s,const std::string&v){integer(s,v.size());s+=v;}

struct Reader{const std::string&s;size_t p=0;bool ok=true;uint64_t number(unsigned n=4){if(n>s.size()-p){ok=false;return 0;}uint64_t v=0;for(unsigned i=0;i<n;++i)v|=uint64_t(static_cast<unsigned char>(s[p++]))<<(i*8);return v;}std::string string(size_t max){auto n=number();if(!ok||n>max||n>s.size()-p){ok=false;return{};}auto out=s.substr(p,size_t(n));p+=size_t(n);return out;}};

void game(std::string&s,const Game&g){integer(s,g.id,8);integer(s,g.contentVersion);integer(s,g.versionKnown?1:0);field(s,g.version);field(s,upper(g.fullBuildId));field(s,g.contentIdentity);}

bool sameGame(Reader&r,const Game&g){const auto id=r.number(8),content=r.number(),known=r.number();const auto ver=r.string(96),bid=r.string(64),token=r.string(64);return r.ok&&id==g.id&&content==g.contentVersion&&known==uint64_t(g.versionKnown)&&ver==g.version&&token==g.contentIdentity&&(bid.empty()||g.fullBuildId.empty()||bid==upper(g.fullBuildId));}

bool validId(const std::string&s){return text(s,1536,false);}

bool consoleId(const std::string&s){const auto end=s.find('|');if(end==s.npos)return false;if(consoleRepositoryBranch(s.substr(0,end)))return true;

 // Stored IDs only identify entries to re-query; they never authorize a payload.

 auto number=[](const std::string&v){return !v.empty()&&v.size()<=10&&v[0]!='0'&&std::all_of(v.begin(),v.end(),[](unsigned char c){return c>='0'&&c<='9';});};

 const auto rest=s.substr(end+1);const auto split=rest.find('|');return s.substr(0,end)=="GameBanana"&&(split==rest.npos?number(rest):number(rest.substr(0,split))&&number(rest.substr(split+1)));}

bool canSelect(const Game&g,const ModEntry&m){return allowsConsoleMod(m)&&canonicalModApplicationId(m.titleId)==g.id&&validId(m.id)&&(m.format==ModFormat::Pchtxt||m.format==ModFormat::Ips||m.format==ModFormat::Romfs);}

bool read(const Game&g,const char*name,const char*magic,std::string&data,std::string&e){data.clear();if(!identity(g,e))return false;const auto dir=folder(g);if(!safeDir(dir,false,e))return false;const auto path=dir+"/"+name;bool exists=false;if(!regular(path,exists,e))return false;if(!exists){e="No hay una selección o lista guardada para este juego.";return false;}FILE*f=std::fopen(path.c_str(),"rb");if(!f){e="No se pudo leer el archivo privado.";return false;}char buffer[4096];size_t n=0;while((n=std::fread(buffer,1,sizeof buffer,f))){if(data.size()+n>MaxBytes){std::fclose(f);e="Archivo privado demasiado grande.";return false;}data.append(buffer,n);}bool ok=!std::ferror(f);if(std::fclose(f))ok=false;if(ok&&std::strcmp(name,"menu.bin")==0&&data.size()>=8&&data.compare(0,8,"NMMMENU2")==0){data.clear();e="Pulsa X para actualizar la lista de mods desde las fuentes.";return false;}if(!ok||data.size()<72||data.substr(0,8)!=magic){e="El archivo privado está incompleto o no es compatible.";return false;}const auto sum=data.substr(data.size()-64);data.resize(data.size()-64);if(mod_hash::shaText(data)!=sum){e="La selección guardada no supera su comprobación de integridad.";data.clear();return false;}return true;}

bool write(const Game&g,const char*name,std::string data,std::string&e){if(!identity(g,e))return false;data+=mod_hash::shaText(data);if(data.size()>MaxBytes){e="La lista supera el límite de memoria del overlay.";return false;}auto dir=folder(g);if(!safeDir(dir,true,e))return false;const auto path=dir+"/"+name,tmp=path+".tmp",old=path+".previous";bool exists=false,unused=false;if(!regular(path,exists,e)||!regular(tmp,unused,e)||!regular(old,unused,e))return false;

 // Never overwrite an interrupted promotion's previous file. It remains available

 // for inspection; loading never guesses which snapshot should authorize a queue.

 struct stat st{};if(!lstat(tmp.c_str(),&st)||!lstat(old.c_str(),&st)){e="Quedó una escritura privada pendiente; conserva esos archivos y vuelve a revisar desde la aplicación.";return false;}

 int fd=open(tmp.c_str(),O_WRONLY|O_CREAT|O_EXCL,0600);if(fd<0){e="No se pudo preparar la selección.";return false;}size_t at=0;bool ok=true;while(at<data.size()){auto n=::write(fd,data.data()+at,data.size()-at);if(n<=0){ok=false;break;}at+=size_t(n);}if(fsync(fd))ok=false;if(close(fd))ok=false;if(!ok||!commit()){unlink(tmp.c_str());e="No se pudo guardar la selección completa.";return false;}

 if(exists&&rename(path.c_str(),old.c_str())){unlink(tmp.c_str());e="No se pudo conservar la selección anterior.";return false;}

 if(rename(tmp.c_str(),path.c_str())){if(exists)rename(old.c_str(),path.c_str());e="No se pudo publicar la selección; se conservó la copia anterior.";return false;}

 if(!commit()){e="No se confirmó la escritura en la microSD; revisa la selección desde la aplicación.";return false;}if(exists&&unlink(old.c_str())){e="Se guardó la selección, pero su copia anterior necesita revisión.";return false;}if(!commit()){e="No se pudo confirmar el cierre de la escritura.";return false;}return true;

}

void putEntry(std::string&s,const ModEntry&m){integer(s,m.titleId,8);integer(s,m.size,8);integer(s,unsigned(m.format));integer(s,m.compatible?1:0);integer(s,m.consoleOnly?1:0);integer(s,m.gbGameId,8);integer(s,m.gbModId,8);integer(s,m.gbFileId,8);for(const auto*p:{&m.id,&m.name,&m.category,&m.source,&m.sourceUrl,&m.reason,&m.version,&m.buildId,&m.detail,&m.repository,&m.path,&m.revision,&m.blobSha,&m.author,&m.downloadUrl,&m.fileName,&m.modVersion,&m.branch})field(s,*p);}

bool getEntry(Reader&r,ModEntry&m){m={};m.titleId=r.number(8);m.size=r.number(8);auto f=r.number(),c=r.number(),hw=r.number();m.gbGameId=r.number(8);m.gbModId=r.number(8);m.gbFileId=r.number(8);if(f>unsigned(ModFormat::Unsupported)||c>1||hw>1){r.ok=false;return false;}m.format=ModFormat(f);m.compatible=c;m.consoleOnly=hw;for(auto*p:{&m.id,&m.name,&m.category,&m.source,&m.sourceUrl,&m.reason,&m.version,&m.buildId,&m.detail,&m.repository,&m.path,&m.revision,&m.blobSha,&m.author,&m.downloadUrl,&m.fileName,&m.modVersion,&m.branch}){*p=r.string(2048);if(!text(*p,2048))r.ok=false;}return r.ok&&validId(m.id);}

} // namespace queue

bool saveModSelection(const Game&g,const std::vector<ModEntry>&mods,std::string&e){e.clear();if(!queue::identity(g,e))return false;if(mods.empty()||mods.size()>queue::MaxIds){e="Elige entre 1 y 32 mods.";return false;}std::set<std::string>ids;std::string s="NMMSEL02";queue::game(s,g);queue::integer(s,mods.size());for(const auto&m:mods){if(!queue::canSelect(g,m)||!ids.insert(m.id).second){e="La selección contiene un formato no admitido, una repetición o un mod de otro juego.";return false;}queue::field(s,m.id);}return queue::write(g,"selection.bin",s,e);}

bool loadSelectionFile(const Game&g,std::vector<std::string>&ids,std::string&e,const char*name,const char*magic){e.clear();ids.clear();std::vector<std::string>checked;std::string s;if(!queue::read(g,name,magic,s,e))return false;queue::Reader r{s,8};if(!queue::sameGame(r,g)){e="La selección pertenece a otra versión o Build ID; vuelve a elegir los mods.";return false;}auto n=r.number();std::set<std::string>unique;if(!n||n>queue::MaxIds){e="Cantidad de mods guardados no válida.";return false;}for(size_t i=0;i<n;++i){auto id=r.string(1536);if(!r.ok||!queue::validId(id)||!unique.insert(id).second){e="Identificadores guardados no válidos.";return false;}if(queue::consoleId(id))checked.push_back(std::move(id));}if(!r.ok||r.p!=s.size()){e="Selección incompleta o con datos adicionales.";return false;}if(checked.empty()){e="La cola anterior no contiene fuentes reconocidas; vuelve a elegir desde la lista actual.";return false;}ids=std::move(checked);return true;}

bool clearSelectionFile(const Game&g,std::string&e,const char*name){e.clear();if(!queue::identity(g,e))return false;auto dir=queue::folder(g);struct stat st{};if(lstat(dir.c_str(),&st)&&errno==ENOENT)return true;if(!queue::safeDir(dir,false,e))return false;auto path=dir+"/"+name;bool exists=false;if(!queue::regular(path,exists,e))return false;if(exists&&unlink(path.c_str())){e="No se pudo retirar la selección guardada.";return false;}if(!queue::commit()){e="No se pudo confirmar la retirada de la selección.";return false;}return true;}

bool loadModSelection(const Game&g,std::vector<std::string>&ids,std::string&e){return loadSelectionFile(g,ids,e,"selection.bin","NMMSEL02");}

bool clearModSelection(const Game&g,std::string&e){return clearSelectionFile(g,e,"selection.bin");}

bool clearAppModSelection(const Game&g,std::string&e){return clearSelectionFile(g,e,"selection-app.bin");}

bool saveAppModSelection(const Game&g,const std::vector<std::string>&ids,std::string&e){

 e.clear();if(ids.empty())return clearAppModSelection(g,e);if(!queue::identity(g,e))return false;

 if(ids.size()>queue::MaxIds){e="La selección pendiente admite hasta 32 mods.";return false;}

 std::string s="NMMAPP01";queue::game(s,g);queue::integer(s,ids.size());std::set<std::string>unique;

 for(const auto&id:ids){if(!queue::validId(id)||!queue::consoleId(id)||!unique.insert(id).second){e="Identificador pendiente no válido o repetido.";return false;}queue::field(s,id);}

 return queue::write(g,"selection-app.bin",s,e);

}

bool loadAppModSelection(const Game&g,std::vector<std::string>&ids,std::string&e){

 e.clear();ids.clear();if(!queue::identity(g,e))return false;

 // A first launch has no intent file. Other filesystem/integrity errors remain visible.

 struct stat st{};const auto path=queue::folder(g)+"/selection-app.bin";

 if(lstat(path.c_str(),&st)&&errno==ENOENT)return true;

 return loadSelectionFile(g,ids,e,"selection-app.bin","NMMAPP01");

}

bool saveModMenuCache(const Game&g,const std::vector<ModEntry>&mods,std::string&e){e.clear();if(!queue::identity(g,e))return false;if(mods.size()>queue::MaxItems){e="La lista compacta admite hasta 128 mods. Usa la aplicación para listas mayores.";return false;}std::string s="NMMMENU3";queue::game(s,g);queue::integer(s,std::count_if(mods.begin(),mods.end(),isBrowsableMod));std::set<std::string>ids;for(const auto&entry:mods){if(!isBrowsableMod(entry))continue;auto m=entry;if(canonicalModApplicationId(m.titleId)!=g.id||!queue::validId(m.id)||!ids.insert(m.id).second){e="Lista compacta con otro juego o identificadores repetidos.";return false;}m.titleId=g.id;m.selected=false;m.installed=false;m.installedName.clear();m.files.clear();m.compatible=false;for(const auto*p:{&m.name,&m.category,&m.source,&m.sourceUrl,&m.reason,&m.version,&m.buildId,&m.detail,&m.repository,&m.path,&m.revision,&m.blobSha,&m.author,&m.downloadUrl,&m.fileName,&m.modVersion,&m.branch})if(!queue::text(*p,2048)){e="Un texto del catálogo supera los límites del overlay.";return false;}queue::putEntry(s,m);if(s.size()>queue::MaxBytes-64){e="La lista supera los 256 KiB del overlay; conserva una selección más pequeña.";return false;}}return queue::write(g,"menu.bin",s,e);}

bool loadModMenuCache(const Game&g,std::vector<ModEntry>&mods,std::string&e){e.clear();mods.clear();std::string s;if(!queue::read(g,"menu.bin","NMMMENU3",s,e))return false;queue::Reader r{s,8};if(!queue::sameGame(r,g)){e="La lista guardada pertenece a otra versión o Build ID.";return false;}auto n=r.number();if(n>queue::MaxItems){e="Lista compacta demasiado grande.";return false;}std::set<std::string>ids;for(size_t i=0;i<n;++i){ModEntry m;if(!queue::getEntry(r,m)||canonicalModApplicationId(m.titleId)!=g.id||!ids.insert(m.id).second){mods.clear();e="Lista compacta no válida.";return false;}if(!isBrowsableMod(m))continue;m.titleId=g.id;m.compatible=false;mods.push_back(std::move(m));}if(!r.ok||r.p!=s.size()){mods.clear();e="Lista compacta incompleta o con datos adicionales.";return false;}return true;}

} // namespace nmm

