#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "update_network.hpp"
#include "gamebanana.hpp"
#include <algorithm>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#ifdef __SWITCH__
#include <switch.h>
#include <curl/curl.h>
#endif

namespace nmm {
namespace {
constexpr uint64_t MaxNro=16ULL*1024*1024;
constexpr const char *Root="sdmc:/config/NinMagicMods/app-update";
bool safeUrl(const std::string &url){
    if(url.size()<9||url.size()>2048||url.rfind("https://",0)!=0)return false;
    const auto end=url.find('/',8);const auto host=url.substr(8,end==std::string::npos?end:end-8);
    return !host.empty()&&host.find('@')==std::string::npos&&url.find('#')==std::string::npos&&std::none_of(url.begin(),url.end(),[](unsigned char c){return c<=32||c==127||c=='\\';});
}
bool digits(const std::string &s,size_t limit=9){return !s.empty()&&s.size()<=limit&&s.front()!='0'&&s.find_first_not_of("0123456789")==s.npos;}
bool gameBananaBatchUrl(const std::string&url,unsigned&page){
    page=0;const std::string prefix="https://gamebanana.com/apiv6/Mod/ByGame?_aGameRowIds%5B%5D=";
    if(url.rfind(prefix,0)!=0)return false;
    const auto end=url.find("&_nPerpage=",prefix.size());
    if(end==url.npos||!digits(url.substr(prefix.size(),end-prefix.size())))return false;
#ifdef NMM_OVERLAY
    const std::string options="&_nPerpage=5&_nPage=";
#else
    const std::string options="&_nPerpage=15&_nPage=";
#endif
    if(url.compare(end,options.size(),options)!=0)return false;
    const auto at=end+options.size();if(at>=url.size()||url[at]<'1'||url[at]>'9'||url.substr(at+1)!="&_csvProperties="+std::string(GameBananaBatchProperties))return false;
    page=unsigned(url[at]-'0');return true;
}
bool gameBananaDownloadUrl(const std::string &url,bool initial){
    if(!safeUrl(url))return false;
    const std::string dl="https://gamebanana.com/dl/";
    if(url.rfind(dl,0)==0)return digits(url.substr(dl.size()));
    if(initial)return false;
    const auto slash=url.find('/',8);if(slash==url.npos)return false;const auto host=url.substr(8,slash-8);
    bool known=host=="files.gamebanana.com";
    const std::string tail=".gamebanana.com";
    if(host.rfind("filecache",0)==0&&host.size()>9+tail.size()&&host.compare(host.size()-tail.size(),tail.size(),tail)==0)known=digits(host.substr(9,host.size()-9-tail.size()),3);
    if(!known||url.compare(slash,6,"/mods/")!=0)return false;
    const auto file=url.substr(slash+6);return !file.empty()&&file.size()<=256&&file.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-%")==file.npos&&file.find("..") == file.npos&&file.find('%')==file.npos;
}
uint64_t bodyLimit(const std::string &path){
    if(path==std::string(Root)+"/manifest.pending")return 4096;
    if(path==std::string(Root)+"/download.pending")return MaxNro;
    return 0;
}
#if defined(__SWITCH__) || defined(NM_UPDATE_NETWORK_TEST)
struct Download{FILE *file=nullptr;uint64_t written=0,limit=0;bool overflow=false;};
size_t receive(void *ptr,size_t size,size_t count,void *user){
    auto &d=*static_cast<Download*>(user);
    if(size&&count>SIZE_MAX/size)return 0;
    const size_t bytes=size*count;
    if(d.written>d.limit||bytes>d.limit-d.written){d.overflow=true;return 0;}
    const size_t written=fwrite(ptr,1,bytes,d.file);d.written+=written;return written;
}
#endif
#ifdef __SWITCH__
bool socketsReady=false,nifmReady=false,curlReady=false;
std::string networkHint;
bool networkInit(std::string &error){
    if(!socketsReady){const Result rc=socketInitializeDefault();if(R_FAILED(rc)){char detail[32];std::snprintf(detail,sizeof(detail),"0x%08lX",static_cast<unsigned long>(rc));error="No se puede abrir BSD para HTTPS ("+std::string(detail)+").";return false;}socketsReady=true;}
    Result rc=0;if(!nifmReady){rc=nifmInitialize(NifmServiceType_User);nifmReady=R_SUCCEEDED(rc);}
    NifmInternetConnectionType type{};u32 strength=0;NifmInternetConnectionStatus status{};
    if(nifmReady)rc=nifmGetInternetConnectionStatus(&type,&strength,&status);
    char hint[96];std::snprintf(hint,sizeof(hint),"NIFM rc=0x%08lX estado=%d",static_cast<unsigned long>(rc),nifmReady&&R_SUCCEEDED(rc)?int(status):-1);networkHint=hint;
    // Nintendo connectivity tests are only diagnostic: verified HTTPS decides
    // whether the publication is reachable.
    if(!curlReady){if(curl_global_init(CURL_GLOBAL_DEFAULT)!=CURLE_OK){error="No se puede iniciar HTTPS.";return false;}curlReady=true;}
    return true;
}
bool validDestination(const std::string &path,std::string &error){
    for(size_t slash=path.find('/',6);slash!=std::string::npos;slash=path.find('/',slash+1)){
        const auto parent=path.substr(0,slash);struct stat st{};
        if(lstat(parent.c_str(),&st)!=0||!S_ISDIR(st.st_mode)||S_ISLNK(st.st_mode)){error="La carpeta de descargas no es un directorio normal.";return false;}
    }
    struct stat st{};if(lstat(path.c_str(),&st)==0){if(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode)){error="El destino de la descarga no es un archivo regular.";return false;}}
    else if(errno!=ENOENT){error="No se puede revisar el archivo temporal de actualización.";return false;}
    return true;
}
#endif
}
static bool transferHttps(const std::string &url,const std::string &path,uint64_t limit,std::string &error,bool redirects=true,bool restrictedGameBanana=false){
    error.clear();
    if(!safeUrl(url)){error="La actualización necesita una URL HTTPS válida.";return false;}
    if(!limit){error="La descarga solo admite los archivos temporales privados del actualizador.";return false;}
#ifdef __SWITCH__
    if(!validDestination(path,error)||!networkInit(error))return false;
    CURL *curl=curl_easy_init();if(!curl){error="No se puede iniciar la consulta HTTPS.";return false;}
    int flags=O_WRONLY|O_CREAT|O_TRUNC;
#ifdef O_NOFOLLOW
    flags|=O_NOFOLLOW;
#endif
    const int fd=open(path.c_str(),flags,0600);FILE *file=fd<0?nullptr:fdopen(fd,"wb");
    if(!file){if(fd>=0)close(fd);curl_easy_cleanup(curl);error="No se puede guardar la descarga en la microSD.";return false;}
    Download d{file,0,limit,false};char detail[CURL_ERROR_SIZE]{};
    const auto set=[&](CURLoption key,auto value){return curl_easy_setopt(curl,key,value)==CURLE_OK;};
    const bool configured=set(CURLOPT_URL,url.c_str())&&set(CURLOPT_USERAGENT,"NinMagic-Mods")&&
        set(CURLOPT_FOLLOWLOCATION,redirects&&!restrictedGameBanana?1L:0L)&&set(CURLOPT_MAXREDIRS,redirects&&!restrictedGameBanana?5L:0L)&&
        set(CURLOPT_PROTOCOLS,long(CURLPROTO_HTTPS))&&set(CURLOPT_REDIR_PROTOCOLS,long(CURLPROTO_HTTPS))&&
        set(CURLOPT_SSL_VERIFYPEER,1L)&&set(CURLOPT_SSL_VERIFYHOST,2L)&&
        set(CURLOPT_CONNECTTIMEOUT,15L)&&set(CURLOPT_TIMEOUT,limit==4096?40L:180L)&&
        set(CURLOPT_LOW_SPEED_LIMIT,512L)&&set(CURLOPT_LOW_SPEED_TIME,20L)&&
        set(CURLOPT_NOSIGNAL,1L)&&set(CURLOPT_FAILONERROR,1L)&&
        set(CURLOPT_MAXFILESIZE_LARGE,curl_off_t(limit))&&set(CURLOPT_WRITEFUNCTION,receive)&&
        set(CURLOPT_WRITEDATA,&d)&&set(CURLOPT_ERRORBUFFER,detail);
    CURLcode result=CURLE_FAILED_INIT;long status=0;bool response=false;bool rejectedRedirect=false;
    for(unsigned hop=0;configured&&hop<=4;++hop){
        result=curl_easy_perform(curl);response=curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&status)==CURLE_OK;
        if(!restrictedGameBanana||result!=CURLE_OK||!response||status<300||status>399)break;
        char *location=nullptr;if(hop==4||curl_easy_getinfo(curl,CURLINFO_REDIRECT_URL,&location)!=CURLE_OK||!location||!gameBananaDownloadUrl(location,false)){rejectedRedirect=true;break;}
        const std::string next=location;
        if(fflush(file)!=0||ftruncate(fileno(file),0)!=0||fseek(file,0,SEEK_SET)!=0){result=CURLE_WRITE_ERROR;break;}
        d.written=0;d.overflow=false;if(!set(CURLOPT_URL,next.c_str())){result=CURLE_FAILED_INIT;break;}
    }
    curl_easy_cleanup(curl);
    bool ok=configured&&response&&result==CURLE_OK&&status==200&&d.written>0&&!d.overflow;
    if(fflush(file)!=0)ok=false;
    if(ok&&fsync(fileno(file))!=0)ok=false;
    if(fclose(file)!=0)ok=false;
    if(!ok){
        unlink(path.c_str());
        if(rejectedRedirect)error="GameBanana redirigió fuera de sus servidores HTTPS de archivos admitidos.";
        else if(!configured)error="No se pudo configurar la conexión HTTPS verificada.";
        else if(d.overflow)error="La descarga supera el tamaño permitido para la actualización.";
        else if(result==CURLE_OK)error="El servidor no devolvió un archivo válido (HTTP "+std::to_string(status)+").";
        else error="No se pudo consultar la actualización por HTTPS: "+std::string(detail[0]?detail:curl_easy_strerror(result));
        if(!status&&!networkHint.empty())error+=" ("+networkHint+").";
    }
    return ok;
#else
    (void)path;(void)redirects;(void)restrictedGameBanana;error="La descarga HTTPS solo está disponible en la consola.";return false;
#endif
}
bool downloadHttpsFile(const std::string &url,const std::string &path,std::string &error){
    return transferHttps(url,path,bodyLimit(path),error);
}
bool downloadModHttps(const std::string &url,const std::string &path,uint64_t maximum,std::string &error){
    error.clear();uint64_t cap=0;const std::string base="sdmc:/config/NinMagicMods/";
    if(path.rfind(base,0)==0){const auto rel=path.substr(base.size());
        if(rel.rfind("mod-files/",0)==0){const auto leaf=rel.substr(10);const auto hex=leaf.substr(0,40);if(leaf.size()==52&&leaf.substr(40)==".bin.pending"&&hex.find_first_not_of("0123456789abcdef")==std::string::npos)cap=32ULL*1024*1024;}
        for(const char *slot:{"mods-a/","mods-b/"})if(rel.rfind(slot,0)==0){const auto leaf=rel.substr(7);for(const char *name:{"ademola.json.pending","optimizer.json.pending","yuzu.json.pending","stevens.json.pending","masagrator.json.pending","cucholix.json.pending","ue4.json.pending","kenji.json.pending","theboy.json.pending","linkle.json.pending"})if(leaf==name)cap=8ULL*1024*1024;}
    }
    if(!cap||!maximum||maximum>cap){error="Destino o tamaño de descarga de mods no admitido.";return false;}
    if(url.rfind("https://api.github.com/repos/",0)!=0&&url.rfind("https://raw.githubusercontent.com/",0)!=0){error="La fuente de mods no es un servidor GitHub admitido.";return false;}
    return transferHttps(url,path,maximum,error);
}
bool downloadGameBananaHttps(const std::string &url,const std::string &path,uint64_t maximum,std::string &error){
    error.clear();const std::string prefix="sdmc:/config/NinMagicMods/gamebanana/";bool allowed=false;unsigned batchDestination=0;
    if(path.rfind(prefix,0)==0){const auto leaf=path.substr(prefix.size());
        if(leaf.size()>16&&leaf.substr(0,4)=="0100"&&leaf.substr(0,16).find_first_not_of("0123456789ABCDEF")==std::string::npos){
            const auto suffix=leaf.substr(16);
            allowed=suffix=="-game.json.pending"||suffix=="-featured.json.pending";
            for(unsigned page=1;page<=6;++page)if(suffix=="-page"+std::to_string(page)+".json.pending")allowed=true;
            if(suffix.rfind("-mod",0)==0&&suffix.size()>17&&suffix.compare(suffix.size()-13,13,".json.pending")==0)allowed=digits(suffix.substr(4,suffix.size()-17));
#ifdef NMM_OVERLAY
            const std::string batchCachePrefix="-mods5-page";
#else
            const std::string batchCachePrefix="-mods15-page";
#endif
            for(unsigned page=1;page<=9;++page)if(suffix==batchCachePrefix+std::to_string(page)+".json.pending"){allowed=true;batchDestination=page;}
        }
    }
    const std::string detailPrefix="https://gamebanana.com/apiv11/Mod/";bool detail=false;
    if(url.rfind(detailPrefix,0)==0){const auto end=url.find('?',detailPrefix.size());if(end!=std::string::npos){const auto id=url.substr(detailPrefix.size(),end-detailPrefix.size());detail=!id.empty()&&id.size()<=9&&id.find_first_not_of("0123456789")==std::string::npos&&url.compare(end,16,"?_csvProperties=")==0;}}
    unsigned batchPage=0;const bool batch=gameBananaBatchUrl(url,batchPage);
    const bool endpoint=url.rfind("https://gamebanana.com/apiv11/Util/Game/NameMatch?_sName=",0)==0||url.rfind("https://gamebanana.com/apiv11/Mod/Index?",0)==0||detail||batch;
    if((batch||batchDestination)&&(!batch||batchPage!=batchDestination)){error="La consulta por juego y su página de caché no coinciden.";return false;}
    if(!allowed||!maximum||maximum>512ULL*1024||!endpoint){error="GameBanana solo admite metadatos HTTPS en su caché privada.";return false;}
    // API requests have no need to redirect to a download host.
    return transferHttps(url,path,maximum,error,false);
}
bool downloadModArchiveHttps(const std::string &url,const std::string &path,uint64_t maximum,std::string &error){
    const std::string prefix="sdmc:/config/NinMagicMods/mod-archives/";bool destination=false;
    if(path.rfind(prefix,0)==0){const auto leaf=path.substr(prefix.size());destination=leaf.size()==56&&leaf.substr(40)==".archive.pending"&&leaf.substr(0,40).find_first_not_of("0123456789abcdef")==leaf.npos;}
    bool source=false;for(const char *repository:{"masagrator/NXGraphicsPatches","cucholix/NX-IPS-romfs-compilation","h2y/BOTW-Chinese-Linkle"}){
        const auto base="https://raw.githubusercontent.com/"+std::string(repository)+"/";
        if(url.rfind(base,0)!=0)continue;
        const auto rest=url.substr(base.size());if(rest.size()>41&&rest[40]=='/'&&rest.substr(0,40).find_first_not_of("0123456789abcdef")==rest.npos){const auto file=rest.substr(41);source=!file.empty()&&file.find("..") == file.npos&&file.find_first_of("?#\\")==file.npos;}
    }
    if(!destination||!source||!maximum||maximum>128ULL*1024*1024){error="Archivo Git no admitido: exige revisión inmutable y caché privada de hasta 128 MiB.";return false;}
    return transferHttps(url,path,maximum,error,false);
}
bool downloadGameBananaArchiveHttps(const std::string &url,const std::string &path,uint64_t maximum,std::string &error){
    const std::string prefix="sdmc:/config/NinMagicMods/gamebanana/";bool destination=false;
    if(path.rfind(prefix,0)==0){const auto leaf=path.substr(prefix.size());const std::string ending=".archive.pending";
        if(leaf.size()>16+1+1+1+1+1+32+ending.size()&&leaf.substr(0,4)=="0100"&&leaf.substr(0,16).find_first_not_of("0123456789ABCDEF")==leaf.npos&&leaf[16]=='-'&&leaf.compare(leaf.size()-ending.size(),ending.size(),ending)==0){
            const auto rest=leaf.substr(17,leaf.size()-17-ending.size());const auto a=rest.find('-'),b=rest.find('-',a==rest.npos?0:a+1);
            if(a!=rest.npos&&b!=rest.npos){const auto md5=rest.substr(b+1);destination=digits(rest.substr(0,a))&&digits(rest.substr(a+1,b-a-1))&&md5.size()==32&&md5.find_first_not_of("0123456789abcdef")==md5.npos;}
        }
    }
    if(!destination||!maximum||maximum>128ULL*1024*1024||!gameBananaDownloadUrl(url,true)){error="GameBanana solo admite ZIP/RAR publicados en su caché privada de hasta 128 MiB.";return false;}
    return transferHttps(url,path,maximum,error,false,true);
}
void updateNetworkExit(){
#ifdef __SWITCH__
    if(curlReady){curl_global_cleanup();curlReady=false;}
    if(nifmReady){nifmExit();nifmReady=false;}
    if(socketsReady){socketExit();socketsReady=false;}
    networkHint.clear();
#endif
}
}
