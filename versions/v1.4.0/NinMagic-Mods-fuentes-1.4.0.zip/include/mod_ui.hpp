#pragma once
#include "model.hpp"
#include "mod_policy.hpp"
namespace nmm {
inline ModFormat effectiveModFormat(const ModEntry&m){return m.format==ModFormat::Archive?(m.archiveInspected?m.archiveFormat:ModFormat::Archive):m.format;}
// Selection expresses the user's choice, never verified game compatibility.
// Download integrity, payload format and destinations are validated at prepare.
inline bool canChooseModFile(const ModEntry&m){return m.format==ModFormat::Archive&&canInspectConsoleArchive(m)&&gameBananaIdentity(m)&&!m.gbFileId;}
inline bool canMarkMod(const ModEntry&m){if(!isBrowsableMod(m)||canChooseModFile(m))return false;return m.format==ModFormat::Ips||m.format==ModFormat::Pchtxt||m.format==ModFormat::Romfs||(m.format==ModFormat::Archive&&canInspectConsoleArchive(m));}
inline bool canInspectMod(const ModEntry&m){return canChooseModFile(m);}
inline std::vector<size_t> visibleMods(const View&v){std::vector<size_t> out;for(size_t i=0;i<v.mods.size();++i)if(isBrowsableMod(v.mods[i])&&(!v.filter||canMarkMod(v.mods[i])))out.push_back(i);return out;}
inline unsigned selectedMods(const View&v){unsigned n=0;for(const auto&m:v.mods)n+=m.selected&&canMarkMod(m);return n;}
}
