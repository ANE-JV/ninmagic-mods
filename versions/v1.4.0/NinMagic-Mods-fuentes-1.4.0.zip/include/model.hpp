#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include "app_update.hpp"
namespace nmm {
struct Game {uint64_t id=0;std::string name,author,version,buildId,fullBuildId,detail;uint32_t contentVersion=0;uint64_t processId=0;std::string contentIdentity;bool versionKnown=false,buildVerified=false,running=false,sd=false,nand=false,card=false;};
struct Environment {std::string firmware,atmosphere,detail;bool applet=false,network=false;uint64_t runningTitle=0;};
enum class ModFormat { Pchtxt, Ips, Romfs, Archive, Unsupported };
struct ModFile {std::string path,url,blobSha;uint64_t size=0;};
struct ModEntry {
    uint64_t titleId=0,size=0;
    std::string name,path,blobSha,revision,buildId,version,detail,repository,source,branch,category,sourceUrl,id;
    ModFormat format=ModFormat::Unsupported;
    bool selected=false,compatible=false,consoleOnly=false;
    bool archiveInspected=false;
    ModFormat archiveFormat=ModFormat::Unsupported;
    std::string archiveSha256;
    uint64_t archiveExpandedSize=0;
    unsigned archiveFiles=0;
    std::string reason;
    std::vector<ModFile> files;
    // GameBanana's revision describes the mod, never the installed game.
    uint64_t gbGameId=0,gbModId=0,gbFileId=0;
    std::string author,downloadUrl,fileName,modVersion,gbFileMd5,consoleEvidence,gbRequirementsHash;
};
struct SourceReport {std::string name,url,detail;unsigned entries=0;bool checked=false,cached=false;};
struct ModsCatalog {std::vector<ModEntry> entries;std::vector<SourceReport> sources;std::string revision,stamp,detail;bool ready=false;};
struct PayloadFile {std::string path;std::vector<uint8_t> bytes;};
struct ModPayload {Game game;ModEntry entry;std::string buildId,detail;std::vector<uint8_t> ips;std::vector<std::string> names;std::vector<PayloadFile> files;bool compatible=false;};
struct Outcome {bool ok=false;std::string message,backupPath;unsigned count=0;};
struct InstalledInfo {bool exists=false,valid=false;unsigned files=0;std::string detail,receipt,fingerprint;};
enum class Screen { Loading, Library, Mods, ModDetail, Confirm, RemoveConfirm, Busy, Result, Sources, Help, AppUpdate, AppUpdateRecord, AppUpdateResult };
struct View {
    Screen screen=Screen::Loading;Environment env;std::vector<Game> games;ModsCatalog catalog;Game game;std::vector<ModEntry> mods;std::vector<ModPayload> payloads;InstalledInfo installed;Outcome outcome;
    int selected=0,modSelected=0,filter=0,sourceSelected=0;bool remove=false,modDetailsOriginal=false;uint64_t frame=0;std::string status="Leyendo juegos instalados...",detail,overlayDetail;
    AppUpdateInfo appUpdate;CompletedUpdateInfo completedUpdate;std::string appUpdateDetail,appUpdateResultMessage;bool appUpdateResultOk=false,appUpdateArchiveResult=false;
};
inline std::string titleId(uint64_t id){char s[17];static constexpr char h[]="0123456789ABCDEF";for(int i=15;i>=0;--i){s[i]=h[id&15];id>>=4;}s[16]=0;return s;}
}
