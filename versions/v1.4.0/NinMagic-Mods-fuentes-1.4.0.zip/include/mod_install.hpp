#pragma once
#include "model.hpp"
namespace nmm {
bool inspectInstalledMods(const Game&,InstalledInfo&,std::string&error);
bool inspectPreparedMods(const Game&,const std::vector<ModPayload>&,InstalledInfo&,std::string&error);
// One transaction contains static IPS with the author target BID, or RomFS.
// Content/process snapshots prevent stale writes; RomFS/removal require closed game.
// Existing ownership of the other domain is preserved without live mutation.
Outcome installMods(const Game&,const std::vector<ModPayload>&,bool replaceExisting,const std::string&expectedFingerprint={});
// Always requires a freshly verified closed resource context. Receipts only
// authorize hash-matching owned paths; their stored BID never proves identity.
Outcome removeMods(const Game&);
#ifdef NMM_MOD_INSTALL_TEST
void setModInstallFailureForTest(const std::string&);
#endif
}
