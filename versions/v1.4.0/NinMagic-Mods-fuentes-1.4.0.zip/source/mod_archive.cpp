#include "mod_archive.hpp"
#include "mods.hpp"
#include "mod_hash.hpp"
#include "gamebanana.hpp"
#include <algorithm>
#include <array>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <map>
#include <set>
#include <sys/stat.h>
#ifndef NMM_OVERLAY
#include <archive.h>
#include <archive_entry.h>
#endif

namespace nmm {
namespace {
constexpr uint64_t MaxMember=32ULL*1024*1024,MaxExpanded=128ULL*1024*1024;
class Sha1 {
    uint32_t h[5]={0x67452301,0xefcdab89,0x98badcfe,0x10325476,0xc3d2e1f0};
    std::array<uint8_t,64> pending{};size_t used=0;uint64_t length=0;
    static uint32_t rol(uint32_t v,unsigned n){return (v<<n)|(v>>(32-n));}
    void block(const uint8_t*p){uint32_t w[80]{};for(unsigned i=0;i<16;++i)for(unsigned n=0;n<4;++n)w[i]=(w[i]<<8)|p[i*4+n];for(unsigned i=16;i<80;++i)w[i]=rol(w[i-3]^w[i-8]^w[i-14]^w[i-16],1);uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4];for(unsigned i=0;i<80;++i){auto f=i<20?((b&c)|(~b&d)):i<40?(b^c^d):i<60?((b&c)|(b&d)|(c&d)):(b^c^d);auto k=i<20?0x5a827999U:i<40?0x6ed9eba1U:i<60?0x8f1bbcdcU:0xca62c1d6U;auto v=rol(a,5)+f+e+k+w[i];e=d;d=c;c=rol(b,30);b=a;a=v;}h[0]+=a;h[1]+=b;h[2]+=c;h[3]+=d;h[4]+=e;}
public:
    void add(const uint8_t*p,size_t n){length+=n;while(n){auto take=std::min(n,64-used);std::memcpy(pending.data()+used,p,take);used+=take;p+=take;n-=take;if(used==64){block(pending.data());used=0;}}}
    std::string finish(){uint64_t bits=length*8;pending[used++]=0x80;if(used>56){std::fill(pending.begin()+used,pending.end(),0);block(pending.data());used=0;}std::fill(pending.begin()+used,pending.begin()+56,0);for(unsigned i=0;i<8;++i)pending[63-i]=uint8_t(bits>>(i*8));block(pending.data());char out[41]{};for(unsigned i=0;i<5;++i)std::snprintf(out+i*8,9,"%08x",h[i]);return out;}
};
std::string upper(std::string s){for(char&c:s)c=char(std::toupper(static_cast<unsigned char>(c)));return s;}
bool hex(const std::string&s,size_t n){return s.size()==n&&s.find_first_not_of("0123456789abcdefABCDEF")==s.npos;}
bool version(const std::string&s){unsigned digits=0,dots=0;for(char c:s){if(c>='0'&&c<='9'){if(++digits>8)return false;}else if(c=='.'&&digits){++dots;digits=0;}else return false;}return digits&&dots>=2&&dots<=3&&s.size()<=32;}
std::vector<std::string> components(const std::string&s){std::vector<std::string>v;size_t at=0;for(;;){auto end=s.find('/',at);v.push_back(s.substr(at,end==s.npos?end:end-at));if(end==s.npos)break;at=end+1;}return v;}
std::string pathVersion(const std::string&s){std::set<std::string>v;for(auto part:components(s)){const auto dot=part.rfind('.');if(dot!=part.npos){const auto ext=upper(part.substr(dot));if(ext==".PCHTXT"||ext==".IPS"||ext==".IPS32")part.resize(dot);}if(!part.empty()&&(part[0]=='v'||part[0]=='V'))part.erase(0,1);if(version(part))v.insert(part);}return v.size()==1?*v.begin():std::string{};}
std::string fullBid(std::string s){if(s.size()<16||s.size()>64||s.size()%2||!hex(s,s.size())||s.find_first_not_of('0')==s.npos)return{};s=upper(s);s.resize(64,'0');return s;}
bool identity(const Game&g){return g.id>=0x0100000000010000ULL&&!(g.id&0xfff)&&g.contentIdentity.size()==64&&g.contentIdentity.find_first_not_of("0123456789abcdef")==g.contentIdentity.npos&&g.contentIdentity.find_first_not_of('0')!=g.contentIdentity.npos;}
bool safePath(std::string&s,bool directory){if(s.empty()||s.size()>768)return false;std::replace(s.begin(),s.end(),'\\','/');if(directory&&!s.empty()&&s.back()=='/')s.pop_back();if(s.empty()||s[0]=='/'||s.back()=='/')return false;for(unsigned char c:s)if(c<32||c>=127||c==':'||c=='*'||c=='?'||c=='"'||c=='<'||c=='>'||c=='|')return false;for(const auto&p:components(s)){if(p.empty()||p=="."||p==".."||p.back()=='.'||p.back()==' '||p.size()>240)return false;auto name=upper(p.substr(0,p.find('.')));if(name=="CON"||name=="PRN"||name=="AUX"||name=="NUL"||(name.size()==4&&(name.rfind("COM",0)==0||name.rfind("LPT",0)==0)&&name[3]>='0'&&name[3]<='9'))return false;}return true;}
bool titleInPath(const std::string&s,uint64_t expected,bool*found=nullptr){if(found)*found=false;for(size_t p=0;p+16<=s.size();++p){if(p&&std::isxdigit(static_cast<unsigned char>(s[p-1])))continue;if(p+16<s.size()&&std::isxdigit(static_cast<unsigned char>(s[p+16])))continue;auto token=upper(s.substr(p,16));if(token.rfind("0100",0)||!hex(token,16))continue;uint64_t id=0;for(char c:token)id=(id<<4)|(c<='9'?c-'0':c-'A'+10);if(canonicalModApplicationId(id)!=expected)return false;if(found)*found=true;}return true;}
#ifndef NMM_OVERLAY
bool readAt(FILE*f,uint64_t at,void*out,size_t n){return at<=MaxModArchive&&fseek(f,long(at),SEEK_SET)==0&&fread(out,1,n,f)==n;}
uint16_t u16(const uint8_t*p){return uint16_t(p[0]|(p[1]<<8));}
uint32_t u32(const uint8_t*p){return uint32_t(p[0])|(uint32_t(p[1])<<8)|(uint32_t(p[2])<<16)|(uint32_t(p[3])<<24);}
bool vint(const std::vector<uint8_t>&b,size_t&at,uint64_t&v){v=0;for(unsigned i=0;i<10&&at<b.size();++i){auto c=b[at++];if(i==9&&(c&0xfe))return false;v|=uint64_t(c&127)<<(7*i);if(!(c&128))return true;}return false;}
// Reject split archives and oversized RAR5 dictionaries before libarchive can
// allocate their decompressor. No SFX/embedded executable archive is accepted.
bool preflight(const std::string&path,uint64_t size,std::string&error){FILE*f=fopen(path.c_str(),"rb");if(!f)return false;std::array<uint8_t,16>b{};bool ok=readAt(f,0,b.data(),std::min<uint64_t>(size,b.size()));
    if(ok&&b[0]=='P'&&b[1]=='K'&&b[2]==3&&b[3]==4){size_t length=size_t(std::min<uint64_t>(size,65557));std::vector<uint8_t>tail(length);ok=readAt(f,size-length,tail.data(),length);bool found=false;uint64_t central=0,centralSize=0,endOffset=0;unsigned count=0;for(size_t i=length;i>=22&&ok;--i){size_t p=i-22;if(tail[p]=='P'&&tail[p+1]=='K'&&tail[p+2]==5&&tail[p+3]==6&&p+22+u16(tail.data()+p+20)==length){found=true;count=u16(tail.data()+p+10);centralSize=u32(tail.data()+p+12);central=u32(tail.data()+p+16);endOffset=size-length+p;ok=u16(tail.data()+p+4)==0&&u16(tail.data()+p+6)==0&&u16(tail.data()+p+8)==count&&count>0&&count<=1024&&central+centralSize==endOffset;break;}}ok=ok&&found;uint64_t cursor=central;for(unsigned i=0;ok&&i<count;++i){std::array<uint8_t,46>record{};ok=readAt(f,cursor,record.data(),record.size())&&std::memcmp(record.data(),"PK\1\2",4)==0;if(!ok)break;const auto method=u16(record.data()+10);ok=!(u16(record.data()+8)&0x41)&&(method==0||method==8)&&u32(record.data()+24)<=MaxMember&&u16(record.data()+34)==0;cursor+=46+u16(record.data()+28)+u16(record.data()+30)+u16(record.data()+32);ok=ok&&cursor<=endOffset;}ok=ok&&cursor==endOffset;
    }else if(ok&&std::memcmp(b.data(),"Rar!\x1a\x07\x00",7)==0){ok=size>=14&&b[9]==0x73&&!(u16(b.data()+10)&0x81);
    }else if(ok&&std::memcmp(b.data(),"Rar!\x1a\x07\x01\x00",8)==0){uint64_t pos=8;bool main=false;unsigned headers=0;while(ok&&pos<size){if(++headers>2048){ok=false;break;}std::array<uint8_t,14>head{};if(!readAt(f,pos,head.data(),std::min<uint64_t>(head.size(),size-pos))){ok=false;break;}std::vector<uint8_t>v(head.begin(),head.end());size_t at=4;uint64_t length=0;if(!vint(v,at,length)||length>65536||length<2||pos+at+length>size){ok=false;break;}const auto start=at;v.resize(size_t(start+length));if(!readAt(f,pos,v.data(),v.size())){ok=false;break;}uint64_t type=0,flags=0,extra=0,data=0;if(!vint(v,at,type)||!vint(v,at,flags)||((flags&1)&&!vint(v,at,extra))||((flags&2)&&!vint(v,at,data))||(flags&0x18)){ok=false;break;}if(type==1){uint64_t mf=0;ok=!main&&vint(v,at,mf)&&!(mf&1);main=true;}else if(type==2){uint64_t ff=0,unpacked=0,attr=0,compression=0;ok=vint(v,at,ff)&&vint(v,at,unpacked)&&vint(v,at,attr);if(ff&2)at+=4;if(ff&4)at+=4;ok=ok&&at<v.size()&&vint(v,at,compression)&&unpacked<=MaxMember&&((compression>>10)&15)<=8;}else if(type==4){ok=false;}else if(type!=3&&type!=5){ok=false;}if(data>size||pos+v.size()>size-data){ok=false;break;}pos+=v.size()+data;if(type==5){ok=ok&&pos==size;break;}}ok=ok&&main&&pos==size;
    }else ok=false;
    fclose(f);if(!ok)error="ZIP/RAR incompleto, dividido, cifrado, autoextraíble o con diccionario no admitido (máximo 32 MiB).";return ok;
}
struct Reader {archive*a=nullptr;~Reader(){if(a)archive_read_free(a);}};
#endif
}
bool hashModArchiveFile(const std::string&path,std::string&sha256,std::string&gitSha1,uint64_t&size,std::string&error){sha256.clear();gitSha1.clear();size=0;struct stat st{};if(lstat(path.c_str(),&st)||!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode)||st.st_size<=0||uint64_t(st.st_size)>MaxModArchive){error="Paquete vacío, no regular o mayor de 128 MiB.";return false;}FILE*f=fopen(path.c_str(),"rb");if(!f){error="No se pudo leer el paquete guardado.";return false;}mod_hash::Sha256 sha;Sha1 git;std::string header="blob "+std::to_string(st.st_size);header+='\0';git.add(reinterpret_cast<const uint8_t*>(header.data()),header.size());std::array<uint8_t,65536>b{};size_t n;while((n=fread(b.data(),1,b.size(),f))){size+=n;if(size>uint64_t(st.st_size))break;sha.add(b.data(),n);git.add(b.data(),n);}bool ok=!ferror(f)&&size==uint64_t(st.st_size);if(fclose(f))ok=false;if(!ok){error="El paquete cambió o su lectura quedó incompleta.";return false;}sha256=sha.finish();gitSha1=git.finish();return true;}

bool readModArchiveFile(const Game&game,const ModEntry&entry,const std::string&path,ModPayload&payload,bool keepResources,std::string&error){payload={};error.clear();
#ifdef NMM_OVERLAY
    (void)game;(void)entry;(void)path;(void)keepResources;error="Revisa ZIP/RAR desde la aplicación NinMagic Mods.";return false;
#else
    if(entry.format!=ModFormat::Archive||!canInspectConsoleArchive(entry)||!identity(game)||(entry.titleId&&canonicalModApplicationId(entry.titleId)!=game.id)){error="El paquete no acredita fuente, Title ID o contenido instalado.";return false;}
    std::string sha,git;uint64_t inputSize=0;if(!hashModArchiveFile(path,sha,git,inputSize,error)||!preflight(path,inputSize,error))return false;
    if(entry.size!=inputSize){error="El tamaño del paquete no coincide con el índice.";return false;}
    Reader reader;reader.a=archive_read_new();if(!reader.a){error="No hay memoria para revisar el paquete.";return false;}archive_read_support_format_zip_seekable(reader.a);archive_read_support_format_rar(reader.a);archive_read_support_format_rar5(reader.a);
    if(archive_read_open_filename(reader.a,path.c_str(),65536)!=ARCHIVE_OK){error="No se pudo abrir el ZIP/RAR: "+std::string(archive_error_string(reader.a)?archive_error_string(reader.a):"formato inválido");return false;}
    payload.game=game;payload.entry=entry;payload.entry.titleId=game.id;payload.entry.archiveSha256=sha;payload.entry.archiveInspected=true;payload.entry.archiveFiles=0;payload.entry.archiveExpandedSize=0;
    std::set<std::string>seen,regularPaths,targets,versions;std::vector<ModPayload>patches;uint64_t total=0,patchBytes=0;unsigned members=0;bool haveRomfs=false,havePatch=false;
    if(!entry.version.empty())versions.insert(entry.version);
    archive_entry*member=nullptr;int status=0;
    while((status=archive_read_next_header(reader.a,&member))==ARCHIVE_OK){if(++members>1024){error="El paquete supera 1024 entradas.";return false;}const auto kind=archive_entry_filetype(member);const char*raw=archive_entry_pathname_utf8(member);if(!raw)raw=archive_entry_pathname(member);std::string name=raw?raw:"";
        if(!safePath(name,kind==AE_IFDIR)||archive_entry_symlink(member)||archive_entry_hardlink(member)||archive_entry_is_encrypted(member)||archive_entry_sparse_count(member)>0||(kind!=AE_IFREG&&kind!=AE_IFDIR)||!seen.insert(upper(name)).second||!titleInPath(name,game.id)){error="El paquete contiene rutas inseguras, duplicadas, enlaces o archivos de otro Title ID.";return false;}
        for(const auto&known:seen){if(known==upper(name))continue;if(kind==AE_IFREG&&known.rfind(upper(name)+"/",0)==0){error="Una ruta es archivo y carpeta a la vez.";return false;}}
        for(const auto&known:regularPaths)if(upper(name).rfind(known+"/",0)==0){error="Una ruta es archivo y carpeta a la vez.";return false;}
        if(kind==AE_IFDIR)continue;
        regularPaths.insert(upper(name));
        const auto length=archive_entry_size(member);if(length<0||uint64_t(length)>MaxMember||total+uint64_t(length)>MaxExpanded){error="El contenido supera 32 MiB por archivo o 128 MiB en total.";return false;}total+=uint64_t(length);auto caps=upper(name);auto parts=components(name);const auto leaf=upper(parts.back());const auto dot=leaf.rfind('.');const auto ext=dot==leaf.npos?std::string{}:leaf.substr(dot);
        for(const char*bad:{".ZIP",".RAR",".7Z",".BNP",".UKMM",".NRO",".OVL",".NSP",".XCI",".NSO",".NCA",".EXE",".DLL",".ELF"})if(ext==bad){error="El paquete contiene otro archivo comprimido, un gestor requerido o un ejecutable no instalable.";return false;}
        size_t rom=parts.size(),exefs=parts.size();for(size_t i=0;i<parts.size();++i){auto part=upper(parts[i]);if(part=="ROMFS"){if(rom!=parts.size()){error="Raíz RomFS ambigua.";return false;}rom=i;}if(part=="EXEFS")exefs=i;if(part=="CHEATS"||part=="SAVE"||part=="SAVES"||part=="CONFIG"||part=="FLAGS"||part=="PLUGIN"||part=="PLUGINS"){if(rom==parts.size()){error="El paquete incluye cheats, ajustes, partidas o plugins; no se instalará automáticamente.";return false;}}}
        if(caps.find("ATMOSPHERE/")!=caps.npos){bool valid=false;for(size_t i=0;i+3<parts.size();++i)if(upper(parts[i])=="ATMOSPHERE"&&upper(parts[i+1])=="CONTENTS"&&upper(parts[i+2])==titleId(game.id)&&upper(parts[i+3])=="ROMFS"){valid=true;}for(size_t i=0;i+2<parts.size();++i)if(upper(parts[i])=="ATMOSPHERE"&&upper(parts[i+1])=="EXEFS_PATCHES")valid=true;if(!valid){error="Destino Atmosphère no admitido o Title ID distinto.";return false;}payload.entry.consoleOnly=true;payload.entry.consoleEvidence="Contenido nativo de Atmosphère con rutas de instalación verificadas.";}
        const bool isRom=rom<parts.size()-1;const bool isPatch=!isRom&&(ext==".PCHTXT"||ext==".IPS"||ext==".IPS32");const bool document=!isRom&&!isPatch&&(leaf.rfind("README",0)==0||leaf.rfind("LICENSE",0)==0||leaf.rfind("LICENCE",0)==0||leaf=="DESCRIPTION.TXT"||leaf=="CREDITS.TXT");
        if(!isRom&&!isPatch&&!document){error="Archivo sin destino RomFS/IPS verificable: "+name;return false;}if(exefs<parts.size()&&!isPatch){error="El paquete contiene un ejecutable ExeFS sin formato de parche estático.";return false;}if((isPatch&&length>2*1024*1024)||(document&&length>128*1024)){error="Parche o documentación demasiado grande.";return false;}
        if(isRom&&keepResources&&(game.running||game.processId)){error="Cierra el juego para preparar sus archivos RomFS.";return false;}
        if(isRom&&length==0){error="El paquete contiene un recurso vacío que el instalador no admite.";return false;}
        std::vector<uint8_t>bytes;if(!isRom||keepResources)bytes.resize(static_cast<size_t>(length));
        std::array<uint8_t,65536>scratch{};size_t used=0;while(used<size_t(length)){const size_t remaining=size_t(length)-used;auto*nbytes=bytes.empty()?scratch.data():bytes.data()+used;const size_t count=bytes.empty()?std::min(remaining,scratch.size()):remaining;auto n=archive_read_data(reader.a,nbytes,count);if(n<=0){error="Archivo comprimido truncado o CRC incorrecto.";return false;}used+=size_t(n);}uint8_t finalByte=0;if(archive_read_data(reader.a,&finalByte,1)!=0){error="Tamaño descomprimido o CRC incorrecto.";return false;}
        if(document){std::string text(bytes.begin(),bytes.end());if(isEmulatorOnlyText(text)){error="La documentación indica que este paquete es solo para emulador.";return false;}continue;}
        if(++payload.entry.archiveFiles>512){error="El paquete supera 512 archivos instalables.";return false;}payload.entry.archiveExpandedSize+=uint64_t(length);auto declaredVersion=pathVersion(name);if(!declaredVersion.empty())versions.insert(declaredVersion);
        if(isRom){haveRomfs=true;std::string tail;for(size_t i=rom+1;i<parts.size();++i){if(!tail.empty())tail+='/';tail+=parts[i];}const auto target="atmosphere/contents/"+titleId(game.id)+"/romfs/"+tail;if(!targets.insert(upper(target)).second){error="Varios archivos escribirían en la misma ruta RomFS.";return false;}if(keepResources)payload.files.push_back({target,std::move(bytes)});
        }else{havePatch=true;patchBytes+=bytes.size();if(patchBytes>2*1024*1024){error="Los parches del paquete superan 2 MiB.";return false;}ModEntry inner=payload.entry;inner.path=name;inner.format=ext==".PCHTXT"?ModFormat::Pchtxt:ModFormat::Ips;inner.titleId=game.id;inner.version=declaredVersion.empty()?entry.version:declaredVersion;if(inner.format==ModFormat::Ips)inner.buildId=fullBid(leaf.substr(0,dot));std::string body(bytes.begin(),bytes.end());if(inner.format==ModFormat::Pchtxt&&!titleInPath(body,game.id)){error="El PCHTXT del paquete declara otro Title ID.";return false;}ModPayload patch;if(!parseModPayload(game,inner,body,patch,error))return false;patches.push_back(std::move(patch));}
    }
    if(status!=ARCHIVE_EOF||archive_read_has_encrypted_entries(reader.a)>0){error="El paquete está incompleto, cifrado o usa una compresión no admitida.";return false;}
    if(haveRomfs&&havePatch){error="El paquete mezcla RomFS e IPS. Usa paquetes separados para conservar retiradas y respaldos independientes.";return false;}if(!haveRomfs&&!havePatch){error="El paquete no contiene recursos RomFS ni parches IPS/PCHTXT instalables.";return false;}
    if(!allowsConsoleMod(payload.entry)){error="La fuente o el formato no están admitidos, o el autor indica solo emulador.";return false;}
    if(versions.size()==1)payload.entry.version=*versions.begin();
    else if(versions.size()>1)payload.entry.detail+=" El paquete incluye varias versiones declaradas por el autor; compatibilidad sin verificar.";
    if(haveRomfs){payload.entry.format=ModFormat::Romfs;payload.entry.archiveFormat=ModFormat::Romfs;payload.detail="Sin verificar; instalación RomFS elegida por el usuario.";
    }else{ModPayload merged;if(patches.size()==1)merged=std::move(patches.front());else if(!combineMods(game,patches,merged,error))return false;payload.ips=std::move(merged.ips);payload.buildId=merged.buildId;payload.entry.buildId=payload.buildId;payload.entry.format=ModFormat::Ips;payload.entry.archiveFormat=ModFormat::Ips;payload.detail="Sin verificar; instalación elegida por el usuario para el Build ID declarado por el autor. Se aplicará al iniciar el juego.";}
    // A source hash pins the download; this second read also detects changes
    // between the initial hash and archive decoding, without a manual review.
    std::string finalSha,finalGit;uint64_t finalSize=0;
    if(!hashModArchiveFile(path,finalSha,finalGit,finalSize,error)||finalSha!=sha||finalSize!=inputSize){payload={};error="El paquete cambió durante la preparación. Vuelve a intentarlo.";return false;}
    payload.compatible=true;payload.names={entry.name};return true;
#endif
}
bool inspectArchiveMod(const Game&game,ModEntry&entry,std::string&error){entry.selected=false;entry.compatible=false;entry.archiveInspected=false;if(!resolveArchiveModMetadata(game,entry,error)){entry.reason=error;return false;}std::string path;ModPayload payload;if(!obtainArchiveModFile(game,entry,path,error)||!readModArchiveFile(game,entry,path,payload,false,error)){entry.reason=error;return false;}auto kind=payload.entry.archiveFormat;entry.titleId=payload.entry.titleId;entry.archiveFormat=kind;entry.archiveSha256=payload.entry.archiveSha256;entry.archiveExpandedSize=payload.entry.archiveExpandedSize;entry.archiveFiles=payload.entry.archiveFiles;entry.archiveInspected=true;entry.version=payload.entry.version;entry.buildId=payload.entry.buildId;entry.consoleOnly=payload.entry.consoleOnly;entry.consoleEvidence=payload.entry.consoleEvidence;entry.compatible=true;entry.reason=payload.detail;if(kind==ModFormat::Romfs&&(game.running||game.processId)){entry.compatible=false;entry.reason="Paquete RomFS revisado. Cierra el juego y vuelve a seleccionarlo para instalar.";}return true;}
bool prepareArchiveMod(const Game&game,const ModEntry&entry,ModPayload&payload,std::string&error){
    payload={};error.clear();ModEntry fresh=entry;fresh.archiveInspected=false;fresh.archiveSha256.clear();
    if(!resolveArchiveModMetadata(game,fresh,error))return false;
    std::string path;if(!obtainArchiveModFile(game,fresh,path,error)||!readModArchiveFile(game,fresh,path,payload,true,error))return false;
    return true;
}
}
