#include "controller.hpp"
#include "platform.hpp"
#include "mod_queue.hpp"
#include "mod_install.hpp"
#include "mod_policy.hpp"
#include "mod_ui.hpp"
#include "mods.hpp"
#include "gamebanana.hpp"
#include "update_network.hpp"
#include "memory_budget.hpp"
#include <algorithm>
#include <atomic>
#include <set>
#ifdef __SWITCH__
#include <switch.h>
#include <malloc.h>
#endif
namespace nmm::overlay {namespace {
enum class Action {None,Refresh,Search,Move,Toggle,Prepare,Apply,Save,Clear};
struct Command{Action action=Action::None;Game expected;int delta=0;size_t index=0;};
Snapshot view;std::vector<ModEntry>mods;std::vector<ModPayload>prepared;InstalledInfo preparedInfo;Game current;Environment environment;Command pending;size_t highlighted=0;bool created=false,services=false,workerAvailable=false,metadataFresh=false;std::atomic<bool>stopping{false},cancelled{false};
#ifdef __SWITCH__
Mutex mutex{};UEvent wake{};Thread worker{};struct Guard{Guard(){mutexLock(&mutex);}~Guard(){mutexUnlock(&mutex);}};
#else
struct Guard{};
#endif
bool same(const Game&a,const Game&b){return a.id&&a.id==b.id&&a.running&&b.running&&a.processId&&a.processId==b.processId&&a.buildVerified==b.buildVerified&&a.fullBuildId==b.fullBuildId&&a.contentIdentity==b.contentIdentity&&a.contentVersion==b.contentVersion&&a.versionKnown==b.versionKnown&&a.version==b.version;}
bool overlayPatch(const ModEntry&m){return m.format==ModFormat::Ips||m.format==ModFormat::Pchtxt;}
bool canChoosePatch(const ModEntry&m){return overlayPatch(m)&&canMarkMod(m);}
void requireApplication(ModEntry&m){m.compatible=false;m.selected=false;if(m.format==ModFormat::Archive)m.reason="ZIP/RAR: elige e instala este paquete desde NinMagic Mods; no se extrae en el overlay.";else if(m.format==ModFormat::Romfs)m.reason="RomFS se instala desde NinMagic Mods con el juego cerrado.";}
void publish(const std::string&s,const std::string&e={}){Guard guard;(void)guard;view.game=current;view.highlighted=highlighted;view.totalItems=mods.size();view.firstItem=(highlighted/8)*8;view.items.clear();view.selectedCount=0;for(const auto&m:mods)if(m.selected)++view.selectedCount;for(size_t i=view.firstItem;i<mods.size()&&i<view.firstItem+8;++i){view.items.push_back(mods[i]);view.items.back().files.clear();}view.ready=current.id&&current.processId&&current.running;view.status=s;view.error=e;view.initialized=services;}
bool reopen(std::string&e){platformExit();services=platformInit(environment,e);return services;}
bool identify(std::string&e){Game next;if(!services&&!reopen(e)){current={};return false;}const bool ok=resolveRunningGame(next,environment,e);current=std::move(next);return ok;}
void clearPrepared(){prepared.clear();preparedInfo={};Guard g;(void)g;view.prepared=false;view.preparedFiles=0;view.review.clear();}
void annotateCached(){for(auto&m:mods){requireApplication(m);if(overlayPatch(m))m.reason="Sin verificar. Puedes elegirlo; Y consulta su archivo en la fuente antes de confirmar.";}}
void selectSaved(){std::vector<std::string>ids;std::string why;if(loadModSelection(current,ids,why))for(auto&m:mods)m.selected=canChoosePatch(m)&&std::find(ids.begin(),ids.end(),m.id)!=ids.end();}
bool refreshList(std::string&e){const auto previous=current;if(!identify(e)){mods.clear();metadataFresh=false;highlighted=0;return false;}if(same(previous,current)&&!mods.empty())return true;mods.clear();metadataFresh=false;highlighted=0;std::string why;if(loadModMenuCache(current,mods,why)){annotateCached();return true;}e.clear();return true;}
bool searchList(std::string&status,std::string&e){if(!identify(e))return false;const auto requested=current;platformExit();services=false;updateNetworkExit();publish("Consultando las fuentes de mods. Solo se leen índices y parches pequeños.");std::vector<ModEntry>found,banana;std::string gitError,bananaError;const bool gitOk=!shouldCancel()&&checkMemoryBudget(MemoryPhase::Git,gitError)&&loadOverlayMods(requested,found,gitError,true);updateNetworkExit();const bool bananaOk=!shouldCancel()&&checkMemoryBudget(MemoryPhase::GameBanana,bananaError)&&loadGameBananaMods(requested,banana,bananaError,true);updateNetworkExit();if(stopping.load()){e="Consulta cancelada al salir.";return false;}if(!reopen(e)||!identify(e))return false;if(!same(requested,current)){mods.clear();metadataFresh=false;highlighted=0;e="El juego o su versión cambió durante la consulta. Se descartó la respuesta.";return false;}if(shouldCancel()){e="Consulta cancelada; se conserva la lista anterior.";return false;}
 if(!gitOk&&!bananaOk&&found.empty()&&banana.empty()){e=gitError;if(!bananaError.empty())e+=(e.empty()?"":" ")+bananaError;return false;}
 std::set<std::string>ids;std::vector<ModEntry>combined;
 for(auto*source:{&found,&banana})for(auto&m:*source){if(!isBrowsableMod(m)||m.titleId!=current.id||m.id.empty()||combined.size()>=128||!ids.insert(m.id).second)continue;m.selected=false;m.files.clear();if(!overlayPatch(m))requireApplication(m);combined.push_back(std::move(m));}
 found.clear();banana.clear();mods=std::move(combined);metadataFresh=true;highlighted=0;selectSaved();std::string cacheError;if(!saveModMenuCache(current,mods,cacheError))e=cacheError;status=std::to_string(mods.size())+" mods encontrados, sin verificar su compatibilidad. A elige; Y prepara IPS para confirmar. ZIP/RAR y RomFS: usa la aplicación.";for(const auto*why:{&gitError,&bananaError})if(!why->empty())e+=(e.empty()?"":" ")+*why;return true;
}
bool prepareSelected(const Game&expected,std::string&status,std::string&e){clearPrepared();if(!identify(e))return false;if(!same(expected,current)){e="El proceso o sus contenidos cambiaron antes de preparar.";return false;}if(!validateRunningGame(current,e))return false;
 if(!metadataFresh){std::set<std::string>wanted;for(const auto&m:mods)if(m.selected)wanted.insert(m.id);if(wanted.empty()){e="Elige primero un parche con A.";return false;}std::string refreshed;if(!searchList(refreshed,e))return false;size_t matched=0;for(auto&m:mods){m.selected=canChoosePatch(m)&&wanted.count(m.id);if(m.selected)++matched;}if(matched!=wanted.size()){e="Una opción guardada ya no aparece en la fuente. Vuelve a elegir antes de confirmar.";return false;}}
 if(!checkMemoryBudget(MemoryPhase::Prepare,e))return false;
 const auto requested=current;std::vector<ModEntry>selected;for(const auto&m:mods)if(m.selected)selected.push_back(m);if(selected.empty()||selected.size()>32){e="Elige entre 1 y 32 parches.";return false;}platformExit();services=false;updateNetworkExit();size_t total=0;bool valid=true;
 for(const auto&m:selected){if(shouldCancel()||!canChoosePatch(m)||m.branch.empty()){e="Formato no instalable en el overlay. ZIP/RAR y RomFS se instalan desde la aplicación.";valid=false;break;}if(!checkMemoryBudget(MemoryPhase::Prepare,e)){valid=false;break;}ModPayload payload;if(!prepareMod(requested,m,payload,e)||!payload.compatible||!payload.files.empty()||payload.ips.size()>128*1024-total){if(e.empty())e="Esta selección supera el límite del overlay. Usa la aplicación.";valid=false;break;}total+=payload.ips.size();prepared.push_back(std::move(payload));}
 updateNetworkExit();std::string reopenError;if(!reopen(reopenError)||!identify(reopenError)){e=reopenError;valid=false;}if(valid&&!same(requested,current)){e="El proceso o sus contenidos cambiaron durante la revisión.";valid=false;}if(valid&&shouldCancel()){e="Revisión cancelada antes de escribir parches.";valid=false;}ModPayload combined;if(valid&&!checkMemoryBudget(MemoryPhase::Combine,e))valid=false;if(valid&&(!combineMods(current,prepared,combined,e)||combined.ips.empty()||!combined.files.empty()||!inspectPreparedMods(current,prepared,preparedInfo,e)))valid=false;
 if(!valid){clearPrepared();return false;}status="Selección preparada, sin verificar compatibilidad. A confirma guardar los parches; no cambia la RAM del juego abierto.";{Guard g;(void)g;view.prepared=true;view.preparedFiles=preparedInfo.files;view.replacing=preparedInfo.exists;view.review=preparedInfo.detail;}return true;}
void perform(const Command&c){std::string e,status;bool ok=false;if(c.action==Action::Refresh||c.action==Action::Search||c.action==Action::Toggle||c.action==Action::Clear)clearPrepared();if(c.action==Action::Refresh){ok=refreshList(e);status=mods.empty()?"X consulta fuentes para el juego abierto. No se modifican sus archivos.":"Lista guardada de este juego. Compatibilidad sin verificar; X actualiza fuentes.";}
 else if(c.action==Action::Search)ok=searchList(status,e);
 else if(c.action==Action::Prepare){ok=prepareSelected(c.expected,status,e);Guard g;(void)g;view.lastSaveKnown=true;view.lastSaveOk=ok;view.lastSave=ok?status:e;}
 else if(c.action==Action::Apply){if(!view.prepared||prepared.empty()||!identify(e)||!same(c.expected,current)||!same(prepared.front().game,current)){e="Cambió el proceso. Pulsa Y para preparar otra confirmación.";}else if(shouldCancel())e="Instalación cancelada antes de escribir.";else if(!checkMemoryBudget(MemoryPhase::Prepare,e)){}else{const auto outcome=installMods(current,prepared,preparedInfo.exists,preparedInfo.fingerprint);ok=outcome.ok;status=outcome.message;if(!ok)e=status;}clearPrepared();Guard g;(void)g;view.lastSaveKnown=true;view.lastSaveOk=ok;view.lastSave=ok?status:e;}
 else if(c.action==Action::Move){if(!mods.empty()){auto n=int64_t(mods.size());highlighted=size_t((int64_t(highlighted)+c.delta%n+n)%n);}ok=true;status="A elige un parche sin verificar compatibilidad. R muestra sus datos.";}
 else if(c.action==Action::Toggle){if(c.index>=mods.size())e="Opción fuera de la lista actual.";else{auto&m=mods[c.index];if((!canChoosePatch(m))&&!m.selected)e=m.reason.empty()?"Este formato se elige desde la aplicación.":m.reason;else if(!m.selected&&std::count_if(mods.begin(),mods.end(),[](const auto&v){return v.selected;})>=32)e="La cola admite hasta 32 mods.";else{m.selected=!m.selected;highlighted=c.index;ok=true;status="Elegido, sin verificar. Y prepara la confirmación; ZR guarda una cola opcional.";}}}
 else if(c.action==Action::Save||c.action==Action::Clear){const auto expected=current;if(!identify(e)||!same(expected,current)||!same(c.expected,current)){e="Cambió el juego, la versión o el Build ID. Vuelve a consultar antes de guardar.";mods.clear();metadataFresh=false;highlighted=0;}else if(shouldCancel())e="Operación cancelada antes de escribir la selección.";else if(c.action==Action::Clear){ok=clearModSelection(current,e);if(ok){for(auto&m:mods)m.selected=false;status="Selección pendiente retirada. Los archivos instalados no se han modificado.";}}
 else{std::vector<ModEntry>selected;for(const auto&m:mods)if(m.selected)selected.push_back(m);ok=saveModSelection(current,selected,e);if(ok)status="Elección guardada sin verificar compatibilidad. Abre NinMagic Mods para continuar; retirar mods requiere cerrar el juego.";}Guard guard;(void)guard;view.lastSaveKnown=true;view.lastSaveOk=ok;view.lastSave=ok?status:e;}
 if(!ok&&e.empty())e="No se pudo completar la operación.";
 publish(ok?status:e,e);
}
#ifdef __SWITCH__
void run(void*){std::string e;const bool sm=R_SUCCEEDED(smInitialize()),sd=sm&&R_SUCCEEDED(fsdevMountSdmc());workerAvailable=sm&&sd;if(workerAvailable)services=platformInit(environment,e);else e="No se pudieron abrir los servicios y la microSD.";if(services){Command c;c.action=Action::Refresh;perform(c);}else publish(e,e);{Guard g;view.busy=false;}while(!stopping.load()){waitSingle(waiterForUEvent(&wake),UINT64_MAX);if(stopping.load())break;Command c;{Guard g;c=std::move(pending);pending={};}if(c.action!=Action::None)perform(c);{Guard g;view.busy=view.searching=view.applying=false;}}updateNetworkExit();platformExit();services=false;mods.clear();clearPrepared();if(sd)fsdevUnmountDevice("sdmc");if(sm)smExit();}
#endif
bool enqueue(Command c){{Guard g;(void)g;if(!created||stopping.load()||view.busy||!workerAvailable)return false;c.expected=view.game;pending=std::move(c);view.busy=true;view.searching=pending.action==Action::Search||pending.action==Action::Prepare;view.applying=pending.action==Action::Apply;view.error.clear();view.status=view.searching?"Consultando las fuentes de mods...":"Comprobando la selección...";cancelled.store(false);}
#ifdef __SWITCH__
ueventSignal(&wake);
#else
Command command=std::move(pending);pending={};perform(command);view.busy=view.searching=view.applying=false;
#endif
return true;}
}
bool init(std::string&e){e.clear();if(created)return true;view={};view.busy=true;stopping.store(false);cancelled.store(false);
#ifdef __SWITCH__
mutexInit(&mutex);ueventCreate(&wake,true);auto rc=threadCreate(&worker,run,nullptr,nullptr,0x40000,0x3B,-2);if(R_FAILED(rc)){e="No se pudo reservar el hilo del overlay.";return false;}rc=threadStart(&worker);if(R_FAILED(rc)){threadClose(&worker);e="No se pudo iniciar el hilo del overlay.";return false;}created=true;
#else
created=workerAvailable=true;services=platformInit(environment,e);Command c;c.action=Action::Refresh;perform(c);view.busy=false;
#endif
return true;}
void shutdown(){if(!created)return;stopping.store(true);cancelled.store(true);
#ifdef __SWITCH__
ueventSignal(&wake);threadWaitForExit(&worker);threadClose(&worker);
#else
updateNetworkExit();platformExit();mods.clear();clearPrepared();services=false;
#endif
created=workerAvailable=metadataFresh=false;view.initialized=view.busy=view.searching=view.applying=false;pending={};}
Snapshot snapshot(){Guard g;(void)g;return view;}
bool refresh(){Command c;c.action=Action::Refresh;return enqueue(c);}bool search(){Command c;c.action=Action::Search;return enqueue(c);}bool move(int d){Command c;c.action=Action::Move;c.delta=d;return enqueue(c);}bool toggle(size_t i){Command c;c.action=Action::Toggle;c.index=i;return enqueue(c);}bool prepare(){Command c;c.action=Action::Prepare;return enqueue(c);}bool apply(){Command c;c.action=Action::Apply;return enqueue(c);}bool save(){Command c;c.action=Action::Save;return enqueue(c);}bool clear(){Command c;c.action=Action::Clear;return enqueue(c);}void cancel(){cancelled.store(true);}bool shouldCancel(){return cancelled.load()||stopping.load();}
}
