#!/usr/bin/env python3
"""Read-only structural verification of the NinMagic NRO and embedded assets."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys

ROOT = Path(__file__).resolve().parent.parent


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def region(data: bytes, offset: int, length: int, name: str) -> bytes:
    require(0 <= offset <= len(data) and 0 <= length <= len(data) - offset, f"{name}: out of bounds")
    return data[offset:offset + length]


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def cstring(data: bytes) -> str:
    return data.split(b"\0", 1)[0].decode("utf-8")


def romfs_root_files(data: bytes) -> dict[str, bytes]:
    require(len(data) >= 80, "RomFS header missing")
    header = struct.unpack_from("<10Q", data)
    require(header[0] == 80, "Unexpected RomFS header size")
    for index, name in ((1, "directory hash"), (3, "directory metadata"), (5, "file hash"), (7, "file metadata")):
        region(data, header[index], header[index + 1], f"RomFS {name}")
    directory_metadata = region(data, header[3], header[4], "RomFS root directory")
    require(len(directory_metadata) >= 24, "RomFS root metadata missing")
    _, _, child_directory, first_file, _, root_name_size = struct.unpack_from("<6I", directory_metadata)
    require(root_name_size == 0 and child_directory == 0xFFFFFFFF, "Expected assets directly inside the RomFS root")
    file_metadata = region(data, header[7], header[8], "RomFS file metadata")
    result: dict[str, bytes] = {}
    visited: set[int] = set()
    offset = first_file
    while offset != 0xFFFFFFFF:
        require(offset not in visited, "RomFS file sibling cycle")
        visited.add(offset)
        entry = region(file_metadata, offset, 32, "RomFS file entry")
        parent, sibling, data_offset, size, _, name_size = struct.unpack("<IIQQII", entry)
        require(parent == 0, "Unexpected RomFS file parent")
        name = region(file_metadata, offset + 32, name_size, "RomFS filename").decode("utf-8")
        require(name not in result and "/" not in name and "\\" not in name, "Duplicate or invalid RomFS filename")
        result[name] = region(data, header[9] + data_offset, size, f"RomFS {name}")
        offset = sibling
    return result


def verify(path: Path, expected_version: str = "1.2.1") -> dict:
    binary = path.read_bytes()
    require(len(binary) >= 0x80 and binary[0x10:0x14] == b"NRO0", "NRO0 header missing")
    nro_size = struct.unpack_from("<I", binary, 0x18)[0]
    require(nro_size >= 0x80, "Invalid NRO code size")
    for index in range(3):
        offset, size = struct.unpack_from("<II", binary, 0x20 + 8 * index)
        require(offset + size <= nro_size, "NRO segment out of bounds")
    asset_header = region(binary, nro_size, 56, "ASET header")
    magic, version, icon_offset, icon_size, nacp_offset, nacp_size, romfs_offset, romfs_size = struct.unpack("<II6Q", asset_header)
    require(magic == 0x54455341 and version == 0, "Unsupported ASET header")
    previous_end = 56
    for name, offset, size in (("icon", icon_offset, icon_size), ("NACP", nacp_offset, nacp_size), ("RomFS", romfs_offset, romfs_size)):
        require(offset >= previous_end and size > 0, f"ASET {name} overlaps a previous section or is empty")
        region(binary, nro_size + offset, size, f"ASET {name}")
        previous_end = offset + size
    icon = region(binary, nro_size + icon_offset, icon_size, "Icon")
    original = (ROOT / "assets/ninmagic-mods-icon.jpg").read_bytes()
    require(icon == original == (ROOT / "assets/icon.jpg").read_bytes(), "The embedded icon must be byte-identical to the prepared neon MODS icon")
    nacp = region(binary, nro_size + nacp_offset, nacp_size, "NACP")
    require(nacp_size == 0x4000, "Unexpected NACP size")
    require(cstring(nacp[:0x200]) == "NinMagic Mods", "NACP primary application title missing")
    for language in range(16):
        start = language * 0x300
        title, author = cstring(nacp[start:start + 0x200]), cstring(nacp[start + 0x200:start + 0x300])
        # nacptool populates its supported language entries; later reserved
        # entries may be empty and fall back to the primary language.
        require((title, author) in (("", ""), ("NinMagic Mods", "NinMagic")), "Unexpected NACP title or author")
    require(cstring(nacp[0x3060:0x3070]) == expected_version, "Unexpected NACP display version")
    romfs = romfs_root_files(region(binary, nro_size + romfs_offset, romfs_size, "RomFS"))
    expected_names = {"font.bin", "logo.rgba", "FONT-LICENSE.txt"}
    if path.suffix.lower() != ".ovl" and expected_version != "1.0.0":
        expected_names |= {"ninmagic-mods.ovl", "overlay-info.txt"}
    require(set(romfs) == expected_names, "Unexpected or missing RomFS files")
    for name, content in romfs.items():
        require(content == (ROOT / "romfs" / name).read_bytes(), f"RomFS {name} differs from the prepared asset")
    require(len(romfs["logo.rgba"]) == 256 * 256 * 4, "Unexpected logo pixel count")
    require(struct.unpack_from("<8I", romfs["font.bin"]) == (0x54464D4E, 32, 224, 24, 34, 24, 16, 26), "Unexpected font header")
    require(len(romfs["font.bin"]) == 183040, "Unexpected font mask size")
    elf_path = path.with_suffix(".elf")
    if elf_path.is_file():
        elf = elf_path.read_bytes()
        require(elf[:6] == b"\x7fELF\x02\x01" and struct.unpack_from("<H", elf, 18)[0] == 183, "ELF must be a little-endian 64-bit AArch64 executable")
    return {
        "file": str(path.resolve()), "bytes": len(binary), "sha256": sha(binary),
        "nro_code_bytes": nro_size, "aset_version": version,
        "icon_bytes": icon_size, "icon_sha256": sha(icon), "mods_neon_icon_verified": True,
        "title": "NinMagic Mods", "author": "NinMagic", "version": expected_version,
        "nacp_bytes": nacp_size, "romfs_bytes": romfs_size,
        "romfs_files": {name: {"bytes": len(content), "sha256": sha(content)} for name, content in romfs.items()},
        "elf_aarch64_verified": elf_path.is_file(),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("nro", nargs="?", type=Path, default=ROOT / "dist/NinMagic-Mods.nro")
    parser.add_argument("--expected-version", default="1.2.1")
    parser.add_argument("--output", type=Path, help="Also save the validation result as JSON")
    args = parser.parse_args()
    try:
        report = json.dumps(verify(args.nro, expected_version=args.expected_version), ensure_ascii=False, indent=2) + "\n"
        if args.output:
            args.output.write_text(report, encoding="utf-8")
        print(report, end="")
        return 0
    except (OSError, ValueError, struct.error) as error:
        print(f"NRO verification failed: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
