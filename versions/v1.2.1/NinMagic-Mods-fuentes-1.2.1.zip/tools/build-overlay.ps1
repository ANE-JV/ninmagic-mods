[CmdletBinding()]
param([string]$DevkitPro='C:\devkitPro',[ValidatePattern('^[0-9]+\.[0-9]+\.[0-9]+$')][string]$ExpectedVersion='1.2.1')
$ErrorActionPreference='Stop'
$projectRoot=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$temporaryParent=[IO.Path]::GetFullPath((Join-Path $env:USERPROFILE '.codex\tmp'))
$stageRoot=[IO.Path]::GetFullPath((Join-Path $temporaryParent 'ninmagic-mods-overlay-build'))
if(-not $stageRoot.StartsWith($temporaryParent+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Unsafe overlay build staging folder.'}
if($stageRoot.Contains(' ')){throw 'devkitPro make needs a staging path without spaces.'}
$bash=Join-Path $DevkitPro 'msys2\usr\bin\bash.exe'
if(-not [IO.File]::Exists($bash)){throw 'devkitPro MSYS2 bash is unavailable.'}
foreach($name in @('overlay\Makefile','overlay\deps\libtesla\include\tesla.hpp','overlay\deps\libtesla\LICENSE','romfs\logo.rgba','romfs\font.bin','romfs\FONT-LICENSE.txt','assets\icon.jpg')){if(-not [IO.File]::Exists((Join-Path $projectRoot $name))){throw "Missing overlay input: $name"}}
if([IO.Directory]::Exists($stageRoot)){Remove-Item -LiteralPath $stageRoot -Recurse -Force}
$null=New-Item -ItemType Directory -Path $stageRoot -Force
foreach($name in @('overlay','include','source','assets')){Copy-Item -LiteralPath (Join-Path $projectRoot $name) -Destination $stageRoot -Recurse}
# Explicit asset allowlist prevents recursively embedding the OVL in its own RomFS.
$stageRomfs=Join-Path $stageRoot 'romfs';$null=New-Item -ItemType Directory -Path $stageRomfs -Force
foreach($name in @('font.bin','logo.rgba','FONT-LICENSE.txt')){Copy-Item -LiteralPath (Join-Path $projectRoot "romfs\$name") -Destination $stageRomfs}
$posixStage='/'+$stageRoot.Substring(0,1).ToLowerInvariant()+$stageRoot.Substring(2).Replace('\','/')
$posixDevkit='/'+$DevkitPro.Substring(0,1).ToLowerInvariant()+$DevkitPro.Substring(2).Replace('\','/')
if($posixStage.Contains("'") -or $posixDevkit.Contains("'")){throw 'Build paths cannot contain a quote.'}
$jobs=[Math]::Min(8,[Math]::Max(1,[Environment]::ProcessorCount))
$buildCommand="export DEVKITPRO='$posixDevkit'; export DEVKITA64=`"`$DEVKITPRO/devkitA64`"; export PATH=`"`$DEVKITPRO/tools/bin:`$PATH`"; cd '$posixStage/overlay' && make -j$jobs"
& $bash --login -c $buildCommand
if($LASTEXITCODE -ne 0){throw "Overlay compilation failed (exit $LASTEXITCODE)."}
$output=Join-Path $projectRoot 'dist\overlay';$null=New-Item -ItemType Directory -Path $output -Force
foreach($extension in @('ovl','elf','nacp')){Copy-Item -LiteralPath (Join-Path $stageRoot "overlay\ninmagic-mods.$extension") -Destination $output -Force}
& python (Join-Path $PSScriptRoot 'verify_nro.py') (Join-Path $output 'ninmagic-mods.ovl') --expected-version $ExpectedVersion --output (Join-Path $output 'validation.json')
if($LASTEXITCODE -ne 0){throw 'Overlay container verification failed.'}
Write-Host "Overlay ready: $(Join-Path $output 'ninmagic-mods.ovl')"
