#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "overlay_bundle.hpp"
#include "app_update.hpp"
#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#ifdef NMM_OVERLAY_BUNDLE_TEST
#include <functional>
#endif
#ifdef __SWITCH__
#include <switch.h>
#endif
namespace nmm { namespace {
constexpr const char *BundleVersion="1.2.1";
constexpr uint64_t MaxOverlay=8ULL*1024*1024;
#ifdef NMM_OVERLAY_BUNDLE_TEST
std::string bundleFailure;
std::function<void(const char*)> bundleHook;
bool bundleFail(const char* point){if(bundleFailure==point){bundleFailure.clear();return true;}return false;}
void bundleCheckpoint(const char* point){if(bundleHook)bundleHook(point);}
#else
bool bundleFail(const char*){return false;}
void bundleCheckpoint(const char*){}
#endif
std::string bundlePath(const char *p){
#ifdef NMM_OVERLAY_BUNDLE_TEST
    const char *r=std::getenv("NMM_OVERLAY_BUNDLE_ROOT");
    if(r&&std::string(p).rfind("sdmc:/",0)==0)return std::string(r)+"/sd/"+std::string(p).substr(6);
    if(r&&std::string(p).rfind("romfs:/",0)==0)return std::string(r)+"/rom/"+std::string(p).substr(7);
#endif
    return p;
}
bool bundleExists(const std::string&p){struct stat s{};return lstat(p.c_str(),&s)==0;}
bool bundleAbsent(const std::string&p){struct stat s{};return lstat(p.c_str(),&s)!=0&&errno==ENOENT;}
bool bundleDir(const std::string&p){struct stat s{};if(lstat(p.c_str(),&s)==0)return S_ISDIR(s.st_mode)&&!S_ISLNK(s.st_mode);if(errno!=ENOENT)return false;
#ifdef _WIN32
    return mkdir(p.c_str())==0;
#else
    return mkdir(p.c_str(),0777)==0;
#endif
}
bool bundlePlain(const std::string&p,uint64_t limit){struct stat s{};return lstat(p.c_str(),&s)==0&&S_ISREG(s.st_mode)&&!S_ISLNK(s.st_mode)&&s.st_size>=0&&uint64_t(s.st_size)<=limit;}
bool bundleRegular(const std::string&p,uint64_t limit){struct stat s{};return bundlePlain(p,limit)&&lstat(p.c_str(),&s)==0&&s.st_size>0;}
bool bundleCommit(){
    if(bundleFail("commit"))return false;
#ifdef __SWITCH__
    return R_SUCCEEDED(fsdevCommitDevice("sdmc"));
#else
    return true;
#endif
}
FILE* bundleRead(const std::string&p){int flags=O_RDONLY;
#ifdef O_NOFOLLOW
    flags|=O_NOFOLLOW;
#endif
    int fd=open(p.c_str(),flags);if(fd<0)return nullptr;FILE*f=fdopen(fd,"rb");if(!f)close(fd);return f;
}
bool bundleIdentity(const std::string&p,std::string&ver,std::string&hash,uint64_t&size,std::string&e){return bundleRegular(p,MaxOverlay)&&inspectNinMagicExecutable(p,ver,hash,size,e);}
bool bundleMatches(const std::string&p,const std::string&hash,uint64_t bytes){std::string v,h,e;uint64_t n=0;return bundleIdentity(p,v,h,n,e)&&h==hash&&n==bytes;}
bool bundleEqual(const std::string&a,const std::string&b,bool prefix=false){
    if(!bundlePlain(a,MaxOverlay)||!bundlePlain(b,MaxOverlay))return false;
    FILE*x=bundleRead(a),*y=bundleRead(b);if(!x||!y){if(x)fclose(x);if(y)fclose(y);return false;}
    std::array<unsigned char,32768> p{},q{};bool ok=true;for(;;){const auto n=fread(p.data(),1,p.size(),x);if(!n){ok=!ferror(x)&&(prefix||fgetc(y)==EOF)&&!ferror(y);break;}const auto m=fread(q.data(),1,n,y);if(m!=n||std::memcmp(p.data(),q.data(),n)){ok=false;break;}}
    if(fclose(x)!=0)ok=false;
    if(fclose(y)!=0)ok=false;
    return ok;
}
bool bundleCopy(const std::string&from,const std::string&to){
    if(!bundlePlain(from,MaxOverlay)||!bundleAbsent(to))return false;
    FILE*in=bundleRead(from);if(!in)return false;int flags=O_WRONLY|O_CREAT|O_EXCL;
#ifdef O_NOFOLLOW
    flags|=O_NOFOLLOW;
#endif
    int fd=open(to.c_str(),flags,0600);if(fd<0){fclose(in);return false;}FILE*out=fdopen(fd,"wb");if(!out){close(fd);fclose(in);return false;}
    std::array<unsigned char,32768>b{};size_t n=0;uint64_t total=0;bool ok=true;
    while((n=fread(b.data(),1,b.size(),in))){total+=n;if(total>MaxOverlay){ok=false;break;}if(bundleFail("copy-short")){fwrite(b.data(),1,n/2,out);ok=false;break;}if(fwrite(b.data(),1,n,out)!=n){ok=false;break;}}
    if(ferror(in))ok=false;
    if(fclose(in)!=0)ok=false;
    if(fflush(out)!=0||fsync(fileno(out))!=0)ok=false;
    if(fclose(out)!=0)ok=false;
    return ok;
}
bool bundleErase(const std::string&p){return bundlePlain(p,MaxOverlay)&&unlink(p.c_str())==0;}
bool bundleArchive(const std::string&from,const std::string&backups,const char*kind,std::string&saved){
    saved.clear();for(unsigned i=1;i<100000;++i){char leaf[64];std::snprintf(leaf,sizeof(leaf),"/%s-%08u.ovl",kind,i);const auto p=backups+leaf;if(!bundleAbsent(p))continue;if(!bundleCopy(from,p)||!bundleEqual(from,p)||!bundleCommit())return false;saved=p;return true;}return false;
}
bool bundleNewer(const std::string&a,const std::string&b){
    std::array<unsigned long,3>x{},y{};const auto parse=[](const std::string&s,std::array<unsigned long,3>&out){const char*p=s.c_str();for(size_t i=0;i<3;++i){char*end=nullptr;out[i]=std::strtoul(p,&end,10);if(end==p||out[i]>65535||(*end!=(i==2?'\0':'.')))return false;p=end+1;}return true;};
    return parse(a,x)&&parse(b,y)&&x>y;
}
bool bundleManifest(const std::string&p,std::string&hash,uint64_t&size){
    if(!bundleRegular(p,160))return false;
    FILE*f=bundleRead(p);if(!f)return false;char b[161]{};size_t n=fread(b,1,160,f);bool ok=!ferror(f);if(fclose(f)!=0)ok=false;if(!ok)return false;
    std::string text(b,n),prefix="NMMODS-OVERLAY-1\nversion="+std::string(BundleVersion)+"\nsha256=";
    if(text.rfind(prefix,0)!=0||text.size()<prefix.size()+65||text[prefix.size()+64]!='\n')return false;
    hash=text.substr(prefix.size(),64);if(hash.find_first_not_of("0123456789abcdef")!=std::string::npos)return false;
    auto off=prefix.size()+65;if(text.compare(off,5,"size="))return false;std::string number=text.substr(off+5);if(number.empty()||number.back()!='\n')return false;number.pop_back();if(number.empty()||number.size()>8||number.find_first_not_of("0123456789")!=std::string::npos||(number.size()>1&&number[0]=='0'))return false;
    size=std::strtoull(number.c_str(),nullptr,10);return size>=0x4000&&size<=MaxOverlay;
}
bool bundleRecoverPrevious(const std::string&target,const std::string&previous,const std::string&backups,const std::string&expected,uint64_t bytes,std::string&detail){
    if(bundleAbsent(previous))return true;
    std::string v,h,e;uint64_t n=0;
    if(!bundleIdentity(previous,v,h,n,e)){
        // An interrupted exclusive copy is removable only if its exact bytes
        // are a prefix of the still-verified installed executable.
        std::string tv,th;uint64_t tn=0;
        if(bundleIdentity(target,tv,th,tn,e)&&bundleEqual(previous,target,true)&&bundleErase(previous)&&bundleCommit())return true;
        detail="Hay una copia anterior incompleta o ajena; se conserva para revisión.";return false;
    }
    if(bundleAbsent(target)){
        if(rename(previous.c_str(),target.c_str())==0&&bundleMatches(target,h,n)&&bundleCommit())return true;
        detail="No se pudo recuperar el overlay anterior. Sus copias se conservan.";return false;
    }
    if(!bundleMatches(target,h,n)&&!bundleMatches(target,expected,bytes)){
        detail="El overlay cambió durante una operación interrumpida; se conservan ambos archivos.";return false;
    }
    std::string archive;if(!bundleArchive(previous,backups,"backup",archive)||!bundleMatches(archive,h,n)||!bundleErase(previous)||!bundleCommit()){
        detail="No se pudo archivar la copia anterior verificada del overlay.";return false;
    }
    return true;
}
} // namespace
bool ensureBundledOverlay(std::string&detail){
    detail.clear();const auto source=bundlePath("romfs:/ninmagic-mods.ovl"),manifest=bundlePath("romfs:/overlay-info.txt"),target=bundlePath("sdmc:/switch/.overlays/ninmagic-mods.ovl"),pending=bundlePath("sdmc:/switch/.overlays/.ninmagic-mods.ovl.pending"),previous=bundlePath("sdmc:/switch/.overlays/.ninmagic-mods.ovl.previous"),backups=bundlePath("sdmc:/config/NinMagicMods/overlay-update");
    std::string expected,ver,hash,e;uint64_t bytes=0,size=0;
    if(!bundleManifest(manifest,expected,bytes)||!bundleIdentity(source,ver,hash,size,e)||ver!=BundleVersion||hash!=expected||size!=bytes){detail="El overlay incluido no supera la verificación; no se ha copiado.";return false;}
    for(const auto*p:{"sdmc:/switch","sdmc:/switch/.overlays","sdmc:/config","sdmc:/config/NinMagicMods","sdmc:/config/NinMagicMods/overlay-update"})if(!bundleDir(bundlePath(p))){detail="No se pudo preparar la carpeta del overlay.";return false;}
    if(!bundleRecoverPrevious(target,previous,backups,expected,bytes,detail))return false;
    std::string oldHash,oldVer;uint64_t oldSize=0;const bool had=bundleExists(target);
    if(had){
        if(!bundleIdentity(target,oldVer,oldHash,oldSize,e)){detail="Ya existe un archivo ajeno o dañado en la ruta del overlay; se conserva.";return false;}
        if(oldHash==expected&&oldSize==bytes){detail="Overlay 1.2.1 comprobado. Ábrelo desde Ultrahand o Tesla.";return true;}
        if(bundleNewer(oldVer,BundleVersion)){detail="Se conserva un overlay con versión posterior a la aplicación.";return false;}
    }else if(!bundleAbsent(target)){detail="No se pudo revisar el overlay instalado.";return false;}
    if(bundleExists(pending)){
        if(!bundleMatches(pending,expected,bytes)){
            if(!bundleEqual(pending,source,true)||!bundleErase(pending)){detail="Hay una preparación de overlay distinta; se conserva para revisión.";return false;}
        }
    }else if(!bundleAbsent(pending)){detail="No se pudo revisar la preparación del overlay.";return false;}
    if(bundleAbsent(pending)&&!bundleCopy(source,pending)){detail="No se pudo preparar la copia del overlay. Se conserva el anterior.";return false;}
    if(!bundleMatches(pending,expected,bytes)||!bundleCommit()){detail="No se pudo confirmar la preparación del overlay; se conserva el anterior.";return false;}
    bundleCheckpoint("prepared");
    if((had&&!bundleMatches(target,oldHash,oldSize))||(!had&&!bundleAbsent(target))){detail="El overlay cambió durante la preparación; vuelve a abrir la aplicación.";return false;}
    if(had){
        std::string backup;if(!bundleArchive(target,backups,"backup",backup)||!bundleMatches(backup,oldHash,oldSize)||!bundleCopy(target,previous)||!bundleMatches(previous,oldHash,oldSize)||!bundleCommit()){detail="No se pudo conservar la copia anterior del overlay.";return false;}
        bundleCheckpoint("backed-up");
        if(!bundleMatches(target,oldHash,oldSize)||!bundleEqual(target,previous)||!bundleErase(target)||!bundleCommit()){detail="No se pudo retirar el overlay anterior de forma comprobada. Se conservan sus copias.";return false;}
    }
    if(bundleFail("after-old-unlink")){detail="Operación interrumpida; la copia anterior permite recuperarla.";return false;}
    bool activated=!bundleFail("activate-rename")&&bundleAbsent(target)&&rename(pending.c_str(),target.c_str())==0;
    bundleCheckpoint("activated");
    if(bundleFail("after-activate")){detail="Operación interrumpida después de activar el overlay; se revisará al volver a abrir.";return false;}
    if(!activated||!bundleMatches(target,expected,bytes)||bundleFail("activate-commit")||!bundleCommit()){
        // Preserve unexpected bytes rather than erase them. Only this failed
        // activation's destination is quarantined; foreign initial files block above.
        if(!activated&&bundleExists(target)){detail="La ruta del overlay cambió antes de activarlo; se conserva para revisión.";return false;}
        if(bundleExists(target)){
            std::string rejected;if(!bundlePlain(target,MaxOverlay)||!bundleArchive(target,backups,"rejected",rejected)||!bundleEqual(target,rejected)||!bundleErase(target)){
                detail="No se pudo terminar ni recuperar el overlay. Se conservan sus copias para revisión.";return false;
            }
        }
        if(had&&bundleAbsent(target)&&bundleMatches(previous,oldHash,oldSize))rename(previous.c_str(),target.c_str());
        const bool restored=had?bundleMatches(target,oldHash,oldSize):bundleAbsent(target);
        bundleCommit();detail=restored?"No se pudo terminar la actualización del overlay; se recuperó el estado anterior.":"No se pudo recuperar el overlay; se conservan sus copias.";return false;
    }
    if(had&&(!bundleMatches(previous,oldHash,oldSize)||!bundleErase(previous)||!bundleCommit())){detail="Overlay actualizado; conserva una copia pendiente de archivar y se revisará al volver a abrir.";return false;}
    detail="Overlay 1.2.1 instalado. Cierra y vuelve a abrir su entrada en Ultrahand o Tesla.";return true;
}
} // namespace nmm
