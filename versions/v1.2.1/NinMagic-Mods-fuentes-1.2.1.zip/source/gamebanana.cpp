#include "gamebanana.hpp"

namespace nmm {
// No GameBanana package currently has physical-console provenance verified by
// this provider. Keep the public API fail-closed for older integration paths.
bool parseGameBananaMods(const Game &game,uint64_t id,const std::string &data,std::vector<ModEntry> &out,std::string &error){
    (void)game;(void)id;(void)data;out.clear();error="GameBanana no aporta procedencia verificable para Switch física en este proveedor; sus paquetes se excluyen.";return false;
}
bool parseGameBananaMod(const Game &game,uint64_t id,uint64_t mod,const std::string &data,ModEntry &out,std::string &error){
    (void)game;(void)id;(void)mod;(void)data;out={};error="GameBanana no aporta procedencia verificable para Switch física en este proveedor; sus paquetes se excluyen.";return false;
}
bool loadGameBananaMods(const Game &game,std::vector<ModEntry> &out,std::string &error,bool force){
    (void)game;(void)force;out.clear();error="GameBanana excluido: este proveedor no acredita los paquetes para Switch física. No se consulta la red.";return false;
}
}
