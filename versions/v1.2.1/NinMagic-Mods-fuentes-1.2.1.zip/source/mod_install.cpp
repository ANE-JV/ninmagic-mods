#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "mod_install.hpp"
#include "mods.hpp"
#include "platform.hpp"
#include "mod_hash.hpp"
#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dirent.h>
#include <fcntl.h>
#include <map>
#include <set>
#include <sys/stat.h>
#include <unistd.h>
#ifdef __SWITCH__
#include <switch.h>
#endif

namespace nmm {
namespace {
using Bytes=std::vector<uint8_t>;
constexpr uint64_t MaxFile=32ULL*1024*1024,MaxTotal=128ULL*1024*1024;
#ifdef NMM_OVERLAY
constexpr size_t MaxEntries=128,MaxRecord=64*1024;
#else
constexpr size_t MaxEntries=4096,MaxRecord=4*1024*1024;
#endif
#ifdef NMM_MOD_INSTALL_TEST
std::string failurePoint;
bool fail(const char*p){if(failurePoint==p){failurePoint.clear();return true;}return false;}
#else
bool fail(const char*){return false;}
#endif
std::string disk(){
#ifdef NMM_MOD_INSTALL_TEST
    const char*p=std::getenv("NMM_MOD_INSTALL_ROOT");return p?p:"mods-install-test";
#else
    return "sdmc:";
#endif
}
std::string upper(std::string s){for(char&c:s)if(c>='a'&&c<='z')c=char(c-'a'+'A');return s;}
bool hex(const std::string&s,size_t n){return s.size()==n&&std::all_of(s.begin(),s.end(),[](unsigned char c){return(c>='0'&&c<='9')||(c>='a'&&c<='f')||(c>='A'&&c<='F');});}
bool gameValid(const Game&g,std::string&e){if(g.id<0x0100000000010000ULL||(g.id&0xfff)||g.version.size()>32||std::any_of(g.version.begin(),g.version.end(),[](unsigned char c){return c<32||c==127;})){e="Primero comprueba el Title ID y la identidad del juego.";return false;}return true;}
bool codeIdentity(const Game&g){return g.buildVerified&&hex(g.fullBuildId,64)&&hex(g.buildId,16)&&upper(g.fullBuildId.substr(0,16))==upper(g.buildId)&&g.buildId.find_first_not_of('0')!=g.buildId.npos;}
bool context(const Game&g,bool code,std::string&e){if(!gameValid(g,e))return false;if(code){if(!codeIdentity(g)||!g.running||!g.processId||!hex(g.contentIdentity,64)){e="Abre el juego y vuelve a comprobar su proceso, contenidos y Build ID completo.";return false;}return validateRunningGame(g,e);}if(!g.versionKnown||g.version.empty()||!hex(g.contentIdentity,64)){e="Falta comprobar la versión y los contenidos instalados para RomFS o retirada.";return false;}return validateClosedResources(g,e);}
bool codePath(const std::string&p){return p.rfind("atmosphere/exefs_patches/",0)==0;}
std::string reviewIdentity(const Game&g,const std::string&prior){return "NMMODS-REVIEW2\n"+titleId(g.id)+"\n"+upper(g.fullBuildId)+"\n"+g.version+"\n"+std::to_string(g.contentVersion)+"\n"+g.contentIdentity+"\n"+std::to_string(g.processId)+"\n"+prior+"\n";}
bool component(const std::string&s){if(s.empty()||s=="."||s==".."||s.size()>255||s.back()=='.'||s.back()==' ')return false;const auto stem=upper(s.substr(0,s.find('.')));if(stem=="CON"||stem=="PRN"||stem=="AUX"||stem=="NUL"||(stem.size()==4&&(stem.substr(0,3)=="COM"||stem.substr(0,3)=="LPT")&&stem[3]>='1'&&stem[3]<='9'))return false;return std::none_of(s.begin(),s.end(),[](unsigned char c){return c<32||c==127||c=='\\'||c==':'||c=='/'||c=='*'||c=='?'||c=='"'||c=='<'||c=='>'||c=='|';});}
bool relative(const std::string&s){if(s.empty()||s.size()>1024||s.front()=='/'||s.back()=='/')return false;size_t p=0;while(p<s.size()){auto end=s.find('/',p);if(!component(s.substr(p,end==s.npos?end:end-p)))return false;if(end==s.npos)break;p=end+1;}return true;}
bool targetAllowed(const std::string&s,uint64_t id){
    if(!relative(s))return false;
    const auto rom=std::string("atmosphere/contents/")+titleId(id)+"/romfs/";
    if(s.rfind(rom,0)==0&&s.size()>rom.size()){
        const auto cap=upper(s);for(const char*ext:{".NRO",".NSO",".NSP",".XCI",".KIP",".KIP1",".OVL"})if(cap.size()>=std::strlen(ext)&&cap.compare(cap.size()-std::strlen(ext),std::strlen(ext),ext)==0)return false;
        return true;
    }
    const auto patch=std::string("atmosphere/exefs_patches/NinMagicMods_")+titleId(id)+"/";
    if(s.rfind(patch,0)!=0)return false;
    const auto name=s.substr(patch.size());return name.size()==68&&name.substr(64)==".ips"&&hex(name.substr(0,64),64)&&name.substr(0,64).find_first_not_of('0')!=std::string::npos;
}
std::string base(uint64_t id){return "config/NinMagicMods/backups/"+titleId(id);}
std::string serial(unsigned n){char s[9];std::snprintf(s,sizeof(s),"%08u",n);return s;}
bool serialValid(const std::string&s){return s.size()==8&&std::all_of(s.begin(),s.end(),[](char c){return c>='0'&&c<='9';})&&s!="00000000";}
bool status(const std::string&p,struct stat&st,bool&exists,std::string&e){exists=false;if(!relative(p)){e="Ruta interna no válida.";return false;}if(lstat((disk()+"/"+p).c_str(),&st)!=0){if(errno==ENOENT)return true;e="No se pudo comprobar la ruta de mods: "+p;return false;}exists=true;if(S_ISLNK(st.st_mode)||(!S_ISREG(st.st_mode)&&!S_ISDIR(st.st_mode))){e="La ruta contiene un enlace o un tipo no admitido: "+p;return false;}return true;}
bool folders(const std::string&p,bool create,bool&exists,std::string&e){
    exists=true;if(!relative(p)){e="Ruta de carpetas no válida.";return false;}size_t at=0;std::string current;
    while(at<p.size()){auto end=p.find('/',at);if(!current.empty())current+='/';current+=p.substr(at,end==p.npos?end:end-at);struct stat st{};if(!status(current,st,exists,e))return false;if(!exists){if(!create)return true;
#ifdef _WIN32
        if(mkdir((disk()+"/"+current).c_str())!=0){e="No se pudo crear la carpeta privada de mods.";return false;}
#else
        if(mkdir((disk()+"/"+current).c_str(),0777)!=0){e="No se pudo crear la carpeta privada de mods.";return false;}
#endif
        if(!status(current,st,exists,e)||!exists)return false;
    }if(!S_ISDIR(st.st_mode)){e="Una carpeta de mods es un archivo.";return false;}if(end==p.npos)break;at=end+1;}return true;
}
bool parent(const std::string&p,bool create,bool&exists,std::string&e){const auto end=p.find_last_of('/');if(end==p.npos){exists=true;return true;}return folders(p.substr(0,end),create,exists,e);}
bool read(const std::string&p,Bytes&b,bool&exists,std::string&e,uint64_t maximum=MaxFile){
#ifdef NMM_OVERLAY
    maximum=std::min<uint64_t>(maximum,128*1024);
#endif
    b.clear();exists=false;bool parents=false;if(!parent(p,false,parents,e)||!parents)return e.empty();struct stat st{};if(!status(p,st,exists,e)||!exists)return !exists&&e.empty();if(!S_ISREG(st.st_mode)||st.st_size<0||uint64_t(st.st_size)>maximum){e="El archivo de mods no es regular o supera sus límites: "+p;return false;}int flags=O_RDONLY;
#ifdef O_NOFOLLOW
    flags|=O_NOFOLLOW;
#endif
    int fd=open((disk()+"/"+p).c_str(),flags);if(fd<0){e="No se pudo abrir un archivo de mods.";return false;}std::array<uint8_t,65536> data{};bool ok=true;for(;;){const auto n=::read(fd,data.data(),data.size());if(n<0){ok=false;break;}if(!n)break;if(b.size()+uint64_t(n)>maximum){ok=false;break;}b.insert(b.end(),data.begin(),data.begin()+n);}if(close(fd)!=0)ok=false;if(!ok)e="La lectura del archivo quedó incompleta.";return ok;
}
bool writeNew(const std::string&p,const Bytes&b,std::string&e){bool exists=false;if(!parent(p,true,exists,e)||!exists)return false;struct stat st{};if(!status(p,st,exists,e)||exists){if(e.empty())e="La nueva ruta privada ya existe.";return false;}int flags=O_WRONLY|O_CREAT|O_EXCL;
#ifdef O_NOFOLLOW
    flags|=O_NOFOLLOW;
#endif
    int fd=open((disk()+"/"+p).c_str(),flags,0600);if(fd<0){e="No se pudo guardar el archivo de mods.";return false;}size_t at=0;bool ok=true;while(at<b.size()){auto n=::write(fd,b.data()+at,b.size()-at);if(n<=0){ok=false;break;}at+=size_t(n);}if(ok&&fsync(fd)!=0)ok=false;if(close(fd)!=0)ok=false;if(!ok){e="No se pudo confirmar el archivo de mods.";return false;}Bytes actual;if(!read(p,actual,exists,e,std::max<uint64_t>(MaxFile,MaxRecord))||!exists||actual!=b){e="La copia del archivo no coincide.";return false;}return true;}
bool eraseRegular(const std::string&p,std::string&e){bool parents=false;if(!parent(p,false,parents,e)||!parents)return e.empty();struct stat st{};bool exists=false;if(!status(p,st,exists,e)||!exists)return !exists&&e.empty();if(!S_ISREG(st.st_mode)||unlink((disk()+"/"+p).c_str())!=0){e="No se pudo retirar el archivo propio de la transacción.";return false;}return true;}
bool commit(std::string&e){
#ifdef __SWITCH__
    if(fsdevCommitDevice("sdmc")!=0){e="No se pudo confirmar la transacción en la microSD.";return false;}
#else
    (void)e;
#endif
    return true;
}
bool privateText(const std::string&p,const std::string&s,std::string&e){
    const Bytes bytes(s.begin(),s.end());const auto temp=p+".writepending";Bytes now;bool exists=false;if(!read(temp,now,exists,e,MaxRecord))return false;if(exists&&now!=bytes){if(now.size()>=bytes.size()||!std::equal(now.begin(),now.end(),bytes.begin())){e="Un marcador temporal cambió; se conserva.";return false;}if(!eraseRegular(temp,e))return false;exists=false;}if(!exists&&!writeNew(temp,bytes,e))return false;
    if(!eraseRegular(p,e)||std::rename((disk()+"/"+temp).c_str(),(disk()+"/"+p).c_str())!=0){if(e.empty())e="No se pudo activar el marcador de mods.";return false;}return commit(e);
}
std::string pointerText(uint64_t id,const std::string&s){const auto value="NMMODS-POINTER1\n"+titleId(id)+"\n"+s+"\n";return value+mod_hash::shaText(value)+"\n";}
bool pointer(uint64_t id,const char*name,std::string&s,std::string&e){s.clear();Bytes raw;bool exists=false;if(!read(base(id)+"/"+name,raw,exists,e,256)||!exists)return !exists&&e.empty();std::string text(raw.begin(),raw.end());const auto prefix="NMMODS-POINTER1\n"+titleId(id)+"\n";if(text.rfind(prefix,0)!=0||text.size()!=prefix.size()+8+1+64+1){e="El marcador de mods está dañado.";return false;}s=text.substr(prefix.size(),8);if(!serialValid(s)||text!=pointerText(id,s)){e="El marcador de mods no supera su comprobación.";return false;}return true;}
bool setPointer(uint64_t id,const char*name,const std::string&s,std::string&e){return s.empty()?eraseRegular(base(id)+"/"+name,e)&&commit(e):privateText(base(id)+"/"+name,pointerText(id,s),e);}
struct State {bool exists=false;uint64_t size=0;std::string hash;};
bool same(const State&a,const State&b){return a.exists==b.exists&&(!a.exists||(a.size==b.size&&a.hash==b.hash));}
State state(const Bytes&b,bool exists){return {exists,exists?uint64_t(b.size()):0,exists?mod_hash::bytes(b):std::string{}};}
bool digestFile(const std::string&p,State&s,std::string&e){s={};bool parents=false;if(!parent(p,false,parents,e)||!parents)return e.empty();struct stat st{};bool exists=false;if(!status(p,st,exists,e)||!exists)return !exists&&e.empty();if(!S_ISREG(st.st_mode)||st.st_size<0||uint64_t(st.st_size)>MaxFile){e="Un archivo de mods supera sus límites.";return false;}int flags=O_RDONLY;
#ifdef O_NOFOLLOW
flags|=O_NOFOLLOW;
#endif
int fd=open((disk()+"/"+p).c_str(),flags);if(fd<0){e="No se pudo leer un archivo de mods.";return false;}mod_hash::Sha256 hash;std::array<uint8_t,65536>b{};uint64_t count=0;bool ok=true;for(;;){auto n=::read(fd,b.data(),b.size());if(n<0){ok=false;break;}if(!n)break;count+=uint64_t(n);if(count>MaxFile){ok=false;break;}hash.add(b.data(),size_t(n));}if(close(fd)||count!=uint64_t(st.st_size))ok=false;if(!ok){e="El archivo cambió o su lectura quedó incompleta.";return false;}s={true,count,hash.finish()};return true;}
bool actual(const std::string&p,State&s,Bytes*body,std::string&e){if(!body)return digestFile(p,s,e);
#ifdef NMM_OVERLAY
struct stat overlayStat{};if(lstat((disk()+"/"+p).c_str(),&overlayStat)==0&&overlayStat.st_size>128*1024){e="Este archivo o respaldo es grande: usa la aplicación NinMagic Mods.";return false;}
#endif
Bytes data;bool exists=false;if(!read(p,data,exists,e))return false;s=state(data,exists);*body=std::move(data);return true;}
struct Change {std::string path;State before,after,original;bool owned=false;};
struct Receipt {Game game;std::string token,prior;bool installing=false,staticCode=false,hasResourceContext=false;Game resourceContext;std::vector<Change> changes;};
void number(Bytes&b,uint64_t n,unsigned count){for(unsigned i=0;i<count;++i)b.push_back(uint8_t(n>>(i*8)));}
void text(Bytes&b,const std::string&s){number(b,s.size(),2);b.insert(b.end(),s.begin(),s.end());}
void encodeState(Bytes&b,const State&s){number(b,s.exists,1);number(b,s.size,8);text(b,s.hash);}
Bytes encode(const Receipt&r){Bytes b={'N','M','M','O','D','S','0','2'};number(b,r.game.id,8);text(b,r.game.fullBuildId);text(b,r.game.version);text(b,r.token);text(b,r.prior);number(b,r.installing,1);number(b,r.staticCode,1);number(b,r.game.contentVersion,4);text(b,r.game.contentIdentity);number(b,r.game.processId,8);number(b,r.hasResourceContext,1);if(r.hasResourceContext){text(b,r.resourceContext.version);number(b,r.resourceContext.contentVersion,4);text(b,r.resourceContext.contentIdentity);}number(b,r.changes.size(),4);for(const auto&c:r.changes){text(b,c.path);encodeState(b,c.before);encodeState(b,c.after);encodeState(b,c.original);number(b,c.owned,1);}const auto hash=mod_hash::bytes(b);b.insert(b.end(),hash.begin(),hash.end());return b;}
struct Reader{const Bytes&b;size_t p=0;bool ok=true;uint64_t number(unsigned n){if(n>b.size()-std::min(p,b.size())){ok=false;return 0;}uint64_t v=0;for(unsigned i=0;i<n;++i)v|=uint64_t(b[p++])<<(8*i);return v;}std::string text(size_t max){const auto n=number(2);if(!ok||n>max||n>b.size()-std::min(p,b.size())){ok=false;return{};}std::string s(b.begin()+p,b.begin()+p+n);p+=size_t(n);return s;}};
State decodeState(Reader&rd){State s;const auto exists=rd.number(1);s.exists=exists==1;s.size=rd.number(8);s.hash=rd.text(64);if(exists>1||(s.exists?(s.size>MaxFile||!hex(s.hash,64)):(s.size||!s.hash.empty())))rd.ok=false;return s;}
bool decode(const Bytes&b,Receipt&r,std::string&e){
    r={};if(b.size()<100||b.size()>MaxRecord||(std::memcmp(b.data(),"NMMODS01",8)&&std::memcmp(b.data(),"NMMODS02",8))){e="El recibo de mods no es válido.";return false;}const Bytes raw(b.begin(),b.end()-64);if(mod_hash::bytes(raw)!=std::string(b.end()-64,b.end())){e="El recibo de mods está dañado.";return false;}const bool modern=raw[7]=='2';Reader rd{raw,8};r.game.id=rd.number(8);r.game.fullBuildId=rd.text(64);r.game.buildId=r.game.fullBuildId.substr(0,16);r.game.buildVerified=hex(r.game.fullBuildId,64)&&hex(r.game.buildId,16)&&r.game.buildId!="0000000000000000";r.game.version=rd.text(32);r.game.versionKnown=!r.game.version.empty();r.token=rd.text(8);r.prior=rd.text(8);const auto kind=rd.number(1);r.installing=kind==1;uint64_t domain=0;if(modern){domain=rd.number(1);r.staticCode=domain==1;r.game.contentVersion=uint32_t(rd.number(4));r.game.contentIdentity=rd.text(64);r.game.processId=rd.number(8);const auto resource=rd.number(1);if(resource>1)rd.ok=false;r.hasResourceContext=resource==1;if(r.hasResourceContext){r.resourceContext.id=r.game.id;r.resourceContext.version=rd.text(32);r.resourceContext.versionKnown=true;r.resourceContext.contentVersion=uint32_t(rd.number(4));r.resourceContext.contentIdentity=rd.text(64);if(r.resourceContext.version.empty()||!hex(r.resourceContext.contentIdentity,64)||!gameValid(r.resourceContext,e))rd.ok=false;}}const auto count=rd.number(4);std::set<std::string> paths;uint64_t totals[3]{};
    if(!rd.ok||kind>1||domain>1||(modern&&(!hex(r.game.contentIdentity,64)||(r.staticCode&&!codeIdentity(r.game))))||(!modern&&!codeIdentity(r.game))||!serialValid(r.token)||(!r.prior.empty()&&!serialValid(r.prior))||r.prior==r.token||!count||count>MaxEntries||!gameValid(r.game,e)){e="La identidad o los límites del recibo de mods no son válidos.";return false;}
    for(size_t i=0;i<count;++i){Change c;c.path=rd.text(1024);c.before=decodeState(rd);c.after=decodeState(rd);c.original=decodeState(rd);const auto owned=rd.number(1);c.owned=owned==1;totals[0]+=c.before.size;totals[1]+=c.after.size;totals[2]+=c.original.size;if(!rd.ok||owned>1||(!r.installing&&c.owned)||!targetAllowed(c.path,r.game.id)||(r.staticCode&&!codePath(c.path)&&!same(c.before,c.after))||!paths.insert(upper(c.path)).second||totals[0]>MaxTotal||totals[1]>MaxTotal||totals[2]>MaxTotal){e="Una ruta o tamaño del recibo no es admisible.";return false;}r.changes.push_back(std::move(c));}
    if(modern&&r.installing&&std::any_of(r.changes.begin(),r.changes.end(),[](const Change&c){return c.owned&&!codePath(c.path);})&&!r.hasResourceContext){e="Falta la identidad original de los recursos conservados.";return false;}
    if(!rd.ok||rd.p!=raw.size()){e="El recibo está incompleto o contiene datos sobrantes.";return false;}return true;
}
std::string dir(const Receipt&r){return base(r.game.id)+"/"+r.token;}
std::string dataPath(const Receipt&r,size_t i,char type){return dir(r)+"/"+type+serial(unsigned(i+1))+".bin";}
bool loadReceipt(uint64_t id,const std::string&token,Receipt&r,std::string&e){if(!serialValid(token)){e="Identificador de recibo no válido.";return false;}Bytes b;bool exists=false;if(!read(base(id)+"/"+token+"/receipt.bin",b,exists,e,MaxRecord)||!exists){if(e.empty())e="Falta un recibo de la transacción de mods.";return false;}return decode(b,r,e)&&r.game.id==id&&r.token==token;}
std::string phaseText(const std::string&phase){const auto prefix="NMMODS-PHASE1\n"+phase+"\n";return prefix+mod_hash::shaText(prefix)+"\n";}
bool phase(const Receipt&r,std::string&value,std::string&e){
    value.clear();std::set<std::string> complete;
    for(const char*p:{"ready","committed","rolledback"}){Bytes b;bool exists=false;if(!read(dir(r)+"/phase-"+p+".txt",b,exists,e,256))return false;if(!exists)continue;const auto expected=phaseText(p);const std::string text(b.begin(),b.end());if(text==expected)complete.insert(p);else if(text.size()>=expected.size()||expected.compare(0,text.size(),text)!=0){e="El estado de la transacción está dañado.";return false;}}
    if(!complete.count("ready")||(complete.count("committed")&&complete.count("rolledback"))){e="Falta un estado válido de la transacción.";return false;}
    value=complete.count("committed")?"committed":complete.count("rolledback")?"rolledback":"ready";return true;
}
bool phaseSet(const Receipt&r,const char*p,std::string&e){
    const auto path=dir(r)+"/phase-"+p+".txt",expected=phaseText(p);Bytes current;bool exists=false;if(!read(path,current,exists,e,256))return false;const std::string text(current.begin(),current.end());if(exists&&text==expected)return commit(e);if(exists&&(text.size()>=expected.size()||expected.compare(0,text.size(),text)!=0)){e="Un estado de la transacción cambió; se conserva.";return false;}if(exists&&!eraseRegular(path,e))return false;return writeNew(path,Bytes(expected.begin(),expected.end()),e)&&commit(e);
}
bool verifyStored(const Receipt&r,size_t i,char type,const State&s,Bytes*body,std::string&e){State now;if(!actual(dataPath(r,i,type),now,body,e))return false;if(!same(now,s)){e="Una copia privada del mod cambió o falta. Se conserva la transacción.";return false;}return true;}
bool copyStored(const Receipt&old,size_t from,char type,const Receipt&next,size_t to,char destination,const State&expected,std::string&e){if(!verifyStored(old,from,type,expected,nullptr,e))return false;if(!expected.exists)return true;const auto src=dataPath(old,from,type),dst=dataPath(next,to,destination);bool exists=false;struct stat st{};if(!parent(dst,true,exists,e)||!status(dst,st,exists,e)||exists){if(e.empty())e="La copia privada de conservación ya existe.";return false;}int readFlags=O_RDONLY,writeFlags=O_WRONLY|O_CREAT|O_EXCL;
#ifdef O_NOFOLLOW
readFlags|=O_NOFOLLOW;writeFlags|=O_NOFOLLOW;
#endif
int input=open((disk()+"/"+src).c_str(),readFlags);if(input<0){e="No se pudo abrir el respaldo previo.";return false;}int output=open((disk()+"/"+dst).c_str(),writeFlags,0600);if(output<0){close(input);e="No se pudo preparar el respaldo conservado.";return false;}std::array<uint8_t,65536>b{};mod_hash::Sha256 hash;uint64_t total=0;bool ok=true;for(;;){auto n=::read(input,b.data(),b.size());if(n<0){ok=false;break;}if(!n)break;total+=uint64_t(n);if(total>expected.size){ok=false;break;}hash.add(b.data(),size_t(n));size_t at=0;while(at<size_t(n)){auto written=::write(output,b.data()+at,size_t(n)-at);if(written<=0){ok=false;break;}at+=size_t(written);}if(!ok)break;}if(fsync(output))ok=false;if(close(output))ok=false;if(close(input))ok=false;if(!ok||total!=expected.size||hash.finish()!=expected.hash){e="El respaldo conservado no coincide con su recibo.";return false;}return verifyStored(next,to,destination,expected,nullptr,e);}
bool store(const Receipt&r,size_t i,char type,const State&s,const Bytes&b,std::string&e){if(!same(s,state(b,s.exists))){e="No coincide la copia previa del mod.";return false;}return !s.exists||writeNew(dataPath(r,i,type),b,e);}
bool allStored(const Receipt&r,std::string&e){for(size_t i=0;i<r.changes.size();++i){const auto&c=r.changes[i];if(!verifyStored(r,i,'b',c.before,nullptr,e)||!verifyStored(r,i,'a',c.after,nullptr,e)||!verifyStored(r,i,'o',c.original,nullptr,e))return false;}return true;}
bool targetState(const Receipt&,const Change&c,bool recovering,std::string&e){State now;if(!actual(c.path,now,nullptr,e))return false;if(same(now,c.before)||same(now,c.after)||(recovering&&!now.exists))return true;e="Un archivo de mods cambió fuera de esta operación. No se sobrescribe: "+c.path;return false;}
bool replaceTarget(const Receipt&r,size_t i,const State&wanted,char stored,bool recovering,std::string&e){
    const auto&c=r.changes[i];State now;if(!actual(c.path,now,nullptr,e)||!targetState(r,c,recovering,e))return false;
    const auto temp=c.path+".ninmagic-mods-"+r.token+".tmp";Bytes bytes;if(!verifyStored(r,i,stored,wanted,&bytes,e))return false;
    Bytes existing;bool has=false;if(!read(temp,existing,has,e))return false;
    if(has){Bytes before,after;if(!verifyStored(r,i,'b',c.before,&before,e)||!verifyStored(r,i,'a',c.after,&after,e))return false;const auto prefix=[&](const Bytes&expected,const State&s){return s.exists&&existing.size()<=expected.size()&&std::equal(existing.begin(),existing.end(),expected.begin());};if(!prefix(before,c.before)&&!prefix(after,c.after)){e="Un archivo temporal del mod cambió; se conserva.";return false;}}
    if(same(now,wanted))return (!has||eraseRegular(temp,e))&&commit(e);
    if(has&&(!wanted.exists||existing!=bytes)){if(!eraseRegular(temp,e))return false;has=false;}
    if(wanted.exists&&!has&&!writeNew(temp,bytes,e))return false;
    // Check again immediately before unlink/rename. Only hashes in the journal
    // and an absent interrupted destination are accepted during recovery.
    if(!targetState(r,c,recovering,e))return false;
    if(!eraseRegular(c.path,e))return false;
    if(fail("after-target-unlink")){e="Fallo simulado antes del renombrado de un mod.";return false;}
    if(wanted.exists&&std::rename((disk()+"/"+temp).c_str(),(disk()+"/"+c.path).c_str())!=0){e="No se pudo activar un archivo de mod; conserva su recibo para recuperar.";return false;}
    if(!actual(c.path,now,nullptr,e)||!same(now,wanted)){e="El archivo aplicado no coincide con el mod verificado.";return false;}return commit(e);
}
bool finalize(const Receipt&r,std::string&e){std::string active;if(!pointer(r.game.id,"active.txt",active,e))return false;if(!active.empty()&&active!=r.prior&&active!=r.token){e="El recibo activo cambió durante la transacción.";return false;}for(const auto&c:r.changes){State now;if(!actual(c.path,now,nullptr,e)||!same(now,c.after)){e="La operación confirmada no coincide con los archivos actuales.";return false;}}return setPointer(r.game.id,"active.txt",r.installing?r.token:std::string{},e)&&setPointer(r.game.id,"pending.txt",{},e);}
bool rollback(const Receipt&r,const Game&expected,bool live,std::string&e){if(!allStored(r,e))return false;for(const auto&c:r.changes)if(!targetState(r,c,true,e))return false;for(size_t i=0;i<r.changes.size();++i)if(!same(r.changes[i].before,r.changes[i].after)&&(!context(expected,live,e)||!replaceTarget(r,i,r.changes[i].before,'b',true,e)))return false;return setPointer(r.game.id,"active.txt",r.prior,e)&&phaseSet(r,"rolledback",e)&&setPointer(r.game.id,"pending.txt",{},e);}
bool recoverPending(const Game&expected,std::string&e){std::string pending;if(!pointer(expected.id,"pending.txt",pending,e)||pending.empty())return e.empty();Receipt r;std::string state;if(!loadReceipt(expected.id,pending,r,e)||!phase(r,state,e)||!context(expected,r.staticCode&&expected.running,e))return false;if(state=="committed")return allStored(r,e)&&finalize(r,e);if(state=="rolledback")return setPointer(expected.id,"active.txt",r.prior,e)&&setPointer(expected.id,"pending.txt",{},e);return rollback(r,expected,r.staticCode&&expected.running,e);}
bool activeReceipt(uint64_t id,Receipt&r,bool&exists,std::string&e){std::string active;exists=false;if(!pointer(id,"active.txt",active,e)||active.empty())return e.empty();if(!loadReceipt(id,active,r,e))return false;std::string state;if(!phase(r,state,e)||state!="committed"||!r.installing){e="El recibo activo no describe una instalación terminada.";return false;}exists=true;return true;}
bool list(const std::string&p,std::vector<std::string>&names,std::string&e){bool exists=false;if(!folders(p,false,exists,e)||!exists)return e.empty();DIR*d=opendir((disk()+"/"+p).c_str());if(!d){e="No se pudo enumerar la carpeta de mods.";return false;}bool ok=true;errno=0;while(auto*entry=readdir(d)){std::string n=entry->d_name;if(n=="."||n=="..")continue;if(!component(n)||names.size()>=20000){ok=false;break;}names.push_back(n);errno=0;}if(errno)ok=false;if(closedir(d)!=0)ok=false;if(!ok){e="La carpeta de mods contiene nombres no admitidos o demasiadas entradas.";return false;}std::sort(names.begin(),names.end());return true;}
bool allocate(Receipt&r,std::string&e){bool exists=false;if(!folders(base(r.game.id),true,exists,e))return false;std::vector<std::string> names;if(!list(base(r.game.id),names,e))return false;unsigned highest=0;for(const auto&n:names)if(serialValid(n))highest=std::max(highest,unsigned(std::strtoul(n.c_str(),nullptr,10)));if(highest>=99999999){e="Se agotó el contador de copias de mods.";return false;}r.token=serial(highest+1);return folders(dir(r),true,exists,e);}
bool sameBuildName(std::string s,const std::string&full){s=upper(s);if(s.size()<6||s.size()>68||s.substr(s.size()-4)!=".IPS")return false;s.resize(s.size()-4);if(s.size()%2||!hex(s,s.size()))return false;s.resize(64,'0');return s==upper(full);}
bool foreignScan(const Game&g,const std::string&p,unsigned depth,size_t&count,std::string&e){if(depth>3){e="La estructura de parches supera la profundidad admitida.";return false;}const auto canonical=upper("atmosphere/exefs_patches/NinMagicMods_"+titleId(g.id)+"/"+upper(g.fullBuildId)+".ips");std::vector<std::string> names;if(!list(p,names,e))return false;for(const auto&n:names){if(++count>20000){e="Hay demasiados archivos de parches para verificar conflictos.";return false;}const auto path=p+"/"+n;struct stat st{};bool exists=false;if(!status(path,st,exists,e)||!exists)return false;if(S_ISDIR(st.st_mode)){if(!foreignScan(g,path,depth+1,count,e))return false;}else if(sameBuildName(n,g.fullBuildId)&&upper(path)!=canonical){e="Hay un parche ExeFS externo para este Build ID. Retíralo con su herramienta antes de instalar otra selección: "+path;return false;}}return true;}
bool retainedResourcesMatch(const Receipt&r,const Game&g,std::string&e){const bool owned=std::any_of(r.changes.begin(),r.changes.end(),[](const Change&c){return c.owned&&!codePath(c.path);});if(!owned)return true;if(!r.hasResourceContext||!r.resourceContext.versionKnown||!g.versionKnown||r.resourceContext.version!=g.version||r.resourceContext.contentVersion!=g.contentVersion||r.resourceContext.contentIdentity!=g.contentIdentity){e="Hay recursos RomFS propios de otra versión o sin identidad comprobada. Cierra el juego y retíralos desde la aplicación antes de preparar IPS nuevos.";return false;}return true;}
bool verifyActive(const Receipt&r,std::string&e){for(size_t i=0;i<r.changes.size();++i)if(r.changes[i].owned){State now;if(!actual(r.changes[i].path,now,nullptr,e)||!same(now,r.changes[i].after)||!verifyStored(r,i,'o',r.changes[i].original,nullptr,e)){if(e.empty())e="Un mod propio o su copia anterior cambió. No se sobrescribe.";return false;}}return true;}
Outcome execute(const Game&expected,Receipt&r,const std::map<std::string,Bytes>&desired,const Receipt*old,const std::string&expectedFingerprint={}){
    Outcome out;std::string e;if(r.installing){if(!r.staticCode){r.hasResourceContext=true;r.resourceContext=expected;}else if(old){if(!retainedResourcesMatch(*old,expected,e)){out.message=e;return out;}r.hasResourceContext=old->hasResourceContext;r.resourceContext=old->resourceContext;}}if(r.changes.empty()||r.changes.size()>MaxEntries){out.message="El recibo de esta selección supera el límite del entorno. Usa la aplicación NinMagic Mods.";return out;}if(!allocate(r,e)){out.message=e;return out;}out.backupPath="sdmc:/"+dir(r);
    uint64_t totalBefore=0,totalAfter=0,totalOriginal=0;
    for(size_t i=0;i<r.changes.size();++i){auto&c=r.changes[i];
        if(r.installing&&old&&codePath(c.path)!=r.staticCode){const Change*prior=nullptr;size_t previous=0;for(size_t j=0;j<old->changes.size();++j)if(old->changes[j].owned&&old->changes[j].path==c.path){prior=&old->changes[j];previous=j;break;}if(!prior||!actual(c.path,c.before,nullptr,e)||!same(c.before,prior->after)){out.message=e.empty()?"Un mod conservado cambió fuera de la aplicación.":e;return out;}c.after=c.before;c.original=prior->original;c.owned=true;totalBefore+=c.before.size;totalAfter+=c.after.size;totalOriginal+=c.original.size;if(totalBefore>MaxTotal||totalAfter>MaxTotal||totalOriginal>MaxTotal||!copyStored(*old,previous,'a',r,i,'b',c.before,e)||!copyStored(*old,previous,'a',r,i,'a',c.after,e)||!copyStored(*old,previous,'o',r,i,'o',c.original,e)){out.message=e.empty()?"Los respaldos conservados superan sus límites.":e;return out;}continue;}
        Bytes before,after,original;if(!actual(c.path,c.before,&before,e)){out.message=e;return out;}auto wanted=desired.find(c.path);
        if(wanted!=desired.end()){after=wanted->second;c.after=state(after,true);c.owned=true;}
        const Change*prior=nullptr;size_t priorIndex=0;if(old)for(size_t j=0;j<old->changes.size();++j)if(old->changes[j].owned&&upper(old->changes[j].path)==upper(c.path)){prior=&old->changes[j];priorIndex=j;break;}
        if(prior){if(!same(c.before,prior->after)){out.message="Un mod propio cambió durante la revisión. No se sobrescribe.";return out;}c.original=prior->original;if(!verifyStored(*old,priorIndex,'o',c.original,&original,e)){out.message=e;return out;}if(wanted==desired.end()){if(r.installing&&codePath(c.path)!=r.staticCode){after=before;c.after=c.before;c.owned=true;}else{after=original;c.after=c.original;c.owned=false;}}}
        else {c.original=c.before;original=before;if(wanted==desired.end()){e="La transacción incluye una ruta ajena a la selección.";out.message=e;return out;}}
        totalBefore+=c.before.size;totalAfter+=c.after.size;totalOriginal+=c.original.size;if(totalBefore>MaxTotal||totalAfter>MaxTotal||totalOriginal>MaxTotal){out.message="La selección o su copia anterior supera 128 MiB.";return out;}
        if(!store(r,i,'b',c.before,before,e)||!store(r,i,'a',c.after,after,e)||!store(r,i,'o',c.original,original,e)){out.message=e;return out;}
    }
    const auto record=encode(r);if(record.size()>MaxRecord||!writeNew(dir(r)+"/receipt.bin",record,e)||!phaseSet(r,"ready",e)||!commit(e)){out.message=e.empty()?"No se pudo guardar el recibo completo.":e;return out;}
    // A full preflight after all backups and immediately before the first game
    // write binds this operation to the current effective executable and state.
    if(!context(expected,r.staticCode,e)){out.message=e;return out;}for(const auto&c:r.changes){State now;if(!actual(c.path,now,nullptr,e)||!same(now,c.before)){out.message=e.empty()?"Los archivos cambiaron después de la revisión.":e;return out;}}
    if(!expectedFingerprint.empty()){
        std::string snapshot=reviewIdentity(expected,r.prior);
        for(const auto&f:desired){const auto at=std::find_if(r.changes.begin(),r.changes.end(),[&](const Change&c){return c.path==f.first;});if(at==r.changes.end()){out.message="Cambió la selección revisada.";return out;}const auto&s=at->before;snapshot+=f.first+"\n"+std::to_string(s.exists)+"\n"+std::to_string(s.size)+"\n"+s.hash+"\n"+mod_hash::bytes(f.second)+"\n";}
        if(mod_hash::shaText(snapshot)!=expectedFingerprint){out.message="Los archivos cambiaron después de confirmar. Vuelve a revisar la selección.";return out;}
    }
    std::string active,pending;if(!pointer(r.game.id,"active.txt",active,e)||!pointer(r.game.id,"pending.txt",pending,e)||active!=r.prior||!pending.empty()){out.message=e.empty()?"Otra operación de mods cambió después de la revisión.":e;return out;}
    if(!setPointer(r.game.id,"pending.txt",r.token,e)){out.message=e;return out;}
    for(size_t i=0;i<r.changes.size();++i){if(same(r.changes[i].before,r.changes[i].after))continue;if(!context(expected,r.staticCode,e)||!replaceTarget(r,i,r.changes[i].after,'a',false,e)||((i==0)&&fail("after-first-write"))){if(e.empty())e="Fallo simulado después del primer cambio.";const auto reason=e;std::string restore;const bool restored=rollback(r,expected,r.staticCode,restore);out.message=reason+(restored?" Se recuperó el estado anterior.":" Conserva la copia y usa Retirar para recuperar: "+restore);return out;}++out.count;}
    if(fail("before-commit")){out.message="Operación pendiente de recuperación; los archivos y recibos se conservan.";return out;}
    if(!context(expected,r.staticCode,e)||!phaseSet(r,"committed",e)||!finalize(r,e)){out.message="Los archivos requieren completar su registro. Conserva la copia y usa Retirar: "+e;return out;}
    out.ok=true;out.message=r.installing?(r.staticCode?"Parches IPS guardados. Reinicia el juego para cargarlos; esta sesión no se ha modificado.":"Recursos RomFS instalados para la versión comprobada. Abre el juego para cargarlos."):"Se retiraron los mods propios y se restauraron sus archivos anteriores. Los archivos ajenos se conservaron.";return out;
}
}
#ifdef NMM_MOD_INSTALL_TEST
void setModInstallFailureForTest(const std::string&value){failurePoint=value;}
#endif
bool inspectInstalledMods(const Game&game,InstalledInfo&info,std::string&error){
    info={};error.clear();if(!gameValid(game,error))return false;std::string pending;if(!pointer(game.id,"pending.txt",pending,error))return false;Receipt active;bool has=false;if(!activeReceipt(game.id,active,has,error))return false;
    if(has){info.exists=true;info.receipt=active.token;for(const auto&c:active.changes)if(c.owned)++info.files;if(!verifyActive(active,error)){info.detail=error;return false;}}
    if(!pending.empty()){Receipt r;std::string state;if(!loadReceipt(game.id,pending,r,error)||!phase(r,state,error))return false;info.exists=true;info.detail="Hay una operación interrumpida. Retirar recuperará primero su estado comprobado.";}
    if(!info.exists){bool exists=false;if(!folders("atmosphere/contents/"+titleId(game.id)+"/romfs",false,exists,error))return false;if(exists){info.exists=true;info.detail="Hay archivos RomFS previos. Solo se sustituirán las rutas de la selección confirmada.";}}
    info.valid=true;if(info.detail.empty())info.detail=has?"Selección propia guardada y copias verificadas.":"No hay una selección propia instalada.";return true;
}
bool inspectPreparedMods(const Game&game,const std::vector<ModPayload>&payloads,InstalledInfo&info,std::string&error){
    if(!inspectInstalledMods(game,info,error))return false;
    std::string pending;if(!pointer(game.id,"pending.txt",pending,error))return false;if(!pending.empty()){error="Recupera primero la operación interrumpida mediante Retirar.";return false;}
    ModPayload combined;if(!combineMods(game,payloads,combined,error)||!context(game,!combined.ips.empty(),error))return false;Receipt prior;bool priorExists=false;if(!combined.ips.empty()&&(!activeReceipt(game.id,prior,priorExists,error)||(priorExists&&!retainedResourcesMatch(prior,game,error))))return false;
    std::map<std::string,Bytes> desired;std::set<std::string> paths;
    for(const auto&f:combined.files){if(!targetAllowed(f.path,game.id)||!paths.insert(upper(f.path)).second){error="Una ruta de la selección no es válida o está duplicada.";return false;}desired.emplace(f.path,f.bytes);}
    if(!combined.ips.empty()){size_t count=0;if(!foreignScan(game,"atmosphere/exefs_patches",0,count,error))return false;desired.emplace("atmosphere/exefs_patches/NinMagicMods_"+titleId(game.id)+"/"+upper(game.fullBuildId)+".ips",combined.ips);}
    std::string snapshot=reviewIdentity(game,info.receipt);
    unsigned collisions=0;for(const auto&f:desired){State now;if(!actual(f.first,now,nullptr,error))return false;if(now.exists)++collisions;snapshot+=f.first+"\n"+std::to_string(now.exists)+"\n"+std::to_string(now.size)+"\n"+now.hash+"\n"+mod_hash::bytes(f.second)+"\n";}
    info.exists=info.exists||collisions>0;info.fingerprint=mod_hash::shaText(snapshot);info.files=unsigned(desired.size());info.valid=true;if(collisions)info.detail=std::to_string(collisions)+" archivos de la selección tienen contenido anterior. Se copiarán antes de reemplazarlos.";return true;
}
Outcome installMods(const Game&game,const std::vector<ModPayload>&payloads,bool replaceExisting,const std::string&expectedFingerprint){
    Outcome out;std::string error;ModPayload combined;if(!combineMods(game,payloads,combined,error)||!context(game,!combined.ips.empty(),error)||!recoverPending(game,error)){out.message=error;return out;}
    if(!expectedFingerprint.empty()){InstalledInfo reviewed;if(!inspectPreparedMods(game,payloads,reviewed,error)||reviewed.fingerprint!=expectedFingerprint){out.message=error.empty()?"Los archivos o la selección cambiaron después de la revisión. Vuelve a confirmar.":error;return out;}}
    Receipt active;bool has=false;if(!activeReceipt(game.id,active,has,error)||(has&&!verifyActive(active,error))){out.message=error;return out;}if(has&&!combined.ips.empty()&&!retainedResourcesMatch(active,game,error)){out.message=error;return out;}if(has&&!replaceExisting){out.message="Hay mods propios instalados. Revisa y confirma su sustitución antes de instalar otra selección.";return out;}
    if(!combined.ips.empty()){size_t count=0;if(!foreignScan(game,"atmosphere/exefs_patches",0,count,error)){out.message=error;return out;}}
    std::map<std::string,Bytes> desired;std::set<std::string> folded;
    for(const auto&f:combined.files){if(!targetAllowed(f.path,game.id)||f.bytes.size()>MaxFile||f.bytes.empty()||!folded.insert(upper(f.path)).second){out.message="Una ruta RomFS seleccionada no es válida o está duplicada.";return out;}desired.emplace(f.path,f.bytes);}
    if(!combined.ips.empty()){const auto path="atmosphere/exefs_patches/NinMagicMods_"+titleId(game.id)+"/"+upper(game.fullBuildId)+".ips";desired.emplace(path,combined.ips);}
    if(desired.empty()||desired.size()>MaxEntries){out.message="La selección no contiene archivos instalables o supera su límite.";return out;}
    Receipt plan;plan.game=game;plan.installing=true;plan.staticCode=!combined.ips.empty();plan.prior=has?active.token:std::string{};std::map<std::string,std::string> affected;
    for(const auto&f:desired){State current;if(!actual(f.first,current,nullptr,error)){out.message=error;return out;}bool owned=false;if(has)for(const auto&c:active.changes)if(c.owned&&upper(c.path)==upper(f.first))owned=true;if(current.exists&&!owned&&!replaceExisting){out.message="La selección reemplaza un archivo anterior. Revisa y confirma su copia antes de continuar: "+f.first;return out;}affected.emplace(upper(f.first),f.first);}
    if(has)for(const auto&c:active.changes)if(c.owned){auto p=affected.find(upper(c.path));if(p!=affected.end()&&p->second!=c.path){out.message="Dos rutas difieren solo en mayúsculas. No se puede aplicar esa selección en FAT.";return out;}affected.emplace(upper(c.path),c.path);}
    for(const auto&p:affected){Change c;c.path=p.second;plan.changes.push_back(std::move(c));}return execute(game,plan,desired,has?&active:nullptr,expectedFingerprint);
}
Outcome removeMods(const Game&game){
    Outcome out;std::string error;if(!context(game,false,error)||!recoverPending(game,error)){out.message=error;return out;}Receipt active;bool has=false;if(!activeReceipt(game.id,active,has,error)||(has&&!verifyActive(active,error))){out.message=error;return out;}if(!has){out.ok=true;out.message="No hay mods propios que retirar. Los archivos externos se conservan.";return out;}
    Receipt plan;plan.game=game;plan.prior=active.token;plan.installing=false;for(const auto&c:active.changes)if(c.owned){Change next;next.path=c.path;plan.changes.push_back(std::move(next));}if(plan.changes.empty()){out.message="El recibo activo no contiene archivos propios.";return out;}return execute(game,plan,{},&active);
}
}
