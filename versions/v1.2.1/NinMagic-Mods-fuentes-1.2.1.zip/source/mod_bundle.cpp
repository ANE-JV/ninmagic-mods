#include "mods.hpp"
#include "mod_identity.hpp"
#include "mod_policy.hpp"
#include <algorithm>
#include <cctype>
#include <cstring>
#include <map>

namespace nmm {
namespace {
#ifdef NMM_OVERLAY
constexpr size_t MaxInput=128*1024,MaxOutput=128*1024,MaxWrites=8*1024;
#else
constexpr size_t MaxInput=2*1024*1024,MaxOutput=2*1024*1024,MaxWrites=1024*1024;
#endif
struct Write {uint32_t address;uint8_t value,source;};
std::string upper(std::string s){for(char&c:s)c=char(std::toupper(static_cast<unsigned char>(c)));return s;}
bool hex(const std::string&s,size_t size){return s.size()==size&&std::all_of(s.begin(),s.end(),[](unsigned char c){return std::isxdigit(c)!=0;});}
bool identity(const Game&g){return g.id>=0x0100000000010000ULL&&g.buildVerified&&hex(g.buildId,16)&&hex(g.fullBuildId,64)&&upper(g.fullBuildId).substr(0,16)==upper(g.buildId)&&g.buildId!="0000000000000000";}
bool resources(const Game&g){return g.id>=0x0100000000010000ULL&&!(g.id&0xfff)&&g.versionKnown&&!g.version.empty()&&g.version.size()<=32&&!g.contentIdentity.empty()&&g.contentIdentity.size()<=128;}
bool sourceBuild(std::string source,const Game&g){if(source.size()<2||source.size()>64||source.size()%2)return false;if(!hex(source,source.size()))return false;source=upper(source);source.resize(64,'0');return source==upper(g.fullBuildId);}
void word32(std::vector<uint8_t>&b,uint32_t n){for(int i=3;i>=0;--i)b.push_back(uint8_t(n>>(8*i)));}
void word16(std::vector<uint8_t>&b,size_t n){b.push_back(uint8_t(n>>8));b.push_back(uint8_t(n));}
bool collect(const std::vector<uint8_t>&b,uint8_t source,std::vector<Write>&all,std::string&error){
    const bool wide=std::memcmp(b.data(),"IPS32",5)==0;const size_t offsetSize=wide?4:3;const char*end=wide?"EEOF":"EOF";size_t at=5;
    while(at<b.size()) {
        if(offsetSize<=b.size()-at&&std::memcmp(b.data()+at,end,offsetSize)==0)return at+offsetSize==b.size();
        if(offsetSize+2>b.size()-at){error="El registro del mod quedó incompleto.";return false;}
        uint32_t address=0;for(size_t i=0;i<offsetSize;++i)address=(address<<8)|b[at++];
        size_t count=(size_t(b[at])<<8)|b[at+1];at+=2;const bool rle=count==0;uint8_t value=0;
        if(rle){if(3>b.size()-at){error="El registro RLE del mod quedó incompleto.";return false;}count=(size_t(b[at])<<8)|b[at+1];at+=2;value=b[at++];}
        else if(count>b.size()-at){error="Faltan bytes de un mod seleccionado.";return false;}
        if(!count||address<0x100||uint64_t(address)+count>0x80000000ULL||all.size()+count>MaxWrites){error="La selección supera un MiB de escrituras estáticas o sus direcciones no son válidas. Selecciona menos mods.";return false;}
        for(size_t i=0;i<count;++i)all.push_back({address+uint32_t(i),rle?value:b[at+i],source});
        if(!rle)at+=count;
    }
    error="Falta el marcador final de un mod seleccionado.";return false;
}

}
bool combineStaticMods(const Game&game,const std::vector<ModPayload>&payloads,ModPayload&combined,std::string&error){
    error.clear();
    // Do not erase an input if a caller accidentally aliases its output slot.
    for(const auto&p:payloads)if(&p==&combined){error="El resultado combinado necesita un destino independiente de los mods originales.";return false;}
    combined={};
    if(!identity(game)||payloads.empty()||payloads.size()>32){error="Selecciona entre 1 y 32 mods para un Title ID y Build ID completo verificados.";return false;}
    size_t inputBytes=0;std::vector<Write> all;std::vector<std::string> names;
    for(size_t i=0;i<payloads.size();++i){const auto&p=payloads[i];
        if(!allowsConsoleMod(p.entry)){error="La selección incluye un mod sin origen verificado para Nintendo Switch física.";return false;}
        if((!p.entry.version.empty()&&(!game.versionKnown||game.version!=p.entry.version))||!p.compatible||!identity(p.game)||p.game.id!=game.id||upper(p.game.buildId)!=upper(game.buildId)||upper(p.game.fullBuildId)!=upper(game.fullBuildId)||canonicalModApplicationId(p.entry.titleId)!=game.id||!sourceBuild(p.buildId,game)||(p.entry.format!=ModFormat::Ips&&p.entry.format!=ModFormat::Pchtxt)){
            error="Un mod seleccionado no coincide con el Title ID y Build ID completo del juego, o no es un parche estático compatible.";return false;
        }
        if(p.entry.name.empty()||p.entry.name.size()>1024||std::any_of(p.entry.name.begin(),p.entry.name.end(),[](unsigned char c){return c<32||c==127;})){error="Un mod seleccionado no tiene un nombre válido para mostrar sus efectos.";return false;}
        if(p.ips.size()>MaxInput-inputBytes){error="Los archivos seleccionados superan 2 MiB. Selecciona menos mods.";return false;}inputBytes+=p.ips.size();
        if(!validateModIps(p.ips,error)||!collect(p.ips,uint8_t(i),all,error))return false;
        names.push_back(p.entry.name);
    }
    std::sort(all.begin(),all.end(),[](const Write&a,const Write&b){return a.address<b.address||(a.address==b.address&&a.value<b.value);});
    size_t count=0;
    for(const auto&w:all){
        if(count&&all[count-1].address==w.address){
            if(all[count-1].value!=w.value){error="No se pueden combinar '"+names[all[count-1].source]+"' y '"+names[w.source]+"': escriben valores distintos en la misma dirección. Elige una variante.";return false;}
            continue;
        }
        all[count++]=w;
    }
    all.resize(count);
    if(all.empty()){error="La selección no contiene escrituras estáticas utilizables.";return false;}
    ModPayload result;result.game=game;result.buildId=upper(game.fullBuildId);result.names=std::move(names);
    result.entry.titleId=game.id;result.entry.buildId=result.buildId;result.entry.format=ModFormat::Ips;
    result.entry.name=std::to_string(payloads.size())+(payloads.size()==1?" mod seleccionado":" mods seleccionados");result.entry.source="Selección NinMagic";
    result.ips={'I','P','S','3','2'};
    for(size_t at=0;at<all.size();){
        size_t end=at+1;while(end<all.size()&&uint64_t(all[end-1].address)+1==all[end].address)++end;
        while(at<end){const uint32_t address=all[at].address;size_t n=std::min(size_t(65535),end-at);
            // The IPS32 end marker cannot also be a record's starting offset.
            // Move a chunk boundary back one known byte instead of inventing data.
            if(address==0x45454f46u){error="No se puede representar una dirección reservada del formato IPS32.";return false;}
            if(at+n<end&&all[at+n].address==0x45454f46u&&n>1)--n;
            if(result.ips.size()+6+n+4>MaxOutput){error="El resultado combinado supera el límite de 2 MiB.";return false;}
            word32(result.ips,address);word16(result.ips,n);for(size_t i=0;i<n;++i)result.ips.push_back(all[at+i].value);at+=n;
        }
    }
    result.ips.insert(result.ips.end(),{'E','E','O','F'});
    if(!validateModIps(result.ips,error))return false;
    result.entry.size=result.ips.size();result.compatible=true;
    result.detail="Selección combinada sin escrituras incompatibles detectadas. Se cargará al reiniciar el juego.";combined=std::move(result);return true;
}
bool combineMods(const Game&game,const std::vector<ModPayload>&payloads,ModPayload&combined,std::string&error){
    error.clear();for(const auto&p:payloads)if(&p==&combined){error="Se necesita un resultado independiente de los originales.";return false;}
    combined={};if(game.id<0x0100000000010000ULL||(game.id&0xfff)||payloads.empty()||payloads.size()>32){error="Selecciona entre 1 y 32 mods de este juego verificado.";return false;}
    bool hasCode=false,hasResources=false;for(const auto&p:payloads){hasCode|=p.entry.format==ModFormat::Ips||p.entry.format==ModFormat::Pchtxt;hasResources|=p.entry.format==ModFormat::Romfs;}
    if(hasCode&&hasResources){error="Instala los parches IPS y los paquetes RomFS por separado. Los IPS se preparan con el juego abierto; RomFS requiere cerrarlo.";return false;}
    if((hasCode&&!identity(game))||(hasResources&&!resources(game))){error=hasCode?"Abre el juego para comprobar el Build ID completo del parche.":"RomFS requiere Title ID, versión y contenidos instalados comprobados.";return false;}
    std::vector<ModPayload> patches;std::map<std::string,std::vector<uint8_t>> romfs;size_t total=0;
    const auto prefix=std::string("atmosphere/contents/")+titleId(game.id)+"/romfs/";
    for(const auto&p:payloads){
        if(!allowsConsoleMod(p.entry)){error="La selección incluye un mod sin origen verificado para Nintendo Switch física.";return false;}
        if(!p.compatible||canonicalModApplicationId(p.entry.titleId)!=game.id||p.game.id!=game.id||p.game.version!=game.version||p.game.versionKnown!=game.versionKnown||p.game.contentVersion!=game.contentVersion||p.game.contentIdentity!=game.contentIdentity||(!p.entry.buildId.empty()&&(!identity(game)||!sourceBuild(p.entry.buildId,game)))||(!p.entry.version.empty()&&(!game.versionKnown||p.entry.version!=game.version))){error="Un mod no corresponde al juego y versión comprobados.";return false;}
        if(hasCode&&(!identity(p.game)||upper(p.game.fullBuildId)!=upper(game.fullBuildId)||p.game.processId!=game.processId)){error="La identidad del proceso del parche cambió.";return false;}
        if(p.entry.name.empty()||p.entry.name.size()>1024||std::any_of(p.entry.name.begin(),p.entry.name.end(),[](unsigned char c){return c<32||c==127;})){error="Un mod no declara un nombre válido para revisar.";return false;}
        if(p.entry.format==ModFormat::Romfs){
            if(!game.versionKnown||p.entry.version.empty()||p.entry.version!=game.version||p.files.empty()||!p.ips.empty()){error="El RomFS no declara esta versión exacta para Switch.";return false;}
            for(const auto&f:p.files){
                if(f.path.rfind(prefix,0)!=0||f.path.size()<=prefix.size()||f.path.find('\\')!=f.path.npos||f.path.find(':')!=f.path.npos||f.path.find("//")!=f.path.npos||f.path.find("/../")!=f.path.npos||f.path.find("/./")!=f.path.npos||f.path.back()=='/'||f.bytes.empty()||f.bytes.size()>32*1024*1024){error="Una ruta o archivo RomFS no es válido.";return false;}
                for(unsigned char c:f.path)if(c<32||c==127){error="La ruta RomFS contiene controles.";return false;}
                auto old=romfs.find(f.path);if(old!=romfs.end()){if(old->second!=f.bytes){error="Dos mods modifican el mismo archivo RomFS con contenido distinto. Elige una variante.";return false;}continue;}
                if(total>128*1024*1024-f.bytes.size()||romfs.size()>=4096){error="La selección RomFS supera sus límites de memoria.";return false;}
                total+=f.bytes.size();romfs.emplace(f.path,f.bytes);
            }
        }else if(p.entry.format==ModFormat::Pchtxt||p.entry.format==ModFormat::Ips){if(!p.files.empty()){error="Un parche estático contiene archivos RomFS inesperados.";return false;}patches.push_back(p);}
        else {error="Formato de mod no instalable.";return false;}
    }
    ModPayload result;if(!patches.empty()&&!combineStaticMods(game,patches,result,error))return false;
    result.game=game;result.buildId=upper(game.fullBuildId);result.entry.titleId=game.id;result.entry.buildId=result.buildId;result.entry.version=game.version;result.entry.name="Selección NinMagic Mods";result.entry.source="NinMagic Mods";
    for(auto&f:romfs)result.files.push_back({f.first,std::move(f.second)});
    result.names.clear();for(const auto&p:payloads)result.names.push_back(p.entry.name);
    result.compatible=true;result.detail="Selección validada sin conflictos estáticos detectados; se cargará al iniciar el juego.";combined=std::move(result);return true;
}

}
