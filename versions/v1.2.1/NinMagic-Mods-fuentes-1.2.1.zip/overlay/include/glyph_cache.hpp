#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>

namespace nmm::overlay {
// A fixed index avoids unbounded unordered_map nodes and bucket growth. Its
// own storage is included in Limit; bitmap bytes are reserved before rasterizing.
template<class Glyph,std::size_t Slots=512,std::size_t Limit=128*1024>
class BoundedGlyphCache {
    struct Entry {std::uint64_t key=0;Glyph glyph{};void* userdata=nullptr;std::size_t bytes=0;bool occupied=false;};
    std::array<Entry,Slots> entries_{};
    using Release=void(*)(Glyph&,void*);
    Release release_;
    std::size_t bytes_=0,next_=0;
    void erase(Entry&entry){if(!entry.occupied)return;release_(entry.glyph,entry.userdata);bytes_-=entry.bytes;entry=Entry{};}
public:
    explicit BoundedGlyphCache(Release release):release_(release){static_assert(Slots>0&&sizeof(BoundedGlyphCache)<Limit,"Glyph index must fit its total memory limit");}
    BoundedGlyphCache(const BoundedGlyphCache&)=delete;
    BoundedGlyphCache&operator=(const BoundedGlyphCache&)=delete;
    ~BoundedGlyphCache(){clear();}
    static constexpr std::size_t fixedBytes(){return sizeof(BoundedGlyphCache);}
    static constexpr std::size_t bitmapLimit(){return Limit-fixedBytes();}
    std::size_t retainedBytes()const{return fixedBytes()+bytes_;}
    std::size_t entries()const{std::size_t n=0;for(const auto&e:entries_)if(e.occupied)++n;return n;}
    Glyph*find(std::uint64_t key){for(auto&e:entries_)if(e.occupied&&e.key==key)return &e.glyph;return nullptr;}
    Glyph*reserve(std::uint64_t key,std::size_t bitmapBytes,void*userdata){
        if(auto*existing=find(key))return existing;
        if(bitmapBytes>bitmapLimit())return nullptr;
        for(;;){
            Entry*free=nullptr;for(auto&e:entries_)if(!e.occupied){free=&e;break;}
            if(free&&bitmapBytes<=bitmapLimit()-bytes_){free->key=key;free->userdata=userdata;free->bytes=bitmapBytes;free->occupied=true;bytes_+=bitmapBytes;return &free->glyph;}
            erase(entries_[next_]);next_=(next_+1)%Slots;
        }
    }
    void clear(){for(auto&e:entries_)erase(e);next_=0;}
};
inline bool glyphBitmapBytes(int x0,int y0,int x1,int y1,std::size_t&bytes){
    bytes=0;const auto width=std::int64_t(x1)-std::int64_t(x0),height=std::int64_t(y1)-std::int64_t(y0);
    if(width<0||height<0||width>std::numeric_limits<int>::max()||height>std::numeric_limits<int>::max())return false;
    if(height&&std::uint64_t(width)>std::numeric_limits<std::size_t>::max()/std::uint64_t(height))return false;
    bytes=std::size_t(width)*std::size_t(height);return true;
}
}
