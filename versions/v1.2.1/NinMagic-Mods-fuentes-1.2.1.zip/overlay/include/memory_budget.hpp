#pragma once
#include <cstdint>
#include <string>
#ifdef __SWITCH__
#include <malloc.h>
extern "C" {extern char *fake_heap_start;extern char *fake_heap_end;}
#endif
namespace nmm::overlay {
// These are incremental costs after the renderer, fonts and worker already
// exist. The UI may grow its glyph cache concurrently, so keep a separate
// margin. They do not describe the loader's configured (code + heap) region.
enum class MemoryPhase {Git,GameBanana,Prepare,Transfer,Combine};
struct MemoryPlan {uint64_t required;const char *label;};
inline constexpr uint64_t MemoryReserve=256*1024;
inline constexpr MemoryPlan memoryPlan(MemoryPhase phase){
 switch(phase){
  case MemoryPhase::Git:return {640*1024,"Fuentes Switch"};
  case MemoryPhase::GameBanana:return {768*1024,"GameBanana"};
  case MemoryPhase::Prepare:return {640*1024,"Revisar IPS"};
  case MemoryPhase::Transfer:return {384*1024,"Descarga HTTPS"};
  case MemoryPhase::Combine:return {384*1024,"Combinar IPS"};
 }
 return {UINT64_MAX,"Operación desconocida"};
}
struct HeapObservation {uintptr_t begin=0,end=0;uint64_t arena=0,used=0,free=0;};
struct HeapCapacity {bool valid=false;uint64_t total=0,used=0,available=0;};
inline HeapCapacity heapCapacity(const HeapObservation&o){
 HeapCapacity result;
 // fake_heap_start/end are initialized by libnx for BOTH OverrideHeap and
 // svcSetHeapSize. They remain bounds; _sbrk_r has a different moving cursor.
 if(!o.begin||o.end<=o.begin)return result;
 const auto total=uint64_t(o.end-o.begin);
 if(o.arena>total||o.used>o.arena||o.free>o.arena-o.used)return result;
 result.valid=true;result.total=total;result.used=o.used;
 // Unrequested sbrk space plus known allocator free chunks. Any unexplained
 // allocator accounting difference stays unavailable instead of being guessed.
 result.available=(total-o.arena)+o.free;return result;
}
// Retained for pure arithmetic users. No overflowing total/reserve additions.
inline bool withinMemoryBudget(uint64_t total,uint64_t used,uint64_t required,uint64_t reserve=512*1024){return total&&used<=total&&required<=total-used&&reserve<=total-used-required;}
inline bool admitsMemory(const HeapCapacity&memory,MemoryPhase phase){const auto need=memoryPlan(phase).required;return memory.valid&&need<=memory.available&&MemoryReserve<=memory.available-need;}
inline std::string memoryDiagnostic(const HeapCapacity&memory,MemoryPhase phase){
 const auto plan=memoryPlan(phase);
 if(!memory.valid)return std::string(plan.label)+": no se pudo comprobar el heap real. Se conserva la lista; usa la aplicación.";
 return std::string(plan.label)+": libres "+std::to_string(memory.available/1024)+" KiB; necesita "+std::to_string(plan.required/1024)+" + reserva "+std::to_string(MemoryReserve/1024)+" KiB. Heap "+std::to_string(memory.total/1024)+", uso "+std::to_string(memory.used/1024)+" KiB. Usa la aplicación.";
}
#if defined(NMM_OVERLAY_MEMORY_TEST)
// Tests inject actual-looking allocator/range snapshots, not a trusted boolean.
HeapObservation observeOverlayHeap();
#elif defined(__SWITCH__)
inline HeapObservation observeOverlayHeap(){const auto m=mallinfo();return {reinterpret_cast<uintptr_t>(fake_heap_start),reinterpret_cast<uintptr_t>(fake_heap_end),m.arena,m.uordblks,m.fordblks};}
#endif
inline bool checkMemoryBudget(MemoryPhase phase,std::string&error){
#if defined(__SWITCH__) || defined(NMM_OVERLAY_MEMORY_TEST)
 const auto memory=heapCapacity(observeOverlayHeap());if(!admitsMemory(memory,phase)){error=memoryDiagnostic(memory,phase);return false;}
#else
 (void)phase;(void)error;
#endif
 return true;
}
}
