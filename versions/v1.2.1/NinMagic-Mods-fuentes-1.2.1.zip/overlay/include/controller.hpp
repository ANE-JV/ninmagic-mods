#pragma once
#include "model.hpp"
namespace nmm::overlay {
struct Snapshot {Game game;std::vector<ModEntry>items;size_t highlighted=0,firstItem=0,totalItems=0,selectedCount=0;bool busy=false,searching=false,applying=false,initialized=false,ready=false,lastSaveKnown=false,lastSaveOk=false,prepared=false,replacing=false;unsigned preparedFiles=0;std::string status,error,lastSave,review;};
bool init(std::string&error);void shutdown();Snapshot snapshot();
bool refresh();bool search();bool move(int delta);bool toggle(size_t index);bool prepare();bool apply();bool save();bool clear();void cancel();bool shouldCancel();
}
