#include "update_network.hpp"
#include "https_lite.hpp"
#include "controller.hpp"
#include "memory_budget.hpp"
#include "mod_policy.hpp"
#include <algorithm>
namespace nmm { namespace {
bool privatePath(const std::string&p){if(p.rfind("sdmc:/config/NinMagicMods/",0)!=0||p.find('\\')!=p.npos||p.find(':',5)!=p.npos)return false;size_t at=6;while(at<p.size()){auto n=p.find('/',at);auto part=p.substr(at,n==p.npos?n:n-at);if(part.empty()||part=="."||part=="..")return false;if(n==p.npos)break;at=n+1;}return true;}
bool run(const std::string&u,const std::string&p,uint64_t limit,std::string&e){if(!privatePath(p)||!limit||limit>3ULL*1024*1024){e="El overlay solo descarga metadatos o parches pequeños en su caché privada.";return false;}if(!overlay::checkMemoryBudget(overlay::MemoryPhase::Transfer,e))return false;https_lite::Response response;const bool ok=https_lite::download(u,p,response,e,false,limit,overlay::shouldCancel);
 // Parse the downloaded file after returning the TLS/BSD transfer pool.
 https_lite::shutdown();return ok;}
}
bool downloadModHttps(const std::string&u,const std::string&p,uint64_t maximum,std::string&e){const std::string api="https://api.github.com/repos/",content="https://raw.githubusercontent.com/";const bool tree=u.rfind(api,0)==0&&u.find("/git/trees/")!=u.npos;const bool raw=u.rfind(content,0)==0;const auto offset=tree?api.size():raw?content.size():0;const auto slash=offset?u.find('/',offset):u.npos,end=slash==u.npos?u.npos:u.find('/',slash+1);if(!offset||end==u.npos||!consoleRepositoryBranch(u.substr(offset,end-offset))){e="Esta fuente no acredita mods para Nintendo Switch física.";return false;}const uint64_t cap=tree?3ULL*1024*1024:128ULL*1024;return run(u,p,std::min(maximum,cap),e);}
bool downloadGameBananaHttps(const std::string&,const std::string&,uint64_t,std::string&e){e="GameBanana no acredita un destino de Nintendo Switch física; consulta desactivada.";return false;}
void updateNetworkExit(){https_lite::shutdown();}
}
