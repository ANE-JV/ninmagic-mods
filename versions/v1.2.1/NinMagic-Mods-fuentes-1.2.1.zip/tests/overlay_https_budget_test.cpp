#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include <cstddef>
#include <cstdlib>
#include <new>
#include <cstdio>
namespace budget {
struct alignas(std::max_align_t) Block{size_t size;bool tracked;};
bool enabled=false;size_t live=0,peak=0;
}
void*operator new(size_t n){auto*p=static_cast<budget::Block*>(std::malloc(sizeof(budget::Block)+n));if(!p)throw std::bad_alloc();p->size=n;p->tracked=budget::enabled;if(p->tracked){budget::live+=n;if(budget::live>budget::peak)budget::peak=budget::live;}return p+1;}
void operator delete(void*p)noexcept{if(!p)return;auto*b=static_cast<budget::Block*>(p)-1;if(b->tracked)budget::live-=b->size;std::free(b);}
void*operator new[](size_t n){return ::operator new(n);}void operator delete[](void*p)noexcept{::operator delete(p);}void operator delete(void*p,size_t)noexcept{::operator delete(p);}void operator delete[](void*p,size_t)noexcept{::operator delete(p);}
#define NMM_HTTPS_LITE_TEST
#include "../overlay/source/https_lite.cpp"
int main(){
    using namespace nmm::https_lite;
    // Prebuilt test input is not owned by the transport. Include all allocations
    // the transport makes while parsing a maximum header and near-maximum URL.
    const std::string wire="HTTP/1.1 200 OK\r\nX-Long: "+std::string(32600,'x')+"\r\nContent-Length: 0\r\n\r\n";
    size_t at=0;detail::testOpen=[&](const detail::Url&,std::string&){at=0;return true;};detail::testSend=[](const std::string&,std::string&){return true;};
    detail::testRead=[&](void*p,size_t cap,std::string&){auto n=std::min(cap,wire.size()-at);std::memcpy(p,wire.data()+at,n);at+=n;return int(n);};
    const std::string url="https://example.com/"+std::string(8160,'a');Response response;std::string error;
    budget::enabled=true;const bool ok=download(url,"",response,error,true);budget::enabled=false;
    std::printf("https_lite_budget: ok=%d cpp_peak_bytes=%zu explicit_native_bsd_bytes=131072 total_known=%zu\n",ok?1:0,budget::peak,budget::peak+131072);
    // Native TLS internals execute in Horizon SSL. getaddrinfo/newlib C malloc
    // are not included here; this is a bounded C++ allocation regression only.
    return !ok||budget::peak>256*1024?1:0;
}
