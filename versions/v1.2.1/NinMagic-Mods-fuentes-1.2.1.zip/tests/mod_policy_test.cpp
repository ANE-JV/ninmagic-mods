#define NC_MODS_TEST
#include "../source/mods.cpp"
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
namespace fs=std::filesystem;
namespace nmm {unsigned policyQueries=0;bool downloadModHttps(const std::string&,const std::string&,uint64_t,std::string&error){++policyQueries;error="offline test";return false;}}
namespace {
unsigned checks=0;fs::path sandbox;
void check(bool x,const char*label){++checks;if(!x)throw std::runtime_error(label);}
#define CHECK(x) check((x),#x)
void put(const fs::path&p,const std::string&s){fs::create_directories(p.parent_path());std::ofstream f(p,std::ios::binary);f<<s;CHECK(bool(f));}
std::string raw(const std::string&path){return "{\"path\":\""+path+"\",\"sha\":\""+std::string(40,'a')+"\",\"type\":\"blob\",\"size\":1}";}
std::string tree(const std::string&rows){return "{\"sha\":\""+std::string(40,'b')+"\",\"truncated\":false,\"tree\":["+rows+"]}";}
}
int main(int argc,char**argv){try{
    for(const char*s:{"emulator-only","Only for Yuzu","Yuzu only","Only on Ryujinx","exclusivo de emulador","Solo para emuladores","does not work on Switch","not supported on physical Switch"})CHECK(nmm::isEmulatorOnlyText(s));
    for(const char*s:{"tested only on emulators","tested on emulator only","not tested on Switch","Switch hardware unknown"})CHECK(nmm::hasUnknownConsoleProvenance(s));
    for(const char*s:{"not emulator-only","isn't emulator-only","No es exclusivo de emulador"})CHECK(!nmm::isEmulatorOnlyText(s));
    nmm::Game game;game.id=0x0100300012F2A000ULL;game.name="Demo";const std::string base="Demo/[0100300012F2A000]/";
    const auto json=tree(raw(base+"Yuzu only/exefs/1.0.0.pchtxt")+","+raw(base+"Hardware/exefs/1.0.0.pchtxt")+","+raw(base+"Tested only on emulators/exefs/1.0.0.pchtxt"));
    nmm::ModsCatalog catalog;std::string error;
    CHECK(!nmm::parseModsTree(json,catalog,error,"ADEMOLA200/Switch-Emulator-Mod-Database")&&catalog.entries.empty());
    CHECK(!nmm::parseModsTree(json,catalog,error,"Kenji-NX/switch-pchtxt-mods")&&catalog.entries.empty());
    CHECK(nmm::parseModsTree(json,catalog,error,"cucholix/NX-IPS-romfs-compilation")&&catalog.entries.size()==1);
    auto physical=catalog.entries[0];CHECK(nmm::allowsConsoleMod(physical));
    auto foreign=physical;foreign.repository="ADEMOLA200/Switch-Emulator-Mod-Database";CHECK(!nmm::allowsConsoleMod(foreign));
    auto forged=physical;forged.branch="other";CHECK(!nmm::allowsConsoleMod(forged));forged=physical;forged.consoleOnly=false;CHECK(!nmm::allowsConsoleMod(forged));forged=physical;forged.path=base+"yuzu only/1.0.0.pchtxt";CHECK(!nmm::allowsConsoleMod(forged));forged=physical;forged.detail="Tested only on emulators";CHECK(!nmm::allowsConsoleMod(forged));
    nmm::ModsCatalog legacy;legacy.entries={physical,foreign,forged};CHECK(nmm::findMods(game,legacy).size()==1);auto mods=legacy.entries;CHECK(nmm::resolveGameMods(game,mods,error)&&mods.size()==1&&nmm::policyQueries==0);nmm::ModPayload payload;CHECK(!nmm::prepareMod(game,foreign,payload,error)&&error.find("Switch física")!=error.npos&&nmm::policyQueries==0);
    sandbox=fs::temp_directory_path()/("nmm-mod-policy-"+std::to_string(getpid())+"-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));fs::create_directories(sandbox);setenv("NC_MODS_ROOT",sandbox.generic_string().c_str(),1);
    for(const auto&provider:nmm::Repos)put(sandbox/"mods-a"/provider.file,json);
    put(sandbox/"mods-a/ademola.json",json);put(sandbox/"mods-a/kenji.json",json);put(sandbox/"mods-a/complete.txt","NMMODS1\n1\n");put(sandbox/"mods-active.txt","a\n");CHECK(nmm::loadModsCatalog(catalog,error)&&catalog.sources.size()==3);for(const auto&e:catalog.entries)CHECK(nmm::allowsConsoleMod(e)&&!nmm::isEmulatorOnly(e));
    const auto input=sandbox/"stream.json";put(input,json);CHECK(nmm::filteredFile(input.generic_string(),game,"cucholix/NX-IPS-romfs-compilation",catalog,error)&&catalog.entries.size()==1);CHECK(!nmm::filteredFile(input.generic_string(),game,"ADEMOLA200/Switch-Emulator-Mod-Database",catalog,error));
    const auto rom=tree(raw("Demo/1.0.0/titles/0100300012F2A000/romfs/normal.bin")+","+raw("Demo/1.0.0/titles/0100300012F2A000/romfs/emulator-only.bin"));CHECK(nmm::parseModsTree(rom,catalog,error,"masagrator/NXGraphicsPatches")&&catalog.entries.empty());
    game.version="1.0.0";game.versionKnown=game.buildVerified=game.running=true;game.processId=42;game.contentIdentity=std::string(64,'d');game.fullBuildId=std::string(64,'a');game.buildId=game.fullBuildId.substr(0,16);const auto bytes="@nsobid-"+game.fullBuildId+"\n# Demo [0100300012F2A000]\n# emulator-only\n@enabled\n00001000 20008052\n@stop\n";physical.size=bytes.size();physical.blobSha=nmm::gitBlobSha(bytes);put(sandbox/"mod-files"/(physical.blobSha+".bin"),bytes);CHECK(!nmm::prepareMod(game,physical,payload,error)&&!payload.compatible&&error.find("Switch física")!=error.npos&&nmm::policyQueries==0);
    if(argc==2){setenv("NC_MODS_ROOT",argv[1],1);CHECK(nmm::loadModsCatalog(catalog,error)&&catalog.sources.size()==3);CHECK(!catalog.entries.empty());for(const auto&e:catalog.entries)CHECK(nmm::allowsConsoleMod(e)&&e.path.find("1998p (yuzu only)")==e.path.npos);std::cout<<"physical-console catalog: "<<catalog.entries.size()<<" entries\n";}
    auto absolute=fs::weakly_canonical(sandbox);CHECK(absolute.parent_path()==fs::weakly_canonical(fs::temp_directory_path())&&absolute.filename().string().rfind("nmm-mod-policy-",0)==0);fs::remove_all(absolute);
    std::cout<<"physical-console policy: "<<checks<<" provenance, legacy-cache, stream and payload checks PASS\n";return 0;
}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<" sandbox "<<sandbox<<'\n';return 1;}}
