#pragma once
#include <cstdint>
using u32=uint32_t;using u64=uint64_t;using Result=uint32_t;
#define R_FAILED(rc) ((rc)!=0)
#define R_SUCCEEDED(rc) ((rc)==0)
enum BsdServiceType{BsdServiceType_User=1};
struct SocketInitConfig {u32 tcp_tx_buf_size,tcp_rx_buf_size,tcp_tx_buf_max_size,tcp_rx_buf_max_size,udp_tx_buf_size,udp_rx_buf_size,sb_efficiency,num_bsd_sessions;BsdServiceType bsd_service_type;};
enum NifmServiceType{NifmServiceType_User};enum NifmInternetConnectionType{NifmInternetConnectionType_WiFi};enum NifmInternetConnectionStatus{NifmInternetConnectionStatus_Connected};
struct SslContext{};struct SslConnection{};
enum {SslVersion_TlsV12=1<<5,SslVersion_TlsV13=1<<6,SslVerifyOption_PeerCa=1,SslVerifyOption_HostName=2,SslVerifyOption_DateCheck=4};
enum SslOptionType{SslOptionType_DoNotCloseSocket=0};enum SslIoMode{SslIoMode_Blocking=1};
bool hosversionBefore(int,int,int);u64 armTicksToNs(u64);u64 armGetSystemTick();
Result socketInitialize(const SocketInitConfig*);void socketExit();Result socketGetLastResult();
Result nifmInitialize(NifmServiceType);void nifmExit();Result nifmGetInternetConnectionStatus(NifmInternetConnectionType*,u32*,NifmInternetConnectionStatus*);
Result sslInitialize(u32);void sslExit();Result sslCreateContext(SslContext*,u32);void sslContextClose(SslContext*);Result sslContextCreateConnection(SslContext*,SslConnection*);void sslConnectionClose(SslConnection*);
Result sslConnectionSetOption(SslConnection*,SslOptionType,bool);Result sslConnectionSetHostName(SslConnection*,const char*,u32);Result sslConnectionSetVerifyOption(SslConnection*,u32);int socketSslConnectionSetSocketDescriptor(SslConnection*,int);
Result sslConnectionSetIoMode(SslConnection*,SslIoMode);Result sslConnectionSetIoTimeout(SslConnection*,u32);Result sslConnectionDoHandshake(SslConnection*,u32*,u32*,void*,u32);
Result sslConnectionWrite(SslConnection*,const void*,u32,u32*);Result sslConnectionRead(SslConnection*,void*,u32,u32*);
