#define NMM_HTTPS_LITE_TEST
#include "../overlay/source/https_lite.cpp"
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <vector>
namespace fs=std::filesystem;
using namespace nmm::https_lite;
namespace {
unsigned checks=0,scenarios=0;
void require(bool condition,const char*label){++checks;if(!condition){std::cerr<<"FAIL "<<label<<"\n";std::exit(1);}}
void scenario(){++scenarios;}
std::string read(const fs::path&p){std::ifstream f(p,std::ios::binary);return {std::istreambuf_iterator<char>(f),{}};}
void write(const fs::path&p,const std::string&s){std::ofstream f(p,std::ios::binary);f<<s;require(bool(f),"fixture file write");}
struct Wire {std::string bytes;size_t at=0,fragment=16384;long fail=-1;};
void route(Wire&w,std::vector<std::string>&urls,std::vector<std::string>&requests){
    detail::testOpen=[&](const detail::Url&u,std::string&){urls.push_back(u.canonical);w.at=0;return true;};
    detail::testSend=[&](const std::string&r,std::string&){requests.push_back(r);return true;};
    detail::testRead=[&](void*p,size_t cap,std::string&e){if(w.fail>=0&&w.at>=size_t(w.fail)){e="Injected read failure";return -1;}const auto n=std::min({cap,w.fragment,w.bytes.size()-w.at});std::memcpy(p,w.bytes.data()+w.at,n);w.at+=n;return int(n);};
}
bool parse(const std::string&wire,std::string&body,std::string&error,Response&response,uint64_t cap=1024,size_t fragment=16384,const std::function<bool()>&cancel={}){
    size_t at=0;detail::Input input([&](void*p,size_t n,std::string&){const auto size=std::min({n,fragment,wire.size()-at});std::memcpy(p,wire.data()+at,size);at+=size;return int(size);},cancel);detail::Headers headers;
    if(!detail::readHeaders(input,headers,error))return false;
    response=headers.response;
    return detail::readBody(input,headers,[&](const void*p,size_t n){body.append(static_cast<const char*>(p),n);return true;},cap,cancel,response,error);
}
}
int main(){
    const auto temp=fs::temp_directory_path();const auto base=temp/("ninmagic-mods-https-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));
    require(base.parent_path()==temp,"dedicated temporary root boundary");fs::create_directories(base);
    detail::Url url;std::string error;
    scenario();require(detail::parseUrl("https://RAW.GitHubusercontent.com:443/a%20b?q=x#fragment",url,error)&&url.host=="raw.githubusercontent.com"&&url.target=="/a%20b?q=x","HTTPS canonical DNS and target");
    for(const std::string &invalid:std::vector<std::string>{"http://github.com/a","file:///a","https://u:p@github.com/a","https://github.com:444/a","https://-host.com/a","https://a..b/a","https://github.com/a\r\nX:yes","https://github.com/a b","https://github.com\\evil/a","https:///a",std::string("https://github.com/a\0z",22)}){scenario();require(!detail::parseUrl(invalid,url,error),"reject unsafe HTTPS URL");}
    scenario();require(detail::parseUrl("https://example.com/a/b?old",url,error),"base URL");detail::Url redirected;require(detail::redirectUrl(url,"../c?q=signed%2Fvalue",redirected,error)&&redirected.canonical=="https://example.com/c?q=signed%2Fvalue","relative redirect preserves signed query");require(detail::redirectUrl(url,"//asset.example.org/file",redirected,error)&&redirected.host=="asset.example.org","HTTPS network-path redirect");require(!detail::redirectUrl(url,"http://example.org/a",redirected,error),"reject TLS downgrade");
    std::string body;Response response;
    scenario();error.clear();require(parse("HTTP/1.1 200 OK\r\nContent-Length: 5\r\nETag: \"a\"\r\nLast-Modified: Mon, 26 Oct 2026 00:00:00 GMT\r\n\r\nhello",body,error,response,5,1)&&body=="hello"&&response.bytes==5&&response.length=="5"&&response.etag=="\"a\"","fragmented fixed response and validators");
    scenario();body.clear();error.clear();require(parse("HTTP/1.1 103 Early Hints\r\nLink: x\r\n\r\nHTTP/1.1 200 OK\r\nTransfer-Encoding: ChUnKeD\r\n\r\n3;ignored=yes\r\nabc\r\n2\r\nde\r\n0\r\nDigest: ignored\r\n\r\n",body,error,response,5,2)&&body=="abcde"&&response.bytes==5,"chunked fragmented response and bounded trailers");
    scenario();body.clear();error.clear();require(parse("HTTP/1.0 200 OK\r\n\r\nclose-delimited",body,error,response)&&body=="close-delimited","bounded EOF response");
    for(const std::string invalid:{
        "HTTP/2 200 OK\r\n\r\n", "HTTP/1.1 200 OK\n\n", "HTTP/1.1 200 OK\r\n folded: x\r\n\r\n",
        "HTTP/1.1 200 OK\r\nContent-Length: 2\r\nContent-Length: 3\r\n\r\naaa",
        "HTTP/1.1 200 OK\r\nContent-Length: +3\r\n\r\naaa", "HTTP/1.1 200 OK\r\nContent-Length: 18446744073709551616\r\n\r\n",
        "HTTP/1.1 200 OK\r\nContent-Length: 3\r\nTransfer-Encoding: chunked\r\n\r\n",
        "HTTP/1.1 200 OK\r\nTransfer-Encoding: gzip, chunked\r\n\r\n", "HTTP/1.1 200 OK\r\nContent-Encoding: gzip\r\n\r\n",
        "HTTP/1.1 101 Upgrade\r\n\r\n", "HTTP/1.1 200 OK\r\nContent-Length: 4\r\n\r\nabc",
        "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\nq\r\n", "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n2\r\nabxx",
        "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n0\r\nContent-Length: 0\r\n\r\n"}){
        scenario();body.clear();error.clear();require(!parse(invalid,body,error,response)&&!error.empty(),"malformed HTTP or incomplete body rejected");
    }
    scenario();body.clear();error.clear();require(!parse("HTTP/1.1 200 OK\r\nX: "+std::string(32768,'a')+"\r\n\r\n",body,error,response)&&!error.empty(),"32 KiB total header bound");
    for(const std::string tooLarge:{"HTTP/1.1 200 OK\r\nContent-Length: 6\r\n\r\n123456","HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n6\r\n123456\r\n0\r\n\r\n","HTTP/1.1 200 OK\r\n\r\n123456"}){scenario();body.clear();error.clear();require(!parse(tooLarge,body,error,response,5),"size cap enforced for every delimiter");}
    scenario();body.clear();error.clear();unsigned cancels=0;require(!parse("HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\nhello",body,error,response,5,1,[&](){return ++cancels>10;})&&error.find("cancelada")!=std::string::npos,"cancel propagated while parsing");
    scenario();{std::function<bool()> cancel;std::string wire="HTTP/1.1 200 OK\r\nContent-Length: 1\r\n\r\nx";size_t at=0;detail::Input input([&](void*p,size_t n,std::string&){auto got=std::min(n,wire.size()-at);std::memcpy(p,wire.data()+at,got);at+=got;return int(got);},cancel);detail::Headers h;require(detail::readHeaders(input,h,error),"write failure header");error.clear();response={};require(!detail::readBody(input,h,[](const void*,size_t){return false;},8,cancel,response,error)&&response.bytes==0,"write error is not success");}
    std::vector<std::string> urls,requests;Wire wire{"HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\nhello"};route(wire,urls,requests);const auto target=base/"result.download";
    scenario();require(download("https://example.com/a",target.generic_string(),response,error,false,5)&&read(target)=="hello"&&response.bytes==5&&response.finalUrl=="https://example.com/a","public GET streams exact file");require(requests.back().find("Accept-Encoding: identity\r\n")!=std::string::npos&&requests.back().find("Connection: close\r\n")!=std::string::npos,"request controls framing and compression");
    scenario();wire.bytes="HTTP/1.1 200 OK\r\nContent-Length: 999999\r\nETag: x\r\n\r\n";require(download("https://example.com/a","",response,error,true,1)&&response.length=="999999"&&response.bytes==0&&requests.back().rfind("HEAD ",0)==0,"HEAD captures length without output/body");
    scenario();wire.bytes="HTTP/1.1 404 Not Found\r\nContent-Length: 3\r\n\r\n404";require(!download("https://example.com/missing",target.generic_string(),response,error,false,5)&&response.status==404&&read(target)=="hello"&&!fs::exists(target.string()+".https-part"),"404 retained and old destination untouched");
    scenario();wire.bytes="HTTP/1.1 200 OK\r\nContent-Length: 9\r\n\r\nshort";require(!download("https://example.com/a",target.generic_string(),response,error,false,9)&&read(target)=="hello"&&!fs::exists(target.string()+".https-part"),"truncated response preserves prior file and removes own temp");
    scenario();wire.bytes="HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\nhello";wire.fragment=1;wire.fail=40;require(!download("https://example.com/a",target.generic_string(),response,error,false,9)&&read(target)=="hello"&&error=="Injected read failure","native read errors preserved");wire.fail=-1;wire.fragment=16384;
    scenario();unsigned opens=0;detail::testOpen=[&](const detail::Url&u,std::string&){++opens;urls.push_back(u.canonical);wire.at=0;wire.bytes=opens==1?"HTTP/1.1 302 Found\r\nLocation: https://assets.example.org/new?q=signed\r\nContent-Length: 0\r\n\r\n":"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n3\r\nnew\r\n0\r\n\r\n";return true;};require(download("https://example.com/old",target.generic_string(),response,error,false,9)&&opens==2&&response.finalUrl=="https://assets.example.org/new?q=signed"&&read(target)=="new","redirect opens verified destination separately and commits body");
    scenario();opens=0;detail::testOpen=[&](const detail::Url&,std::string&){++opens;wire.at=0;wire.bytes="HTTP/1.1 302 Found\r\nLocation: /again\r\n\r\n";return true;};require(!download("https://example.com/a",target.generic_string(),response,error,false,9)&&opens==6&&read(target)=="new","maximum five redirects prevents infinite loop");
    scenario();detail::testOpen=[&](const detail::Url&,std::string&){wire.at=0;wire.bytes="HTTP/1.1 302 Found\r\nLocation: http://insecure.example/a\r\n\r\n";return true;};require(!download("https://example.com/a",target.generic_string(),response,error,false,9)&&read(target)=="new","redirect downgrade never reaches output");
    scenario();route(wire,urls,requests);wire.bytes="HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\nhello";require(!download("https://example.com/a",target.generic_string(),response,error,false,9,[](){return true;})&&read(target)=="new","pre-open cancellation changes no files");
    scenario();const auto outside=base/"outside";write(outside,"private");fs::create_symlink(outside,base/"linked");require(fs::is_symlink(base/"linked"),"real symlink fixture");require(!download("https://example.com/a",(base/"linked").generic_string(),response,error,false,9)&&read(outside)=="private","destination link rejected");
    scenario();fs::create_directory_symlink(base,base/"parent-link");require(!download("https://example.com/a",(base/"parent-link"/"nested").generic_string(),response,error,false,9),"linked parent rejected");
    scenario();fs::create_symlink(outside,target.string()+".https-part");require(!download("https://example.com/a",target.generic_string(),response,error,false,9)&&read(outside)=="private","pending link rejected without deletion");fs::remove(target.string()+".https-part");
    scenario();require(!download("https://example.com/a",(base/".."/"escape").generic_string(),response,error,false,9),"parent traversal rejected");
    require(base.parent_path()==temp&&base.filename().string().rfind("ninmagic-mods-https-",0)==0,"cleanup stays in own temporary directory");fs::remove_all(base);
    std::cout<<"https_lite: "<<scenarios<<" scenarios, "<<checks<<" checks PASS\n";
}
