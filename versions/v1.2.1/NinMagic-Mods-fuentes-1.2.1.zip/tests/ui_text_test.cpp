#include "ui_text.hpp"
#include <cstdio>
#include <cstdlib>

namespace {
unsigned checks=0;
void require(bool ok,int line){++checks;if(!ok){std::fprintf(stderr,"ui_text failure at line %d\n",line);std::exit(1);}}
#define CHECK(x) require((x),__LINE__)
std::string latinText(const std::string&s){std::string out;for(auto cp:nmm::ui_text::displayCodepoints(s))out+=static_cast<char>(cp);return out;}
}
int main(){
    using namespace nmm::ui_text;
    CHECK(validUtf8(u8"Super Mario Bros.™ Wonder"));
    CHECK(canDisplayUtf8(u8"Super Mario Bros.™ Wonder"));
    CHECK(latinText(u8"Super Mario Bros.™ Wonder")=="Super Mario Bros.(TM) Wonder");
    CHECK(latinText(u8"‘Vida’ – “Munición”…")==std::string("'Vida' - \"Munici\xF3n\"..."));
    CHECK(latinText(u8"Salud • Vidas − 1")==std::string("Salud \xB7 Vidas - 1"));
    CHECK(canDisplayUtf8(u8"Pokémon: Edición ñ ÁÉÍÓÚ ¿¡"));
    CHECK(latinText(u8"Pokémon")==std::string("Pok\xE9mon"));
    CHECK(latinText(u8"Œuvre Łódź ﬁ")==std::string("OEuvre L\xF3" "dz fi"));
    CHECK(canDisplayUtf8(u8"Œuvre Łódź ﬁ"));
    CHECK(latinText(u8"A\u00A0B\u202FC\u2009D")=="A B C D");
    CHECK(latinText(u8"\uFEFFNombre\u200B")=="Nombre");
    CHECK(!canDisplayUtf8(""));CHECK(!canDisplayUtf8("   "));CHECK(!canDisplayUtf8(u8"\uFEFF"));
    CHECK(validUtf8(u8"スーパーマリオ"));CHECK(!canDisplayUtf8(u8"スーパーマリオ"));CHECK(latinText(u8"日本")=="??");
    CHECK(validUtf8(u8"中文"));CHECK(!canDisplayUtf8(u8"中文"));
    CHECK(validUtf8(u8"Русский"));CHECK(!canDisplayUtf8(u8"Русский"));
    CHECK(validUtf8(u8"💙"));CHECK(!canDisplayUtf8(u8"💙"));CHECK(latinText(u8"💙")=="?");
    const std::string malformed[]={std::string("\x80"),std::string("\xC0\xAF"),std::string("\xE0\x80\xAF"),std::string("\xED\xA0\x80"),std::string("\xF4\x90\x80\x80"),std::string("\xF5\x80\x80\x80"),std::string("\xC2"),std::string("\xE3\x81"),std::string("\xF0\x9F\x92")};
    for(const auto&s:malformed){CHECK(!validUtf8(s));CHECK(!canDisplayUtf8(s));const auto display=displayCodepoints(s);CHECK(!display.empty());for(auto cp:display)CHECK(cp=='?');}
    CHECK(latinText(std::string("\xC2")+"A")=="?A");
    CHECK(latinText(std::string("\xE3")+"ABC")=="?ABC");
    CHECK(latinText(std::string("\xF0\x9F")+" X")=="?? X");
    CHECK(validUtf8(std::string("A\0B",3)));CHECK(!canDisplayUtf8(std::string("A\0B",3)));CHECK(latinText(std::string("A\0B",3))=="A?B");
    CHECK(!canDisplayUtf8(std::string("\x7F")));CHECK(!canDisplayUtf8(u8"\u0085"));
    CHECK(validUtf8(u8"\u007F\u0080\u07FF\u0800\uD7FF\uE000\uFFFF\U00010000\U0010FFFF"));
    for(const auto&s:malformed)for(auto cp:displayCodepoints(s))CHECK(cp>=32&&cp<=255);
    std::printf("PASS ui_text: %u checks\n",checks);return 0;
}
