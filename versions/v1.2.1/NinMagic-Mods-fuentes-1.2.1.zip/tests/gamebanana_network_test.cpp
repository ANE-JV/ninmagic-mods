#include "../source/update_network.cpp"
#include <iostream>
#include <stdexcept>
namespace {unsigned checks=0;void check(bool ok){++checks;if(!ok)throw std::runtime_error("GameBanana HTTPS isolation");}}
int main(){try{std::string error;const std::string file="sdmc:/config/NinMagicMods/gamebanana/010015100B514000-page1.json.pending";
    for(const auto *url:{"https://gamebanana.com/apiv11/Mod/Index?_nPerpage=15&_nPage=1&_aFilters%5BGeneric_Game%5D=18604","https://gamebanana.com/apiv11/Mod/556710?_csvProperties=_sName,_aGame","https://gamebanana.com/apiv11/Util/Game/NameMatch?_sName=Example%20%28Switch%29"})check(!nmm::downloadGameBananaHttps(url,file,512*1024,error)&&error.find("consola")!=error.npos);
    const std::string url="https://gamebanana.com/apiv11/Mod/Index?_nPage=1";
    for(const auto *path:{"sdmc:/config/NinMagicMods/gamebanana/010015100B514000-page0.json.pending","sdmc:/config/NinMagicMods/gamebanana/010015100B514000-page7.json.pending","sdmc:/config/NinMagicMods/gamebanana/010015100B514000-page1.json","sdmc:/config/NinMagicMods/gamebanana/010015100B514000-page1.json.pending/evil","sdmc:/config/NinMagicMods/gamebanana/010015100B514000/../a.json.pending","sdmc:/config/NinMagicMods/gamebanana/010015100b514000-page1.json.pending","sdmc:/config/NinMagicCheats/gamebanana/010015100B514000-page1.json.pending","sdmc:/config/NinMagicMods/app-update/download.pending","sdmc:/atmosphere/contents/010015100B514000/romfs/a"})check(!nmm::downloadGameBananaHttps(url,path,4096,error)&&error.find("caché privada")!=error.npos);
    for(const auto *bad:{"http://gamebanana.com/apiv11/Mod/Index?a=1","https://gamebanana.com.evil.test/apiv11/Mod/Index?a=1","https://u:p@gamebanana.com/apiv11/Mod/Index?a=1","https://gamebanana.com/dl/1325083","https://gamebanana.com/apiv11/Mod/../../../file","https://gamebanana.com/apiv11/Mod/evil?_csvProperties=x","https://gamebanana.com/apiv11/Mod/556710","https://api.github.com/repos/test"})check(!nmm::downloadGameBananaHttps(bad,file,4096,error)&&!error.empty());
    check(!nmm::downloadGameBananaHttps(url,file,0,error));check(!nmm::downloadGameBananaHttps(url,file,512ULL*1024+1,error));
    std::cout<<"GameBanana HTTPS: "<<checks<<" API, destination and body bounds checks PASS\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
