#include "mods.hpp"
#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <map>

using namespace nmm;
namespace {
unsigned scenarios=0,checks=0;
void require(bool v,const char*s){++checks;if(!v){std::cerr<<"FAILED after scenario "<<scenarios<<": "<<s<<'\n';std::exit(1);}}
#define CHECK(x) require((x),#x)
using Bytes=std::vector<uint8_t>;
Game game(){Game g;g.id=0x01007300020FA000ULL;g.name="Fixture";g.buildVerified=true;g.buildId="4B159F0F7A360669";g.fullBuildId=g.buildId+std::string(48,'0');return g;}
void number(Bytes&b,uint32_t n,unsigned size){for(int i=int(size)-1;i>=0;--i)b.push_back(uint8_t(n>>(8*i)));}
void record(Bytes&b,uint32_t address,const Bytes&values,unsigned width=4){number(b,address,width);number(b,uint32_t(values.size()),2);b.insert(b.end(),values.begin(),values.end());}
Bytes ips(uint32_t address=0x1000,Bytes values={1,2,3,4},bool wide=true){Bytes b=wide?Bytes{'I','P','S','3','2'}:Bytes{'P','A','T','C','H'};record(b,address,values,wide?4:3);if(wide)b.insert(b.end(),{'E','E','O','F'});else b.insert(b.end(),{'E','O','F'});return b;}
Bytes rle(uint32_t address,uint16_t count,uint8_t value,bool wide=true){Bytes b=wide?Bytes{'I','P','S','3','2'}:Bytes{'P','A','T','C','H'};number(b,address,wide?4:3);number(b,0,2);number(b,count,2);b.push_back(value);if(wide)b.insert(b.end(),{'E','E','O','F'});else b.insert(b.end(),{'E','O','F'});return b;}
Bytes span(uint32_t address,size_t size,uint8_t value=7){Bytes b={'I','P','S','3','2'};size_t at=0;while(at<size){size_t n=std::min(size_t(65535),size-at);record(b,address+uint32_t(at),Bytes(n,value));at+=n;}b.insert(b.end(),{'E','E','O','F'});return b;}
Bytes sparse(unsigned count,uint32_t base){Bytes b={'I','P','S','3','2'};for(unsigned i=0;i<count;++i)record(b,base+i*2,{1});b.insert(b.end(),{'E','E','O','F'});return b;}
ModPayload payload(std::string name="60 FPS",Bytes data=ips()){ModPayload p;p.game=game();p.entry.repository="masagrator/NXGraphicsPatches";p.entry.branch="master";p.entry.consoleOnly=true;p.entry.titleId=p.game.id;p.entry.format=ModFormat::Ips;p.entry.name=name;p.buildId=p.game.fullBuildId;p.ips=std::move(data);p.compatible=true;return p;}
std::map<uint32_t,uint8_t> decode(const Bytes&b){CHECK(b.size()>=9&&std::equal(b.begin(),b.begin()+5,"IPS32"));std::map<uint32_t,uint8_t> out;size_t at=5;while(at+4<=b.size()&&!std::equal(b.begin()+at,b.begin()+at+4,"EEOF")){CHECK(at+6<=b.size());uint32_t address=0;for(unsigned i=0;i<4;++i)address=(address<<8)|b[at++];size_t count=(size_t(b[at])<<8)|b[at+1];at+=2;CHECK(count&&at+count<=b.size());for(size_t i=0;i<count;++i)out[address+uint32_t(i)]=b[at++];}CHECK(at+4==b.size());return out;}
bool fail(const Game&g,const std::vector<ModPayload>&in){ModPayload out=payload("sentinel");std::string error;const auto before=in;const bool ok=combineMods(g,in,out,error);CHECK(!ok&&!out.compatible&&out.ips.empty()&&out.names.empty()&&!error.empty());for(size_t i=0;i<in.size();++i)CHECK(in[i].ips==before[i].ips&&in[i].entry.name==before[i].entry.name&&in[i].game.fullBuildId==before[i].game.fullBuildId&&in[i].compatible==before[i].compatible);return !ok;}
}
int main(){
    std::string error;ModPayload out;
    {auto p=payload();CHECK(combineMods(game(),{p},out,error));CHECK(out.compatible&&out.names==std::vector<std::string>{"60 FPS"}&&out.entry.name=="Selección NinMagic Mods"&&out.buildId==game().fullBuildId&&out.entry.titleId==game().id);CHECK(decode(out.ips).size()==4);++scenarios;}
    {auto a=payload("60 FPS",ips(0x1000,{1,2},false));auto b=payload("Quitar desenfoque",ips(0x2000,{3,4}));CHECK(combineMods(game(),{a,b},out,error));const auto bytes=decode(out.ips);CHECK(bytes.size()==4&&bytes.at(0x1000)==1&&bytes.at(0x2001)==4&&out.names.size()==2&&out.names[1]==b.entry.name);++scenarios;}
    {auto a=payload("Resolución",rle(0x3000,8,9,false));auto b=payload("Gráficos",ips(0x4000,{1}));CHECK(combineMods(game(),{a,b},out,error));const auto bytes=decode(out.ips);CHECK(bytes.size()==9&&bytes.at(0x3007)==9&&bytes.at(0x4000)==1);++scenarios;}
    {auto a=payload("A",ips(0x1000,{1,2,3,4}));auto b=payload("B",ips(0x1002,{3,4,5,6}));CHECK(combineMods(game(),{a,b},out,error));const auto bytes=decode(out.ips);CHECK(bytes.size()==6&&bytes.at(0x1005)==6);++scenarios;}
    {CHECK(combineMods(game(),{payload("A"),payload("B")},out,error));CHECK(decode(out.ips).size()==4&&out.names.size()==2);++scenarios;}
    {CHECK(combineMods(game(),{payload("A",rle(0x1000,4,9)),payload("B",ips(0x1002,{9,9}))},out,error));CHECK(decode(out.ips).size()==4);++scenarios;}
    {CHECK(fail(game(),{payload("30 FPS",ips(0x1000,{1})),payload("60 FPS",ips(0x1000,{2}))}));++scenarios;}
    {CHECK(fail(game(),{payload("A",rle(0x1000,4,9)),payload("B",ips(0x1003,{8}))}));++scenarios;}
    {CHECK(fail(game(),{}));++scenarios;}
    {std::vector<ModPayload> p(33,payload());CHECK(fail(game(),p));++scenarios;}
    {std::vector<ModPayload> p;for(unsigned i=0;i<32;++i)p.push_back(payload("Mod "+std::to_string(i),ips(0x1000+i,{uint8_t(i)})));CHECK(combineMods(game(),p,out,error)&&out.names.size()==32&&decode(out.ips).size()==32);++scenarios;}
    {auto g=game();g.buildVerified=false;CHECK(fail(g,{payload()}));++scenarios;}
    {auto g=game();g.id=0x0100000000001000ULL;CHECK(fail(g,{payload()}));++scenarios;}
    {auto g=game();g.fullBuildId.clear();CHECK(fail(g,{payload()}));++scenarios;}
    {auto g=game();g.fullBuildId[0]='F';CHECK(fail(g,{payload()}));++scenarios;}
    {auto p=payload();p.compatible=false;CHECK(fail(game(),{p}));++scenarios;}
    {auto p=payload();p.game.id+=0x10000;CHECK(fail(game(),{p}));++scenarios;}
    {auto p=payload();p.game.fullBuildId.back()='1';CHECK(fail(game(),{p}));++scenarios;}
    {auto p=payload();p.game.buildVerified=false;CHECK(fail(game(),{p}));++scenarios;}
    {auto p=payload();++p.entry.titleId;CHECK(fail(game(),{p}));++scenarios;}
    {auto p=payload();p.buildId[0]='F';CHECK(fail(game(),{p}));++scenarios;}
    {auto p=payload();p.buildId.back()='1';CHECK(fail(game(),{p}));++scenarios;}
    {auto p=payload();p.buildId=game().buildId;CHECK(combineMods(game(),{p},out,error)&&out.buildId==game().fullBuildId);++scenarios;}
    {auto g=game();g.fullBuildId[31]='1';auto p=payload();p.game=g;p.buildId=g.buildId;CHECK(fail(g,{p}));++scenarios;}
    {auto p=payload();p.entry.format=ModFormat::Romfs;CHECK(fail(game(),{p}));p.entry.format=ModFormat::Archive;CHECK(fail(game(),{p}));p.entry.format=ModFormat::Unsupported;CHECK(fail(game(),{p}));++scenarios;}
    {auto p=payload();p.entry.format=ModFormat::Pchtxt;CHECK(combineMods(game(),{p},out,error));++scenarios;}
    {auto p=payload();p.ips.clear();CHECK(fail(game(),{p}));p.ips=ips();p.ips.pop_back();CHECK(fail(game(),{p}));p.ips=ips();p.ips.push_back(0);CHECK(fail(game(),{p}));++scenarios;}
    {CHECK(fail(game(),{payload("A",ips(0xff,{1}))}));CHECK(fail(game(),{payload("A",ips(0x7fffffff,{1,2}))}));++scenarios;}
    {CHECK(fail(game(),{payload("A",rle(0x1000,0,9))}));++scenarios;}
    {auto p=payload();p.entry.name.clear();CHECK(fail(game(),{p}));p.entry.name="name\ncontrol";CHECK(fail(game(),{p}));p.entry.name=std::string(1025,'x');CHECK(fail(game(),{p}));++scenarios;}
    {auto a=payload("A",ips(0x1000,{1,2})),b=payload("B",ips(0x2000,{3,4}));ModPayload reverse;CHECK(combineMods(game(),{a,b},out,error)&&combineMods(game(),{b,a},reverse,error));CHECK(out.ips==reverse.ips&&out.names[0]==a.entry.name&&reverse.names[0]==b.entry.name);++scenarios;}
    {auto p=payload("Límite",span(0x1000,65536));CHECK(combineMods(game(),{p},out,error));CHECK(decode(out.ips).size()==65536&&validateModIps(out.ips,error));++scenarios;}
    {constexpr uint32_t sentinel=0x45454f46u;Bytes b={'I','P','S','3','2'};record(b,sentinel-65535,Bytes(65534,7));record(b,sentinel-1,Bytes(2,7));b.insert(b.end(),{'E','E','O','F'});CHECK(validateModIps(b,error)&&combineMods(game(),{payload("Límite de registro",b)},out,error));const auto bytes=decode(out.ips);CHECK(bytes.size()==65536&&bytes.at(sentinel)==7&&validateModIps(out.ips,error));++scenarios;}
    {auto p=payload("Un MiB",span(0x1000,1024*1024));CHECK(combineMods(game(),{p},out,error));CHECK(out.ips.size()<2*1024*1024&&validateModIps(out.ips,error));CHECK(fail(game(),{p,payload("Otro",ips(0x200000,{1}))}));++scenarios;}
    {auto p=payload("Entrada grande",sparse(90000,0x1000));CHECK(validateModIps(p.ips,error));CHECK(fail(game(),{p,p,p,p}));++scenarios;}
    {std::vector<ModPayload> input={payload("Aliasing")};const auto original=input[0].ips;CHECK(!combineMods(game(),input,input[0],error)&&input[0].ips==original&&input[0].compatible);++scenarios;}
    std::cout<<"mod bundle: "<<scenarios<<" identity, merge and conflict scenarios passed ("<<checks<<" checks)\n";
}
