#include <array>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
#define NMM_PLATFORM_WRAPPER_TEST
using u64=uint64_t;using Result=uint32_t;
#define R_SUCCEEDED(r) ((r)==0)
#define R_FAILED(r) ((r)!=0)
#define MAKERESULT(m,d) ((m)|((d)<<9))
constexpr uint32_t Module_Libnx=345,LibnxError_IoError=10;
enum NcmStorageId {NcmStorageId_SdCard=5,NcmStorageId_GameCard=2};
enum FsFileSystemType {FsFileSystemType_Logo=2};
enum FsContentAttributes {FsContentAttributes_None=0};
constexpr int FsOpenMode_Read=1,FsReadOption_None=0;
struct Service {int id=0;};struct FsFileSystem {int id=0;};struct FsFile {int id=0;};struct FsCodeInfo {uint8_t bytes[0x124]{};};
struct Dispatch {bool in_send_pid=false;};
namespace {
unsigned checks=0,scenarios=0;unsigned version=23;
Result connectResult=0,domainResult=0,pidResult=0,loaderResult=0,contentResult=0,fileResult=0,readResult=0;
bool rejectApplicationId=false;u64 byteCount=0x60,loaderId=0;int loaderStorage=0,loaderCalls=0,contentCalls=0,fileCalls=0,readCalls=0,fileCloses=0,fsCloses=0,serviceCloses=0,domainCalls=0,pidCalls=0;
std::string loaderPath;std::vector<std::string> contentPaths;std::vector<u64> contentIds;
constexpr u64 Title=0x010093801237C000ULL,Patch=Title^0x800;
void check(bool b,const char* text){++checks;if(!b)throw std::runtime_error(text);}
#define CHECK(x) check((x),#x)
void reset(){++scenarios;version=23;connectResult=domainResult=pidResult=loaderResult=contentResult=fileResult=readResult=0;rejectApplicationId=false;byteCount=0x60;loaderId=0;loaderStorage=loaderCalls=contentCalls=fileCalls=readCalls=fileCloses=fsCloses=serviceCloses=domainCalls=pidCalls=0;loaderPath.clear();contentPaths.clear();contentIds.clear();}
}
bool hosversionAtLeast(unsigned major,unsigned,unsigned){return version>=major;}
Result smGetService(Service* service,const char* name){CHECK(std::string(name)=="fsp-ldr");if(!connectResult)service->id=1;return connectResult;}
bool serviceIsActive(Service* service){return service->id!=0;}
void serviceClose(Service* service){CHECK(service->id!=0);++serviceCloses;service->id=0;}
Result serviceConvertToDomain(Service* service){CHECK(service->id==1);++domainCalls;return domainResult;}
Result dispatch(Service* service,unsigned command,u64 input,Dispatch params){CHECK(service->id==1&&command==2&&input==0&&params.in_send_pid);++pidCalls;return pidResult;}
#define serviceDispatchIn(service,command,input,...) dispatch(service,command,input,Dispatch{__VA_ARGS__})
Result fsldrOpenCodeFileSystem(FsCodeInfo*,u64 id,NcmStorageId storage,const char* path,FsContentAttributes attr,FsFileSystem* fs){CHECK(attr==FsContentAttributes_None);++loaderCalls;loaderId=id;loaderStorage=storage;loaderPath=path;if(!loaderResult)fs->id=1;return loaderResult;}
Result fsOpenFileSystemWithId(FsFileSystem* fs,u64 id,FsFileSystemType type,const char* path,FsContentAttributes attr){CHECK(int(type)==0&&attr==FsContentAttributes_None);++contentCalls;contentIds.push_back(id);contentPaths.emplace_back(path);const auto result=rejectApplicationId&&id==Title?0x202U:contentResult;if(!result)fs->id=2;return result;}
Result fsFsOpenFile(FsFileSystem* fs,const char* path,int mode,FsFile* file){CHECK(fs->id!=0&&std::string(path)=="/main"&&mode==FsOpenMode_Read);++fileCalls;if(!fileResult)file->id=1;return fileResult;}
Result fsFileRead(FsFile* file,u64 offset,void* bytes,size_t size,int option,u64* got){CHECK(file->id==1&&offset==0&&size==0x60&&option==FsReadOption_None);++readCalls;std::memset(bytes,0xA5,size);std::memcpy(bytes,"NSO0",4);*got=byteCount;return readResult;}
void fsFileClose(FsFile* file){CHECK(file->id==1);file->id=0;++fileCloses;}
void fsFsClose(FsFileSystem* fs){CHECK(fs->id!=0);fs->id=0;++fsCloses;}
#include "platform_native.hpp"

int main(){try{using namespace nmm::platform_native;
    reset();connectResult=0x15;auto p=probeLoader();CHECK(p.stage==LoaderStage::Connect&&p.result==0x15&&domainCalls==0&&pidCalls==0&&serviceCloses==0);
    reset();domainResult=0x15;p=probeLoader();CHECK(p.stage==LoaderStage::Domain&&p.result==0x15&&domainCalls==1&&pidCalls==0&&serviceCloses==1);
    reset();pidResult=0x15;p=probeLoader();CHECK(p.stage==LoaderStage::CurrentProcess&&p.result==0x15&&pidCalls==1&&serviceCloses==1);
    reset();p=probeLoader();CHECK(p.stage==LoaderStage::Ready&&p.result==0&&pidCalls==1&&serviceCloses==1);
    reset();version=3;p=probeLoader();CHECK(p.stage==LoaderStage::Ready&&pidCalls==0&&domainCalls==1&&serviceCloses==1);
    std::array<uint8_t,0x60> bytes{};std::string error;unsigned lookups=0;
    const auto path=[&](std::string& out,std::string&){++lookups;out="@SdCardContent://registered/newest-program.nca";return true;};
    reset();lookups=0;bytes.fill(0xAA);CHECK(!readInstalledHeader(Title,Patch,NcmStorageId_SdCard,false,false,"SM/fsp-ldr 0x00000615",path,bytes,error));CHECK(loaderCalls==0&&contentCalls==0&&lookups==0&&readCalls==0&&fileCloses==0&&fsCloses==0&&bytes[0]==0&&error.find("0x00000615")!=error.npos&&error.find("Abre el juego")!=error.npos);
    reset();lookups=0;CHECK(readInstalledHeader(Title,Patch,NcmStorageId_GameCard,true,false,"",path,bytes,error));CHECK(loaderCalls==1&&loaderId==Title&&loaderStorage==2&&loaderPath.empty()&&lookups==0&&contentCalls==0&&fileCloses==1&&fsCloses==1);
    reset();lookups=0;loaderResult=0x15;rejectApplicationId=true;CHECK(!readInstalledHeader(Title,Patch,NcmStorageId_SdCard,true,false,"",path,bytes,error));CHECK(loaderCalls==1&&contentCalls==0&&lookups==0&&fileCloses==0&&fsCloses==0&&error.find("fsp-ldr/abrir contenido")!=error.npos);
    reset();lookups=0;const auto noPath=[&](std::string&,std::string& why){++lookups;why="NCM/Program effective failed";return false;};CHECK(!readInstalledHeader(Title,Patch,NcmStorageId_SdCard,false,false,"fsp-ldr/SetCurrentProcess 0x00000015",noPath,bytes,error));CHECK(lookups==0&&loaderCalls==0&&contentCalls==0&&error.find("SetCurrentProcess")!=error.npos);
    reset();lookups=0;CHECK(readInstalledHeader(Title,Patch,NcmStorageId_SdCard,true,true,"",path,bytes,error));CHECK(lookups==1&&loaderPath=="@SdCardContent://registered/newest-program.nca"&&contentCalls==0);
    reset();lookups=0;CHECK(!readInstalledHeader(Title,Patch,NcmStorageId_SdCard,true,true,"",noPath,bytes,error));CHECK(lookups==1&&loaderCalls==0&&contentCalls==0);
    reset();lookups=0;fileResult=0x202;CHECK(!readInstalledHeader(Title,Patch,NcmStorageId_SdCard,true,false,"",path,bytes,error));CHECK(contentCalls==0&&fsCloses==1&&fileCloses==0&&readCalls==0&&error.find("abrir /main")!=error.npos);
    reset();lookups=0;readResult=0x202;CHECK(!readInstalledHeader(Title,Patch,NcmStorageId_SdCard,true,false,"",path,bytes,error));CHECK(contentCalls==0&&fileCloses==1&&fsCloses==1&&bytes[0]==0&&error.find("leer cabecera")!=error.npos);
    reset();lookups=0;byteCount=0x50;CHECK(!readInstalledHeader(Title,Patch,NcmStorageId_SdCard,true,false,"",path,bytes,error));CHECK(fileCloses==1&&fsCloses==1&&bytes[0]==0&&error.find("Abre el juego")!=error.npos);
    reset();lookups=0;contentResult=0x202;CHECK(!readInstalledHeader(Title,Title,NcmStorageId_SdCard,false,false,"init failed",path,bytes,error));CHECK(contentCalls==0&&fsCloses==0&&fileCloses==0&&fileCalls==0&&lookups==0);
    std::cout<<"platform native read-only wrappers: "<<scenarios<<" scenarios / "<<checks<<" checks PASS\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
