#include "app_update_ui.hpp"
#include <iostream>
#include <stdexcept>

namespace {unsigned checks=0;void check(bool b){++checks;if(!b)throw std::runtime_error("update UI action guard");}}
int main(){try{
    nmm::AppUpdateInfo u;nmm::CompletedUpdateInfo r;
    check(nmm::appUpdateAction(u,r,{})==nmm::AppUpdateAction::None);
    u.configured=u.available=true;u.runningVersion="1.0.0";u.version="1.1.0";u.sha256=std::string(64,'a');u.size=2500000;
    check(nmm::appUpdateAction(u,r,{})==nmm::AppUpdateAction::Install);
    u.sdVerified=true;u.sdVersion=u.version;u.sdSha256=u.sha256;u.sdSize=u.size;
    check(nmm::publishedAppOnSd(u)&&nmm::differentAppOnSd(u));check(nmm::appUpdateAction(u,r,{})==nmm::AppUpdateAction::None);
    u.sdSha256=std::string(64,'b');check(!nmm::publishedAppOnSd(u));check(nmm::appUpdateAction(u,r,{})==nmm::AppUpdateAction::None);
    u.sdVersion="0.9.0";check(nmm::differentAppOnSd(u));check(nmm::appUpdateAction(u,r,{})==nmm::AppUpdateAction::None);
    u.sdVersion="1.0.1";check(nmm::appUpdateAction(u,r,{})==nmm::AppUpdateAction::None);
    u.sdVersion=u.runningVersion;check(!nmm::differentAppOnSd(u));check(nmm::appUpdateAction(u,r,{})==nmm::AppUpdateAction::Install);
    check(nmm::appUpdateAction(u,r,"manifest failed")==nmm::AppUpdateAction::None);
    r.state=nmm::CompletedUpdateState::CanArchive;check(nmm::appUpdateAction(u,r,"legacy record retained")==nmm::AppUpdateAction::ReviewCompletedRecord);check(!nmm::completedReviewReady(r));
    r.token="00000001";r.reviewSha256=std::string(64,'c');check(nmm::completedReviewReady(r));
    u.sdVersion=u.version;u.sdSha256=u.sha256;check(nmm::publishedAppOnSd(u));check(nmm::appUpdateAction(u,r,{})==nmm::AppUpdateAction::ReviewCompletedRecord);
    r.state=nmm::CompletedUpdateState::Blocked;check(!nmm::completedReviewReady(r));check(nmm::appUpdateAction(u,r,{})==nmm::AppUpdateAction::None);
    r={};u.sdVersion=u.runningVersion;u.installed=true;check(nmm::appUpdateAction(u,r,{})==nmm::AppUpdateAction::None);
    u.installed=false;u.available=false;check(nmm::appUpdateAction(u,r,{})==nmm::AppUpdateAction::None);
    u.available=true;u.configured=false;check(nmm::appUpdateAction(u,r,{})==nmm::AppUpdateAction::None);
    u.configured=true;u.sdVersion=u.version;u.sdSha256=u.sha256;u.sdSize=u.size+1;check(!nmm::publishedAppOnSd(u));
    u.sdSize=u.size;u.sdVerified=false;check(!nmm::publishedAppOnSd(u)&&!nmm::differentAppOnSd(u));
    u={};u.configured=u.sdVerified=true;u.runningVersion=u.version=u.sdVersion="1.1.0";u.sha256=u.sdSha256=std::string(64,'a');u.size=u.sdSize=2500000;
    check(nmm::currentPublishedApp(u,{}));check(!nmm::currentPublishedApp(u,"HTTPS failed"));
    u.configured=false;check(!nmm::currentPublishedApp(u,{}));u.configured=true;
    u.available=true;check(!nmm::currentPublishedApp(u,{}));u.available=false;
    u.installed=true;check(!nmm::currentPublishedApp(u,{}));u.installed=false;
    u.prepared=true;check(!nmm::currentPublishedApp(u,{}));u.prepared=false;
    u.sdSha256=std::string(64,'b');check(!nmm::currentPublishedApp(u,{}));u.sdSha256=u.sha256;
    u.sdSize++;check(!nmm::currentPublishedApp(u,{}));u.sdSize=u.size;
    u.runningVersion="1.0.1";check(!nmm::currentPublishedApp(u,{}));u.runningVersion=u.version;
    u.sdVerified=false;check(!nmm::currentPublishedApp(u,{}));
    std::cout<<"app update UI: "<<checks<<" action guards PASS\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
