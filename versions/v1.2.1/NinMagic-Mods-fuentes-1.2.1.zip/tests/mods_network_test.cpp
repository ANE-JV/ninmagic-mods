#define NM_UPDATE_NETWORK_TEST
#include "../source/update_network.cpp"
#include <iostream>
#include <stdexcept>
namespace {unsigned checks=0;void check(bool b){++checks;if(!b)throw std::runtime_error("mod network policy");}}
int main(){try{std::string error;const std::string url="https://api.github.com/repos/masagrator/NXGraphicsPatches/git/trees/master?recursive=1";
    const std::string slot="sdmc:/config/NinMagicMods/mods-a/masagrator.json.pending",blob="sdmc:/config/NinMagicMods/mod-files/"+std::string(40,'a')+".bin.pending";
    check(!nmm::downloadModHttps(url,slot,8*1024*1024,error)&&error.find("consola")!=error.npos);
    check(!nmm::downloadModHttps("https://raw.githubusercontent.com/owner/repo/main/file",blob,32*1024*1024,error)&&error.find("consola")!=error.npos);
    for(const auto&path:{"sdmc:/config/NinMagicCheats/mods-a/masagrator.json.pending","sdmc:/config/NinMagicMods/mods-a/../bindings.bin","sdmc:/config/NinMagicMods/mods-a/masagrator.json","sdmc:/config/NinMagicMods/mods-a/masagrator.json.pending/evil","sdmc:/config/NinMagicMods/mods-a/extra.json.pending","sdmc:/atmosphere/contents/0100300012F2A000/romfs/a","sdmc:/config/NinMagicMods/app-update/download.pending","sdmc:/config/NinMagicMods/mod-files/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.bin"})check(!nmm::downloadModHttps(url,path,4096,error)&&error.find("Destino")!=error.npos);
    for(const auto&bad:{"http://api.github.com/repos/x","https://api.github.com.evil.test/repos/x","https://user:pass@api.github.com/repos/x","https://example.test/file"})check(!nmm::downloadModHttps(bad,slot,4096,error)&&!error.empty());
    check(!nmm::downloadModHttps(url,slot,8ULL*1024*1024+1,error)&&error.find("tamaño")!=error.npos);check(!nmm::downloadModHttps(url,slot,0,error));
    check(!nmm::downloadHttpsFile(url,slot,error)&&error.find("temporales")!=error.npos);check(!nmm::downloadModHttps(url,blob,32ULL*1024*1024+1,error));
    FILE *file=std::tmpfile();check(file!=nullptr);nmm::Download d{file,0,3,false};char data[]="abcd";check(nmm::receive(data,1,3,&d)==3&&d.written==3);check(nmm::receive(data,1,1,&d)==0&&d.overflow);check(std::fclose(file)==0);
    std::cout<<"mods HTTPS: "<<checks<<" source/path/body isolation checks PASS\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
