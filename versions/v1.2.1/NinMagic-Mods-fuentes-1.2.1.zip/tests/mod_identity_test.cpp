#define NC_MODS_TEST
#include "../source/mods.cpp"
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
namespace fs=std::filesystem;
namespace nmm {unsigned identityQueries=0;bool downloadModHttps(const std::string&,const std::string&,uint64_t,std::string&error){++identityQueries;error="offline fixture";return false;}}
namespace {
unsigned checks=0;fs::path sandbox;
void check(bool value,const char*label){++checks;if(!value)throw std::runtime_error(label);}
#define CHECK(x) check((x),#x)
void put(const fs::path&p,const std::string&s){fs::create_directories(p.parent_path());std::ofstream f(p,std::ios::binary);f<<s;CHECK(bool(f));}
std::string patch(const std::string&bid,uint64_t declared){return "@nsobid-"+bid+"\n# Demo ["+nmm::titleId(declared)+"] v1.0.0\n@enabled\n00001000 20008052\n@stop\n";}
nmm::ModEntry entry(const std::string&bytes,const std::string&path){std::string error;nmm::ModsCatalog c;const auto tree="{\"sha\":\""+std::string(40,'a')+"\",\"truncated\":false,\"tree\":[{\"path\":\""+path+"\",\"type\":\"blob\",\"sha\":\""+nmm::gitBlobSha(bytes)+"\",\"size\":"+std::to_string(bytes.size())+"}]}";CHECK(nmm::parseModsTree(tree,c,error,"StevensND/switch-port-mods")&&c.entries.size()==1);put(sandbox/"mod-files"/(c.entries[0].blobSha+".bin"),bytes);return c.entries[0];}
}
int main(){try{
    const uint64_t app=0x0100300012F2A000ULL,update=app^0x800;
    CHECK(nmm::canonicalModApplicationId(app)==app);CHECK(nmm::canonicalModApplicationId(update)==app);CHECK(nmm::modUsesUpdateTitleId(update));CHECK(!nmm::modUsesUpdateTitleId(app));CHECK(nmm::canonicalModApplicationId(app+1)==0);CHECK(nmm::canonicalModApplicationId(app+0x1000)!=app);CHECK(nmm::canonicalModApplicationId((app+0x10000)^0x800)!=app);
    bool ambiguous=false,updateTag=false;CHECK(nmm::titleFromPath("# ["+nmm::titleId(app)+"] ["+nmm::titleId(update)+"]",&ambiguous,&updateTag)==app&&!ambiguous&&updateTag);CHECK(nmm::titleFromPath("# ["+nmm::titleId(app+1)+"]",&ambiguous)==0&&ambiguous);
    sandbox=fs::temp_directory_path()/("nmm-mod-identity-"+std::to_string(getpid())+"-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));fs::create_directories(sandbox);setenv("NC_MODS_ROOT",sandbox.generic_string().c_str(),1);
    nmm::Game game;game.id=app;game.name="Demo";game.version="1.0.0";game.versionKnown=game.buildVerified=game.running=true;game.processId=42;game.contentIdentity=std::string(64,'d');game.fullBuildId=std::string(64,'a');game.buildId=game.fullBuildId.substr(0,16);std::string error;nmm::ModPayload payload;
    const auto bytes=patch(game.fullBuildId,update);auto candidate=entry(bytes,"Demo/1.0.0.pchtxt");CHECK(candidate.titleId==0);CHECK(nmm::prepareMod(game,candidate,payload,error)&&payload.compatible&&payload.entry.titleId==app&&payload.entry.detail.find("ID de actualización")!=error.npos&&nmm::identityQueries==0);
    auto changed=game;changed.version="1.0.1";CHECK(!nmm::prepareMod(changed,candidate,payload,error));changed=game;changed.fullBuildId=std::string(64,'b');changed.buildId=changed.fullBuildId.substr(0,16);CHECK(!nmm::prepareMod(changed,candidate,payload,error));
    candidate=entry(bytes,"Demo/["+nmm::titleId(update)+"]/1.0.0.pchtxt");CHECK(candidate.titleId==app&&candidate.detail.find("ID de actualización")!=error.npos);CHECK(nmm::prepareMod(game,candidate,payload,error)&&payload.entry.titleId==app);
    for(const auto declared:{app+1,app+0x1000,(app+0x10000)^0x800}){auto bad=entry(patch(game.fullBuildId,declared),"Demo/1.0.0.pchtxt");CHECK(!nmm::prepareMod(game,bad,payload,error));}
    auto absolute=fs::weakly_canonical(sandbox);CHECK(absolute.parent_path()==fs::weakly_canonical(fs::temp_directory_path())&&absolute.filename().string().rfind("nmm-mod-identity-",0)==0);fs::remove_all(absolute);
    std::cout<<"mod application identity: "<<checks<<" base/update, wrong-family, program-index and DLC checks PASS\n";return 0;
}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<" sandbox "<<sandbox<<'\n';return 1;}}
