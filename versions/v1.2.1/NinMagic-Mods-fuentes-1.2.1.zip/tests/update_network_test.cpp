#define NM_UPDATE_NETWORK_TEST
#include "../source/update_network.cpp"
#include <iostream>
#include <stdexcept>

namespace {unsigned checks=0;void check(bool value){++checks;if(!value)throw std::runtime_error("update HTTPS policy check");}}
int main(){try{
    for(const std::string url:{"https://raw.githubusercontent.com/ANE-JV/ninmagic-mods/main/update.txt","https://example.test:443/versions/v1.2.0/NinMagic-Mods.nro"})check(nmm::safeUrl(url));
    for(const std::string url:{"http://example.test/update.txt","https://u:p@example.test/update.txt","https:///update.txt","https://example.test/a#fragment","https://example.test/a b","https://example.test/a\nb","https://example.test/a\\b"})check(!nmm::safeUrl(url));
    check(!nmm::safeUrl(std::string(2049,'a')));
    check(nmm::bodyLimit("sdmc:/config/NinMagicMods/app-update/manifest.pending")==4096);
    check(nmm::bodyLimit("sdmc:/config/NinMagicMods/app-update/download.pending")==16ULL*1024*1024);
    for(const std::string path:{"sdmc:/config/NinMagicMods/bindings.bin","sdmc:/config/NinMagicCheats/app-update/manifest.pending","sdmc:/switch/NinMagicMods/NinMagic-Mods.nro","sdmc:/config/NinMagicMods/app-update/../bindings.bin","sdmc:/Nintendo/Contents/any"})check(nmm::bodyLimit(path)==0);
    FILE *file=std::tmpfile();check(file!=nullptr);nmm::Download d{file,0,5,false};char bytes[]="abcdef";
    check(nmm::receive(bytes,1,3,&d)==3&&d.written==3&&!d.overflow);
    check(nmm::receive(bytes+3,1,2,&d)==2&&d.written==5&&!d.overflow);
    check(nmm::receive(bytes,1,1,&d)==0&&d.written==5&&d.overflow);
    check(std::fflush(file)==0&&std::fseek(file,0,SEEK_END)==0&&std::ftell(file)==5);check(std::fclose(file)==0);
    file=std::tmpfile();check(file!=nullptr);d={file,0,5,false};check(nmm::receive(bytes,SIZE_MAX,2,&d)==0&&d.written==0);check(std::fclose(file)==0);
    std::string error="stale";check(!nmm::downloadHttpsFile("https://example.test/update.txt","sdmc:/config/NinMagicMods/bindings.bin",error)&&error.find("temporales")!=error.npos);
    check(!nmm::downloadHttpsFile("http://example.test/update.txt","sdmc:/config/NinMagicMods/app-update/manifest.pending",error)&&error.find("HTTPS válida")!=error.npos);
    nmm::updateNetworkExit();std::cout<<"Cleaner HTTPS: "<<checks<<" URL, path isolation and bounded receive checks PASS\n";return 0;
}catch(const std::exception &e){std::cerr<<e.what()<<'\n';return 1;}}
