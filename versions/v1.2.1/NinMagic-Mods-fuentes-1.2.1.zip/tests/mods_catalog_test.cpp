#define NC_MODS_TEST
#include "../source/mods.cpp"
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <functional>
namespace fs=std::filesystem;
namespace nmm {std::function<bool(const std::string&,const std::string&,uint64_t,std::string&)> downloadTest;bool downloadModHttps(const std::string&u,const std::string&p,uint64_t n,std::string&e){return downloadTest&&downloadTest(u,p,n,e);}}
namespace {
unsigned checks=0;fs::path sandbox;
void check(bool b,const char*s){++checks;if(!b)throw std::runtime_error(s);}
#define CHECK(x) check((x),#x)
void put(const fs::path&p,const std::string&s){fs::create_directories(p.parent_path());std::ofstream f(p,std::ios::binary);f.write(s.data(),s.size());CHECK(bool(f));}
std::string body(const std::string&bid,const std::string&tid="0100300012F2A000"){return "@nsobid-"+bid+"\n# Demo ["+tid+"]\n@flag offset_shift 0x100\n@enabled\n00001000 20008052\n@stop\n";}
std::string tree(const std::string&path,const std::string&content){return "{\"sha\":\""+std::string(40,'a')+"\",\"truncated\":false,\"tree\":[{\"path\":\""+path+"\",\"type\":\"blob\",\"sha\":\""+nmm::gitBlobSha(content)+"\",\"size\":"+std::to_string(content.size())+"}]}";}
nmm::ModEntry entry(const std::string&content){nmm::ModsCatalog c;std::string e;CHECK(nmm::parseModsTree(tree("Demo/[0100300012F2A000]/60FPS/1.0.0.pchtxt",content),c,e,"cucholix/NX-IPS-romfs-compilation"));CHECK(c.entries.size()==1);return c.entries[0];}
}
int main(int argc,char**argv){try{
    sandbox=fs::temp_directory_path()/("ninmagic-mod-catalog-test-"+std::to_string(getpid())+"-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));fs::create_directories(sandbox);setenv("NC_MODS_ROOT",sandbox.generic_string().c_str(),1);
    const std::string bid="112233445566778899AABBCCDDEEFF00"+std::string(32,'0');const auto bytes=body(bid);
    nmm::Game game;game.id=0x0100300012F2A000ULL;game.name="Demo";game.version="1.0.0";game.versionKnown=game.buildVerified=game.running=true;game.processId=42;game.contentIdentity=std::string(64,'d');game.fullBuildId=bid;game.buildId=bid.substr(0,16);
    auto mod=entry(bytes);CHECK(mod.titleId==game.id&&mod.version=="1.0.0"&&mod.category=="FPS"&&!mod.compatible);CHECK(mod.branch=="main");
    unsigned downloads=0;nmm::downloadTest=[&](const std::string&url,const std::string&path,uint64_t,std::string&){CHECK(url.rfind("https://raw.githubusercontent.com/cucholix/NX-IPS-romfs-compilation/main/",0)==0);++downloads;put(path,bytes);return true;};
    std::vector<nmm::ModEntry> mods{mod};std::string error;CHECK(nmm::resolveGameMods(game,mods,error));CHECK(mods[0].compatible&&mods[0].buildId==bid&&downloads==1);
    nmm::ModPayload payload;CHECK(nmm::prepareMod(game,mods[0],payload,error)&&payload.compatible&&!payload.ips.empty()&&downloads==1);
    auto other=game;other.fullBuildId=std::string(64,'A');other.buildId=other.fullBuildId.substr(0,16);mods={mod};CHECK(nmm::resolveGameMods(other,mods,error)&&!mods[0].compatible&&downloads==1);
    other=game;other.version="1.0.1";mods={mod};CHECK(nmm::resolveGameMods(other,mods,error)&&!mods[0].compatible&&mods[0].reason.find("1.0.0")!=error.npos&&downloads==1);
    other=game;other.buildVerified=false;mods={mod};CHECK(nmm::resolveGameMods(other,mods,error)&&!mods[0].compatible&&downloads==1);
    other=game;other.running=false;other.processId=0;mods={mod};CHECK(nmm::resolveGameMods(other,mods,error)&&!mods[0].compatible&&mods[0].reason.find("Inicia")!=error.npos&&downloads==1);CHECK(!nmm::prepareMod(other,mod,payload,error)&&downloads==1);
    other=game;other.processId=0;CHECK(!nmm::prepareMod(other,mod,payload,error)&&downloads==1);
    other=game;other.contentIdentity.clear();mods={mod};CHECK(nmm::resolveGameMods(other,mods,error)&&!mods[0].compatible&&mods[0].reason.find("identidad de contenido")!=error.npos&&downloads==1);CHECK(!nmm::prepareMod(other,mod,payload,error)&&downloads==1);
    auto oversized=mod;oversized.size=2ULL*1024*1024+1;CHECK(!nmm::prepareMod(game,oversized,payload,error)&&error.find("2 MiB")!=error.npos&&downloads==1);oversized.format=nmm::ModFormat::Ips;CHECK(!nmm::prepareMod(game,oversized,payload,error)&&error.find("2 MiB")!=error.npos&&downloads==1);
    auto corrupt=mod;corrupt.branch="evil";CHECK(!nmm::prepareMod(game,corrupt,payload,error)&&downloads==1);
    nmm::ModsCatalog c;CHECK(!nmm::parseModsTree(tree("../escape.ips",bytes),c,error,"cucholix/NX-IPS-romfs-compilation"));CHECK(!nmm::parseModsTree(tree("Demo/a.pchtxt",bytes),c,error,"evil/repo"));
    auto invalid=tree("Demo/a.pchtxt",bytes);invalid.replace(invalid.find("false"),5,"true");CHECK(!nmm::parseModsTree(invalid,c,error,"cucholix/NX-IPS-romfs-compilation"));
    CHECK(nmm::parseModsTree(tree("Demo/[0100300012F2A000]/60FPS/1.0.0.zip",bytes),c,error,"cucholix/NX-IPS-romfs-compilation"));CHECK(c.entries.empty());auto archive=mod;archive.format=nmm::ModFormat::Archive;CHECK(!nmm::prepareMod(game,archive,payload,error)&&error.find("formato")!=error.npos);
    const std::string rom="standalone-romfs-data";CHECK(nmm::parseModsTree(tree("Demo/1.0.0/titles/0100300012F2A000/romfs/Data/settings.bin",rom),c,error,"masagrator/NXGraphicsPatches"));CHECK(c.entries.size()==1&&c.entries[0].format==nmm::ModFormat::Romfs&&c.entries[0].consoleOnly&&c.entries[0].files.size()==1);
    auto resource=game;resource.running=false;resource.processId=0;resource.buildVerified=false;resource.buildId.clear();resource.fullBuildId.clear();resource.contentIdentity=std::string(64,'b');
    mods=c.entries;CHECK(nmm::resolveGameMods(resource,mods,error)&&mods[0].compatible);nmm::downloadTest=[&](const std::string&,const std::string&path,uint64_t,std::string&){++downloads;put(path,rom);return true;};CHECK(nmm::prepareMod(resource,mods[0],payload,error)&&payload.files.size()==1&&payload.files[0].path=="atmosphere/contents/0100300012F2A000/romfs/Data/settings.bin"&&payload.buildId.empty());
    other=resource;other.contentIdentity.clear();CHECK(!nmm::prepareMod(other,mods[0],payload,error));other=resource;other.contentIdentity=std::string(64,'0');CHECK(!nmm::prepareMod(other,mods[0],payload,error));other=resource;other.contentIdentity=std::string(64,'B');CHECK(!nmm::prepareMod(other,mods[0],payload,error));other=resource;other.running=true;other.processId=99;CHECK(!nmm::prepareMod(other,mods[0],payload,error));other=resource;other.versionKnown=false;CHECK(!nmm::prepareMod(other,mods[0],payload,error));
    corrupt=mods[0];corrupt.files[0].path="Other/1.0.0/titles/0100300012F2A000/romfs/Data/settings.bin";CHECK(!nmm::prepareMod(resource,corrupt,payload,error));
    corrupt=mods[0];corrupt.version.clear();CHECK(!nmm::prepareMod(resource,corrupt,payload,error));corrupt=mods[0];corrupt.consoleOnly=false;CHECK(!nmm::prepareMod(resource,corrupt,payload,error)&&!payload.compatible);
    corrupt=mods[0];corrupt.buildId=bid;CHECK(!nmm::prepareMod(resource,corrupt,payload,error)&&error.find("sin verificar")!=error.npos);other=resource;other.buildVerified=true;other.fullBuildId=bid;other.buildId=bid.substr(0,16);CHECK(nmm::prepareMod(other,corrupt,payload,error)&&payload.compatible);other.fullBuildId=std::string(64,'A');other.buildId=other.fullBuildId.substr(0,16);CHECK(!nmm::prepareMod(other,corrupt,payload,error)&&error.find("No compatible")!=error.npos);
    auto fresh=entry(bytes+"# new\n");nmm::downloadTest=[](const std::string&,const std::string&,uint64_t,std::string&e){e="HTTPS offline";return false;};mods={fresh};CHECK(!nmm::resolveGameMods(game,mods,error)&&!mods[0].compatible&&!error.empty());
    nmm::downloadTest=[&](const std::string&,const std::string&path,uint64_t,std::string&){put(path,"changed-upstream");return true;};CHECK(!nmm::prepareMod(game,fresh,payload,error)&&!payload.compatible);
    CHECK(nmm::gitBlobSha("")=="e69de29bb2d1d6434b8b29ae775ad8c2e48c5391");
    const auto index=tree("Demo/[0100300012F2A000]/60FPS/1.0.0.pchtxt",bytes);
    for(const auto&r:nmm::Repos)put(sandbox/"mods-a"/r.file,index);
    put(sandbox/"mods-a/complete.txt","NMMODS1\n12345\n");put(sandbox/"mods-active.txt","a\n");put(sandbox/"mods-check.txt",std::to_string(std::time(nullptr))+"\n");
    unsigned treeQueries=0;nmm::downloadTest=[&](const std::string&,const std::string&,uint64_t,std::string&why){++treeQueries;why="HTTPS offline";return false;};
    CHECK(nmm::syncModsCatalog(c,error)&&c.ready&&treeQueries==0);const auto before=c.entries.size();CHECK(!nmm::syncModsCatalog(c,error,true)&&c.ready&&c.entries.size()==before&&treeQueries==3&&!error.empty());CHECK(c.sources.size()==3);for(const auto&r:c.sources)CHECK(!r.checked&&r.cached);
    nmm::downloadTest=[&](const std::string&,const std::string&path,uint64_t,std::string&){++treeQueries;put(path,index);return true;};CHECK(nmm::syncModsCatalog(c,error,true)&&c.ready&&treeQueries==6&&error.empty());for(const auto&r:c.sources)CHECK(r.checked&&!r.cached);
    if(argc==2){unsigned sources=0,total=0,romfsGroups=0;for(const auto&r:nmm::Repos){std::ifstream f(fs::path(argv[1])/(std::string(r.name).replace(std::string(r.name).find('/'),1,"-")+".json"),std::ios::binary);CHECK(bool(f));std::string json((std::istreambuf_iterator<char>(f)),{});CHECK(nmm::parseModsTree(json,c,error,r.name));++sources;total+=unsigned(c.entries.size());for(const auto&e:c.entries){CHECK(!e.selected&&!e.compatible);CHECK(!e.sourceUrl.empty()&&e.repository==r.name);if(e.format==nmm::ModFormat::Romfs)++romfsGroups;}}std::cout<<"real source trees: "<<sources<<" / "<<total<<" entries / "<<romfsGroups<<" RomFS groups\n";}
    if(argc==2){struct Sample{const char*path,*hash,*bid,*version,*name;uint64_t title;};const Sample samples[]={
        {"0-9/1000xResist/1.0.4.pchtxt","4ff1c356639abd018cd821ae331604a83e6e3466","DE9599C18D3F2B7AA26677A423DE37A3","1.0.4","1000xResist",0x0100B02019866800ULL}};
        for(const auto&s:samples){std::ifstream f(fs::path(argv[1])/(std::string("payload-")+s.hash+".bin"),std::ios::binary);CHECK(bool(f));std::string data((std::istreambuf_iterator<char>(f)),{});CHECK(nmm::gitBlobSha(data)==s.hash);CHECK(nmm::parseModsTree(tree(s.path,data),c,error,"cucholix/NX-IPS-romfs-compilation"));auto candidate=c.entries[0];put(sandbox/"mod-files"/(std::string(s.hash)+".bin"),data);auto actual=game;actual.id=nmm::canonicalModApplicationId(s.title);actual.name=s.name;actual.version=s.version;actual.fullBuildId=nmm::fullBid(s.bid);actual.buildId=actual.fullBuildId.substr(0,16);CHECK(nmm::prepareMod(actual,candidate,payload,error)&&payload.compatible&&!payload.ips.empty());if(nmm::modUsesUpdateTitleId(s.title))CHECK(payload.entry.titleId==actual.id&&payload.entry.detail.find("ID de actualización")!=error.npos);actual.fullBuildId=std::string(64,'A');actual.buildId=actual.fullBuildId.substr(0,16);CHECK(!nmm::prepareMod(actual,candidate,payload,error));}
        std::cout<<"real physical-console author patch: exact-build pass, wrong-build refusal, formally matched update-ID declaration\n";
    }
    auto absolute=fs::weakly_canonical(sandbox);CHECK(absolute.parent_path()==fs::weakly_canonical(fs::temp_directory_path())&&absolute.filename().string().rfind("ninmagic-mod-catalog-test-",0)==0);fs::remove_all(absolute);
    std::cout<<"mods catalog: "<<checks<<" identity, source, payload and cache checks PASS\n";return 0;
}catch(const std::exception&e){std::cerr<<"FAILED "<<e.what()<<" fixtures: "<<sandbox<<'\n';return 1;}}
