#include "title_metadata.hpp"
#include <zlib.h>
#include <algorithm>
#include <array>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <vector>

namespace {
unsigned scenarios=0,checks=0;
void check(bool value,const char *name){++checks;if(!value)throw std::runtime_error(name);}
#define CHECK(x) check((x),#x)
using Bytes=std::vector<uint8_t>;
Bytes nacp(){Bytes b(0x4000);std::memcpy(b.data()+0x3060,"1.2.1",5);return b;}
void put(Bytes&b,size_t at,const std::string&s){CHECK(at+s.size()<b.size());std::memcpy(b.data()+at,s.data(),s.size());b[at+s.size()]=0;}
void language(Bytes&b,unsigned index,const std::string&name,const std::string&author="Publisher"){put(b,index*0x300,name);put(b,index*0x300+0x200,author);}
Bytes compressed(const Bytes&entries,int window=-MAX_WBITS){
    z_stream z{};CHECK(deflateInit2(&z,Z_BEST_COMPRESSION,Z_DEFLATED,window,8,Z_DEFAULT_STRATEGY)==Z_OK);
    Bytes compressed(0x10000);z.next_in=const_cast<Bytef*>(entries.data());z.avail_in=static_cast<uInt>(entries.size());z.next_out=compressed.data();z.avail_out=static_cast<uInt>(compressed.size());CHECK(deflate(&z,Z_FINISH)==Z_STREAM_END);const auto length=z.total_out;deflateEnd(&z);CHECK(length<=0x2FFE);auto b=nacp();b[0x3215]=1;b[0]=uint8_t(length);b[1]=uint8_t(length>>8);std::copy_n(compressed.begin(),length,b.begin()+2);return b;
}
}
int main(){try{nmm::TitleMetadata out;std::string error;
    {auto b=nacp();language(b,0,"English Game","English Publisher");CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error));CHECK(out.languageCount==16&&!out.compressed&&out.titleValid&&out.authorValid&&out.versionValid&&out.version=="1.2.1"&&out.name=="English Game"&&out.author=="English Publisher");++scenarios;}
    {auto b=nacp();language(b,0,"English");language(b,6,"Juego español","Editor español");CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error,6)&&out.selectedLanguage==6&&out.name=="Juego español"&&out.author=="Editor español");++scenarios;}
    {auto b=nacp();language(b,1,"British game");CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error,6)&&out.selectedLanguage==1&&out.name=="British game");++scenarios;}
    {auto b=nacp();language(b,5,"Juego latino");CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error,-1)&&out.selectedLanguage==5);++scenarios;}
    {auto b=nacp();language(b,2,"日本語","出版社");CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error)&&out.name=="日本語"&&out.author=="出版社");++scenarios;}
    {auto b=nacp();language(b,6,"Juego","");language(b,0,"English","Publisher fallback");CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error,6)&&out.selectedLanguage==6&&out.authorLanguage==0&&out.author=="Publisher fallback");++scenarios;}
    {auto b=nacp();language(b,0,"English");CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error,99)&&out.selectedLanguage==0);++scenarios;}
    {auto b=nacp();CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error)&&!out.titleValid&&!out.authorValid&&out.name.empty()&&out.author.empty()&&out.versionValid);++scenarios;}
    {auto b=nacp();language(b,6,"   ","  ");language(b,0,"  Trimmed title  ","  Publisher  ");CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error,6)&&out.selectedLanguage==0&&out.name=="Trimmed title"&&out.author=="Publisher");++scenarios;}
    {Bytes entries(32*0x300);language(entries,0,"No Fate","Konami");language(entries,6,"Terminator español","Konami");auto b=compressed(entries);CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error,6)&&out.compressed&&out.languageCount==32&&out.name=="Terminator español"&&out.author=="Konami"&&out.version=="1.2.1");++scenarios;}
    {Bytes entries(18*0x300);language(entries,16,"Gra polska","Wydawca");language(entries,17,"เกมไทย","ผู้จัดจำหน่าย");auto b=compressed(entries);CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error,17)&&out.languageCount==18&&out.selectedLanguage==17&&out.name=="เกมไทย");++scenarios;}
    {Bytes entries(16*0x300);language(entries,0,"Compressed legacy");auto b=compressed(entries);CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error)&&out.languageCount==16&&out.name=="Compressed legacy");++scenarios;}
    {auto b=nacp();b[0x3215]=2;CHECK(!nmm::parseTitleMetadata(b.data(),b.size(),out,error)&&!out.titleValid&&out.languageCount==0&&out.versionValid&&out.version=="1.2.1");++scenarios;}
    {CHECK(!nmm::parseTitleMetadata(nullptr,0x4000,out,error)&&out.name.empty()&&!out.versionValid);auto b=nacp();CHECK(!nmm::parseTitleMetadata(b.data(),0x3215,out,error)&&out.name.empty());++scenarios;}
    {auto b=nacp();b[0x3215]=1;CHECK(!nmm::parseTitleMetadata(b.data(),b.size(),out,error)&&out.compressed&&out.languages[0].name.empty()&&out.versionValid);++scenarios;}
    {auto b=nacp();b[0x3215]=1;b[0]=0xFF;b[1]=0x2F;CHECK(!nmm::parseTitleMetadata(b.data(),b.size(),out,error)&&out.name.empty());++scenarios;}
    {Bytes entries(18*0x300);language(entries,0,"Truncated");auto b=compressed(entries);unsigned size=b[0]|(unsigned(b[1])<<8);CHECK(size>2);--size;b[0]=uint8_t(size);b[1]=uint8_t(size>>8);CHECK(!nmm::parseTitleMetadata(b.data(),b.size(),out,error)&&out.name.empty()&&out.versionValid);++scenarios;}
    {Bytes entries(32*0x300);language(entries,0,"Garbage stream");auto b=compressed(entries);std::fill(b.begin()+2,b.begin()+0x100,0xFF);CHECK(!nmm::parseTitleMetadata(b.data(),b.size(),out,error)&&out.name.empty());++scenarios;}
    {Bytes entries(18*0x300);language(entries,0,"Wrapped zlib");auto b=compressed(entries,MAX_WBITS);CHECK(!nmm::parseTitleMetadata(b.data(),b.size(),out,error));++scenarios;}
    {Bytes entries(18*0x300);language(entries,0,"Trailing data");auto b=compressed(entries);unsigned size=b[0]|(unsigned(b[1])<<8);b[2+size]=0x12;++size;b[0]=uint8_t(size);b[1]=uint8_t(size>>8);CHECK(!nmm::parseTitleMetadata(b.data(),b.size(),out,error));++scenarios;}
    {Bytes entries(32*0x300+1);auto b=compressed(entries);CHECK(!nmm::parseTitleMetadata(b.data(),b.size(),out,error)&&out.languageCount==0);++scenarios;}
    {Bytes entries(16*0x300-1);auto b=compressed(entries);CHECK(!nmm::parseTitleMetadata(b.data(),b.size(),out,error));++scenarios;}
    {Bytes entries(18*0x300+3);auto b=compressed(entries);CHECK(!nmm::parseTitleMetadata(b.data(),b.size(),out,error));++scenarios;}
    {auto b=nacp();language(b,0,"Safe fallback");std::fill(b.begin()+6*0x300,b.begin()+6*0x300+0x200,'X');CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error,6)&&!out.languages[6].nameValid&&out.selectedLanguage==0);++scenarios;}
    for(const auto &bad:std::array<std::string,8>{std::string("\xC0\xAF",2),std::string("\xE2\x28\xA1",3),std::string("\xF0\x9F",2),std::string("\xED\xA0\x80",3),std::string("\xF4\x90\x80\x80",4),std::string("\x80",1),std::string("bad\nname"),std::string("\xC2\x85",2)}){auto b=nacp();language(b,0,"Safe");language(b,6,bad);CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error,6)&&!out.languages[6].nameValid&&out.name=="Safe");++scenarios;}
    {auto b=nacp();language(b,0,"Game",std::string("bad\xFF",4));CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error)&&out.titleValid&&!out.authorValid&&out.author.empty());++scenarios;}
    {auto b=nacp();language(b,0,"Game");std::fill(b.begin()+0x3060,b.begin()+0x3070,'X');CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error)&&!out.versionValid&&out.version.empty()&&out.titleValid);++scenarios;}
    {auto b=nacp();language(b,0,"Game");put(b,0x3060,"bad\nversion");CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error)&&!out.versionValid);++scenarios;}
    {auto b=nacp();language(b,0,"Before");CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error)&&out.name=="Before");b[0x3215]=99;CHECK(!nmm::parseTitleMetadata(b.data(),b.size(),out,error)&&out.name.empty()&&out.languages[0].name.empty());++scenarios;}
    {auto b=nacp();language(b,2,"日本語","出版社");language(b,0,"English fallback","Publisher");CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error,2)&&out.name=="日本語");std::string name,author;CHECK(nmm::selectDisplayTitleMetadata(out,name,author)&&name=="English fallback"&&author=="Publisher"&&out.name=="日本語");++scenarios;}
    {auto b=nacp();language(b,2,"日本語","出版社");CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error,2));std::string name="stale",author="stale";CHECK(!nmm::selectDisplayTitleMetadata(out,name,author)&&name.empty()&&author.empty());++scenarios;}
    {auto b=nacp();language(b,0,u8"Super Mario Bros.™ Wonder","Nintendo");CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error));std::string name,author;CHECK(nmm::selectDisplayTitleMetadata(out,name,author)&&name==u8"Super Mario Bros.™ Wonder"&&author=="Nintendo");++scenarios;}
    {auto b=nacp();language(b,6,"Juego","出版社");language(b,0,"English","Publisher");CHECK(nmm::parseTitleMetadata(b.data(),b.size(),out,error,6));std::string name,author;CHECK(nmm::selectDisplayTitleMetadata(out,name,author)&&name=="Juego"&&author=="Publisher");++scenarios;}
    std::cout<<"title metadata: "<<scenarios<<" raw/compressed NACP, language and UTF-8 scenarios passed ("<<checks<<" checks)\n";return 0;
}catch(const std::exception&e){std::cerr<<"FAILED: "<<e.what()<<'\n';return 1;}}
