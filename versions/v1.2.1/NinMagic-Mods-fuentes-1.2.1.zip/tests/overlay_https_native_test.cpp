// Native API contract simulation. Includes nonblocking connect/poll/SO_ERROR
// and libnx's positive-mask-on-fcntl-error quirk; no real network or certificates.
#define __SWITCH__
#include "../overlay/source/https_lite.cpp"
#include <iostream>
#include <vector>
#include <cstdarg>
namespace {
enum class Tcp {Immediate,Pending,WouldBlock,AlreadyPending,InterruptedConnect,AlreadyConnected,
 SetFlagsMaskError,SetFlagsIpcError,SetFlagsMinusError,SocketFailure,DnsFailure,
 Refused,AsyncRefused,PollFailure,PollInterrupt,PollInvalid,Hangup,ReadOnlyEvent,
 OptionFailure,ShortOption,Timeout,TrySecond};
unsigned checks=0,scenarios=0;std::vector<std::string> events;std::string request,wire;
uint64_t ticks=0;size_t at=0;bool oldFirmware=false,denyCert=false,denyFlags=false,denyTimeout=false;
u32 tlsMask=0,verifyMask=0,ioTimeout=0;SocketInitConfig config{};
unsigned sockets=0,contexts=0,connections=0,reads=0,writes=0,connects=0,polls=0,options=0,flagSets=0;
Result lastBsd=0;Tcp tcp=Tcp::Immediate;
Result nifmInitFailure=0,nifmQueryFailure=0;int nifmStatus=0;
void require(bool ok,const char*label){++checks;if(!ok){std::cerr<<"FAIL "<<label<<"\n";std::exit(1);}}
void reset(){nmm::https_lite::shutdown();events.clear();request.clear();wire="HTTP/1.1 200 OK\r\nContent-Length: 1234\r\nETag: verified\r\n\r\n";at=0;ticks=0;
 oldFirmware=denyCert=denyFlags=denyTimeout=false;tlsMask=verifyMask=ioTimeout=0;sockets=contexts=connections=reads=writes=connects=polls=options=flagSets=0;tcp=Tcp::Immediate;lastBsd=0;nifmInitFailure=nifmQueryFailure=0;nifmStatus=0;}
bool ordered(const char*a,const char*b){auto x=std::find(events.begin(),events.end(),a),y=std::find(events.begin(),events.end(),b);return x!=events.end()&&y!=events.end()&&x<y;}
bool head(std::string&error,const std::function<bool()>&cancel={}){nmm::https_lite::Response response;return nmm::https_lite::download("https://example.com/a?token=DO_NOT_LOG","",response,error,true,1,cancel);}
void clean(){require(!sockets&&!connections&&!contexts,"every failed attempt closes exact owned handles");}
}
bool hosversionBefore(int,int,int){return oldFirmware;}u64 armTicksToNs(u64 t){return t;}u64 armGetSystemTick(){return ticks+=1000;}
Result socketInitialize(const SocketInitConfig*c){config=*c;events.push_back("socketInit");return 0;}void socketExit(){events.push_back("socketExit");}Result socketGetLastResult(){return lastBsd;}
Result nifmInitialize(NifmServiceType){events.push_back("nifmInit");return nifmInitFailure;}void nifmExit(){events.push_back("nifmExit");}Result nifmGetInternetConnectionStatus(NifmInternetConnectionType*,u32*,NifmInternetConnectionStatus*s){if(nifmQueryFailure)return nifmQueryFailure;*s=static_cast<NifmInternetConnectionStatus>(nifmStatus);return 0;}
Result sslInitialize(u32 count){require(count==1,"single SSL session budget");events.push_back("sslInit");return 0;}void sslExit(){events.push_back("sslExit");}
Result sslCreateContext(SslContext*,u32 mask){tlsMask=mask;++contexts;events.push_back("contextCreate");return 0;}void sslContextClose(SslContext*){require(contexts>0,"context closes only once");--contexts;events.push_back("contextClose");}
Result sslContextCreateConnection(SslContext*,SslConnection*){++connections;events.push_back("connectionCreate");return 0;}void sslConnectionClose(SslConnection*){require(connections>0,"connection closes only once");--connections;events.push_back("connectionClose");}
Result sslConnectionSetOption(SslConnection*,SslOptionType type,bool value){require(type==SslOptionType_DoNotCloseSocket&&value,"never skip verification; original FD stays owned");events.push_back("dontClose");return 0;}
Result sslConnectionSetHostName(SslConnection*,const char*host,u32 size){require(std::string(host)=="example.com"&&size==12,"SNI exact peer with terminator");return 0;}
Result sslConnectionSetVerifyOption(SslConnection*,u32 mask){verifyMask=mask;events.push_back("verify");return denyFlags?0x4444:0;}
int socketSslConnectionSetSocketDescriptor(SslConnection*,int fd){require(fd==1000,"use libnx socket descriptor wrapper");events.push_back("descriptor");errno=ENOENT;return -1;}
Result sslConnectionSetIoMode(SslConnection*,SslIoMode mode){require(mode==SslIoMode_Blocking,"explicit bounded TLS blocking");return 0;}
Result sslConnectionSetIoTimeout(SslConnection*,u32 timeout){ioTimeout=timeout;return denyTimeout?0x5555:0;}
Result sslConnectionDoHandshake(SslConnection*,u32*,u32*,void*,u32){events.push_back("handshake");require(verifyMask==7,"CA/host/date before handshake");return denyCert?0x6666:0;}
Result sslConnectionWrite(SslConnection*,const void*p,u32 size,u32*done){++writes;*done=std::min<u32>(size,7);request.append(static_cast<const char*>(p),*done);return 0;}
Result sslConnectionRead(SslConnection*,void*p,u32 size,u32*done){++reads;*done=u32(std::min<size_t>({size,wire.size()-at,9}));std::memcpy(p,wire.data()+at,*done);at+=*done;return 0;}
extern "C" {
int __wrap_socket(int,int,int){lastBsd=0;if(tcp==Tcp::SocketFailure){errno=ENOBUFS;return -1;}require(!sockets,"one sequential TCP FD");++sockets;events.push_back("fdCreate");return 1000;}
int __wrap_fcntl(int fd,int command,...){
 require(fd==1000,"fcntl exact socket");require(command==F_SETFL,"F_GETFL is not required for fresh socket");va_list args;va_start(args,command);const int flags=va_arg(args,int);va_end(args);
 require(flags==O_NONBLOCK,"libnx only supported flag is O_NONBLOCK");++flagSets;lastBsd=0;
 if(tcp==Tcp::SetFlagsMaskError){errno=EACCES;return O_NONBLOCK;} // libnx from_nx(-1), not a success
 if(tcp==Tcp::SetFlagsIpcError){errno=EPIPE;lastBsd=0xD401;return O_NONBLOCK;}
 if(tcp==Tcp::SetFlagsMinusError){errno=EINVAL;return -1;}return 0;
}
int __wrap_connect(int fd,const sockaddr*,socklen_t){
 require(fd==1000,"connect exact socket");lastBsd=0;++connects;events.push_back("connect");
 if(tcp==Tcp::Immediate)return 0;
 if(tcp==Tcp::AlreadyConnected){errno=EISCONN;return -1;}
 if(tcp==Tcp::Refused||(tcp==Tcp::TrySecond&&connects==1)){errno=ECONNREFUSED;return -1;}
 errno=tcp==Tcp::WouldBlock?EWOULDBLOCK:tcp==Tcp::AlreadyPending?EALREADY:tcp==Tcp::InterruptedConnect?EINTR:EINPROGRESS;return -1;
}
int __wrap_poll(pollfd*fds,nfds_t count,int timeout){
 require(count==1&&fds[0].fd==1000&&fds[0].events==POLLOUT&&timeout==200,"poll bounded single exact socket");
 lastBsd=0;++polls;events.push_back("poll");
 if(tcp==Tcp::Timeout){ticks+=200000000;return 0;}
 if(tcp==Tcp::PollFailure){errno=EIO;lastBsd=0xD401;return -1;}
 if(tcp==Tcp::PollInterrupt&&polls==1){errno=EINTR;return -1;}
 fds[0].revents=tcp==Tcp::PollInvalid?POLLNVAL:tcp==Tcp::Hangup?short(POLLOUT|POLLHUP):tcp==Tcp::AsyncRefused?short(POLLOUT|POLLERR):(tcp==Tcp::ReadOnlyEvent&&polls==1)?POLLIN:POLLOUT;return 1;
}
int __wrap_getsockopt(int fd,int level,int name,void*value,socklen_t*size){
 require(fd==1000&&level==SOL_SOCKET&&name==SO_ERROR&&*size==sizeof(int),"SO_ERROR exact length and socket");
 ++options;lastBsd=0;if(tcp==Tcp::OptionFailure){errno=ENOPROTOOPT;return -1;}
 *static_cast<int*>(value)=tcp==Tcp::AsyncRefused?111:0; // Horizon reports raw Linux errno in SO_ERROR.
 if(tcp==Tcp::ShortOption)*size=1;
 return 0;
}
int __real_close(int);
int __wrap_close(int fd){if(fd!=1000)return __real_close(fd);require(sockets==1,"close input FD exactly once");--sockets;events.push_back("fdClose");return 0;}
int __wrap_getaddrinfo(const char*host,const char*service,const addrinfo*hints,addrinfo**out){
 require(std::string(host)=="example.com"&&std::string(service)=="443"&&hints->ai_family==AF_INET,"resolve exact HTTPS peer");
 if(tcp==Tcp::DnsFailure){*out=nullptr;return EAI_AGAIN;}static sockaddr address{};static addrinfo first{},second{};
 first={};second={};first.ai_family=second.ai_family=AF_INET;first.ai_socktype=second.ai_socktype=SOCK_STREAM;first.ai_addr=second.ai_addr=&address;first.ai_addrlen=second.ai_addrlen=sizeof(address);
 if(tcp==Tcp::TrySecond)first.ai_next=&second;
 *out=&first;return 0;
}
void __wrap_freeaddrinfo(addrinfo*){}
}
int main(){
 using namespace nmm::https_lite;Response response;std::string error;
 ++scenarios;reset();require(download("https://example.com/a","",response,error,true,1),"immediate native HEAD");require(response.status==200&&response.length=="1234"&&!response.bytes,"HEAD validators without body");
 require(tlsMask==96&&verifyMask==7,"TLS1.2/1.3 and full verify");require(ioTimeout==10000&&writes>1&&reads>1,"bounded partial I/O");
 const u32 total=config.tcp_tx_buf_size+config.tcp_rx_buf_size+config.udp_tx_buf_size+config.udp_rx_buf_size;
 require(total==128*1024&&!config.tcp_rx_buf_max_size&&!config.tcp_tx_buf_max_size&&config.sb_efficiency==1&&config.num_bsd_sessions==1,"unchanged128KiB BSD pool");clean();
 require(ordered("dontClose","descriptor")&&ordered("verify","handshake")&&ordered("connectionClose","fdClose")&&ordered("fdClose","contextClose"),"duplicate FD cleanup order");
 shutdown();require(ordered("sslExit","nifmExit")&&ordered("nifmExit","socketExit"),"reverse service shutdown");
 for(const auto mode:{Tcp::Pending,Tcp::WouldBlock,Tcp::AlreadyPending,Tcp::InterruptedConnect,Tcp::AlreadyConnected,Tcp::PollInterrupt,Tcp::ReadOnlyEvent,Tcp::TrySecond}){
  ++scenarios;reset();tcp=mode;require(head(error),"pending/EINTR/EALREADY and second address reach TLS");require(verifyMask==7&&writes>0,"only verified TLS sends HTTP");clean();
  if(mode==Tcp::PollInterrupt||mode==Tcp::ReadOnlyEvent)require(polls==2&&options==1,"ignore interrupted or non-write poll event");
  if(mode==Tcp::TrySecond)require(connects==2,"retry next DNS address after closing first");
 }
 struct Failure {Tcp mode;const char*stage;};
 for(const auto&f:std::vector<Failure>{{Tcp::SetFlagsMaskError,"tcp/fcntl-setfl"},{Tcp::SetFlagsIpcError,"tcp/fcntl-setfl"},{Tcp::SetFlagsMinusError,"tcp/fcntl-setfl"},{Tcp::SocketFailure,"tcp/socket"},{Tcp::DnsFailure,"dns/getaddrinfo"},{Tcp::Refused,"tcp/connect"},{Tcp::AsyncRefused,"tcp/connect-resultado"},{Tcp::PollFailure,"tcp/poll"},{Tcp::PollInvalid,"tcp/poll-fd"},{Tcp::Hangup,"tcp/poll-cerrado"},{Tcp::OptionFailure,"tcp/so-error"},{Tcp::ShortOption,"tcp/so-error"},{Tcp::Timeout,"tcp/tiempo-agotado"}}){
  ++scenarios;reset();tcp=f.mode;require(!head(error),"failed TCP stage is never TLS success");require(error.find(f.stage)!=std::string::npos&&error.find("host=example.com")!=std::string::npos,"failure includes safe peer and exact stage");
  require(error.find("DO_NOT_LOG")==std::string::npos&&writes==0&&reads==0,"no signed URL/token or HTTP before TCP");clean();
  if(f.mode==Tcp::SetFlagsMaskError||f.mode==Tcp::SetFlagsIpcError||f.mode==Tcp::SetFlagsMinusError)require(connects==0,"fcntl failure including positive mask prevents connect");
  if(f.mode==Tcp::AsyncRefused)require(error.find("so_error=111")!=std::string::npos,"raw BSD SO_ERROR retained for diagnosis");
  if(f.mode==Tcp::SetFlagsIpcError||f.mode==Tcp::PollFailure)require(error.find("0000D401")!=std::string::npos,"BSD result retained before close");
  if(f.mode==Tcp::PollInvalid)require(options==0,"POLLNVAL never queried");
 }
 ++scenarios;reset();tcp=Tcp::Timeout;require(!head(error,[](){return polls>0;})&&error.find("cancelada")!=std::string::npos,"cancel pending poll without TLS or stale generic error");clean();
 ++scenarios;reset();nifmQueryFailure=0xD46ED;require(head(error)&&connects==1&&verifyMask==7,"NIFM status IPC failure does not veto verified endpoint");clean();
 ++scenarios;reset();nifmStatus=2;require(head(error)&&connects==1&&verifyMask==7,"NIFM disconnected hint does not veto verified endpoint");clean();
 ++scenarios;reset();nifmInitFailure=0x3456;require(head(error)&&connects==1&&verifyMask==7,"optional NIFM access failure does not veto BSD and TLS");clean();
 ++scenarios;reset();tcp=Tcp::Refused;nifmQueryFailure=0xD46ED;require(!head(error)&&error.find("tcp/connect")!=std::string::npos&&error.find("nifm_rc=0x000D46ED")!=std::string::npos&&error.find("Conecta")==std::string::npos,"actual endpoint failure retains advisory NIFM context");clean();
 ++scenarios;reset();denyCert=true;require(!head(error)&&writes==0&&reads==0&&error.find("tls/handshake")!=std::string::npos,"certificate failure diagnostic and no HTTP");clean();
 ++scenarios;reset();denyFlags=true;require(!head(error)&&std::find(events.begin(),events.end(),"handshake")==events.end(),"verify policy failure closed");clean();
 ++scenarios;reset();denyTimeout=true;require(!head(error)&&std::find(events.begin(),events.end(),"handshake")==events.end(),"timeout failure closed");clean();
 ++scenarios;reset();oldFirmware=true;require(!head(error)&&events.empty(),"unsupported firmware no allocation");
 ++scenarios;reset();require(!head(error,[](){return true;})&&events.empty(),"cancel before services");
 shutdown();std::cout<<"https_lite_native: "<<scenarios<<" scenarios, "<<checks<<" checks PASS\n";
}
