#define NMM_QUEUE_TEST
#include "../source/mod_queue.cpp"
#include "mods.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <chrono>
namespace fs=std::filesystem;
using namespace nmm;unsigned checks=0;
void need(bool b,const char*why){++checks;if(!b){std::cerr<<"FAIL "<<why<<'\n';std::exit(1);}}
Game game(){Game g;g.id=0x010093801237C000ULL;g.contentIdentity=std::string(64,'c');g.fullBuildId="646761F643AFEBB3"+std::string(48,'0');g.buildId=g.fullBuildId.substr(0,16);g.buildVerified=g.versionKnown=true;g.version="2.1.0";return g;}
ModPayload payload(){auto g=game();ModPayload p;p.game=g;p.entry.titleId=g.id;p.entry.name="60 FPS";p.entry.repository="masagrator/NXGraphicsPatches";p.entry.branch="master";p.entry.consoleOnly=true;p.entry.id=p.entry.repository+"|fps.pchtxt";p.entry.buildId=g.fullBuildId;p.entry.format=ModFormat::Ips;p.buildId=g.fullBuildId;p.compatible=p.entry.compatible=true;p.ips={'P','A','T','C','H',0,0x10,0,0,1,0x22,'E','O','F'};return p;}
int main(){auto g=game();auto p=payload();std::string error;ModPayload combined;need(combineMods(g,{p},combined,error),"documented hardware source accepted");for(unsigned scenario=0;scenario<5;++scenario){auto bad=p;if(scenario==0)bad.entry.consoleOnly=false;if(scenario==1)bad.entry.repository="ADEMOLA200/Switch-Emulator-Mod-Database";if(scenario==2)bad.entry.branch="other";if(scenario==3)bad.entry.name="Yuzu only";if(scenario==4)bad.entry.detail="not tested on Switch";need(!combineMods(g,{bad},combined,error)&&!combined.compatible,"compatible=true never bypasses physical provenance");ModPayload parsed;need(!parseModPayload(g,bad.entry,std::string(bad.ips.begin(),bad.ips.end()),parsed,error)&&!parsed.compatible,"direct parser same provenance gate");}
 const auto parent=fs::temp_directory_path(),sandbox=parent/("nmm-policy-"+std::to_string(std::chrono::high_resolution_clock::now().time_since_epoch().count()));fs::create_directories(sandbox);setenv("NMM_QUEUE_ROOT",sandbox.generic_string().c_str(),1);
 auto foreign=p.entry;foreign.repository="Kenji-NX/switch-pchtxt-mods";foreign.id=foreign.repository+"|old";auto archive=p.entry;archive.id=archive.repository+"|old.zip";archive.format=ModFormat::Archive;need(!allowsConsoleMod(archive),"archive not a supported console format");auto unsupported=archive;unsupported.format=ModFormat::Unsupported;need(!allowsConsoleMod(unsupported),"unsupported format excluded");std::string menu="NMMMENU2";queue::game(menu,g);queue::integer(menu,3);queue::putEntry(menu,foreign);queue::putEntry(menu,archive);queue::putEntry(menu,p.entry);need(queue::write(g,"menu.bin",menu,error),"old cache fixture with valid digest");std::vector<ModEntry> loaded;need(loadModMenuCache(g,loaded,error)&&loaded.size()==1&&loaded[0].id==p.entry.id,"old unknown and archive excluded when reading cache");
 std::string selection="NMMSEL02";queue::game(selection,g);queue::integer(selection,2);queue::field(selection,foreign.id);queue::field(selection,p.entry.id);need(queue::write(g,"selection.bin",selection,error),"old queue fixture");std::vector<std::string>ids;need(loadModSelection(g,ids,error)&&ids==std::vector<std::string>{p.entry.id},"old queue IDs from excluded source ignored");
 need(!saveModSelection(g,{foreign},error),"excluded source cannot be saved asnew queue");need(saveModMenuCache(g,{foreign,p.entry},error)&&loadModMenuCache(g,loaded,error)&&loaded.size()==1,"new compact cache contains only console sources");
 const auto resolved=fs::weakly_canonical(sandbox);need(resolved.parent_path()==fs::weakly_canonical(parent)&&resolved.filename().string().rfind("nmm-policy-",0)==0,"safe sandbox cleanup");fs::remove_all(resolved);std::cout<<checks<<" policy integration checks passed\n";
}
