"""The new seed contains only the three documented physical-Switch sources."""
from pathlib import Path
import hashlib
import json
ROOT = Path(__file__).resolve().parents[1]
folder = ROOT / "dist/mods-seed-console"
report = json.loads((folder / "verification.json").read_text())
allowed = {"masagrator/NXGraphicsPatches", "cucholix/NX-IPS-romfs-compilation", "h2y/BOTW-Chinese-Linkle"}
checks = 0
def check(ok):
    global checks
    checks += 1
    if not ok:
        raise AssertionError("physical-console seed")
check(report["physical_switch_sources_only"])
check({r["repository"] for r in report["sources"]} == allowed)
slot = folder / "config/NinMagicMods/mods-a"
check({p.name for p in slot.glob("*.json")} == {r["file"] for r in report["sources"]})
for row in report["sources"]:
    data = (slot / row["file"]).read_bytes()
    check(hashlib.sha256(data).hexdigest() == row["sha256"])
    original = ROOT / "dist/research" / (row["repository"].replace("/", "-") + ".json")
    check(original.read_bytes() == data)
    tree = json.loads(data)
    check(tree["truncated"] is False)
    check(not any("1998p (yuzu only)" in e["path"].lower() for e in tree["tree"]))
print(f"physical-console seed: {checks} source, hash and exclusion checks PASS")
