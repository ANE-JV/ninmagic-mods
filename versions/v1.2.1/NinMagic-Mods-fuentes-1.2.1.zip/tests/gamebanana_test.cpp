#define NM_GAMEBANANA_TEST
#include "../source/gamebanana.cpp"
#include "mod_policy.hpp"
#include <iostream>
#include <stdexcept>
namespace nmm {unsigned queries=0;bool downloadGameBananaHttps(const std::string&,const std::string&,uint64_t,std::string&){++queries;return false;}}
int main(){unsigned checks=0;auto check=[&](bool ok){++checks;if(!ok)throw std::runtime_error("GameBanana physical-console exclusion");};try{
    for(uint64_t id:{0x010015100B514000ULL,0x010093801237C000ULL,0x0100000001110000ULL}){nmm::Game game;game.id=id;game.name="Example";game.version="1.0.0";nmm::ModEntry e;e.name="stale";std::vector<nmm::ModEntry> entries{e};std::string error;
        check(!nmm::loadGameBananaMods(game,entries,error,true)&&entries.empty()&&!error.empty()&&nmm::queries==0);
        check(!nmm::loadGameBananaMods(game,entries,error,false)&&entries.empty()&&nmm::queries==0);
        entries={e};check(!nmm::parseGameBananaMods(game,123,"{}",entries,error)&&entries.empty());
        check(!nmm::parseGameBananaMod(game,123,556710,"{}",e,error)&&e.name.empty()&&!e.compatible&&!nmm::allowsConsoleMod(e));}
    std::cout<<"GameBanana: "<<checks<<" physical-console exclusion and zero-network checks PASS\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
