#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>
#define NMM_PLATFORM_CONTENT_TEST
using u8=uint8_t;using u32=uint32_t;using u64=uint64_t;using s32=int32_t;using s64=int64_t;using Result=uint32_t;
#define R_FAILED(x) ((x)!=0)
constexpr size_t FS_MAX_PATH=0x301;
enum NcmStorageId{NcmStorageId_GameCard=2,NcmStorageId_BuiltInUser=4,NcmStorageId_SdCard=5};
enum {NcmContentInstallType_Full=0,NcmContentType_Program=1};
struct NcmContentId{u8 c[16]{};};
struct NcmContentMetaKey{u64 id=0;u32 version=0;u8 type=0,install_type=0,padding[2]{};};
struct NcmContentInfo{NcmContentId content_id;u32 size_low=0;u8 size_high=0,attr=0,content_type=0,id_offset=0;};
struct NcmContentMetaDatabase{int id=0;};struct NcmContentStorage{int id=0;};
struct Status{u64 id=0;u32 version=0;u8 storage=0,type=0;};
namespace {
constexpr u64 Title=0x010093801237C000ULL;
Status requested{Title^0x800,2,5,0x81};
unsigned checks=0,scenarios=0,dbOpened=0,dbClosed=0,storageOpened=0,storageClosed=0,listCalls=0,hasCalls=0,pathCalls=0,sizeCalls=0;
std::string failAt,pathValue;bool metaPresent=true,contentPresent=true,unterminated=false;int listCountFault=0;s64 physicalSize=1234;std::vector<NcmContentInfo>contents;
void check(bool value,const char*message){++checks;if(!value)throw std::runtime_error(std::string(message)+" [scenario "+std::to_string(scenarios)+"]");}
#define CHECK(x) check((x),#x)
Result code(const char*at){return failAt==at?0x402U:0U;}
NcmContentInfo program(u8 index=0){NcmContentInfo out;std::fill(std::begin(out.content_id.c),std::end(out.content_id.c),u8(index+1));out.content_type=1;out.id_offset=index;out.attr=3;out.size_low=1234;return out;}
void reset(){++scenarios;dbOpened=dbClosed=storageOpened=storageClosed=listCalls=hasCalls=pathCalls=sizeCalls=0;requested={Title^0x800,2,5,0x81};failAt.clear();pathValue="@SdCardContent://registered/program.nca";metaPresent=contentPresent=true;unterminated=false;listCountFault=0;physicalSize=1234;contents={program()};}
void key(const NcmContentMetaKey*k){CHECK(k->id==requested.id&&k->version==requested.version&&k->type==requested.type&&k->install_type==0&&k->padding[0]==0&&k->padding[1]==0);}
void closed(){CHECK(dbOpened==dbClosed&&storageOpened==storageClosed);}
}
void ncmContentInfoSizeToU64(const NcmContentInfo*info,u64*out){*out=(u64(info->size_high)<<32)|info->size_low;}
Result ncmOpenContentMetaDatabase(NcmContentMetaDatabase*db,NcmStorageId storage){CHECK(int(storage)==requested.storage);if(!code("open-db")){db->id=1;++dbOpened;}return code("open-db");}
void ncmContentMetaDatabaseClose(NcmContentMetaDatabase*db){CHECK(db->id==1);db->id=0;++dbClosed;}
Result ncmContentMetaDatabaseHas(NcmContentMetaDatabase*db,bool*out,const NcmContentMetaKey*k){CHECK(db->id==1);key(k);*out=metaPresent;return code("meta-has");}
Result ncmContentMetaDatabaseListContentInfo(NcmContentMetaDatabase*db,s32*out,NcmContentInfo*infos,s32 count,const NcmContentMetaKey*k,s32 offset){CHECK(db->id==1&&count==32&&offset>=0);key(k);++listCalls;if(listCountFault){*out=listCountFault;return 0;}*out=s32(std::min<size_t>(size_t(count),contents.size()-std::min<size_t>(size_t(offset),contents.size())));std::copy_n(contents.begin()+std::min<size_t>(size_t(offset),contents.size()),*out,infos);return code("list");}
Result ncmOpenContentStorage(NcmContentStorage*storage,NcmStorageId id){CHECK(int(id)==requested.storage);if(!code("open-storage")){storage->id=1;++storageOpened;}return code("open-storage");}
void ncmContentStorageClose(NcmContentStorage*storage){CHECK(storage->id==1);storage->id=0;++storageClosed;}
Result ncmContentStorageHas(NcmContentStorage*storage,bool*out,const NcmContentId*){CHECK(storage->id==1);++hasCalls;*out=contentPresent;return code("has");}
Result ncmContentStorageGetSizeFromContentId(NcmContentStorage*storage,s64*out,const NcmContentId*){CHECK(storage->id==1);++sizeCalls;*out=physicalSize;return code("size");}
Result ncmContentStorageGetPath(NcmContentStorage*storage,char*out,size_t size,const NcmContentId*){CHECK(storage->id==1&&size==FS_MAX_PATH);++pathCalls;if(unterminated)std::memset(out,'x',size);else{CHECK(pathValue.size()<size);std::memcpy(out,pathValue.c_str(),pathValue.size()+1);}return code("path");}
#include "platform_content_native.hpp"
int main(){try{using nmm::platform_content_native::readProgramRecord;std::string record,error;
    reset();CHECK(readProgramRecord(requested,record,error)&&error.empty());CHECK(record.find(pathValue)!=record.npos&&record.find(":1234:")!=record.npos);CHECK(hasCalls==1&&pathCalls==1&&sizeCalls==1&&listCalls==2);closed();const auto original=record;
    reset();contents={program(1),program(0)};CHECK(readProgramRecord(requested,record,error));const auto ordered=record;std::swap(contents[0],contents[1]);CHECK(readProgramRecord(requested,record,error)&&ordered==record);closed();
    reset();contents={program(0),program(3)};contents[0].content_type=2;CHECK(readProgramRecord(requested,record,error)&&hasCalls==1&&record.find("\n3:")!=record.npos);closed();
    reset();contents.clear();for(unsigned i=0;i<33;++i)contents.push_back(program(u8(i)));CHECK(readProgramRecord(requested,record,error)&&listCalls==3&&hasCalls==33);closed();
    for(const auto*stage:{"open-db","meta-has","list","open-storage","has","size","path"}){reset();record="stale";failAt=stage;CHECK(!readProgramRecord(requested,record,error)&&record.empty()&&error.find("0x00000402")!=error.npos);closed();}
    reset();metaPresent=false;CHECK(!readProgramRecord(requested,record,error)&&error.find("Full")!=error.npos&&listCalls==0&&storageOpened==0);closed();
    reset();contents.clear();CHECK(!readProgramRecord(requested,record,error)&&error.find("ningún Program")!=error.npos);closed();
    reset();contents.push_back(program(0));CHECK(!readProgramRecord(requested,record,error)&&error.find("duplicado")!=error.npos);closed();
    for(const auto zero:{u8(0),u8(0xFF)}){reset();std::fill(std::begin(contents[0].content_id.c),std::end(contents[0].content_id.c),zero);CHECK(!readProgramRecord(requested,record,error)&&error.find("identidad")!=error.npos);closed();}
    reset();contentPresent=false;CHECK(!readProgramRecord(requested,record,error)&&error.find("falta un Program")!=error.npos&&sizeCalls==0&&pathCalls==0);closed();
    for(const auto wrong:{s64(-1),s64(0),s64(1233),s64(1235)}){reset();physicalSize=wrong;CHECK(!readProgramRecord(requested,record,error)&&error.find("tamaño físico")!=error.npos&&pathCalls==0);closed();}
    reset();contents[0].size_low=0;CHECK(!readProgramRecord(requested,record,error)&&error.find("tamaño válido")!=error.npos);closed();
    reset();contents[0].size_high=1;physicalSize=(s64(1)<<32)+1234;CHECK(readProgramRecord(requested,record,error)&&record.find("4294968530")!=record.npos);closed();
    for(const std::string&invalid:{std::string(),std::string("path\nother"),std::string("path\x7F")}){reset();pathValue=invalid;CHECK(!readProgramRecord(requested,record,error)&&error.find("ruta Program")!=error.npos);closed();}
    reset();unterminated=true;CHECK(!readProgramRecord(requested,record,error)&&error.find("ruta Program")!=error.npos);closed();
    for(int count:{-1,33}){reset();listCountFault=count;CHECK(!readProgramRecord(requested,record,error)&&error.find("inventario")!=error.npos);closed();}
    reset();contents.assign(16385,program());CHECK(!readProgramRecord(requested,record,error)&&error.find("inventario")!=error.npos&&storageOpened==0);closed();
    for(const auto storage:{u8(2),u8(4)}){reset();requested.storage=storage;CHECK(readProgramRecord(requested,record,error)&&record!=original);closed();}
    reset();contents[0].attr++;CHECK(readProgramRecord(requested,record,error)&&record!=original);closed();
    reset();contents[0].content_id.c[0]++;CHECK(readProgramRecord(requested,record,error)&&record!=original);closed();
    std::cout<<"platform native NCM read-only inventory: "<<scenarios<<" scenarios / "<<checks<<" checks PASS\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
