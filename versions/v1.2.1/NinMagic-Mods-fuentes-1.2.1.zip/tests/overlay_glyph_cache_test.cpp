#include "glyph_cache.hpp"
#include <algorithm>
#include <climits>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>
namespace {
std::map<void*,std::size_t>allocations;std::size_t allocated=0,peak=0;unsigned releases=0,checks=0;
void require(bool value,const char*message){++checks;if(!value)throw std::runtime_error(message);}
#define CHECK(x) require((x),#x)
void*allocate(std::size_t bytes,void*){void*p=std::malloc(bytes?bytes:1);if(!p)throw std::bad_alloc();CHECK(allocations.emplace(p,bytes).second);allocated+=bytes;peak=std::max(peak,allocated);return p;}
void release(void*p,void*){if(!p)return;auto at=allocations.find(p);CHECK(at!=allocations.end());allocated-=at->second;allocations.erase(at);std::free(p);++releases;}
}
#define STBTT_malloc(size,userdata) allocate((size),(userdata))
#define STBTT_free(pointer,userdata) release((pointer),(userdata))
#define STB_TRUETYPE_IMPLEMENTATION
#include <stb_truetype.h>
namespace {
struct Glyph{stbtt_fontinfo*currFont=nullptr;float currFontSize=0;int bounds[4]{};int xAdvance=0;unsigned char*glyphBmp=nullptr;int width=0,height=0;};
void freeGlyph(Glyph&glyph,void*userdata){if(glyph.glyphBmp)stbtt_FreeBitmap(glyph.glyphBmp,userdata);glyph.glyphBmp=nullptr;}
using Cache=nmm::overlay::BoundedGlyphCache<Glyph>;
void fill(Glyph*glyph,std::size_t bytes){CHECK(glyph);glyph->glyphBmp=bytes?static_cast<unsigned char*>(allocate(bytes,nullptr)):nullptr;}
}
int main(int argc,char**argv){try{
    {
        nmm::overlay::BoundedGlyphCache<Glyph,2,2048>cache(freeGlyph);const auto fixed=cache.fixedBytes();CHECK(fixed<2048&&cache.retainedBytes()==fixed);
        auto*first=cache.reserve(1,200,nullptr);fill(first,200);auto*second=cache.reserve(2,100,nullptr);fill(second,100);CHECK(cache.entries()==2&&allocated==300&&cache.retainedBytes()==fixed+300);
        const auto before=releases;CHECK(cache.reserve(1,SIZE_MAX,nullptr)==first&&releases==before&&allocated==300);
        CHECK(!cache.reserve(3,cache.bitmapLimit()+1,nullptr)&&cache.find(1)&&cache.find(2)&&releases==before);
        auto*third=cache.reserve(3,250,nullptr);CHECK(third&&releases==before+1&&allocated==100&&cache.entries()==2);fill(third,250);CHECK(cache.retainedBytes()==fixed+350);
        cache.clear();CHECK(allocated==0&&cache.entries()==0&&cache.retainedBytes()==fixed);
        auto*exact=cache.reserve(99,cache.bitmapLimit(),nullptr);fill(exact,cache.bitmapLimit());CHECK(cache.retainedBytes()==2048);
        auto*zero=cache.reserve(100,0,nullptr);CHECK(zero&&cache.retainedBytes()==2048);
        auto*replacement=cache.reserve(101,1,nullptr);CHECK(replacement&&allocated==0);fill(replacement,1);CHECK(cache.retainedBytes()==fixed+1);
    }
    CHECK(allocated==0&&allocations.empty());
    {
        Cache cache(freeGlyph);for(std::uint64_t key=0;key<10000;++key){const auto bytes=std::size_t(key%8192+1);auto*glyph=cache.reserve(key,bytes,nullptr);CHECK(glyph&&cache.retainedBytes()<=128*1024);fill(glyph,bytes);CHECK(allocated+cache.fixedBytes()==cache.retainedBytes());}
        CHECK(cache.entries()<=512);const auto retained=cache.retainedBytes();CHECK(!cache.reserve(10001,SIZE_MAX,nullptr)&&cache.retainedBytes()==retained);
    }
    CHECK(allocated==0&&allocations.empty());
    std::size_t pixels=99;CHECK(nmm::overlay::glyphBitmapBytes(-2,-3,7,9,pixels)&&pixels==108);
    CHECK(nmm::overlay::glyphBitmapBytes(2,3,2,9,pixels)&&pixels==0);
    CHECK(!nmm::overlay::glyphBitmapBytes(7,0,6,1,pixels)&&pixels==0);
    CHECK(!nmm::overlay::glyphBitmapBytes(INT_MIN,0,INT_MAX,1,pixels)&&pixels==0);
    CHECK(!nmm::overlay::glyphBitmapBytes(0,INT_MIN,1,INT_MAX,pixels)&&pixels==0);
    CHECK(nmm::overlay::glyphBitmapBytes(0,0,INT_MAX,INT_MAX,pixels));
    {Cache cache(freeGlyph);CHECK(!cache.reserve(1,pixels,nullptr)&&cache.entries()==0);}
    if(argc==2){
        std::ifstream fontFile(argv[1],std::ios::binary);std::vector<unsigned char>fontBytes(std::istreambuf_iterator<char>(fontFile),{});CHECK(!fontBytes.empty());
        stbtt_fontinfo font{};CHECK(stbtt_InitFont(&font,fontBytes.data(),stbtt_GetFontOffsetForIndex(fontBytes.data(),0)));
        Cache cache(freeGlyph);std::size_t measured=0;
        for(int size:{9,12,16,22,30})for(int codepoint=32;codepoint<2048;++codepoint){
            const auto key=(std::uint64_t(codepoint)<<32)|std::uint64_t(size);if(cache.find(key))continue;
            Glyph metrics{};metrics.currFont=&font;metrics.currFontSize=stbtt_ScaleForPixelHeight(&font,float(size));
            stbtt_GetCodepointBitmapBoxSubpixel(&font,codepoint,metrics.currFontSize,metrics.currFontSize,0,0,&metrics.bounds[0],&metrics.bounds[1],&metrics.bounds[2],&metrics.bounds[3]);
            CHECK(nmm::overlay::glyphBitmapBytes(metrics.bounds[0],metrics.bounds[1],metrics.bounds[2],metrics.bounds[3],pixels));
            auto*glyph=cache.reserve(key,pixels,font.userdata);CHECK(glyph);*glyph=metrics;
            if(pixels){glyph->glyphBmp=stbtt_GetCodepointBitmap(&font,metrics.currFontSize,metrics.currFontSize,codepoint,&glyph->width,&glyph->height,nullptr,nullptr);CHECK(glyph->glyphBmp&&std::size_t(glyph->width)*std::size_t(glyph->height)==pixels);}
            CHECK(cache.retainedBytes()<=128*1024&&allocated+cache.fixedBytes()==cache.retainedBytes());measured=std::max(measured,cache.retainedBytes());
        }
        cache.clear();CHECK(allocated==0&&allocations.empty());std::cout<<"real STB glyph cache max retained="<<measured<<"B (includes fixed index), transient allocator peak="<<peak<<"B\n";
    }
    CHECK(allocated==0&&allocations.empty());std::cout<<checks<<" bounded glyph cache checks PASS; fixed index="<<Cache::fixedBytes()<<"B; bitmap cap="<<Cache::bitmapLimit()<<"B\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
