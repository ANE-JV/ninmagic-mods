#include "mods.hpp"
#include "memory_budget.hpp"
#include <algorithm>
#include <cstdlib>
#include <cstddef>
#include <new>
#include <iostream>
namespace allocation {struct alignas(std::max_align_t) Block{size_t bytes;bool tracked;};bool enabled=false;size_t live=0,peak=0;}
void*operator new(size_t n){auto*b=static_cast<allocation::Block*>(std::malloc(sizeof(allocation::Block)+n));if(!b)throw std::bad_alloc();b->bytes=n;b->tracked=allocation::enabled;if(b->tracked){allocation::live+=n;allocation::peak=std::max(allocation::peak,allocation::live);}return b+1;}
void operator delete(void*p)noexcept{if(!p)return;auto*b=static_cast<allocation::Block*>(p)-1;if(b->tracked)allocation::live-=b->bytes;std::free(b);}
void*operator new[](size_t n){return ::operator new(n);}void operator delete[](void*p)noexcept{::operator delete(p);}void operator delete(void*p,size_t)noexcept{::operator delete(p);}void operator delete[](void*p,size_t)noexcept{::operator delete(p);}
using namespace nmm;unsigned checks=0;size_t largest=0;
void need(bool b,const char*why){++checks;if(!b){std::cerr<<"FAIL "<<why<<'\n';std::exit(1);}}
Game game(){Game g;g.id=0x010093801237C000ULL;g.fullBuildId="646761F643AFEBB3"+std::string(48,'0');g.buildId=g.fullBuildId.substr(0,16);g.buildVerified=true;return g;}
ModEntry entry(){ModEntry m;m.titleId=game().id;m.name="Graphics patch";m.repository="masagrator/NXGraphicsPatches";m.branch="master";m.consoleOnly=true;m.format=ModFormat::Pchtxt;return m;}
std::string header(){return "@nsobid-"+game().fullBuildId+"\n@flag offset_shift 0x100\n@enabled\n";}
void run(const std::string&fixture,bool expected,const char*why){const auto g=game();const auto e=entry();allocation::peak=allocation::live=0;allocation::enabled=true;{std::string input(fixture),error;ModPayload payload;const bool actual=parseModPayload(g,e,input,payload,error);need(actual==expected,why);if(expected)need(validateModIps(payload.ips,error),"output still validated");else need(!payload.compatible&&payload.ips.empty(),"failed parser never authorizes");}allocation::enabled=false;largest=std::max(largest,allocation::peak);need(allocation::live==0,"parser allocations released");need(allocation::peak<512*1024,"full input plus parse stays below512KiB envelope");}
int main(){std::string sparse=header();for(unsigned i=8192;i;--i){char line[32];std::snprintf(line,sizeof(line),"%08X 22\n",0x1000+i*2);sparse+=line;}sparse+="@stop\n";while(sparse.size()<128*1024){const auto n=std::min<size_t>(16000,128*1024-sparse.size());if(n==1)sparse+='\n';else sparse+=std::string(n-1,';')+'\n';}need(sparse.size()==128*1024,"full128KiB input fixture");run(sparse,true,"full input,8KiB sparse descending writes");
 auto block=std::string("00001000 ")+std::string(8192,'2')+"\n00002000 "+std::string(8192,'2')+"\n";auto identical=header()+block+block+"@stop\n";run(identical,true,"identical overlap keepsunique8KiB");
 run(header()+"00001000 1122\n00001001 FF\n@stop\n",false,"conflicting overlap rejected");
 run(header()+"00001000 1122\n@disabled\n00001000 FFFF\n@stop\n",true,"disabled alternative never overrides");
 run(header()+std::string(128*1024,'x'),false,"overlarge input rejected");
 run(header()+std::string(32000,';')+"\n",false,"giant line rejected before a copy");
 run(header()+"# emulator only\n00001000 11\n@stop\n",false,"body emulator declaration rejected");
 run(header()+"# tested only on yuzu\n00001000 11\n@stop\n",false,"body unknown hardware declaration rejected");
 std::cout<<checks<<" parser/budget checks; full_input_peak="<<largest<<" bytes\n";
}
