#pragma once
#include <cstdint>
namespace nmm {
// NCM's formal base/patch relation, not a fuzzy title or version match.
// Callers must compare this result with the independently read ApplicationID.
inline uint64_t canonicalModApplicationId(uint64_t declared){
    if(declared<0x0100000000010000ULL)return 0;
    const auto suffix=declared&0xfff;
    if(suffix==0)return declared;
    return suffix==0x800?declared^uint64_t(0x800):0;
}
inline bool modUsesUpdateTitleId(uint64_t declared){return (declared&0xfff)==0x800&&canonicalModApplicationId(declared)!=0;}
}
