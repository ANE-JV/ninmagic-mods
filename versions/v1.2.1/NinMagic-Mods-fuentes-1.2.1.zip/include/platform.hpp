#pragma once
#include "model.hpp"
namespace nmm {
bool platformInit(Environment&,std::string&error);
void platformExit();
bool scanGames(std::vector<Game>&,Environment&,std::string&error);
// Captures installed resource identity and, when available, the full Build ID.
// A true result for a closed title can be resource-only; inspect buildVerified.
bool resolveBuild(Game&,Environment&,std::string&error);
// Read-only current-game identity for an overlay; never attaches to the cheat service.
// True means the real running program's full Build ID was verified. NS metadata is optional.
bool resolveRunningGame(Game&,Environment&,std::string&error);
// Static executable patches are only scheduled on SD for the next launch.
// This proves the exact live process and rereads its full module Build ID.
bool validateRunningGame(const Game&expected,std::string&error);
// Resources use a declared game version plus a fresh installed NCM identity;
// this deliberately makes no claim about an unavailable closed-game Build ID.
bool validateClosedResources(const Game&expected,std::string&error);
// Must obtain a fresh effective content/version/build and prove the title is closed.
bool validateClosedGame(const Game&expected,std::string&error);
}
