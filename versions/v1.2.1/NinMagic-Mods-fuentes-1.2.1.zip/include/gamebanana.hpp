#pragma once
#include "model.hpp"
namespace nmm {
// Discovery metadata only. Unknown game version/Build ID never enables install.
// Requests are per selected game, bounded, and privately cached for six hours.
bool loadGameBananaMods(const Game&,std::vector<ModEntry>&,std::string&error,bool force=false);
// Bounded pure parsers also used with captured, real provider responses in tests.
bool parseGameBananaMods(const Game&,uint64_t gameBananaId,const std::string&,std::vector<ModEntry>&,std::string&error);
bool parseGameBananaMod(const Game&,uint64_t gameBananaId,uint64_t modId,const std::string&,ModEntry&,std::string&error);
}
