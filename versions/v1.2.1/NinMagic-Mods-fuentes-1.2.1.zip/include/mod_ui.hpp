#pragma once
#include "model.hpp"
#include "mod_policy.hpp"
namespace nmm {
inline std::vector<size_t> visibleMods(const View&v){std::vector<size_t> out;for(size_t i=0;i<v.mods.size();++i)if(allowsConsoleMod(v.mods[i])&&(!v.filter||v.mods[i].compatible))out.push_back(i);return out;}
inline unsigned selectedMods(const View&v){unsigned n=0;for(const auto&m:v.mods)n+=m.selected&&allowsConsoleMod(m);return n;}
inline bool canMarkMod(const ModEntry&m){return m.compatible&&allowsConsoleMod(m);}
}
