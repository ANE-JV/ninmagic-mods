#pragma once
#include "model.hpp"
namespace nmm {
// A selection is a request for a new NRO review, never installation authority.
// Title, content version, display version and fresh NCM contentIdentity must match.
// A present full BID is compared; IDs alone never authorize applying code.
bool saveModSelection(const Game&,const std::vector<ModEntry>&,std::string&error);
bool loadModSelection(const Game&,std::vector<std::string>&ids,std::string&error);
bool clearModSelection(const Game&,std::string&error);
// Compact, bounded menu only. No payloads, RomFS files or install receipts are cached.
bool saveModMenuCache(const Game&,const std::vector<ModEntry>&,std::string&error);
bool loadModMenuCache(const Game&,std::vector<ModEntry>&,std::string&error);
}
