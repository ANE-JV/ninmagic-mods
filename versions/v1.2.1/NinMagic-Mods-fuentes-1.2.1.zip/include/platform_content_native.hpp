#pragma once
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <set>
#include <string>
#include <vector>
#ifndef NMM_PLATFORM_CONTENT_TEST
#include <switch.h>
#endif

namespace nmm::platform_content_native {
inline std::string resultText(Result result){char out[16];std::snprintf(out,sizeof(out),"0x%08lX",static_cast<unsigned long>(result));return out;}
inline bool fail(std::string&error,const char*stage,Result result){error=std::string("NCM/")+stage+" "+resultText(result);return false;}
inline std::string contentId(const NcmContentId&id){static constexpr char hex[]="0123456789abcdef";std::string out;for(auto b:id.c){out+=hex[b>>4];out+=hex[b&15];}return out;}
// Exact Full CNMT key and every Program content, including secondary indices.
// The path is data returned by NCM, never opened or used for writes here.
template<class Status>
bool readProgramRecord(const Status&status,std::string&record,std::string&error){
    record.clear();error.clear();NcmContentMetaDatabase db{};NcmContentStorage storage{};
    auto result=ncmOpenContentMetaDatabase(&db,static_cast<NcmStorageId>(status.storage));
    if(R_FAILED(result))return fail(error,"abrir metadatos",result);
    struct CloseDb{NcmContentMetaDatabase*p;~CloseDb(){ncmContentMetaDatabaseClose(p);}}closeDb{&db};
    NcmContentMetaKey key{};key.id=status.id;key.version=status.version;key.type=status.type;key.install_type=NcmContentInstallType_Full;
    bool has=false;result=ncmContentMetaDatabaseHas(&db,&has,&key);
    if(R_FAILED(result))return fail(error,"comprobar clave Full",result);
    if(!has){error="NCM: falta la clave Full exacta de un contenido instalado.";return false;}
    std::vector<NcmContentInfo> programs;size_t total=0;
    for(s32 offset=0;;){
        NcmContentInfo infos[32]{};s32 written=0;
        result=ncmContentMetaDatabaseListContentInfo(&db,&written,infos,32,&key,offset);
        if(R_FAILED(result))return fail(error,"listar contenido",result);
        if(written<0||written>32||total+size_t(written)>16384){error="NCM devolvió un inventario de contenido incompleto o excesivo.";return false;}
        if(!written)break;
        total+=size_t(written);offset+=written;
        for(s32 i=0;i<written;++i)if(infos[i].content_type==NcmContentType_Program)programs.push_back(infos[i]);
    }
    if(programs.empty()){error="NCM: la clave Full no contiene ningún Program verificable.";return false;}
    std::sort(programs.begin(),programs.end(),[](const auto&a,const auto&b){return a.id_offset<b.id_offset;});
    result=ncmOpenContentStorage(&storage,static_cast<NcmStorageId>(status.storage));
    if(R_FAILED(result))return fail(error,"abrir almacenamiento",result);
    struct CloseStorage{NcmContentStorage*p;~CloseStorage(){ncmContentStorageClose(p);}}closeStorage{&storage};
    std::string value=std::to_string(status.id)+":"+std::to_string(status.version)+":"+std::to_string(status.type)+":"+std::to_string(status.storage)+":0\n";
    std::set<unsigned> indices;
    for(const auto&program:programs){
        const auto cid=contentId(program.content_id);u64 expectedSize=0;ncmContentInfoSizeToU64(&program,&expectedSize);
        if(!indices.insert(program.id_offset).second||cid==std::string(32,'0')||cid==std::string(32,'f')||!expectedSize){error="NCM devolvió Program duplicado o sin identidad/tamaño válido.";return false;}
        has=false;result=ncmContentStorageHas(&storage,&has,&program.content_id);
        if(R_FAILED(result))return fail(error,"presencia Program",result);
        if(!has){error="NCM: falta un Program referenciado por la clave Full.";return false;}
        s64 actualSize=0;result=ncmContentStorageGetSizeFromContentId(&storage,&actualSize,&program.content_id);
        if(R_FAILED(result))return fail(error,"tamaño Program",result);
        if(actualSize<=0||u64(actualSize)!=expectedSize){error="NCM: el tamaño físico Program no coincide con sus metadatos.";return false;}
        std::array<char,FS_MAX_PATH>path{};result=ncmContentStorageGetPath(&storage,path.data(),path.size(),&program.content_id);
        if(R_FAILED(result))return fail(error,"ruta Program",result);
        const auto end=std::find(path.begin(),path.end(),'\0');
        if(end==path.begin()||end==path.end()||std::any_of(path.begin(),end,[](unsigned char c){return c<32||c==127;})){error="NCM devolvió una ruta Program no válida.";return false;}
        const std::string location(path.begin(),end);
        value+=std::to_string(program.id_offset)+":"+cid+":"+std::to_string(program.attr)+":"+std::to_string(expectedSize)+":"+std::to_string(location.size())+":"+location+"\n";
    }
    record=std::move(value);return true;
}
}
