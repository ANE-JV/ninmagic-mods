#pragma once
#include "model.hpp"
#include <cctype>
namespace nmm {
inline std::string modLabelKey(const ModEntry&m){std::string s=m.name;for(char&c:s)c=char(std::tolower(static_cast<unsigned char>(c)));return s;}
inline std::string modEffectName(const ModEntry&m){
    const auto s=modLabelKey(m);
    if(s.find("disable bloom")!=s.npos||s.find("disablebloom")!=s.npos)return "Quitar resplandor de luces";
    if(s.find("disable dof")!=s.npos||s.find("disable depth")!=s.npos)return "Quitar desenfoque de profundidad";
    if(s.find("disable motion blur")!=s.npos||s.find("disablemotionblur")!=s.npos)return "Quitar desenfoque de movimiento";
    if(s.find("disable dynamic resolution")!=s.npos)return "Desactivar resolución dinámica";
    if(s.find("hood down")!=s.npos)return "Bajar la capucha de Zelda";
    for(const char *rate:{"120","60","30"})if(s.find(std::string(rate)+"fps")!=s.npos||s.find(std::string(rate)+" fps")!=s.npos)return std::string("Objetivo de ")+rate+" FPS";
    for(const char *pixels:{"2160","1440","1080","1008","900","720","540","480"})if(s.find(std::string(pixels)+"p")!=s.npos)return std::string("Resolución ")+pixels+"p";
    if(s.find("graphics mod")!=s.npos||s.find("graphic mod")!=s.npos)return "Paquete de ajustes gráficos";
    return {};
}
inline std::string modDisplayName(const ModEntry&m){
    auto label=modEffectName(m);if(label.empty())return m.name;const auto raw=modLabelKey(m);
    for(size_t i=0;i+1<raw.size();++i)if(raw[i]=='v'&&(i==0||!std::isalnum(static_cast<unsigned char>(raw[i-1])))&&std::isdigit(static_cast<unsigned char>(raw[i+1]))){size_t end=i+1;while(end<raw.size()&&std::isdigit(static_cast<unsigned char>(raw[end])))++end;if(end-i<=3&&(end==raw.size()||raw[end]==' '||raw[end]=='/'||raw[end]=='_')){label+=" (V"+raw.substr(i+1,end-i-1)+")";break;}}
    if(!m.version.empty())label+=" / "+m.version;
    return label;
}
inline std::string modExplanation(const ModEntry&m){
    const auto effect=modEffectName(m);
    if(effect=="Quitar resplandor de luces")return "Desactiva el brillo difuso alrededor de luces y zonas luminosas (Bloom).";
    if(effect=="Quitar desenfoque de profundidad")return "Desactiva el desenfoque de elementos que quedan fuera de foco (Depth of Field).";
    if(effect=="Quitar desenfoque de movimiento")return "Desactiva el efecto de borrosidad al mover la cámara o al desplazarte (Motion Blur).";
    if(effect=="Desactivar resolución dinámica")return "Evita que la resolución se ajuste automáticamente. Consulta la resolución y los requisitos que indica el autor.";
    if(effect=="Bajar la capucha de Zelda")return "Cambia el aspecto de la capucha de Zelda. Conserva los demás requisitos del parche.";
    if(effect.find("Objetivo de ")==0)return "Cambia el objetivo de imágenes por segundo. No garantiza que la consola alcance esa velocidad; algunos juegos o mods requieren ajustes adicionales.";
    if(effect.find("Resolución ")==0)return "Cambia la resolución de renderizado. Una resolución mayor puede exigir más rendimiento. Consulta si el autor lo preparó para consola o emulador.";
    if(effect=="Paquete de ajustes gráficos")return "Agrupa varios cambios visuales. El nombre por sí solo no permite saber cuáles; revisa la descripción original y los requisitos.";
    if(m.gbModId&&m.category=="Personajes")return "Sustituye o modifica un personaje. La descripción del autor indica a quién reemplaza y qué variantes incluye.";
    if(m.gbModId&&m.category=="Ropa")return "Modifica la apariencia o vestimenta de un personaje. Revisa a quién afecta y sus requisitos.";
    return "No hay una explicación verificada en español para este nombre. Conservamos el original; revisa la descripción y el enlace del autor antes de decidir.";
}
}
