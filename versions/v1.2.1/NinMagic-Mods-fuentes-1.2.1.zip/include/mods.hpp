#pragma once
#include "model.hpp"
#include "mod_policy.hpp"
#include "mod_identity.hpp"
namespace nmm {
bool loadModsCatalog(ModsCatalog&,std::string&error);
bool syncModsCatalog(ModsCatalog&,std::string&error,bool force=false);
bool refreshModsCatalog(ModsCatalog&,bool force,std::string&error);
bool parseModsTree(const std::string&,ModsCatalog&,std::string&error,const std::string&repository);
std::vector<ModEntry> findMods(const Game&,const ModsCatalog&);
bool resolveGameMods(const Game&,std::vector<ModEntry>&,std::string&error);
// Overlay discovery reads/releases one bounded source at a time. Only small,
// fully verified static patches can become compatible; model packs use the NRO.
bool loadOverlayMods(const Game&,std::vector<ModEntry>&,std::string&error,bool force=false);
bool prepareMod(const Game&,const ModEntry&,ModPayload&,std::string&error);
bool parseModPayload(const Game&,const ModEntry&,const std::string&,ModPayload&,std::string&error);
bool validateModIps(const std::vector<uint8_t>&,std::string&error);
bool combineMods(const Game&,const std::vector<ModPayload>&,ModPayload&,std::string&error);
}
