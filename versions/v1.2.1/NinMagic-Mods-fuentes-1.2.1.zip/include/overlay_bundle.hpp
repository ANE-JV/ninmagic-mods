#pragma once
#include <string>
namespace nmm {
// Copies only this application's embedded, verified OVL. Retains numbered backups.
// Call with RomFS mounted. Does not install/configure an overlay loader.
bool ensureBundledOverlay(std::string &detail);
}
