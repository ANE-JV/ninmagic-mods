#pragma once
#include "model.hpp"
namespace nmm {bool uiInit(const std::string&);void uiDraw(uint32_t*,int,const View&);void uiExit();}
