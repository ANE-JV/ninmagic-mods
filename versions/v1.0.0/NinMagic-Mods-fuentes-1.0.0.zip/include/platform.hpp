#pragma once
#include "model.hpp"
namespace nmm {
bool platformInit(Environment&,std::string&error);
void platformExit();
bool scanGames(std::vector<Game>&,Environment&,std::string&error);
bool resolveBuild(Game&,Environment&,std::string&error);
// Must obtain a fresh effective content/version/build and prove the title is closed.
bool validateClosedGame(const Game&expected,std::string&error);
}
