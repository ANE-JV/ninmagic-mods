#pragma once
#include <string>
#include <cstdint>
namespace nmm {
// Downloads only the updater-owned manifest/download temporary paths. HTTPS,
// certificate/host validation and bounded bodies remain mandatory.
bool downloadHttpsFile(const std::string &url,const std::string &path,std::string &error);
// Catalog trees and content-addressed mod payloads only; cannot target games.
bool downloadModHttps(const std::string &url,const std::string &path,uint64_t maximum,std::string &error);
// Call only after the updater worker has ended.
void updateNetworkExit();
}
