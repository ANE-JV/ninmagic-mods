"""Package the checked NinMagic Mods app, catalogue indexes and sources."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import zipfile
from verify_nro import verify
ROOT=Path(__file__).resolve().parent.parent
VERSION="1.0.0"
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def checked_zip(path,payload,refresh):
    if not path.exists() and not refresh:
        with zipfile.ZipFile(path,"x",compression=zipfile.ZIP_DEFLATED)as z:
            for name,data in sorted(payload.items()):z.writestr(name,data)
    with zipfile.ZipFile(path)as z:
        if z.testzip()is not None or len(z.namelist())!=len(payload)or set(z.namelist())!=set(payload):raise ValueError("ZIP CRC/inventory mismatch")
        for name,data in payload.items():
            if z.read(name)!=data:raise ValueError("Versioned ZIP differs: "+name)
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--refresh-report",action="store_true");args=p.parse_args();dist=ROOT/"dist"
    nro=dist/"NinMagic-Mods.nro";report=verify(nro,expected_version=VERSION)
    sources={}
    for folder in("source","include","tests","assets","romfs","third_party"):
        for path in(ROOT/folder).rglob("*"):
            if not path.is_file()or"__pycache__"in path.parts:continue
            if path.is_symlink():raise ValueError("Source link refused")
            if path.suffix.lower()in{".exe",".o",".elf",".nro",".nacp",".pyc",".ppm"}:continue
            sources[path.relative_to(ROOT).as_posix()]=path.read_bytes()
    for name in("README.md","Makefile","tools/build.ps1","tools/verify_nro.py","tools/publish_update.py","tools/package.py","tools/preview.cpp","tools/fetch_mods.py","docs/sources.md","docs/logo-generation.json"):
        sources[name]=(ROOT/name).read_bytes()
    source_zip=dist/f"NinMagic-Mods-fuentes-{VERSION}.zip";checked_zip(source_zip,sources,args.refresh_report)
    channel="https://raw.githubusercontent.com/ANE-JV/ninmagic-mods/main/update.txt"
    if channel not in(ROOT/"include/app_update.hpp").read_text(encoding="utf-8"):raise ValueError("Unexpected app update channel")
    payload={"switch/NinMagicMods/NinMagic-Mods.nro":nro.read_bytes(),"switch/NinMagicMods/LEEME.txt":(ROOT/"README.md").read_bytes(),"switch/NinMagicMods/Fuentes.txt":(ROOT/"docs/sources.md").read_bytes(),"config/NinMagicMods/update-url.txt":(channel+"\n").encode("ascii"),"fuentes/"+source_zip.name:source_zip.read_bytes()}
    for path in(ROOT/"third_party").glob("*-LICENSE.txt"):payload["switch/NinMagicMods/licencias/"+path.name]=path.read_bytes()
    seed=dist/"mods-seed/config/NinMagicMods"
    allowed={"mods-active.txt","mods-check.txt","mods-a/complete.txt"}
    seed_report=json.loads((dist/"mods-seed/verification.json").read_text(encoding="utf-8"))
    for row in seed_report["sources"]:
        name="mods-a/"+row["file"];path=seed/name
        if sha(path)!=row["sha256"]or path.stat().st_size!=row["bytes"]:raise ValueError("Seed differs from audited source")
        allowed.add(name)
    for name in allowed:payload["config/NinMagicMods/"+name]=(seed/name).read_bytes()
    package=dist/f"NinMagic-Mods-{VERSION}.zip";checked_zip(package,payload,args.refresh_report)
    report.update({"package":{"file":package.name,"bytes":package.stat().st_size,"sha256":sha(package),"entries":len(payload)},"sources":{"file":source_zip.name,"sha256":sha(source_zip),"files":len(sources)},"catalog":seed_report,"official_update_manifest":channel,"console_runtime_tested":False,"game_effects_tested":False,"console_installation":"not_transferred","public_channel_published":False})
    report["host_reports"]={}
    for name in("platform-verification-1.0.0.json","app-update-verification-1.0.0.json","ui-preview-verification-1.0.0.json","mods-catalog-verification.json","mods-install-verification.json","mods-integration-review.json","package-peer-1.0.0.json"):
        f=dist/name
        if f.is_file():report["host_reports"][name]=json.loads(f.read_text(encoding="utf-8-sig"))
    f=dist/"public-channel-check-1.0.0.json"
    if f.is_file():
        public=json.loads(f.read_text(encoding="utf-8"));report["public_channel_published"]=bool(public.get("passed")and public.get("nro",{}).get("sha256")==report["sha256"])
    validation=dist/"VERIFICACION.json";validation.write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    desktop=Path.home()/"Desktop"/f"NinMagic-Mods-{VERSION}";desktop.mkdir(exist_ok=True)
    for path in(nro,package,source_zip,validation):
        shutil.copy2(path,desktop/path.name)
        if sha(path)!=sha(desktop/path.name):raise ValueError("Desktop copy mismatch")
    for name,target in(("README.md","LEEME.txt"),("docs/sources.md","Fuentes.txt"),("assets/ninmagic-mods-neon.png","Logo-MODS.png")):shutil.copy2(ROOT/name,desktop/target)
    print(json.dumps({"desktop":str(desktop),"nro_sha256":report["sha256"],"zip_sha256":sha(package),"entries":len(payload),"public_channel_published":report["public_channel_published"]}))
if __name__=="__main__":main()
