#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include "gamebanana.hpp"
#include "mod_policy.hpp"
#include "update_network.hpp"
#include "gamebanana_md5.hpp"
#include "mod_hash.hpp"
#include <algorithm>
#include <array>
#include <cerrno>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <map>
#include <set>
#include <sys/stat.h>
#include <unistd.h>

namespace nmm {
namespace gb {
#ifdef NMM_OVERLAY
constexpr size_t MaxJson=96*1024,MaxNodes=1600,MaxPages=9,QueryPerPage=5;
#else
constexpr size_t MaxJson=512*1024,MaxNodes=12000,MaxPages=6,QueryPerPage=15;
#endif
constexpr size_t PerPage=15,MaxEntries=128;
constexpr uint64_t MaxArchive=128ULL*1024*1024;
struct Json {char kind=0;std::string text;std::map<std::string,Json> object;std::vector<Json> array;};
class Parser {
    const std::string &s;size_t p=0,nodes=0;
    // Ignore display media and account decorations before retaining the DOM.
    // Their JSON is still syntax/depth/node checked; overlays retain only mod metadata.
    static bool kept(const std::string &key){static const char *keys[]={"_aRecords","_aMetadata","_nRecordCount","_bIsComplete","_nPerpage","_idRow","_sName","_sModelName","_sProfileUrl","_aGame","_aSubmitter","_aRootCategory","_aSubCategory","_aCategory","_sVersion","_sText","_bIsTrashed","_bIsObsolete","_bIsWithheld","_aFiles","_sFile","_sDescription","_aAnalysisWarnings","contains_exe","_nFilesize","_sDownloadUrl","_sMd5Checksum","_bIsArchived","_bHasFiles"};for(auto k:keys)if(key==k)return true;return false;}
    void ws(){while(p<s.size()&&(s[p]==' '||s[p]=='\n'||s[p]=='\r'||s[p]=='\t'))++p;}
    bool chr(char c){ws();if(p==s.size()||s[p]!=c)return false;++p;return true;}
    bool code(uint32_t &v){v=0;for(unsigned i=0;i<4;++i){if(p==s.size())return false;unsigned char c=s[p++];if(!std::isxdigit(c))return false;v=(v<<4)|(c<='9'?c-'0':std::tolower(c)-'a'+10);}return true;}
    static void utf(std::string &v,uint32_t c){if(c<128)v+=char(c);else if(c<2048){v+=char(0xc0|(c>>6));v+=char(0x80|(c&63));}else if(c<65536){v+=char(0xe0|(c>>12));v+=char(0x80|((c>>6)&63));v+=char(0x80|(c&63));}else{v+=char(0xf0|(c>>18));v+=char(0x80|((c>>12)&63));v+=char(0x80|((c>>6)&63));v+=char(0x80|(c&63));}}
    bool string(std::string &v){v.clear();if(!chr('"'))return false;while(p<s.size()){unsigned char c=s[p++];if(c=='"')return true;if(c<32)return false;if(c!='\\')v+=char(c);else{if(p==s.size())return false;char e=s[p++];if(e=='"'||e=='/'||e=='\\')v+=e;else if(e=='b')v+='\b';else if(e=='f')v+='\f';else if(e=='n')v+='\n';else if(e=='r')v+='\r';else if(e=='t')v+='\t';else if(e=='u'){uint32_t a=0;if(!code(a))return false;if(a>=0xd800&&a<=0xdbff){if(s.compare(p,2,"\\u"))return false;p+=2;uint32_t b=0;if(!code(b)||b<0xdc00||b>0xdfff)return false;a=0x10000+((a-0xd800)<<10)+(b-0xdc00);}else if(a>=0xdc00&&a<=0xdfff)return false;utf(v,a);}else return false;}if(v.size()>32768)return false;}return false;}
    bool value(Json &v,unsigned depth,bool keep=true){if(depth>24||++nodes>MaxNodes)return false;ws();if(p==s.size())return false;const char c=s[p];v.kind=c;if(c=='"')return string(v.text);
        if(c=='{'){++p;if(chr('}'))return true;do{std::string key;if(!string(key)||key.size()>256||!chr(':')||v.object.count(key))return false;Json item;const bool child=keep&&kept(key);if(!value(item,depth+1,child))return false;if(child)v.object.emplace(std::move(key),std::move(item));if(chr('}'))return true;}while(chr(','));return false;}
        if(c=='['){++p;if(chr(']'))return true;do{if(v.array.size()>=1024)return false;Json item;if(!value(item,depth+1,keep))return false;if(keep)v.array.push_back(std::move(item));if(chr(']'))return true;}while(chr(','));return false;}
        for(const char *literal:{"true","false","null"}){const size_t n=std::char_traits<char>::length(literal);if(s.compare(p,n,literal)==0){v.text=literal;p+=n;return true;}}
        v.kind='n';const size_t begin=p;if(s[p]=='-')++p;if(p==s.size()||s[p]<'0'||s[p]>'9')return false;if(s[p]=='0')++p;else while(p<s.size()&&s[p]>='0'&&s[p]<='9')++p;
        if(p<s.size()&&s[p]=='.'){++p;const auto start=p;while(p<s.size()&&s[p]>='0'&&s[p]<='9')++p;if(p==start)return false;}
        if(p<s.size()&&(s[p]=='e'||s[p]=='E')){++p;if(p<s.size()&&(s[p]=='+'||s[p]=='-'))++p;const auto start=p;while(p<s.size()&&s[p]>='0'&&s[p]<='9')++p;if(p==start)return false;}
        v.text=s.substr(begin,p-begin);return v.text.size()<=40;
    }
public:explicit Parser(const std::string &input):s(input){}bool parse(Json &v){if(s.empty()||s.size()>MaxJson||!value(v,0))return false;ws();return p==s.size()&&(v.kind=='{'||v.kind=='[');}
};
const Json &field(const Json &v,const char *key){static const Json none;auto i=v.object.find(key);return i==v.object.end()?none:i->second;}
std::string text(const Json &v,const char *key,size_t maximum=256){const auto &x=field(v,key);return x.kind=='"'&&x.text.size()<=maximum?x.text:std::string{};}
uint64_t number(const Json &v,const char *key){const auto &x=field(v,key);if(x.kind!='n'||x.text.empty()||x.text.size()>12||x.text.find_first_not_of("0123456789")!=std::string::npos)return 0;uint64_t n=0;for(char c:x.text)n=n*10+unsigned(c-'0');return n;}
bool yes(const Json &v,const char *key){return field(v,key).text=="true";}
std::string normalized(std::string s){const std::string suffix=" (Switch)";if(s.size()>suffix.size()&&s.compare(s.size()-suffix.size(),suffix.size(),suffix)==0)s.resize(s.size()-suffix.size());std::string out;for(unsigned char c:s){if(c>=128)out+=char(c);else if(std::isalnum(c))out+=char(std::tolower(c));}return out;}
struct Mapping {uint64_t title,id;const char *name;};
// Reviewed Switch-exclusive identities, not guessed from a similar title.
const Mapping Known[]={
 {0x010015100B514000ULL,18604,"Super Mario Bros. Wonder"},
 {0x010093801237C000ULL,14275,"Metroid Dread"},
 {0x0100F2C0115B6000ULL,7617,"The Legend of Zelda: Tears of the Kingdom"}
};
const Mapping *known(uint64_t title){for(const auto &v:Known)if(v.title==title)return &v;return nullptr;}
bool validGame(const Game &game,uint64_t id,const std::string &name){if(game.id<0x0100000000010000ULL||!id||id>999999999)return false;if(const auto *k=known(game.id))return k->id==id&&normalized(k->name)==normalized(name);const auto expected=normalized(game.name),actual=normalized(name);return !expected.empty()&&!actual.empty()&&name.size()>9&&name.compare(name.size()-9,9," (Switch)")==0&&actual==expected;}
std::string clean(const std::string &input,size_t maximum){std::string out;bool tag=false,space=false;for(unsigned char c:input){if(c=='<'){tag=true;space=true;continue;}if(c=='>'){tag=false;continue;}if(tag)continue;if(c<=32||c==127){space=true;continue;}if(space&&!out.empty())out+=' ';space=false;out+=char(c);if(out.size()>=maximum)break;}return out;}
std::string category(const Json &v){std::string s=normalized(text(field(v,"_aRootCategory"),"_sName")+" "+text(field(v,"_aSubCategory"),"_sName")+" "+text(v,"_sName"));if(s.find("character")!=s.npos||s.find("skin")!=s.npos||s.find("model")!=s.npos)return "Personajes";if(s.find("costume")!=s.npos||s.find("outfit")!=s.npos||s.find("cloth")!=s.npos)return "Ropa";if(s.find("fps")!=s.npos||s.find("framerate")!=s.npos)return "FPS";return "Gráficos";}
bool archiveName(const std::string &name){if(name.empty()||name.size()>180||name=="."||name==".."||name.find_first_of("/\\:")!=name.npos||std::any_of(name.begin(),name.end(),[](unsigned char c){return c<32||c==127;}))return false;std::string lower=name;std::transform(lower.begin(),lower.end(),lower.begin(),[](unsigned char c){return char(std::tolower(c));});return lower.size()>4&&(lower.compare(lower.size()-4,4,".zip")==0||lower.compare(lower.size()-4,4,".rar")==0);}
std::string lower(std::string text){std::transform(text.begin(),text.end(),text.begin(),[](unsigned char c){return char(std::tolower(c));});return text;}
bool pcToolFile(const std::string&name,const std::string&description,const Json&file){
    const auto filename=text(file,"_sFile");const auto fileDescription=clean(text(file,"_sDescription",32768),32768);
    if(declaresPcModBuilder(name,description+" "+fileDescription,filename))return true;
    if(pcBuilderFilename(filename)){
        const auto&executables=field(field(file,"_aAnalysisWarnings"),"contains_exe");
        if(executables.kind=='[')for(const auto&item:executables.array){const auto path=lower(item.text);if(item.kind=='"'&&path.size()>4&&path.compare(path.size()-4,4,".exe")==0)return true;}
    }
    return false;
}
bool pcToolPublication(const Json&v){
    const auto name=text(v,"_sName"),description=clean(text(v,"_sText",32768),32768);
    if(declaresPcModBuilder(name,description))return true;
    bool tool=false;const auto&files=field(v,"_aFiles");
    if(files.kind=='[')for(const auto&f:files.array){if(yes(f,"_bIsArchived")||!archiveName(text(f,"_sFile")))continue;if(!pcToolFile(name,description,f))return false;tool=true;}
    return tool;
}
std::string gameVersion(const std::string &description){
    // _sVersion is the release of the MOD. A number is accepted only immediately
    // after a statement explicitly describing the GAME's supported version.
    const auto s=lower(description);std::set<std::string> versions;
    for(const char *label:{"game version:","game version ","game version =","version del juego:","versión del juego:","supported game version:","requires game version ","requires game v"}){
        size_t pos=0;while((pos=s.find(label,pos))!=std::string::npos){const auto clause=s.find_last_of(".;!",pos);const auto before=" "+s.substr(clause==s.npos?0:clause+1,pos-(clause==s.npos?0:clause+1));const bool negated=before.find(" not ")!=before.npos||before.find(" incompatible ")!=before.npos||before.find(" unsupported ")!=before.npos||before.find(" except ")!=before.npos;pos+=std::char_traits<char>::length(label);if(negated)continue;while(pos<s.size()&&(s[pos]==' '||s[pos]=='v'))++pos;const auto begin=pos;while(pos<s.size()&&((s[pos]>='0'&&s[pos]<='9')||s[pos]=='.'))++pos;auto value=s.substr(begin,pos-begin);if(value.size()>1&&value.back()=='.'&&value[value.size()-2]!='.'){value.pop_back();--pos;}unsigned dots=unsigned(std::count(value.begin(),value.end(),'.'));
            if(value.size()>=3&&value.size()<=20&&dots>=1&&dots<=3&&value.front()!='.'&&value.back()!='.'&&value.find("..")==value.npos){
                auto tail=s.substr(pos,12);if(tail.rfind(" -",0)==0||tail.rfind("-",0)==0||tail.rfind(" and",0)==0||tail.rfind(" or",0)==0||tail.rfind(",",0)==0||tail.rfind("+",0)==0||tail.rfind(" to ",0)==0||tail.rfind(" /",0)==0||tail.rfind("/",0)==0||tail.rfind(" &",0)==0)return {};
                versions.insert(value);
            }
        }
    }
    return versions.size()==1?*versions.begin():std::string{};
}
std::string physicalEvidence(const Game &game,const std::string &description){
    const auto s=lower(description),tid=lower(titleId(game.id));
    if(hasUnknownConsoleProvenance(description)||isEmulatorOnlyText(description))return {};
    auto affirmative=[&](size_t at){const auto clause=s.find_last_of(".;!",at);const auto start=clause==s.npos?(at>120?at-120:0):clause+1;const auto before=" "+s.substr(start,at-start);for(const char *word:{" not "," never "," don't "," do not "," haven't "," hasn't "," untested "," no "})if(before.find(word)!=before.npos)return false;return true;};
    const auto installation=s.find("atmosphere/contents/"+tid);
    if(installation!=s.npos&&affirmative(installation)){const auto before=s.substr(installation>120?installation-120:0,std::min(installation,size_t(120)));for(const char *word:{"copy ","extract ","place ","install "})if(before.find(word)!=before.npos)return "El autor indica atmosphere/contents/"+titleId(game.id)+" para instalar en Switch.";}
    for(const char *phrase:{"tested on real hardware","tested on switch hardware","works on real hardware","works on a real switch","tested on a real switch","tested on physical switch","compatible with real switch"}){const auto at=s.find(phrase);if(at!=s.npos&&affirmative(at))return "Destino Switch física declarado por el autor: "+std::string(phrase)+".";}
    return {};
}
bool record(const Game &game,uint64_t gameId,uint64_t expected,const Json &v,ModEntry &out,std::string &error,uint64_t expectedFile=0){
    const auto &remote=field(v,"_aGame");const auto id=expected?expected:number(v,"_idRow");const auto name=text(v,"_sName");
    const auto profile="https://gamebanana.com/mods/"+std::to_string(id);
    if(!id||id>999999999||(expected&&number(v,"_idRow")&&number(v,"_idRow")!=expected)||name.empty()||number(remote,"_idRow")!=gameId||!validGame(game,gameId,text(remote,"_sName"))||text(v,"_sProfileUrl")!=profile){error="GameBanana devolvió un mod de otro juego o una identidad sin verificar.";return false;}
    if(yes(v,"_bIsTrashed")||yes(v,"_bIsObsolete")||yes(v,"_bIsWithheld")){error="El autor ha retirado o marcado obsoleto este mod.";return false;}
    const auto model=text(v,"_sModelName");if(!model.empty()&&model!="Mod"){error="GameBanana devolvió un tipo de publicación distinto de Mod.";return false;}
    if(pcToolPublication(v)){error="El autor publica una herramienta para PC que genera el mod a partir de archivos del juego, no un mod instalable en Switch; se excluye.";return false;}
    out={};out.titleId=game.id;out.gbGameId=gameId;out.gbModId=id;out.id="GameBanana|"+std::to_string(id);out.name=clean(name,192);out.source=out.repository="GameBanana";out.sourceUrl=profile;out.category=category(v);out.author=clean(text(field(v,"_aSubmitter"),"_sName"),128);out.modVersion=clean(text(v,"_sVersion",64),64);
    out.format=ModFormat::Archive;out.reason="Elige el archivo y prepara su instalación. Compatibilidad sin verificar.";
    out.detail="GameBanana · "+out.author+(out.modVersion.empty()?"":" · versión del mod "+out.modVersion)+". "+clean(text(v,"_sText",32768),900);
    const std::string description=clean(text(v,"_sText",32768),32768);
    if(isEmulatorOnlyText(name+"\n"+description)){error="El autor declara este mod exclusivamente para emulador; se excluye.";return false;}
    out.version=gameVersion(description);
    out.consoleEvidence=physicalEvidence(game,description);
    out.consoleOnly=!out.consoleEvidence.empty();
    // Keep a negative platform declaration even when its original location is
    // beyond the short UI summary. Archive contents may not override it.
    if(hasUnknownConsoleProvenance(description))out.detail+=" El autor indica hardware Switch sin comprobar.";
    const auto &files=field(v,"_aFiles");if(files.kind=='['){
        if(files.array.size()>32){error="La ficha supera el límite de archivos de GameBanana.";return false;}
        unsigned accepted=0;std::set<uint64_t> fileIds;
        for(const auto &f:files.array){const auto fileId=number(f,"_idRow"),size=number(f,"_nFilesize");const auto filename=text(f,"_sFile");const auto url=text(f,"_sDownloadUrl",2048);auto md5=text(f,"_sMd5Checksum",32);std::transform(md5.begin(),md5.end(),md5.begin(),[](unsigned char c){return char(std::tolower(c));});
            if(yes(f,"_bIsArchived")||!fileId||fileId>999999999||!size||size>MaxArchive||!archiveName(filename)||url!="https://gamebanana.com/dl/"+std::to_string(fileId)||md5.size()!=32||md5.find_first_not_of("0123456789abcdef")!=md5.npos)continue;
            if(isEmulatorOnlyText(filename)||pcToolFile(name,description,f))continue;
            if(!fileIds.insert(fileId).second){error="La ficha repite una identidad de archivo; no se elegirá una variante ambigua.";return false;}
            ++accepted;if(expectedFile&&fileId!=expectedFile)continue;
            if(!expectedFile&&accepted>1)continue;
            out.fileName=out.path=filename;out.size=size;out.downloadUrl=url;out.gbFileId=fileId;out.gbFileMd5=md5;
        }
        if(!expectedFile&&accepted>1){out.gbFileId=0;out.size=0;out.fileName.clear();out.path.clear();out.downloadUrl.clear();out.gbFileMd5.clear();out.reason="La ficha contiene "+std::to_string(accepted)+" ZIP/RAR. Elige la variante antes de prepararla.";}
        if(expectedFile&&!out.gbFileId){error="La variante seleccionada ya no está disponible o no supera los controles del proveedor.";return false;}
        if(!accepted){out.format=ModFormat::Unsupported;out.reason="El autor no publica un ZIP/RAR verificable de hasta 128 MiB; consulta su ficha.";}
    }
    if(out.gbFileId){
        out.id+="|"+std::to_string(out.gbFileId);
        // The complete author declaration is immutable for an inspected entry.
        // Use length-delimited fields so HTML/text changes, removed requirements,
        // and provenance corrections cannot reuse an old installation approval.
        mod_hash::Sha256 requirements;
        const auto add=[&](const std::string &value){const auto length=std::to_string(value.size())+":";requirements.add(reinterpret_cast<const uint8_t*>(length.data()),length.size());requirements.add(reinterpret_cast<const uint8_t*>(value.data()),value.size());};
        add("NMM-GB-REQUIREMENTS-1");add(titleId(game.id));add(std::to_string(gameId));add(std::to_string(id));add(name);add(text(remote,"_sName"));add(text(v,"_sText",32768));add(text(v,"_sVersion",64));add(text(field(v,"_aSubmitter"),"_sName"));add(std::to_string(number(field(v,"_aSubmitter"),"_idRow")));add(text(field(v,"_aRootCategory"),"_sName"));add(text(field(v,"_aCategory"),"_sName"));add(std::to_string(out.gbFileId));add(out.fileName);add(out.downloadUrl);add(std::to_string(out.size));add(out.gbFileMd5);
        out.gbRequirementsHash=requirements.finish();
    }
    if(!out.fileName.empty())out.detail+=" Archivo: "+out.fileName+" ("+std::to_string(out.size)+" bytes).";
    if(!out.version.empty())out.detail+=" Versión de juego declarada por el autor: "+out.version+".";
    if(!out.consoleEvidence.empty())out.detail+=" "+out.consoleEvidence;
    out.detail+=" La versión del mod no es la versión del juego. "+profile;return true;
}
bool parse(const std::string &data,Json &j,std::string &error){if(!Parser(data).parse(j)){error="Respuesta JSON de GameBanana inválida o demasiado grande.";return false;}return true;}
std::string root(){
#ifdef NM_GAMEBANANA_TEST
 const char *s=std::getenv("NM_GAMEBANANA_ROOT");return s?s:"gamebanana-test";
#else
 return "sdmc:/config/NinMagicMods/gamebanana";
#endif
}
bool directory(const std::string &path,bool make,std::string &error){struct stat st{};if(lstat(path.c_str(),&st)!=0){if(errno!=ENOENT||!make){error="No se puede leer la caché privada de GameBanana.";return false;}
#ifdef _WIN32
 if(mkdir(path.c_str())!=0){error="No se pudo crear la caché privada de GameBanana.";return false;}
#else
 if(mkdir(path.c_str(),0777)!=0){error="No se pudo crear la caché privada de GameBanana.";return false;}
#endif
 if(lstat(path.c_str(),&st)!=0)return false;}if(!S_ISDIR(st.st_mode)||S_ISLNK(st.st_mode)){error="La caché de GameBanana no es un directorio normal.";return false;}return true;}
bool regular(const std::string &p){struct stat st{};return lstat(p.c_str(),&st)==0&&S_ISREG(st.st_mode)&&!S_ISLNK(st.st_mode)&&st.st_size>0&&uint64_t(st.st_size)<=MaxJson;}
bool read(const std::string &p,std::string &out){if(!regular(p))return false;FILE*f=fopen(p.c_str(),"rb");if(!f)return false;out.clear();std::array<char,8192> b{};size_t n;bool ok=true;while((n=fread(b.data(),1,b.size(),f))){if(out.size()+n>MaxJson){ok=false;break;}out.append(b.data(),n);}if(ferror(f))ok=false;if(fclose(f)!=0)ok=false;return ok;}
bool cacheRoot(std::string &error){
#ifndef NM_GAMEBANANA_TEST
 for(const char *p:{"sdmc:/config","sdmc:/config/NinMagicMods"})if(!directory(p,true,error))return false;
#endif
 return directory(root(),true,error);
}
std::string encoded(const std::string &s){std::string out;const char*h="0123456789ABCDEF";for(unsigned char c:s){if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='-'||c=='_'||c=='.'||c=='~')out+=char(c);else{out+='%';out+=h[c>>4];out+=h[c&15];}}return out;}
bool fresh(const std::string &path){struct stat st{};const auto now=std::time(nullptr);return lstat(path.c_str(),&st)==0&&now>=st.st_mtime&&now-st.st_mtime<6*60*60;}
template<typename Validate>bool request(const std::string &url,const std::string &name,bool force,std::string &data,bool &cached,std::string &error,Validate valid){
    const auto target=root()+"/"+name,pending=target+".pending",previous=target+".previous";std::string saved,why;const bool have=read(target,saved)&&valid(saved,why);
    if(have&&!force&&fresh(target)){data=std::move(saved);cached=true;return true;}
    std::string{}.swap(saved); // do not hold two full JSON documents during validation
    std::string received;bool downloaded=downloadGameBananaHttps(url,pending,MaxJson,why)&&read(pending,received)&&valid(received,why);
    if(downloaded){struct stat st{};bool prior=lstat(target.c_str(),&st)==0;
        if(prior&&!regular(target)){why="El archivo de caché no es regular.";downloaded=false;}
        if(downloaded&&lstat(previous.c_str(),&st)==0&&(!regular(previous)||unlink(previous.c_str())!=0)){why="No se pudo conservar la caché anterior.";downloaded=false;}
        if(downloaded&&prior&&rename(target.c_str(),previous.c_str())!=0){why="No se pudo conservar la caché anterior.";downloaded=false;}
        if(downloaded&&rename(pending.c_str(),target.c_str())!=0){if(prior)rename(previous.c_str(),target.c_str());why="No se pudo activar la caché de GameBanana.";downloaded=false;}
        if(downloaded){if(prior)unlink(previous.c_str());data=std::move(received);return true;}
    }
    if(regular(pending))unlink(pending.c_str());
    if(have&&read(target,saved)&&valid(saved,why)){data=std::move(saved);cached=true;error="GameBanana no respondió; se conserva la copia guardada. "+why;return true;}
    error="No se pudo consultar GameBanana. "+why;return false;
}
bool identify(const Game &game,const std::string &data,uint64_t &id,std::string &error){Json j;if(!parse(data,j,error))return false;const auto &records=field(j,"_aRecords");if(records.kind!='['||records.array.size()>20){error="La búsqueda de juego de GameBanana no es válida.";return false;}std::set<uint64_t> ids;
    for(const auto &r:records.array){const auto n=number(r,"_idRow");if(validGame(game,n,text(r,"_sName"))&&text(r,"_sProfileUrl")=="https://gamebanana.com/games/"+std::to_string(n))ids.insert(n);}
    if(ids.size()!=1){error="GameBanana no confirma exactamente este juego para Switch; no se usarán coincidencias parecidas.";return false;}id=*ids.begin();return true;}
}
bool parseGameBananaMods(const Game &game,uint64_t id,const std::string &data,std::vector<ModEntry> &out,std::string &error){
    error.clear();gb::Json j;if(!gb::parse(data,j,error))return false;const bool batch=j.kind=='[';const auto &records=batch?j:gb::field(j,"_aRecords"),&meta=gb::field(j,"_aMetadata");if(records.kind!='['||records.array.size()>gb::PerPage||(!batch&&(meta.kind!='{'||gb::field(meta,"_nRecordCount").kind!='n'||gb::field(meta,"_nPerpage").kind!='n'||!gb::number(meta,"_nPerpage")||gb::number(meta,"_nPerpage")>gb::PerPage||gb::number(meta,"_nRecordCount")>100000000))){error="La página de GameBanana supera los límites o no es un índice válido.";return false;}
    std::vector<ModEntry> result;std::set<uint64_t> ids;for(const auto &r:records.array){if(gb::yes(r,"_bIsTrashed")||gb::yes(r,"_bIsObsolete")||gb::yes(r,"_bIsWithheld")||isEmulatorOnlyText(gb::text(r,"_sName")+"\n"+gb::text(r,"_sText",32768))||gb::pcToolPublication(r))continue;ModEntry item;if(!gb::record(game,id,0,r,item,error)||!ids.insert(item.gbModId).second)return false;
        // Batch v6 omits the mod release field returned by v11. List parent
        // publications, then resolve their exact file/requirements via the same
        // canonical v11 detail endpoint used at preparation. Never fingerprint
        // a partially projected batch as if it were that complete file record.
        if(batch&&item.format==ModFormat::Archive){item.id="GameBanana|"+std::to_string(item.gbModId);item.gbFileId=item.size=0;item.path.clear();item.fileName.clear();item.downloadUrl.clear();item.gbFileMd5.clear();item.gbRequirementsHash.clear();}
        result.push_back(std::move(item));}out=std::move(result);return true;
}
bool parseGameBananaMod(const Game &game,uint64_t id,uint64_t mod,const std::string &data,ModEntry &out,std::string &error){error.clear();gb::Json j;ModEntry next;if(!gb::parse(data,j,error)||!gb::record(game,id,mod,j,next,error))return false;out=std::move(next);return true;}
bool loadGameBananaMods(const Game &game,std::vector<ModEntry> &out,std::string &error,bool force){
    out.clear();error.clear();if(game.id<0x0100000000010000ULL||game.name.empty()||game.name.size()>256){error="El juego no tiene una identidad válida para consultar GameBanana.";return false;}if(!gb::cacheRoot(error))return false;
    const auto tid=titleId(game.id);uint64_t id=0;std::string data,why;bool cached=false;
    if(const auto*k=gb::known(game.id))id=k->id;
    else{if(!gb::request("https://gamebanana.com/apiv11/Util/Game/NameMatch?_sName="+gb::encoded(game.name),tid+"-game.json",force,data,cached,why,[&](const std::string&s,std::string&e){return gb::identify(game,s,id,e);})||!gb::identify(game,data,id,error)){if(error.empty())error=why;return false;}if(!why.empty())error=why;}
    // Include the independently identified character mod even beyond the page cap.
    if(game.id==0x010015100B514000ULL){ModEntry featured;why.clear();if(gb::request("https://gamebanana.com/apiv11/Mod/556710?_csvProperties=_idRow,_sName,_sProfileUrl,_sVersion,_aGame,_aSubmitter,_aRootCategory,_aCategory,_aFiles,_sText,_bIsTrashed,_bIsObsolete,_bIsWithheld",tid+"-featured.json",force,data,cached,why,[&](const std::string&s,std::string&e){gb::Json json;if(!gb::parse(s,json,e))return false;const auto&remote=gb::field(json,"_aGame");return gb::number(json,"_idRow")==556710&&gb::number(remote,"_idRow")==id&&gb::validGame(game,id,gb::text(remote,"_sName"))&&gb::text(json,"_sProfileUrl")=="https://gamebanana.com/mods/556710";})){const auto warning=why;if(parseGameBananaMod(game,id,556710,data,featured,why))out.push_back(std::move(featured));if(why.empty())why=warning;}if(!why.empty())error=why;}
    std::set<uint64_t> seen;for(const auto&e:out)seen.insert(e.gbModId);bool gotPage=false;
    for(size_t page=1;page<=gb::MaxPages;++page){std::string{}.swap(data);std::vector<ModEntry> entries;why.clear();const auto url="https://gamebanana.com/apiv6/Mod/ByGame?_aGameRowIds%5B%5D="+std::to_string(id)+"&_nPerpage="+std::to_string(gb::QueryPerPage)+"&_nPage="+std::to_string(page)+"&_csvProperties="+GameBananaBatchProperties;
        // A separate cache generation prevents old Index summaries (which omit
        // author text/files) from hiding the distinction between a mod and a PC tool.
        if(!gb::request(url,tid+"-mods"+std::to_string(gb::QueryPerPage)+"-page"+std::to_string(page)+".json",force,data,cached,why,[&](const std::string&s,std::string&e){return parseGameBananaMods(game,id,s,entries,e);})){if(error.empty())error=why;break;}
        const auto warning=why;if(!parseGameBananaMods(game,id,data,entries,why)){error=why;break;}gotPage=true;if(!warning.empty())error=warning;for(auto&e:entries)if(seen.insert(e.gbModId).second&&out.size()<gb::MaxEntries)out.push_back(std::move(e));
        gb::Json j;std::string ignored;if(!gb::parse(data,j,ignored))break;if(j.kind=='['){if(j.array.size()<gb::QueryPerPage)break;}else{const auto&meta=gb::field(j,"_aMetadata");if(gb::yes(meta,"_bIsComplete")||gb::field(j,"_aRecords").array.size()<gb::QueryPerPage||gb::number(meta,"_nRecordCount")<=page*gb::QueryPerPage)break;}
    }
    if(cached&&!out.empty())for(auto&e:out)e.detail+=" Metadatos guardados; actualizar vuelve a comprobar la fuente.";
    if(out.size()>=gb::MaxPages*gb::QueryPerPage)for(auto&e:out)e.detail+=" Consulta acotada a "+std::to_string(gb::MaxPages*gb::QueryPerPage)+" publicaciones por juego; la ficha enlaza la fuente completa.";
    if(!gotPage&&out.empty()){if(error.empty())error="GameBanana no devolvió un índice verificado; no significa que el juego carezca de mods.";return false;}return true;
}
bool parseGameBananaModFiles(const Game &game,uint64_t gameId,uint64_t modId,const std::string &data,std::vector<ModEntry> &out,std::string &error){
    out.clear();error.clear();gb::Json json;if(!gb::parse(data,json,error))return false;ModEntry parent;if(!gb::record(game,gameId,modId,json,parent,error))return false;
    const auto &files=gb::field(json,"_aFiles");if(files.kind!='['){error="La ficha no contiene archivos descargables.";return false;}
    std::vector<ModEntry> result;std::set<uint64_t> seen;
    for(const auto &file:files.array){const auto id=gb::number(file,"_idRow");if(!id||!seen.insert(id).second)continue;ModEntry next;std::string ignored;
        if(gb::record(game,gameId,modId,json,next,ignored,id)&&next.gbFileId==id&&next.format==ModFormat::Archive){next.name+=" · "+next.fileName;result.push_back(std::move(next));}}
    if(result.empty()){error=parent.reason.empty()?"No hay ZIP/RAR activos y verificables de hasta 128 MiB.":parent.reason;return false;}out=std::move(result);return true;
}
bool loadGameBananaModFiles(const Game &game,const ModEntry &entry,std::vector<ModEntry> &out,std::string &error,bool force){
    out.clear();error.clear();if(!gameBananaIdentity(entry)||entry.titleId!=game.id||!entry.gbModId||entry.gbModId>999999999||!entry.gbGameId||entry.gbGameId>999999999){error="Identidad de GameBanana no válida para este juego.";return false;}
    if(!gb::cacheRoot(error))return false;
    const auto url="https://gamebanana.com/apiv11/Mod/"+std::to_string(entry.gbModId)+"?_csvProperties=_idRow,_sName,_sProfileUrl,_sVersion,_aGame,_aSubmitter,_aRootCategory,_aCategory,_aFiles,_sText,_bIsTrashed,_bIsObsolete,_bIsWithheld";
    std::string data;bool cached=false;std::vector<ModEntry> next;
    // A valid withdrawal or an empty file list must replace stale metadata.
    // Only transport/malformed-envelope failures may fall back to the old cache.
    if(!gb::request(url,titleId(game.id)+"-mod"+std::to_string(entry.gbModId)+".json",force,data,cached,error,[&](const std::string &s,std::string &e){gb::Json json;if(!gb::parse(s,json,e))return false;const auto &remote=gb::field(json,"_aGame");return gb::number(json,"_idRow")==entry.gbModId&&gb::number(remote,"_idRow")==entry.gbGameId&&gb::validGame(game,entry.gbGameId,gb::text(remote,"_sName"))&&gb::text(json,"_sProfileUrl")==entry.sourceUrl;}))return false;
    const auto warning=error;if(!parseGameBananaModFiles(game,entry.gbGameId,entry.gbModId,data,next,error))return false;if(error.empty())error=warning;
    if(cached)for(auto &item:next)item.detail+=" Metadatos guardados; la huella del archivo se comprobará antes de preparar.";
    out=std::move(next);return true;
}
bool refreshGameBananaMod(const Game &game,ModEntry &entry,std::string &error,bool force){
    std::vector<ModEntry> files;if(!loadGameBananaModFiles(game,entry,files,error,force))return false;
    auto selected=files.end();if(entry.gbFileId)selected=std::find_if(files.begin(),files.end(),[&](const ModEntry &candidate){return candidate.gbFileId==entry.gbFileId;});else if(files.size()==1)selected=files.begin();
    if(selected==files.end()){error=entry.gbFileId?"La variante seleccionada ya no está disponible. Actualiza la lista.":"Elige uno de los ZIP/RAR publicados antes de preparar; no se seleccionará una variante automáticamente.";return false;}
    if(entry.gbFileId&&(selected->gbFileMd5!=entry.gbFileMd5||selected->size!=entry.size||selected->fileName!=entry.fileName||selected->downloadUrl!=entry.downloadUrl)){error="El archivo del autor cambió desde la consulta. Actualiza la lista y vuelve a seleccionarlo.";return false;}
    if(entry.archiveInspected&&(entry.gbRequirementsHash.size()!=64||entry.gbRequirementsHash!=selected->gbRequirementsHash)){error="El autor cambió los requisitos o la procedencia del mod. Vuelve a seleccionarlo antes de instalar.";return false;}
    entry=std::move(*selected);return true;
}
namespace gb {
#ifndef NMM_OVERLAY
bool archiveMatches(const std::string &path,const ModEntry &entry){
    struct stat st{};if(lstat(path.c_str(),&st)!=0||!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode)||st.st_size<=0||uint64_t(st.st_size)!=entry.size||entry.size>MaxArchive)return false;
    FILE *file=fopen(path.c_str(),"rb");if(!file)return false;
    Md5 hash;std::array<uint8_t,16384> buffer{};uint64_t count=0;bool magic=false;size_t n=0;
    while((n=fread(buffer.data(),1,buffer.size(),file))){
        if(!count){const auto name=lower(entry.fileName);const bool zip=n>=4&&buffer[0]=='P'&&buffer[1]=='K'&&((buffer[2]==3&&buffer[3]==4)||(buffer[2]==5&&buffer[3]==6)||(buffer[2]==7&&buffer[3]==8));const bool rar=n>=7&&std::memcmp(buffer.data(),"Rar!\x1a\x07",6)==0&&(buffer[6]==0||(n>=8&&buffer[6]==1&&buffer[7]==0));magic=name.size()>4&&(name.compare(name.size()-4,4,".zip")==0?zip:rar);}
        count+=n;if(count>entry.size)break;hash.add(buffer.data(),n);
    }
    bool ok=magic&&count==entry.size&&!ferror(file)&&hash.finish()==entry.gbFileMd5;if(fclose(file)!=0)ok=false;return ok;
}
#endif
}
bool obtainGameBananaArchive(const Game &game,const ModEntry &entry,std::string &path,std::string &error){
    path.clear();error.clear();
#ifdef NMM_OVERLAY
    (void)game;(void)entry;error="Abre NinMagic Mods para inspeccionar y descargar paquetes ZIP/RAR.";return false;
#else
    if(!gameBananaIdentity(entry)||entry.titleId!=game.id||!entry.gbFileId||!gb::archiveName(entry.fileName)||entry.gbFileMd5.size()!=32||entry.gbFileMd5.find_first_not_of("0123456789abcdef")!=entry.gbFileMd5.npos){error="Primero consulta e inspecciona la ficha actual de GameBanana.";return false;}
    ModEntry checked=entry;if(!refreshGameBananaMod(game,checked,error,true))return false;
    if(entry.gbRequirementsHash.size()!=64||checked.gbRequirementsHash!=entry.gbRequirementsHash){error="La ficha del autor cambió desde la revisión. Actualiza sus requisitos y vuelve a inspeccionarla.";return false;}
    if(!canInspectConsoleArchive(checked)){error="El autor no ofrece un paquete admitido para Switch física.";return false;}
    const auto target=gb::root()+"/"+titleId(game.id)+"-"+std::to_string(entry.gbModId)+"-"+std::to_string(entry.gbFileId)+"-"+entry.gbFileMd5+".archive";
    if(gb::archiveMatches(target,entry)){path=target;return true;}
    const auto pending=target+".pending";
    if(!downloadGameBananaArchiveHttps(entry.downloadUrl,pending,entry.size,error))return false;
    if(!gb::archiveMatches(pending,entry)){struct stat st{};if(lstat(pending.c_str(),&st)==0&&S_ISREG(st.st_mode)&&!S_ISLNK(st.st_mode))unlink(pending.c_str());error="El ZIP/RAR descargado no coincide con su tamaño, formato o checksum publicado.";return false;}
    struct stat st{};if(lstat(target.c_str(),&st)==0&&(!S_ISREG(st.st_mode)||S_ISLNK(st.st_mode))){error="La caché del paquete no es un archivo normal.";return false;}
    if(rename(pending.c_str(),target.c_str())!=0){error="No se pudo guardar el paquete comprobado; no se ha instalado nada.";return false;}
    path=target;return true;
#endif
}

}
